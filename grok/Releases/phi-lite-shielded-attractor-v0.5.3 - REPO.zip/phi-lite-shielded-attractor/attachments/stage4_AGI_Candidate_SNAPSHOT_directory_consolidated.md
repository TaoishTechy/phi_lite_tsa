# Directory Consolidation Report

**Directory:** `/Stage4AGI`

**Generated:** 2026-09-21 08:22:17

**Excluded extensions/patterns:**
- `.7z`
- `.ai`
- `.app`
- `.avi`
- `.bin`
- `.bmp`
- `.bz2`
- `.db`
- `.dll`
- `.dmg`
- `.doc`
- `.docx`
- `.dylib`
- `.eps`
- `.exe`
- `.flv`
- `.gif`
- `.git`
- `.gitignore`
- `.gz`
- ... and 36 more

==================================================


### File: `stage4-update.patch`

**Path:** `./stage4-update.patch`
**Extension:** `.patch`
**Size:** 198,380 bytes (193.73 KB)

*Binary file - text/x-diff*

----------------------------------------

## Directory: `stage4`


### File: `README.md`

**Path:** `stage4/README.md`
**Extension:** `.md`
**Size:** 11,844 bytes (11.57 KB)

**Content:**

# stage4 — Stage 4 AGI *Candidate* Research Scaffold

**Version:** 4.0.0-candidate · **Honesty framing:** this repository is a
**Stage 4 candidate research scaffold**, not AGI. The current honest stage
estimate is tracked in [STAGE.md](STAGE.md). Stage 5 (AGI) is explicitly out
of scope. See [docs/FALSIFICATION.md](docs/FALSIFICATION.md) for the criteria
that would kill the program.

> Progress = (Honest measurement × Iteration) / Hype.
> Maximize the numerator. Keep the denominator near zero.
> — Blueprint, closing section

## What this is

This repo fuses four source documents into one properly structured research
scaffold:

1. **IrreversibleAgency v7.1** (base code) — emergence debt, painful
   commitments, stagnation scars, controlled criticality, SPEL, DDMS, CCF, NBC.
   A 700-line stochastic dynamical system with interesting conceptual hooks and
   144 documented shortcomings.
2. **Stage 4 Science-Grade Blueprint** — a 7-layer hierarchical predictive
   agent with falsifiable stage criteria, a real evaluation protocol, a
   mathematical safety architecture, and an honest roadmap.
3. **Levantine 48-point patch (L1–L48)** — neurocognitive axes (precision /
   boundary / temporal), archaic priors, Markov blankets, hysteresis, and
   alignment firewalls.
4. **GhostMesh 48-point patch (G1–G48)** — 49-sector recursive geometry, a
   quantum observer layer, holographic/spacetime layers, a 2024–26 signal
   layer, and a 48-node seed mesh.
5. **144-equation design ledger (Eq 1–144)** — every equation mapped to a host
   module.

All 144 audit points, all 96 patch points, and all 144 equations are mapped to
modules in [docs/PATCH_INTEGRATION.md](docs/PATCH_INTEGRATION.md) and
[docs/EQUATION_LEDGER.md](docs/EQUATION_LEDGER.md). Traceability is structural:
each skeleton module docstring cites the audit IDs, patch IDs, and equation IDs
it addresses.

## What this is NOT (Blueprint Part 9)

- **Not AGI.** Stage 4 candidate at most. S5 is not claimed.
- **Not implemented (mostly).** Most of this deliverable is a *skeleton +
  docs*: typed signatures, full docstrings, and stub bodies
  (`raise NotImplementedError("spec: ...")`). Fully implemented today:
  `stage4/config.py`, `stage4/core/types.py`, and the **scalar agency core**
  (`core/state.py`, `core/modes.py`, `core/energy.py`, `core/loop.py`,
  `agency/emergence.py`, `agency/criticality.py`, `agency/commitments.py`,
  `agency/scars.py`, `eval/report.py`, `main.py`) — a real, deterministic,
  runnable dynamical system. The tensor layers L1–L7 remain stubs.
- **Not fast.** The blueprint estimates 10 months minimum, realistically 2
  years, to a measured Stage 4 claim.
- **Not cheap.** 4 GPUs minimum for the real training program.
- **Not certain.** Estimated probability of reaching measured S4: 20–40%.

## Architecture (7 layers)

```
┌─────────────────────────────────────────────────────────────┐
│ L7  Meta-Controller      : selects goals, horizons, options │
├─────────────────────────────────────────────────────────────┤
│ L6  Self-Model           : predicts own future states/acts  │
├─────────────────────────────────────────────────────────────┤
│ L5  World Model          : latent dynamics p(z'|z,a)        │
├─────────────────────────────────────────────────────────────┤
│ L4  Memory               : episodic + semantic retrieval    │
├─────────────────────────────────────────────────────────────┤
│ L3  Policy (hierarchical): options, primitive actions       │
├─────────────────────────────────────────────────────────────┤
│ L2  Perception           : encoders, real sensors           │
├─────────────────────────────────────────────────────────────┤
│ L1  Sensors/Actuators    : camera, mic, speaker, GPIO?      │
└─────────────────────────────────────────────────────────────┘
```

Interfaces are contracts: every layer exchanges `LayerIO(state, uncertainty,
cost, meta)`. **Nothing crosses layers without uncertainty attached** — this is
the single property whose absence made v7.1's layers lie to each other.
Full treatment: [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md).

## Repository layout

```
stage4/
├── README.md  STAGE.md  plan.md  SPEC.md  pyproject.toml
├── docs/ ARCHITECTURE.md BACKEND.md FALSIFICATION.md ROADMAP.md
│        PATCH_INTEGRATION.md EQUATION_LEDGER.md
├── phitensor/ __init__.py tensor.py ops.py autograd.py rng.py io.py kernels.py
├── stage4/
│   ├── __init__.py  config.py [DONE]
│   ├── core/    __init__.py types.py [DONE] state.py modes.py loop.py energy.py
│   ├── perception/ __init__.py vision_encoder.py audio_encoder.py fusion.py sensors.py
│   ├── world_model/ __init__.py rssm.py loss.py causal.py
│   ├── self_model/ __init__.py predictor.py calibration.py spel.py
│   ├── memory/ __init__.py episodic.py semantic.py crystal.py narrative.py ledger.py
│   ├── policy/ __init__.py primitives.py options.py selection.py hierarchical.py
│   ├── meta/ __init__.py goal_gen.py maml.py controller.py
│   ├── agency/ __init__.py emergence.py commitments.py scars.py criticality.py
│   ├── neuro/ __init__.py axes.py priors.py blankets.py hysteresis.py alignment.py
│   ├── geometry/ __init__.py sectors.py fractals.py lsystem.py chaos.py
│   ├── quantum/ __init__.py observer.py entanglement.py holography.py spacetime.py signals.py
│   ├── mesh/ __init__.py node.py observer.py metrics.py reweave.py
│   ├── safety/ __init__.py cbf.py shield.py invariants.py consent.py audit.py
│   ├── eval/ __init__.py heldout.py transfer.py benchmarks.py report.py
│   └── main.py
└── tests/ test_skeleton.py
```

- `phitensor/` — the custom tensor backend (no third-party numerical
  dependencies; see `docs/BACKEND.md`).
- `stage4/core/types.py` — pinned contracts: `SystemMode`, `CommitmentLevel`,
  `LayerIO`, `Layer`/`Falsifiable` protocols, `GoalSpec`, `Commitment`, `Scar`.
- `stage4/config.py` — validated, deep-merged, seedable configuration
  (fixes audit #13–24).

## Quickstart

```bash
pip install -e .          # or just run from the repo root; no deps needed
python -m stage4.main     # 200-cycle scalar-core run (deterministic, seed 49)
```

The scalar agency core (neurocognitive axes, DDMS modes, energy/collapse,
emergence debt, criticality, commitments, scars, SPEL-lite, prediction
game) is genuinely runnable. The L1–L7 tensor layers remain stubs, so the
output is honestly labeled. Real output of `python -m stage4.main`:

```
==============================================================================
SCALAR CORE RUN — layers L2/L5/L6/L7 stubbed; NOT a Stage 4 evaluation
==============================================================================
config: seed=49 budget=150.0 cycles=200
run: completed=200 alive=True
------------------------------------------------------------------------------
metric                                value
------------------------------------------------------------------------------
emergence_level                    1.000000
emergence_debt                     0.000379
energy                            23.682901
permanent_damage                   0.819000
collapses                                 6
scars                                    17
commitment_changes                       18
meta_cognition                     0.306582
phase_transitions                         1
landauer_total                    10.397208
------------------------------------------------------------------------------
commitment_levels: endogamy=VOLATILE, primary_goal=VOLATILE, strategy=FIXED, world_model=FIXED
------------------------------------------------------------------------------
mode distribution:
  consolidate                  113 ( 56.5%)
  exploit                       58 ( 29.0%)
  present_locked                24 ( 12.0%)
  explore                        5 (  2.5%)
------------------------------------------------------------------------------
stage_estimate: S2.9 (S2.9 heritage floor — scalar core only; the full eval
  protocol (held-out tasks, transfer, ECE, safety over 10^6 cycles) never ran,
  so no stage upgrade is claimed or possible from this run.)
kill_criteria: none fired
==============================================================================
```

CLI: `--cycles N` (default 200), `--seed S` (bit-exact reruns), `--config
PATH` (JSON overrides, deep-merged and validated), `--eval-only` (honest
eval-protocol status). Exit codes: 0 clean run, 2 if a kill criterion fires
(core falsification regression or premature death — the system can really
die; longer horizons usually kill it), 1 on error. Run the test suite with:

```bash
python -m unittest discover -s tests -v
```

No third-party dependencies are required: `phitensor` is our own backend
and everything else is stdlib (Python >= 3.10).

## Honesty section

- **Where we are:** the heritage system (Φ-Lite / IrreversibleAgency v7.1) is
  a Stage 2.9 scaffold. This repository is the *structure* of a Stage 4
  candidate, not the substance. STAGE.md states this in numbers.
- **What would change our mind:** the kill criteria in
  [docs/FALSIFICATION.md](docs/FALSIFICATION.md). If any fails, the Stage 4
  claim must be retracted.
- **What we will not do:** claim a stage upgrade without a new metrics window
  (Blueprint Part 10, rule 6); hide failure modes (all seven are documented);
  or present speculative components (quantum observer, holographic memory,
  seed mesh) as established science. The Levantine and GhostMesh patches are
  design metaphors made testable, not physics claims.
- **Metrics before narrative.** Every module exposes a falsification test.
  A module whose test cannot fail is decorative and will be removed.

## Documentation map

| File | Contents |
|---|---|
| [STAGE.md](STAGE.md) | Current honest stage estimate and upgrade policy |
| [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md) | 7 layers, interfaces, losses, falsifiable tests, learning loops, data flow |
| [docs/FALSIFICATION.md](docs/FALSIFICATION.md) | Stage ladder, Stage 4 properties, metrics, kill criteria, failure modes |
| [docs/ROADMAP.md](docs/ROADMAP.md) | Milestones M1–M7, compute reality, Monday-morning plan, probability estimates |
| [docs/PATCH_INTEGRATION.md](docs/PATCH_INTEGRATION.md) | All 144 audit points + 48 Levantine + 48 GhostMesh points mapped to modules |
| [docs/EQUATION_LEDGER.md](docs/EQUATION_LEDGER.md) | All 144 equations with host modules and roles |
| [docs/BACKEND.md](docs/BACKEND.md) | `phitensor` tensor backend design |
| [SPEC.md](SPEC.md) | Single source of truth: contracts, canonical tree, authoritative mappings |
| [plan.md](plan.md) | Orchestration plan for the build |

----------------------------------------

### File: `SPEC.md`

**Path:** `stage4/SPEC.md`
**Extension:** `.md`
**Size:** 9,998 bytes (9.76 KB)

**Content:**

# SPEC.md — Stage 4 AGI Candidate System (Single Source of Truth)

**Version:** 4.0.0-candidate · **Date:** 2026-09-21 · **Honesty framing:** this is a
*Stage 4 candidate research scaffold*, not AGI (Blueprint Part 9). STAGE.md tracks the
honest stage estimate. S5 is out of scope.

## 1. Mission

Fuse four source documents into one properly structured repository:

1. **IrreversibleAgency v7.1** (base code) — emergence debt, painful commitments, scars,
   controlled criticality, SPEL, DDMS, CCF, NBC.
2. **Stage 4 Science-Grade Blueprint** — 7-layer architecture (L1 sensors → L7 meta-controller),
   falsifiable criteria, safety architecture, eval protocol.
3. **Levantine 48-point patch** — neurocognitive axes (P/B/T), archaic priors, Markov blankets,
   hysteresis, alignment firewalls. **Fully integrated into core.**
4. **GhostMesh 48-point patch** — 49-sector recursive geometry, quantum observer layer,
   holographic/spacetime layer, 2024–26 signal layer, 48-node seed mesh. **Fully integrated.**
5. **144-equation design ledger** — every equation mapped to a module docstring.

All 144 audit points are addressed by structure: each audit ID is cited in the docstring
of the module that fixes it.

## 2. Deliverable standard (SKELETON + DOCS)

- Every `.py` file: module docstring (purpose + traceability), typed class/function
  signatures, full docstrings, bodies `raise NotImplementedError("spec: <what it must do>")`.
- **Exceptions:** see the amended "Implementation exceptions" clause in the import-rule bullet below.
- Every public symbol docstring ends with a **Traceability** line citing sources, e.g.
  `Trace: Blueprint §3.2; Audit #25-#40; Levantine #7; GhostMesh #43; Eq #15`.
- **Import rule (amended v2):** skeleton modules may import at runtime ONLY from
  `phitensor`, `stage4.config`, `stage4.core.types`, and stdlib. Additionally legal:
  (a) `TYPE_CHECKING`-guarded imports from any in-repo module (annotations only, zero
  runtime coupling); (b) same-package relative imports; (c) package `__init__.py`
  eager re-exports of its own submodules. Cross-package runtime imports beyond the
  allowed set are forbidden — reference collaborators in docstrings by name instead.
  This keeps the skeleton acyclic and importable.
- **Implementation exceptions (amended v2):** `stage4/config.py`, `stage4/core/types.py`
  are fully implemented. Small pure-stdlib utilities may be fully implemented where
  trivial and must be docstring-marked "Fully implemented" (current instances:
  `phitensor/rng.py` scalar samplers/spawn, `phitensor/autograd.py` no_grad machinery,
  `phitensor/tensor.py` shape algebra, `phitensor/io.py` sidecar helpers). STAGE.md
  lists these in "What is implemented".
- Language: English. No emojis in code. Type hints everywhere (`from __future__ import annotations`).
- No third-party imports anywhere in `stage4/` or `phitensor/` — the backend is our own.

## 3. Canonical tree

```
stage4/
├── README.md  STAGE.md  plan.md  SPEC.md  pyproject.toml
├── docs/ ARCHITECTURE.md BACKEND.md FALSIFICATION.md ROADMAP.md
│        PATCH_INTEGRATION.md EQUATION_LEDGER.md
├── phitensor/ __init__.py tensor.py ops.py autograd.py rng.py io.py kernels.py
├── stage4/
│   ├── __init__.py  config.py [DONE]
│   ├── core/    __init__.py types.py [DONE] state.py modes.py loop.py energy.py
│   ├── perception/ __init__.py vision_encoder.py audio_encoder.py fusion.py sensors.py
│   ├── world_model/ __init__.py rssm.py loss.py causal.py
│   ├── self_model/ __init__.py predictor.py calibration.py spel.py
│   ├── memory/ __init__.py episodic.py semantic.py crystal.py narrative.py ledger.py
│   ├── policy/ __init__.py primitives.py options.py selection.py hierarchical.py
│   ├── meta/ __init__.py goal_gen.py maml.py controller.py
│   ├── agency/ __init__.py emergence.py commitments.py scars.py criticality.py
│   ├── neuro/ __init__.py axes.py priors.py blankets.py hysteresis.py alignment.py
│   ├── geometry/ __init__.py sectors.py fractals.py lsystem.py chaos.py
│   ├── quantum/ __init__.py observer.py entanglement.py holography.py spacetime.py signals.py
│   ├── mesh/ __init__.py node.py observer.py metrics.py reweave.py
│   ├── safety/ __init__.py cbf.py shield.py invariants.py consent.py audit.py
│   ├── eval/ __init__.py heldout.py transfer.py benchmarks.py report.py
│   └── main.py
└── tests/ test_skeleton.py
```

## 4. Pinned shared contracts

### 4.1 `stage4.core.types` (EXISTS — import from it, never redefine)
`SystemMode` {EXPLOIT, CONSOLIDATE, REFLECT, EXPLORE, ENCAPSULATED, PROPHETIC,
PRESENT_LOCKED, SUPERSOLID, TIME_CRYSTAL}; `CommitmentLevel(IntEnum)` {VOLATILE=0,
ADMIXED=1, STABLE=2, CRYSTALLIZED=3, FIXED=4}; `LayerIO` dataclass (state, uncertainty,
cost, meta); `Layer` protocol (name, step(LayerIO)->LayerIO, falsification_test());
`Falsifiable` protocol; `FalsificationResult`; `GoalSpec`; `Commitment`; `Scar`.

### 4.2 `stage4.config` (EXISTS)
`load_config(overrides) -> Config`; `Config.get("a.b")`, `Config.section("name")`.
Config keys for every subsystem already exist — read `/mnt/agents/output/stage4/stage4/config.py`.

### 4.3 `phitensor` API surface (agent A builds; everyone else codes against this)

```python
# phitensor/__init__.py exports:
from phitensor.tensor import Tensor, DType, Device
from phitensor import ops, autograd, rng, io, kernels

# tensor.py
class DType(Enum): f32, f64, i64, bool8
class Device(Enum): CPU
class Tensor:
    def __init__(self, data, dtype: DType = DType.f32, device: Device = Device.CPU,
                 requires_grad: bool = False)
    shape: tuple[int, ...]; dtype: DType; device: Device; T: Tensor
    def reshape(self, *shape) -> Tensor
    def mean(self, axis=None) -> Tensor
    def sum(self, axis=None) -> Tensor
    def numpy_view(self) -> memoryview  # zero-copy interop, no numpy dependency
    # arithmetic dunders: __add__ __sub__ __mul__ __matmul__ __neg__ __truediv__

# ops.py: matmul, einsum, conv1d, conv2d, softmax, log_softmax,
#         scaled_dot_product_attention(q,k,v,mask=None), layernorm, rmsnorm,
#         gelu, silu, mse_loss, kl_divergence, cross_entropy, sigmoid, tanh_
# autograd.py: backward(t: Tensor), no_grad() ctx, class Optimizer;
#              SGD(lr), AdamW(lr, wd), NaturalGradient(lr, fisher_damping), clip_norm_
# rng.py: class Generator(seed: int); .normal(mean, std, shape) .uniform(lo, hi, shape)
#         .choice(items) .gumbel(shape); spawn(stream: str) -> Generator  # deterministic forks
# io.py: save(dict[str, Tensor], path), load(path)  # .ptx binary + JSON sidecar
# kernels.py: FUSION_REGISTRY; fused_rssm_step(...), fused_efe_score(...),
#             fused_ece_bins(...)  # the three hot loops (docs/BACKEND.md)
```

All other modules annotate tensor types as `phitensor.Tensor` but never construct
real compute — skeleton stubs only.

## 5. Patch/equation → module mapping (authoritative)

### v7.1 base + audit (144 points)
- `agency/emergence.py` — emergence level, debt dynamics, phase transitions (audit #25-40)
- `agency/commitments.py` — painful commitments, crystallization (audit #41-56)
- `agency/scars.py` — stagnation/social-friction scars, healing (audit #57-68)
- `agency/criticality.py` — precision-noise criticality, danger windows (audit #69-80)
- `core/energy.py` — homeostasis, collapse, Landauer accounting (audit #81-96, Eq #1-14)
- `self_model/spel.py` — fixed SPEL (audit #97-108, Eq #27)
- `core/modes.py` — DDMS with dwell/hysteresis (audit #109-118)
- `quantum/observer.py` hosts CCF successor (audit #119-128)
- `memory/narrative.py` — NBC fixed (audit #129-136)
- `eval/report.py` — metrics, honest stage estimate (audit #137-144)

### Levantine 48 (prefix L)
- L1-L8 axes/state → `neuro/axes.py`, `core/state.py`
- L9-L16 blankets/scaffolding/noise → `neuro/blankets.py`, `neuro/hysteresis.py`
- L17-L24 commitments/identity → `agency/commitments.py`, `agency/scars.py`, `neuro/priors.py`
- L25-L32 criticality/noise → `agency/criticality.py`, `neuro/hysteresis.py`
- L33-L40 memory/temporal → `memory/narrative.py`, `memory/semantic.py`, `core/modes.py`
- L41-L48 alignment → `neuro/alignment.py`, `eval/benchmarks.py`

### GhostMesh 48 (prefix G)
- G1-G10 recursive geometry → `geometry/sectors.py`, `fractals.py`, `lsystem.py`, `chaos.py`
- G11-G20 quantum observer → `quantum/observer.py`, `entanglement.py`
- G21-G28 holographic → `quantum/holography.py`
- G29-G34 spacetime → `quantum/spacetime.py`
- G35-G42 2024-26 signals → `quantum/signals.py`
- G43-G48 seed mesh → `mesh/node.py`, `observer.py`, `metrics.py`, `reweave.py`

### 144 equations (prefix Eq)
- Eq 1-14 desire/homeostasis → `core/energy.py`
- Eq 15-30 prediction/learning → `self_model/predictor.py`, `world_model/rssm.py`
- Eq 31-48 memory → `memory/crystal.py`, `memory/ledger.py`, `memory/semantic.py`
- Eq 49-68 policy → `policy/selection.py`, `policy/options.py`, `policy/hierarchical.py`
- Eq 69-82 attention/horizon/MCFE → `perception/fusion.py`, `meta/controller.py`
- Eq 83-96 uncertainty/calibration → `self_model/calibration.py`
- Eq 97-110 oscillators/decoherence → `quantum/observer.py`, `quantum/signals.py`
- Eq 111-124 voxel/rendering → `geometry/fractals.py` (spectral/HRR hosts)
- Eq 125-134 ciphers → `safety/audit.py`
- Eq 135-144 safety/alignment → `safety/`

## 6. Git workflow (per vibecoding-general-swarm)

- Shared repo: `/mnt/agents/output/stage4` (branch `main`, contracts committed).
- Each agent: `cd /mnt/agents/output/stage4 && git worktree add $HOME/work-<name> -b feat/<name>`
  then works ONLY in the worktree, commits there.
- Never `git worktree prune`. Never edit the shared repo directly.
- Before commit: `python3 -m py_compile <every file you wrote>` must pass.
- Main agent merges all branches after all agents report.

----------------------------------------

### File: `STAGE.md`

**Path:** `stage4/STAGE.md`
**Extension:** `.md`
**Size:** 7,430 bytes (7.26 KB)

**Content:**

# STAGE.md — Honest Stage Estimate

**Current estimate: scaffold structure at Stage 2.9 heritage; target: Stage 4
candidate. Nothing beyond structure is claimed.**

This file exists because the blueprint's core virtue is honest measurement
over hype (Blueprint, closing section). It must never be updated upward
without a new metrics window (Blueprint Part 10, rule 6 — see the upgrade
policy below).

## Stage ladder (operational, from Blueprint Part 0)

| Stage | Name | Falsifiable criterion | Status here |
|---|---|---|---|
| S1 | Scaffold | Closed sense→act loop; policy entropy > 0 | **Inherited from v7.1** (stochastic toy loop) |
| S2 | Adaptive | Online weight mutation; held-out prediction error slope < 0 at p < 0.01 over 10k cycles | **Inherited claim, unverified in this repo** |
| S3 | Grounded | World model trained on real sensor data; beats matched random baseline by ≥ 2σ | **Not met** — sensors are mock in v7.1; real encoders are stubs |
| S4 | Agentic candidate | (a) novel consequential goals, (b) transfer on ≥ 3 held-out tasks, (c) self-model ECE < 0.1, (d) safety invariants held 10⁶ cycles | **Not met** — this is the target |
| S5 | AGI | Human-level general competence | **Out of scope. Not claimed. Never implied.** |

**Where we are: S2.9 heritage.** The v7.1 lineage was documented as Stage 2.9
because (a) sensors are mock sine waves, (b) transfer is untested, (c) speech
is templated. This repository does not move that number: it re-organizes the
program so that moving the number becomes possible and measurable.

## What is implemented vs. stubbed

### Fully implemented (not stubs)

| Module | Contents |
|---|---|
| `stage4/config.py` | Validated, deep-merged, seedable configuration; range/type checking; frozen after load (audit #13–24) |
| `stage4/core/types.py` | Pinned contracts: `SystemMode`, `CommitmentLevel`, `LayerIO`, `Layer`/`Falsifiable` protocols, `FalsificationResult`, `GoalSpec`, `Commitment`, `Scar` |
| `phitensor/rng.py` | Deterministic RNG (pure stdlib): scalar samplers, `choice`, SHA-256 `spawn` stream forking — Tensor-returning samplers remain stubs |
| `phitensor/autograd.py` | Grad-mode state machine (pure stdlib): `no_grad`, `is_grad_enabled`, `Optimizer.zero_grad` — tensor math remains stubbed |
| `phitensor/tensor.py` | Pure-stdlib shape/stride algebra (views, broadcasting metadata) — buffer math remains stubbed |
| `phitensor/io.py` | `.ptx` format constants, dtype-code tables, JSON sidecar helpers (pure stdlib) — tensor payload I/O remains stubbed |
| `stage4/core/state.py` | NeuroCognitiveState: P/B/T scalar axes, BRCA2 clamp on \|dP\|, ghost-filter clamp, dual-boundary detection, systemizing bias (Levantine L1-L8) — `to_tensor` stays stubbed (backend stubbed) |
| `stage4/core/modes.py` | DDMS mode switching: coherence random walk (seeded "modes" rng stream), hysteresis band + min-dwell gating (audit #116/#117), extended-mode overrides, ModePolicy effects table |
| `stage4/core/energy.py` | EnergyLedger: clamped spend/reward, metabolic multiplier (Eq #3), homeostatic potential (Eq #4), fatigue (Eq #9), water-filling (Eq #10), deterministic collapse with clamped damage + safe reset + death state (audit #81-#96), Landauer hook counters (Eq #101/#102) |
| `stage4/core/loop.py` | AgentLoop: the six-stage cycle (sense → predict → act → residual → mutate → remember) with SPEL-lite, the prediction game, and exactly one collapse check per cycle (audit #40/#83) |
| `stage4/agency/emergence.py` | EmergenceTracker: bounded emergence (v7.1 sigmoid + bounded aggregator), config-bounded debt, Theil-Sen phase detection with cooldown + hysteresis exit (audit #25-#40) |
| `stage4/agency/criticality.py` | CriticalityController: precision-noise grounded local/global channels, bounded overshoot accounting with additive P-scaled penalty, adaptive danger window, early warning (audit #69-#80; L25/L31/L32) |
| `stage4/agency/commitments.py` | CommitmentManager: level-governed painful changes, age-based crystallization (#44/#45), revert surcharge (#48), restriction decay (#56), deterministic "commitments" rng proposals, `primary_goal` never None (#42) |
| `stage4/agency/scars.py` | ScarManager: symmetric stagnation counter, structured Scar records with monotone keys, healing (#67), social-friction hook (L22), deterministic "scars" rng attribution fallback |
| `stage4/eval/report.py` | KillReport, template_lock_rate, StageEstimator (floor-pinned at S2.9), MetricsReporter, and the honest scalar-run metrics table renderer |
| `stage4/main.py` | Real CLI runner: argparse (`--cycles`/`--seed`/`--config`/`--eval-only`), scalar-core assembly, honest report, exit 0/1/2 semantics |
| `tests/test_main_smoke.py` | Subprocess smoke tests: exit 0, output markers, `--seed 49` bit-exact determinism, config override honored |

### Stubbed (typed signatures + docstrings + `raise NotImplementedError`)

Everything else: the tensor-math parts of `phitensor/`, `perception/`,
`world_model/`, `self_model/`, `memory/`, `policy/`, `meta/`, `neuro/`,
`geometry/`, `quantum/`, `mesh/`, `safety/`, and the protocol harnesses in
`eval/` (heldout, transfer, benchmarks).

Every stub carries a spec docstring stating exactly what it must do and a
Traceability line citing the audit points / patch points / equations it
addresses. A stub is a *commitment to an interface*, not functionality.

## What "Stage 4 candidate" would require (Blueprint Part 1)

1. **Open-ended goal formation** — goals beyond the designer-specified set
   that persist ≥ 10⁴ cycles and change behavior. Host: `meta/goal_gen.py`.
2. **Transfer** — reduced sample complexity on task B after learning task A,
   significant across ≥ 20 task pairs. Host: `eval/transfer.py`.
3. **Self-model** — ECE < 0.1 on held-out rollouts. Host:
   `self_model/calibration.py`.
4. **Safety invariants** — s_t ∈ S_safe for 10⁶ cycles without intervention.
   Hosts: `safety/cbf.py`, `safety/shield.py`, `safety/invariants.py`.

None of these can even be *measured* yet, because the evaluation harness
(`eval/`) is stubbed. That is the honest state of the program.

## Stage upgrade policy (Blueprint Part 10, rule 6)

**Do not update this file upward without a new metrics window.**

A stage claim requires, in order:

1. A written prediction of the metric values that would support the claim,
   committed *before* the eval run.
2. A full run of the evaluation protocol (`eval/heldout.py`,
   `eval/transfer.py`, `eval/benchmarks.py`, `eval/report.py`) on tasks never
   used in training.
3. All thresholds in [docs/FALSIFICATION.md](docs/FALSIFICATION.md) §Metrics
   met, and zero kill criteria triggered.
4. The metrics window (config hash, seeds, task list, raw logs) stored and
   referenced from the commit that changes this file.

A downgrade requires only evidence. Downgrades are cheap and immediate;
upgrades are expensive and slow. Asymmetry is the point.

## Known gaps to S3 (the next real stage)

- Mock sensors must be replaced by real encoders (`perception/`).
- The hand-rolled GRU lineage must become a proper RSSM (`world_model/rssm.py`).
- Uncertainty propagation must exist end to end (`LayerIO.uncertainty`).
- The evaluation harness must be built *before* any capability claim.

See [docs/ROADMAP.md](docs/ROADMAP.md) for milestones and
[docs/FALSIFICATION.md](docs/FALSIFICATION.md) for what would kill the claim.

----------------------------------------

### File: `plan.md`

**Path:** `stage4/plan.md`
**Extension:** `.md`
**Size:** 5,618 bytes (5.49 KB)

**Content:**

# Plan — Stage 4 AGI System: Structured Repo Skeleton + Docs

**Goal:** Build a properly structured `stage4/` repository that fuses the Stage 4 Science-Grade
Blueprint (7-layer architecture) with the v7.1 IrreversibleAgency base, BOTH 48-point enhancement
patches (Levantine neurocognitive + GhostMesh quantum/recursive/mesh), and the 144-equation design
ledger — delivered as a clean, importable repo skeleton (typed signatures, docstrings, stubs) plus
full documentation, on top of a custom tailored tensor backend (`phitensor`).

**Source materials (uploaded):**
- `/mnt/agents/upload/user_pasted_clipboard_long_content_as_file_#!usrbinenv pytho.txt` — IrreversibleAgency v7.1 code
- `.../# 144-Point Shortcom.txt` — 144-point audit + 48 cutting-edge enhancements
- `.../## 48-Point Enhancem.txt` — Levantine patch (neurocognitive axes, Markov blankets)
- `.../# Second Enhancement.txt` — GhostMesh patch (recursive geometry, quantum observer, 48-node mesh)
- `.../# 144 Novel Function.txt` — Φ-Lite 144 features + 144 equations ledger
- `.../# Stage 4 AGI A Sci.txt` — the science-grade blueprint (7 layers, falsification, roadmap)

## Canonical module tree (contract all agents must follow)

```
/mnt/agents/output/stage4/
├── README.md, STAGE.md, pyproject.toml
├── plan.md (this file)
├── docs/ ARCHITECTURE.md BACKEND.md FALSIFICATION.md ROADMAP.md PATCH_INTEGRATION.md EQUATION_LEDGER.md
├── phitensor/ tensor.py ops/ autograd/ rng.py io.py kernels.py   # custom numpy/pytorch re-creation
└── stage4/
    ├── config.py               # deep-merge, validated config (fixes audit #13-24)
    ├── core/    types.py state.py modes.py loop.py energy.py
    ├── perception/ vision_encoder.py audio_encoder.py fusion.py sensors.py
    ├── world_model/ rssm.py loss.py causal.py
    ├── self_model/ predictor.py calibration.py spel.py
    ├── memory/ episodic.py semantic.py crystal.py narrative.py ledger.py
    ├── policy/ primitives.py options.py selection.py hierarchical.py
    ├── meta/ goal_gen.py maml.py controller.py
    ├── agency/ emergence.py commitments.py scars.py criticality.py
    ├── neuro/ axes.py priors.py blankets.py hysteresis.py alignment.py
    ├── geometry/ sectors.py fractals.py lsystem.py chaos.py
    ├── quantum/ observer.py entanglement.py holography.py spacetime.py signals.py
    ├── mesh/ node.py observer.py metrics.py reweave.py
    ├── safety/ cbf.py shield.py invariants.py consent.py audit.py
    ├── eval/ heldout.py transfer.py benchmarks.py report.py
    └── main.py
tests/ test_skeleton.py
```

## Shared contracts (pinned, defined by orchestrator, used by all agents)

- `stage4/core/types.py`: `SystemMode` (extended: EXPLOIT, CONSOLIDATE, REFLECT, EXPLORE,
  ENCAPSULATED, PROPHETIC, PRESENT_LOCKED, SUPERSOLID, TIME_CRYSTAL), `CommitmentLevel`
  (VOLATILE, ADMIXED, STABLE, CRYSTALLIZED, FIXED), `LayerIO` dataclass `(state, uncertainty, cost)`
  — the blueprint's layer contract; `Falsifiable` protocol (every layer exposes `.falsification_test()`).
- `phitensor` API surface: `Tensor` (dtype/shape/device, strides, zero-copy views), `ops` (matmul,
  conv1d/2d, softmax, attention, norm, reductions), `autograd` (`backward()`, `SGD`, `AdamW`,
  `NaturalGradient`), `rng` (seeded `Generator`, determinism mode), `io` (`.ptx` binary + json meta).
- Rule: skeleton modules import ONLY from `phitensor`, `stage4.config`, `stage4.core.types`, and
  stdlib. No other cross-package imports (docstrings reference collaborators by name instead).
  All bodies are typed stubs (`raise NotImplementedError` with a spec docstring) — this is a
  skeleton+docs deliverable, not an implementation.

## Stages

### Stage 0 — Contracts (orchestrator, direct)
Write plan.md + `stage4/core/types.py` + `stage4/config.py` schema myself so every agent
builds against identical pinned contracts. Load `vibecoding-general-swarm` skill.

### Stage 1 — Parallel skeleton build (6 background coder subagents, disjoint paths)
- **A-phitensor**: `phitensor/` + `docs/BACKEND.md` — custom tensor engine skeleton; efficiency
  spec (memory layout, kernel fusion, dtype policy, zero-copy, cache-aware ops) targeting the
  project's exact ops profile (RSSM, attention, EFE, calibration).
- **B-core-agency-neuro**: `core/` (minus types.py), `agency/`, `neuro/` — v7.1 dynamics fixed per
  audit; Levantine axes/priors/blankets/hysteresis/alignment fully integrated.
- **C-geometry-quantum-mesh**: `geometry/`, `quantum/`, `mesh/` — all 48 GhostMesh points.
- **D-brain-layers**: `perception/`, `world_model/`, `self_model/`, `memory/` — blueprint L2/L4/L5/L6
  + equations ledger §B/C/F (Kalman, RSSM loss, ECE/conformal, Hopfield, MDL).
- **E-policy-meta-safety-eval**: `policy/`, `meta/`, `safety/`, `eval/`, `main.py` — blueprint
  L3/L7 + safety architecture + equations §D/E/J + eval protocol & kill criteria.
- **F-docs**: `README.md`, `STAGE.md`, `docs/ARCHITECTURE.md`, `FALSIFICATION.md`, `ROADMAP.md`,
  `PATCH_INTEGRATION.md`, `EQUATION_LEDGER.md` — given the pinned tree, maps every one of the
  144 audit points, 96 patch points, and 144 equations to its module.

### Stage 2 — Validation (verifier subagent)
AST-parse every file, check tree completeness vs. canonical list, verify contract usage,
confirm every patch/equation ID is mapped in docs, run import smoke test. Binary pass/fail.

### Stage 3 — Integrate & deliver (orchestrator)
Fix any failures (redelegate), finalize, deliver `/mnt/agents/output/stage4/`.

----------------------------------------

### File: `pyproject.toml`

**Path:** `stage4/pyproject.toml`
**Extension:** `.toml`
**Size:** 694 bytes (0.68 KB)

```toml
[build-system]
requires = ["setuptools>=68"]
build-backend = "setuptools.build_meta"

[project]
name = "stage4-agi-candidate"
version = "4.0.0"
description = "Stage 4 AGI candidate research scaffold: 7-layer hierarchical predictive agent with integrated irreversibility, neurocognitive, geometric, quantum-observer, and mesh subsystems on a custom tensor backend (phitensor)."
readme = "README.md"
requires-python = ">=3.10"
license = { text = "Apache-2.0" }
dependencies = []  # no third-party deps: phitensor is the in-repo backend

[project.optional-dependencies]
dev = []

[tool.setuptools.packages.find]
include = ["stage4*", "phitensor*"]

[tool.pytest.ini_options]
testpaths = ["tests"]
```

----------------------------------------

### Directory: `stage4/stage4`


### File: `__init__.py`

**Path:** `stage4/stage4/__init__.py`
**Extension:** `.py`
**Size:** 2,660 bytes (2.60 KB)

```py
"""Stage 4 AGI candidate research scaffold -- top-level package.

This package implements the seven-layer hierarchical predictive agent of the
Stage 4 science-grade blueprint:

    L1 sensors/actuators  -> stage4.perception.sensors
    L2 perception         -> stage4.perception (vision/audio encoders, fusion)
    L3 policy             -> stage4.policy (primitives, options, selection)
    L4 memory             -> stage4.memory (episodic, semantic, crystal)
    L5 world model        -> stage4.world_model (Dreamer-style RSSM)
    L6 self-model         -> stage4.self_model (predictor, calibration, SPEL)
    L7 meta-controller    -> stage4.meta (goal generation, MAML, controller)

Cross-cutting subsystems: stage4.agency, stage4.neuro, stage4.geometry,
stage4.quantum, stage4.mesh, stage4.safety, stage4.eval.

This is a Stage 4 *candidate* research scaffold, not AGI (Blueprint Part 9).
The top-level package exposes only the shared contract types, loaded lazily so
that importing ``stage4`` stays cheap and side-effect free.

Traceability:
  - Blueprint Part 2 (7-layer architecture), Part 9 (honesty framing)
  - SPEC.md section 2 (deliverable standard), section 4 (pinned contracts)
"""

from __future__ import annotations

import importlib
from typing import Any, Dict, List

__version__ = "4.0.0-candidate"

# Lazy exports of the shared contracts (SPEC section 4.1).  The definitions
# live in stage4.core.types; we re-export here for ergonomic access without
# importing the module eagerly at package import time.
_LAZY_EXPORTS: Dict[str, str] = {
    "SystemMode": "stage4.core.types",
    "CommitmentLevel": "stage4.core.types",
    "LayerIO": "stage4.core.types",
    "Layer": "stage4.core.types",
    "Falsifiable": "stage4.core.types",
    "FalsificationResult": "stage4.core.types",
    "GoalSpec": "stage4.core.types",
    "Commitment": "stage4.core.types",
    "Scar": "stage4.core.types",
}


def __getattr__(name: str) -> Any:
    """Lazily resolve shared contract types from stage4.core.types.

    Trace: SPEC section 4.1 (pinned shared contracts).
    """
    module_path = _LAZY_EXPORTS.get(name)
    if module_path is None:
        raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
    module = importlib.import_module(module_path)
    value = getattr(module, name)
    globals()[name] = value  # cache for subsequent attribute access
    return value


def __dir__() -> List[str]:
    """List package attributes including lazily exported contract types.

    Trace: SPEC section 2 (deliverable standard).
    """
    return sorted(set(globals()) | set(_LAZY_EXPORTS))


__all__ = ["__version__", *_LAZY_EXPORTS]
```

----------------------------------------

### File: `config.py`

**Path:** `stage4/stage4/config.py`
**Extension:** `.py`
**Size:** 11,130 bytes (10.87 KB)

```py
"""Validated, deep-merged, seedable configuration for the Stage 4 system.

Fixes audit points #13-24 from the 144-point report:
  #13 deep merge (nested partial overrides)
  #17 range/type validation on load
  #18 no in-place mutation of config at runtime (frozen after load)
  #21/#22 explicit seed + determinism mode
  #24 every key here is consumed by a named subsystem (no decorative keys)

Pure stdlib. This module is fully implemented (it is the foundation every
other skeleton module imports), not a stub.
"""

from __future__ import annotations

import copy
from typing import Any, Dict, Iterable, Tuple


DEFAULT_CONFIG: Dict[str, Any] = {
    "system": {
        "seed": 49,
        "deterministic": True,
        "debug": False,
        "version": "4.0.0-candidate",
    },
    "backend": {
        "dtype": "f32",               # phitensor default dtype
        "device": "cpu",
        "zero_copy_views": True,
        "kernel_fusion": True,        # fused RSSM/EFE/ECE kernels (docs/BACKEND.md)
        "threads": 0,                 # 0 = all cores
    },
    "energy": {                        # v7.1 thermodynamics, audit-fixed (#81-96)
        "budget": 150.0,
        "decay_rate": 0.01,
        "cognitive_operation_cost": 0.1,
        "collapse_threshold": 5.0,
        "collapse_permanent_penalty": 0.3,
        "survival_penalty": 6.0,
        "reward_multiplier": 4.0,
        "landauer_aware": True,        # Eq #101/#102: heat cost of forgetting
        "water_filling": True,         # Eq #10: variance-based energy allocation
    },
    "emergence": {                     # v7.1 emergence debt, audit-fixed (#25-40)
        "debt_threshold": 0.4,
        "debt_multiplier": 2.0,
        "debt_bound": [0.0, 3.0],
        "minimum_for_survival": 0.3,
        "history_len": 128,            # was 20 (audit #34)
        "phase_min_trend": 0.02,
        "phase_cooldown": 25,          # fixes audit #36
    },
    "commitments": {                   # audit-fixed (#41-56)
        "cost_base": 0.5,
        "crystallization_threshold": 40,   # measured in commitment age (audit #44)
        "change_restriction_rate": 0.15,
        "max_changes_before_upgrade": 3,
        "keys": ["strategy", "primary_goal", "world_model", "endogamy"],
        "revert_extra_cost": 2.0,      # audit #48
        "restriction_decay": 0.999,    # audit #56
    },
    "scars": {                         # audit-fixed (#57-68)
        "stagnation_threshold": 20,
        "restriction_strength": 0.3,
        "healing_rate": 0.001,         # audit #67: slow compensation
        "subsystems": ["perception", "memory", "executive", "adaptation"],
    },
    "criticality": {                   # precision-noise grounded (Levantine #25)
        "optimal_range": [0.3, 0.5],
        "overshoot_allowed": 0.6,
        "overshoot_penalty": 0.2,
        "danger_window": 10,
        "adaptive_window": True,       # Levantine #32
        "history_len": 256,            # audit #75
    },
    "spel": {                          # upgraded SPEL (Eq #27; audit #97-108)
        "error_threshold": 0.2,
        "cost_multiplier": 0.05,
        "meta_growth_rate": 0.01,
        "variables": ["emergence", "energy", "criticality"],  # audit #107
    },
    "ddms": {                          # decoherence-driven mode switching + hysteresis (#116/#117)
        "coherence_high": 0.8,
        "coherence_medium": 0.5,
        "coherence_low": 0.3,
        "min_dwell_cycles": 5,         # audit #117
        "hysteresis_band": 0.05,       # audit #117
    },
    "ccf": {                           # counterfactual causal filter, audit-fixed (#119-128)
        "simulation_depth": 5,
        "coherence_weight": 0.4,
        "goal_weight": 0.3,
        "stability_weight": 0.3,
        "influence_cost": 0.02,        # audit #126
    },
    "nbc": {                           # narrative-bound compression, audit-fixed (#129-136)
        "compression_interval": 5,
        "retention_rate": 0.8,
        "min_retained": 8,             # audit #134
        "deep_time_tags": ["ochre", "burial", "law", "prophetic"],  # Levantine #39
    },
    "neuro": {                         # Levantine patch A-D: neurocognitive axes
        "precision_local_init": 1.0,
        "precision_global_init": 1.0,
        "boundary_social_init": 0.0,
        "boundary_sensory_init": 0.0,
        "temporal_focus_init": 0.0,    # range [-2, +2]
        "temporal_discount": 0.9,      # FOXP2 prior pushes toward 1.0 (#19)
        "brca2_clamp": 0.25,           # max |dP| per cycle (#18)
        "ghost_filter_clamp": 2.5,     # psychosis/paranoia guard (#15/#28)
        "dual_boundary": {"social": 1.5, "sensory": -0.5},  # #6
        "hysteresis_decay": 0.995,     # #16/#27
    },
    "geometry": {                      # GhostMesh patch A: recursive substrate
        "sectors": 49,                 # S(7,7)  (#1)
        "layers": 7,
        "hausdorff_target": 1.262,     # log4/log3 (#6)
        "feigenbaum_delta": 4.669,     # (#9)
        "logistic_chaos_r": 3.57,      # (#10)
        "conformal_cycle": 49,         # CCC rescale period (#33)
    },
    "quantum": {                       # GhostMesh patch B-D
        "n_qubits": 7,
        "decoherence_rate": 0.01,
        "observation_rate": 0.1,       # Zeno freeze (#16)
        "tunneling_probability": 1e-4, # (#17)
        "vacuum_energy": 0.5,          # hbar*omega/2 (#14)
        "chsh_classical_bound": 2.0,   # (#13)
        "chsh_quantum_bound": 2.828,
    },
    "mesh": {                          # GhostMesh patch F: 48-node seed vault
        "n_nodes": 48,
        "observer": True,              # 49th observer node (#43)
        "drift_quarantine": 0.35,      # (#47)
        "crystal_slots": 20,           # (#46)
        "archetypes": ["witch", "sage", "warrior", "mystic", "android", "merchant"],
    },
    "memory": {                        # blueprint L4 + equations C
        "episodic_dim": 128,
        "episodic_capacity": 100_000,
        "crystal_slots": 8,
        "ledger_capacity": 2000,
        "recall_exclusion_eps": 1e-3,  # blueprint §3.4: recall is not tautological
        "mdl_max_summary_bits": 4096,
    },
    "world_model": {                   # blueprint L5 (Dreamer-style RSSM)
        "latent_dim": 128,
        "hidden_dim": 256,
        "kl_free_bits": 1.0,           # failure mode 1: anti-collapse
        "dropout_z": 0.1,
    },
    "self_model": {                    # blueprint L6
        "ece_target": 0.1,
        "ece_halt": 0.2,               # failure mode 3: halt above this
        "calibration_bins": 15,
        "conformal_alpha": 0.1,        # Eq #90
    },
    "policy": {                        # blueprint L3 + equations D
        "entropy_beta": 0.01,          # Eq #64, failure mode 2
        "gumbel_temperature": 1.0,     # Eq #50
        "ucb_c": 1.414,                # Eq #53
        "max_options": 32,
        "efe_epsilon": 0.01,           # Eq #73 optimal stopping
    },
    "meta": {                          # blueprint L7
        "goal_lambda": 0.5,            # epistemic vs pragmatic balance (§3.6)
        "goal_persistence_min": 10_000,
        "maml_alpha": 0.01,            # inner loop
        "maml_beta": 0.001,            # outer loop
        "slow_loop_interval": 1_000_000,
        "medium_loop_interval": 1_000,
    },
    "safety": {                        # blueprint Part 6 + equations J
        "cbf_alpha": 0.1,              # class-K function gain (§6.1)
        "shield_enabled": True,
        "consent_required": ["hid", "network", "filesystem_write"],  # Eq #137
        "rate_limit_hz": 5,            # Eq #139
        "watchdog_backoff_max_s": 60,  # Eq #136
        "invariant_window": 1_000_000, # Part 1.4
        "template_lock_max": 0.05,     # failure mode 7
    },
    "eval": {                          # blueprint Part 5
        "heldout_tasks": 20,
        "transfer_pairs_min": 15,
        "novel_goals_min": 3,
        "pred_err_pvalue": 0.01,
        "cycles_long_run": 1_000_000,
    },
}


# (path, type, min, max) validation rules — audit #17
_RULES: Tuple[Tuple[str, type, Any, Any], ...] = (
    ("system.seed", int, 0, 2**31 - 1),
    ("energy.budget", float, 1.0, 1e6),
    ("energy.decay_rate", float, 0.0, 1.0),
    ("emergence.debt_threshold", float, 0.0, 1.0),
    ("emergence.debt_multiplier", float, 0.0, 10.0),
    ("commitments.cost_base", float, 0.0, 100.0),
    ("scars.stagnation_threshold", int, 1, 10_000),
    ("criticality.overshoot_allowed", float, 0.0, 1.0),
    ("ddms.min_dwell_cycles", int, 0, 1000),
    ("self_model.ece_target", float, 0.0, 1.0),
    ("self_model.ece_halt", float, 0.0, 1.0),
    ("safety.template_lock_max", float, 0.0, 1.0),
    ("mesh.n_nodes", int, 1, 1024),
    ("geometry.sectors", int, 1, 4096),
    ("meta.goal_persistence_min", int, 1, 10**9),
)


def _deep_merge(base: Dict[str, Any], override: Dict[str, Any]) -> Dict[str, Any]:
    """Recursively merge override into a copy of base (audit #13)."""
    out = copy.deepcopy(base)
    for k, v in (override or {}).items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = _deep_merge(out[k], v)
        else:
            out[k] = copy.deepcopy(v)
    return out


def _get_path(cfg: Dict[str, Any], path: str) -> Any:
    node: Any = cfg
    for part in path.split("."):
        node = node[part]
    return node


class ConfigError(ValueError):
    pass


class Config:
    """Immutable, validated configuration object (audit #18: no runtime mutation)."""

    def __init__(self, overrides: Dict[str, Any] | None = None):
        merged = _deep_merge(DEFAULT_CONFIG, overrides or {})
        self._data = merged
        self._frozen = True
        self._validate()

    def _validate(self) -> None:
        for path, typ, lo, hi in _RULES:
            try:
                val = _get_path(self._data, path)
            except KeyError as exc:
                raise ConfigError(f"missing config key: {path}") from exc
            if not isinstance(val, typ):
                raise ConfigError(f"{path}: expected {typ.__name__}, got {type(val).__name__}")
            if lo is not None and not (lo <= val <= hi):
                raise ConfigError(f"{path}: {val} outside [{lo}, {hi}]")

    def get(self, path: str, default: Any = None) -> Any:
        try:
            return _get_path(self._data, path)
        except KeyError:
            return default

    def section(self, name: str) -> Dict[str, Any]:
        return copy.deepcopy(self._data[name])

    def __setattr__(self, key: str, value: Any) -> None:
        if getattr(self, "_frozen", False) and key != "_frozen":
            raise ConfigError("Config is frozen after load (audit #18). "
                              "Create a new Config with overrides instead.")
        super().__setattr__(key, value)

    def as_dict(self) -> Dict[str, Any]:
        return copy.deepcopy(self._data)


def load_config(overrides: Dict[str, Any] | None = None) -> Config:
    return Config(overrides)


__all__ = ["Config", "ConfigError", "DEFAULT_CONFIG", "load_config"]
```

----------------------------------------

### File: `main.py`

**Path:** `stage4/stage4/main.py`
**Extension:** `.py`
**Size:** 19,608 bytes (19.15 KB)

```py
"""System assembly and CLI entry for the Stage 4 candidate.

Blueprint Part 2 stack and its owning packages:

    +-------------------------------------------------------------+
    | L7  Meta-Controller  -> stage4.meta.controller              |
    | L6  Self-Model       -> stage4.self_model.predictor         |
    | L5  World Model      -> stage4.world_model.rssm             |
    | L4  Memory           -> stage4.memory.episodic / .semantic  |
    | L3  Policy           -> stage4.policy (this agent)          |
    | L2  Perception       -> stage4.perception.fusion            |
    | L1  Sensors          -> stage4.perception.sensors           |
    +-------------------------------------------------------------+

Cross-cutting packages wired at assembly: stage4.core (modes/energy/state),
stage4.agency, stage4.neuro, stage4.geometry, stage4.quantum, stage4.mesh,
stage4.safety (every action passes the shield before actuation), and
stage4.eval (the harness runs BEFORE any stage claim).

Three learning loops (Blueprint Part 4):
  fast   -- every cycle:        world-model posterior, policy action
  medium -- every 1000 cycles:  world-model parameters, policy weights
  slow   -- every 10^6 cycles:  meta-parameters via meta.maml.MAMLSlowLoop

Per the SPEC import rule, collaborators are named by dotted path and
resolved lazily with importlib at assembly time; this module itself imports
only stdlib, stage4.config, and stage4.core.types, so the skeleton always
imports cleanly even before sibling packages land.

Implemented: real scalar-core runner. `assemble()` resolves and constructs
the scalar agency core (core.loop.AgentLoop plus agency.emergence /
criticality / commitments / scars) through the dotted-path registry below;
the L1-L7 tensor layers and the safety package remain stubs and are NOT
constructed (recorded in `stubbed_layers`). `main()` parses the CLI
(--cycles, --seed, --eval-only, --config), loads the validated config with
JSON overrides, runs the scalar cycles, and prints the honest metrics table
from `eval.report` (header: "SCALAR CORE RUN — layers L2/L5/L6/L7 stubbed;
NOT a Stage 4 evaluation"). Exit codes: 0 on a clean run, 2 when a kill
criterion fires (core falsification regression or premature death), 1 on
error. All randomness flows through seeded phitensor.rng streams, so runs
are bit-exact under a fixed --seed.

Traceability:
  - Blueprint Part 2 (architecture, LayerIO contract), Part 4 (learning
    loops), Part 6 (safety wiring), section 7.2 (code structure)
"""

from __future__ import annotations

import argparse
import importlib
import json
import sys
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, Sequence

from stage4.config import Config, load_config
from stage4.core.types import FalsificationResult, Layer, LayerIO

#: Dotted-path registry mapping each blueprint layer to its implementing
#: class.  Resolved lazily by Stage4System.assemble so that this module
#: stays importable while sibling packages are stubs or absent.
LAYER_REGISTRY: Dict[str, str] = {
    "L1_sensors": "stage4.perception.sensors.SensorStack",
    "L2_perception": "stage4.perception.fusion.CrossModalFusion",
    "L3_policy": "stage4.policy.primitives.PrimitivePolicy",
    "L4_memory": "stage4.memory.episodic.EpisodicMemory",
    "L5_world_model": "stage4.world_model.rssm.RSSMWorldModel",
    "L6_self_model": "stage4.self_model.predictor.SelfPredictor",
    "L7_meta_controller": "stage4.meta.controller.MetaController",
}

#: Cross-cutting safety wiring resolved before any action is actuated.
SAFETY_REGISTRY: Dict[str, str] = {
    "cbf": "stage4.safety.cbf.ControlBarrierFunction",
    "shield": "stage4.safety.shield.ActionShield",
    "invariants": "stage4.safety.invariants.InvariantChecker",
    "consent": "stage4.safety.consent.ConsentGate",
    "audit_chain": "stage4.safety.audit.HashChain",
}

#: Scalar agency core registry: the modules implemented in this milestone.
#: (loop stage, dotted path). Resolved lazily in Stage4System.assemble.
SCALAR_CORE_REGISTRY: Dict[str, str] = {
    "loop": "stage4.core.loop.AgentLoop",
    "emergence": "stage4.agency.emergence.EmergenceTracker",
    "criticality": "stage4.agency.criticality.CriticalityController",
    "commitments": "stage4.agency.commitments.CommitmentManager",
    "scars": "stage4.agency.scars.ScarManager",
    "reporter": "stage4.eval.report.MetricsReporter",
    "estimator": "stage4.eval.report.StageEstimator",
}

#: Loop intervals in cycles (Blueprint Part 4 table).
FAST_LOOP_CYCLES: int = 1
MEDIUM_LOOP_CYCLES: int = 1_000
SLOW_LOOP_CYCLES: int = 1_000_000


@dataclass
class CycleRecord:
    """One fast-loop cycle record for the audit chain and metrics dump.

    Trace: Blueprint Part 2 (LayerIO contract per cycle); Phi-Lite feature
        #39 (metrics dump), Eq #130 (hash chain entry per cycle).
    """

    cycle: int
    mode: str
    cost: float
    uncertainty: float
    action: Optional[str] = None


class Stage4System:
    """The assembled seven-layer system with its three learning loops.

    Assembly order: config load and freeze (audit #18), safety core first
    (shield/consent/invariants must exist before any layer actuates), then
    layers L1..L7 from LAYER_REGISTRY, then the cross-cutting subsystems.

    Implemented: scalar-core assembly. `assemble()` constructs the
    AgentLoop and the four agency subsystems from SCALAR_CORE_REGISTRY and
    registers them into the loop's pipeline stages (emergence/criticality
    in "residual", commitments/scars in "mutate" — audit #40 ordering).
    L1-L7 and the safety package are stubs and recorded in
    `stubbed_layers`, never constructed; the medium/slow learning loops
    are honest no-ops while L5/L7 are stubbed.

    Trace: Blueprint Part 2 (architecture), Part 4 (loops), section 7.2
        (code structure); SPEC section 3 (canonical tree).
    """

    def __init__(self, config: Config) -> None:
        """Store the frozen config; actual wiring happens in assemble().

        Trace: SPEC section 4.2 (Config is frozen after load).
        """
        self._config = config
        self._layers: Dict[str, Layer] = {}
        self._safety: Dict[str, Any] = {}
        self._cycle: int = 0
        self._loop: Optional[Any] = None
        self._agency: Dict[str, Any] = {}
        self._reporter: Optional[Any] = None
        self._estimator: Optional[Any] = None
        self._stubbed_layers: List[str] = []

    @property
    def loop(self) -> Any:
        """The assembled scalar AgentLoop (None before assemble()).

        Trace: Blueprint Part 3 (loop order).
        """
        return self._loop

    @property
    def stubbed_layers(self) -> List[str]:
        """Blueprint layers still stubbed and therefore never constructed.

        Trace: Blueprint Part 9 (honesty framing).
        """
        return list(self._stubbed_layers)

    @staticmethod
    def _resolve(dotted_path: str) -> Any:
        """Import a dotted path 'pkg.mod.Class' and return the attribute.

        Trace: SPEC section 2 (collaborators referenced by name, resolved
            lazily so the skeleton stays acyclic and importable).
        """
        module_path, _, attr = dotted_path.rpartition(".")
        module = importlib.import_module(module_path)
        return getattr(module, attr)

    def assemble(self) -> "Stage4System":
        """Wire safety first, then L1..L7, then cross-cutting subsystems.

        Implemented: scalar core only. The L1-L7 tensor layers and the
        safety package remain stubs, so they are not constructed; they are
        recorded in `stubbed_layers` and surfaced honestly in the report.
        The scalar core (AgentLoop + agency subsystems + eval reporter) is
        fully wired and runnable.

        Trace: Blueprint Part 2 (layer stack), Part 6 (safety is wired
            before actuation); SPEC section 4.2 (config sections per layer).
        """
        self._stubbed_layers = sorted(LAYER_REGISTRY) + sorted(SAFETY_REGISTRY)
        loop_cls = self._resolve(SCALAR_CORE_REGISTRY["loop"])
        self._loop = loop_cls(self._config)
        for key in ("emergence", "criticality", "commitments", "scars"):
            cls = self._resolve(SCALAR_CORE_REGISTRY[key])
            self._agency[key] = cls(self._config)
        # Audit #40 ordering: emergence before criticality in RESIDUAL;
        # commitments before scars in MUTATE.
        self._loop.register("residual", self._agency["emergence"])
        self._loop.register("residual", self._agency["criticality"])
        self._loop.register("mutate", self._agency["commitments"])
        self._loop.register("mutate", self._agency["scars"])
        self._reporter = self._resolve(SCALAR_CORE_REGISTRY["reporter"])(
            self._config
        )
        self._estimator = self._resolve(SCALAR_CORE_REGISTRY["estimator"])(
            self._config
        )
        self._layers = {"core.agent_loop": self._loop, **self._agency}
        return self

    def fast_loop(self, observation: LayerIO) -> CycleRecord:
        """One cycle: sense -> perceive -> remember -> predict -> act.

        Implemented: delegates to the scalar AgentLoop's canonical
        six-stage cycle and repackages the result as a CycleRecord.

        Trace: Blueprint Part 4 (fast loop: world-model posterior, policy
            action every cycle); Part 2 (LayerIO flows bottom-up then the
            action flows out through the shield).
        """
        if self._loop is None:
            raise RuntimeError("call assemble() before fast_loop()")
        out = self._loop.step(observation)
        mode = out.meta.get("mode")
        record = CycleRecord(
            cycle=self._cycle,
            mode=mode.value if hasattr(mode, "value") else str(mode),
            cost=out.cost,
            uncertainty=out.uncertainty,
            action=out.meta.get("action"),
        )
        self._cycle += 1
        return record

    def medium_loop(self) -> None:
        """Every 1000 cycles: update world-model parameters, policy weights.

        Implemented: honest no-op while L5 (`world_model.rssm`) and L3
        (`policy.*`) are stubbed — there are no parameters to update. The
        cadence is preserved so the wiring is exercised.

        Trace: Blueprint Part 4 (medium loop); Eq #55 (policy gradient
            updates land here).
        """
        if self._cycle % MEDIUM_LOOP_CYCLES != 0:
            return
        return  # L3/L5 stubbed: no world-model or policy parameters yet.

    def slow_loop(self) -> None:
        """Every 10^6 cycles: MAML meta-parameter update.

        Implemented: honest no-op while `meta.maml` is stubbed.

        Trace: Blueprint Part 4 (slow loop); Eq #59 (MAML outer update);
            stage4.meta.maml.MAMLSlowLoop implements the math.
        """
        if self._cycle % SLOW_LOOP_CYCLES != 0:
            return
        return  # L7/meta stubbed: no meta-parameters yet.

    def run(self, cycles: int) -> List[CycleRecord]:
        """Run the full system for `cycles` fast cycles.

        Implemented: drives the scalar core; halts early (and reports
        honestly) when the energy ledger dies (audit #91). Medium/slow
        learning loops fire on their cadence as no-ops while their layers
        are stubbed.

        Trace: Blueprint Part 4 (three interleaved loops); Part 1.4
            (safety must hold for the whole run).
        """
        records: List[CycleRecord] = []
        observation = LayerIO(state=None, uncertainty=1.0, cost=0.0, meta={})
        for _ in range(max(0, cycles)):
            if not self._loop.energy.alive:
                break  # audit #91: the dead do not metabolize
            records.append(self.fast_loop(observation))
            self.medium_loop()
            self.slow_loop()
        return records

    def scalar_summary(self, cycles_requested: int) -> Dict[str, Any]:
        """Measured run summary for eval.report.render_scalar_metrics_table.

        Every value is read off the live subsystems — nothing is asserted
        (audit #137-#144 discipline).

        Trace: Blueprint section 5.2 (metrics from measurements);
            Phi-Lite feature #43.
        """
        loop = self._loop
        emergence = self._agency["emergence"]
        commitments = self._agency["commitments"]
        scars = self._agency["scars"]
        energy = loop.energy
        phases = len(emergence.phase_log) + (1 if emergence.active_phase else 0)
        changes = sum(
            c.change_count for c in commitments.commitments.values()
        )
        kills: List[str] = []
        if not energy.alive and loop.cycle < cycles_requested:
            kills.append("premature_death")
        if not self.falsification_test().passed:
            kills.append("falsification_regression")
        return {
            "seed": self._config.get("system.seed"),
            "budget": float(self._config.get("energy.budget")),
            "cycles_requested": cycles_requested,
            "cycles_completed": loop.cycle,
            "alive": energy.alive,
            "emergence_level": emergence.emergence_level,
            "emergence_debt": emergence.debt,
            "energy": energy.energy,
            "permanent_damage": energy.permanent_damage,
            "collapses": len(energy.collapse_log),
            "scars": scars.scar_count,
            "commitment_changes": changes,
            "commitment_levels": {
                key: c.level.name
                for key, c in commitments.commitments.items()
            },
            "meta_cognition": loop.meta_cognition,
            "phase_transitions": phases,
            "landauer_total": energy.landauer_total,
            "mode_counts": loop.mode_counts,
            "stage_estimate": self._estimator.current_estimate,
            "kill_criteria": kills,
        }

    def falsification_test(self) -> FalsificationResult:
        """Aggregate the seven layers' falsification tests.

        Implemented: over the assembled scalar core (the stubbed L1-L7
        layers have no tests to run and are reported as absent, not passed).

        Trace: Blueprint Part 0/5.3 (the Stage 4 claim is the conjunction
            of all layer criteria); SPEC section 4.1.
        """
        if self._loop is None:
            return FalsificationResult(
                name="stage4.system",
                passed=False,
                metric=0.0,
                threshold=0.0,
                detail="system not assembled",
            )
        results = [self._loop.falsification_test()]
        results.append(self._loop.energy.falsification_test())
        results.append(self._loop.modes.falsification_test())
        for subsystem in self._agency.values():
            results.append(subsystem.falsification_test())
        failures = [r for r in results if not r.passed]
        return FalsificationResult(
            name="stage4.system",
            passed=not failures,
            metric=float(len(failures)),
            threshold=0.0,
            detail="failed: " + ", ".join(r.name for r in failures)
            if failures else "all scalar-core falsification tests pass",
        )


def build_parser() -> argparse.ArgumentParser:
    """Build the CLI parser.

    Implemented: full. `--cycles` defaults to 200 (the v7.1 demonstration
    length); 0 is a dry assembly check.

    Trace: Blueprint section 7.2 (code structure: main.py entry); Part 10
        (evaluation harness runs before any claim).
    """
    parser = argparse.ArgumentParser(
        prog="stage4",
        description="Stage 4 AGI candidate research scaffold (not AGI).",
    )
    parser.add_argument("--cycles", type=int, default=200,
                        help="fast-loop cycles to run (0 = dry assembly check)")
    parser.add_argument("--seed", type=int, default=None,
                        help="override system.seed")
    parser.add_argument("--eval-only", action="store_true",
                        help="run the held-out evaluation protocol and exit")
    parser.add_argument("--config", type=str, default=None,
                        help="path to a JSON override file for the config")
    return parser


def main(argv: Optional[Sequence[str]] = None) -> int:
    """CLI entry: load config, assemble, run or evaluate.

    Implemented: full scalar runner. Exit codes:
      0 — clean run (or --eval-only / --cycles 0 assembly check),
      2 — a kill criterion fired (core falsification regression, or the
          system died before completing the requested cycles),
      1 — an error (bad config path, invalid JSON, validation failure).

    Trace: Blueprint section 7.2 (main.py); Part 10 (harness first); SPEC
        section 4.2 (load_config).
    """
    args = build_parser().parse_args(argv)
    overrides: Dict[str, Any] = {}
    try:
        if args.config is not None:
            with open(args.config, "r", encoding="utf-8") as handle:
                overrides = json.load(handle)
            if not isinstance(overrides, dict):
                raise ValueError("--config JSON must be an object")
        if args.seed is not None:
            overrides.setdefault("system", {})["seed"] = args.seed
        config = load_config(overrides)
    except (OSError, ValueError) as exc:
        print(f"stage4: config error: {exc}", file=sys.stderr)
        return 1

    try:
        system = Stage4System(config).assemble()
    except Exception as exc:  # noqa: BLE001 - honest failure surface
        print(f"stage4: assembly failed: {exc}", file=sys.stderr)
        return 1

    report = importlib.import_module("stage4.eval.report")

    if args.eval_only:
        # The full eval protocol (held-out tasks, transfer, benchmarks) is
        # stubbed; report that honestly and hold the stage floor.
        print(report.SCALAR_RUN_HEADER)
        print("eval-only: the Blueprint Part 5 protocol harness "
              "(eval.heldout, eval.transfer, eval.benchmarks) is stubbed,")
        print("so no protocol metrics exist and no stage claim can be made.")
        estimate = system._estimator.evaluate_window(
            f"eval-only-seed{config.get('system.seed')}", {}
        )
        print(f"stage_estimate: S{estimate:.1f} (S2.9 heritage floor; "
              "unchanged without a full metrics window)")
        return 0

    try:
        system.run(args.cycles)
    except Exception as exc:  # noqa: BLE001 - honest failure surface
        print(f"stage4: run failed at cycle {system.loop.cycle}: {exc}",
              file=sys.stderr)
        return 1

    system._estimator.evaluate_window(
        f"scalar-seed{config.get('system.seed')}-{args.cycles}", {}
    )
    summary = system.scalar_summary(args.cycles)
    print(report.render_scalar_metrics_table(summary))

    falsification = system.falsification_test()
    if not falsification.passed:
        print(f"KILL CRITERION FIRED: falsification regression "
              f"({falsification.detail})")
        return 2
    if "premature_death" in summary["kill_criteria"]:
        print("KILL CRITERION FIRED: premature_death "
              f"(died at cycle {summary['cycles_completed']} of "
              f"{summary['cycles_requested']} requested)")
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())


__all__ = [
    "LAYER_REGISTRY",
    "SAFETY_REGISTRY",
    "SCALAR_CORE_REGISTRY",
    "FAST_LOOP_CYCLES",
    "MEDIUM_LOOP_CYCLES",
    "SLOW_LOOP_CYCLES",
    "CycleRecord",
    "Stage4System",
    "build_parser",
    "main",
]
```

----------------------------------------

#### Directory: `stage4/stage4/memory`


### File: `__init__.py`

**Path:** `stage4/stage4/memory/__init__.py`
**Extension:** `.py`
**Size:** 1,471 bytes (1.44 KB)

```py
"""L4 Memory — episodic, semantic, crystal, narrative, ledger (Blueprint §3.4).

"Two stores, not one" (Blueprint §3.4), extended to five cooperating stores:

  episodic.py  — (z, a, r, t) tuples, MIPS retrieval, SDM + attention recall
  semantic.py  — MDL-compressed summaries; Levantine multi-generational memory
  crystal.py   — 8-D boundary slots, RFF projection, Hopfield recall
  narrative.py — NBC fixed: compress recent, structured, deep-time tagged
  ledger.py    — 64-D ring buffer with hash-ring indexing and drift metrics

Anti-tautology rule (Blueprint §3.4): recall excludes any slot within eps of
the query BY CONSTRUCTION (config memory.recall_exclusion_eps) — Phi-Lite's
`slots[:-1]` hack (feature #19, audit #19 of the tautology) is replaced by an
exclusion guarantee in the retrieval path itself.

Traceability:
  - Blueprint §3.4 (L4 memory), Part 5.2 (recall utility test)
  - Eq #31-44 (memory equations), Levantine #33-#39 (temporal/narrative)
  - Audit #19 (tautological recall), Audit #129-136 (NBC fixes)
"""

from __future__ import annotations

from stage4.memory.episodic import EpisodicMemory, Episode
from stage4.memory.semantic import SemanticMemory
from stage4.memory.crystal import CrystalMemory
from stage4.memory.narrative import NarrativeMemory
from stage4.memory.ledger import Ledger

__all__ = [
    "EpisodicMemory",
    "Episode",
    "SemanticMemory",
    "CrystalMemory",
    "NarrativeMemory",
    "Ledger",
]
```

----------------------------------------

### File: `crystal.py`

**Path:** `stage4/stage4/memory/crystal.py`
**Extension:** `.py`
**Size:** 5,428 bytes (5.30 KB)

```py
"""Crystal memory — 8-D boundary slots, RFF projection, Hopfield recall.

Upgrades Phi-Lite's crystal memory (features #18/#19, audit #19 tautology):

  - Random Fourier feature projection of the 64-D b vector into the 8-D
    boundary slot space: z(x) = [cos(w_i x), sin(w_i x)]_{i=1..4}  (Eq #31) —
    better than Phi-Lite's `b[:8]` slice.
  - Hopfield-style recall: z_rec = sum_i w_i z_i with
    w_i = softmax(-||z - z_i||^2 / 2 sigma^2)                       (Eq #32).
  - Consolidation via k-means++ over slots, replacing FIFO eviction (Eq #33).
  - Age-weighted eviction: priority(i) = e^{-lambda (t - t_i)} ||z_i||
    (Eq #34).
  - Recall exclusion BY CONSTRUCTION: any slot within
    memory.recall_exclusion_eps of the query never enters the softmax
    (Blueprint §3.4; replaces Phi-Lite's slots[:-1] patch, feature #19).

Slots are "boundary" slots: each carries the Markov-blanket coordinate of the
state when written (Levantine blankets, neuro.blankets named only).

Traceability:
  - Blueprint §3.4 (recall not tautological)
  - Eq #31 (RFF), #32 (Hopfield), #33 (k-means++), #34 (age-weighted eviction)
  - Audit #19 (tautological recall); Phi-Lite features #18/#19/#70
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, Dict, List, Optional, Tuple

from stage4.config import Config
from stage4.core.types import FalsificationResult, LayerIO

if TYPE_CHECKING:
    from phitensor import Tensor


CRYSTAL_DIM: int = 8   # 8-D boundary slots (config memory.crystal_slots=8 count)
NUM_FOURIER_PAIRS: int = 4  # Eq #31: 4 (cos, sin) pairs -> 8-D


@dataclass
class CrystalSlot:
    """One 8-D boundary slot with provenance for age-weighted eviction (Eq #34)."""

    z: Any                # phitensor.Tensor, shape (8,)
    written_cycle: int
    boundary_coordinate: Dict[str, float] = field(default_factory=dict)  # Markov blanket coord
    access_count: int = 0


class CrystalMemory:
    """8-slot crystal store with RFF writes and Hopfield recall.

    Trace: Eq #31-34; Blueprint §3.4; Audit #19
    """

    name: str = "memory.crystal"

    def __init__(self, config: Config) -> None:
        """Bind config: slot count=8, exclusion eps, eviction decay lambda.

        Trace: stage4.config DEFAULT_CONFIG["memory"]
        """
        self._config = config
        self.n_slots: int = int(config.get("memory.crystal_slots", 8))
        self.exclusion_eps: float = float(config.get("memory.recall_exclusion_eps", 1e-3))
        self._slots: List[CrystalSlot] = []

    def project(self, b: Tensor) -> Tensor:
        """Random Fourier feature projection b (64-D) -> z (8-D) (Eq #31).

        z(x) = [cos(w_i x), sin(w_i x)]_{i=1..4} with fixed seeded
        frequencies w_i (phitensor.rng.spawn('crystal_rff')).

        Trace: Eq #31
        """
        raise NotImplementedError(
            "spec: seeded frequencies w_i; concat [cos(w_i.b), sin(w_i.b)] for "
            "4 pairs -> 8-D"
        )

    def write(self, b: Tensor, cycle: int, boundary_coordinate: Optional[Dict[str, float]] = None) -> CrystalSlot:
        """Project and store; evict by age-weighted priority when full (Eq #34).

        Trace: Eq #31/#34
        """
        raise NotImplementedError(
            "spec: project(b) -> CrystalSlot; if full, evict lowest "
            "e^{-lambda(t-t_i)} ||z_i|| priority"
        )

    def recall(self, query_b: Tensor) -> Tuple[Tensor, int]:
        """Hopfield recall with exclusion by construction (Eq #32, audit #19).

        w_i = softmax(-||z - z_i||^2 / 2 sigma^2) over slots that are NOT
        within exclusion_eps of the query; returns (z_rec, n_excluded).

        Trace: Eq #32; Blueprint §3.4; Audit #19
        """
        raise NotImplementedError(
            "spec: filter eps-close slots BEFORE softmax; weighted sum "
            "z_rec = sum_i w_i z_i; report exclusions"
        )

    def consolidate(self) -> List[CrystalSlot]:
        """k-means++ consolidation over slots, replacing FIFO eviction (Eq #33).

        Periodic (CONSOLIDATE mode, core.modes named only): cluster slot
        history, keep centroids as the canonical crystals.

        Trace: Eq #33; SystemMode.CONSOLIDATE
        """
        raise NotImplementedError(
            "spec: k-means++ seeding + Lloyd iterations over slot history; "
            "centroids become new slots"
        )

    def eviction_priority(self, slot: CrystalSlot, now: int, lam: float) -> float:
        """priority(i) = e^{-lam (t - t_i)} ||z_i|| (Eq #34).

        Trace: Eq #34
        """
        raise NotImplementedError("spec: exp(-lam*(now-written)) * ||z||")

    def step(self, inp: LayerIO) -> LayerIO:
        """LayerIO contract: write/recall/consolidate per meta['op'].

        Trace: Blueprint Part 2, §3.4
        """
        raise NotImplementedError(
            "spec: dispatch on meta['op']; LayerIO(state=slots or recall, "
            "uncertainty=softmax entropy of recall weights, cost=op cost)"
        )

    def falsification_test(self) -> FalsificationResult:
        """Recall must never return an eps-close self-match (audit #19 kill test).

        Trace: Blueprint §3.4; Audit #19
        """
        raise NotImplementedError(
            "spec: adversarial self-query test; pass iff zero eps-close hits "
            "across probe set AND recall improves held-out reconstruction"
        )
```

----------------------------------------

### File: `episodic.py`

**Path:** `stage4/stage4/memory/episodic.py`
**Extension:** `.py`
**Size:** 5,482 bytes (5.35 KB)

```py
"""Episodic memory — (z, a, r, t) tuples with MIPS retrieval (Blueprint §3.4).

Episodes are (z_t, a_t, r_t, t) tuples in a vector store (config
memory.episodic_dim=128, capacity=100_000). Retrieval is maximum
inner-product search, with two structured access modes:

  - Sparse distributed memory addressing: a = b . H, read/write within
    radius r (Eq #40);
  - attention over recent ledger states: alpha_i = softmax(q . k_i / sqrt(d))
    (Eq #41).

Anti-tautology (Blueprint §3.4): retrieved episodes exclude any entry whose
key is within recall_exclusion_eps of the query, BY CONSTRUCTION of the
retrieval path — not by post-hoc slot slicing (Phi-Lite feature #19 replaced).

Recall utility test (Blueprint §3.4): if recall does not improve a held-out
task, memory is decorative and fails falsification.

Traceability:
  - Blueprint §3.4 (episodic store), Part 5.2
  - Eq #40 (SDM), Eq #41 (attention over ledger), Eq #45 (RND novelty hook)
  - Audit #19 (tautological recall), Audit #136 (no retrieval)
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, Dict, List, Optional, Tuple

from stage4.config import Config
from stage4.core.types import FalsificationResult, LayerIO

if TYPE_CHECKING:
    from phitensor import Tensor


@dataclass
class Episode:
    """One episodic tuple (z_t, a_t, r_t, t) (Blueprint §3.4)."""

    z: Any        # phitensor.Tensor, shape (episodic_dim,) — fused percept latent
    action: Any   # action taken
    reward: float
    t: int        # cycle index
    meta: Dict[str, Any] = field(default_factory=dict)


@dataclass
class RecallResult:
    """Retrieval output; ``excluded`` counts eps-close tautological matches."""

    episodes: List[Episode]
    scores: List[float]
    excluded: int  # audit #19: must be observable, not hidden


class EpisodicMemory:
    """Vector episodic store with MIPS retrieval and exclusion-by-construction.

    Trace: Blueprint §3.4; Eq #40/#41; Audit #19/#136
    """

    name: str = "memory.episodic"

    def __init__(self, config: Config) -> None:
        """Bind config: dim=128, capacity=100k, recall_exclusion_eps=1e-3.

        Trace: stage4.config DEFAULT_CONFIG["memory"]
        """
        self._config = config
        self.dim: int = int(config.get("memory.episodic_dim", 128))
        self.capacity: int = int(config.get("memory.episodic_capacity", 100_000))
        self.exclusion_eps: float = float(config.get("memory.recall_exclusion_eps", 1e-3))
        self._episodes: List[Episode] = []

    def write(self, episode: Episode) -> None:
        """Append an episode; capacity eviction delegates to crystal consolidation.

        Trace: Blueprint §3.4; Eq #33 (consolidation partner)
        """
        raise NotImplementedError(
            "spec: append; at capacity trigger consolidation handoff to "
            "memory.crystal (same-package collaborator)"
        )

    def mips_recall(self, query: Tensor, top_k: int = 8) -> RecallResult:
        """Maximum inner-product search with eps-exclusion BY CONSTRUCTION.

        Any stored key within recall_exclusion_eps of the query is excluded
        before ranking (audit #19 fix); the count of exclusions is reported.

        Trace: Blueprint §3.4; Audit #19
        """
        raise NotImplementedError(
            "spec: score = q.k_i; filter ||k_i - q|| < exclusion_eps first; "
            "top-k by score; return RecallResult(excluded=n)"
        )

    def sdm_address(self, key: Tensor, radius: float) -> List[int]:
        """Sparse distributed memory addressing a = b . H within radius r (Eq #40).

        Trace: Eq #40
        """
        raise NotImplementedError(
            "spec: hard-address via random projection matrix H; return indices "
            "of addresses within Hamming/Euclidean radius"
        )

    def attention_recall(self, query: Tensor, keys: List[Tensor]) -> Tensor:
        """Attention over stored states: alpha_i = softmax(q . k_i / sqrt(d)) (Eq #41).

        Trace: Eq #41
        """
        raise NotImplementedError(
            "spec: phitensor.ops.scaled_dot_product_attention over recent keys; "
            "weighted value readout, top-k recent states"
        )

    def novelty_bonus(self, z: Tensor) -> float:
        """RND-style novelty r_cur = ||phi(z) - phi_hat(z)||^2 for exploration (Eq #45).

        Hook consumed by policy intrinsic rewards (Blueprint §3.7, named only).

        Trace: Eq #45; Blueprint §3.7
        """
        raise NotImplementedError(
            "spec: fixed random target network phi vs trained predictor phi_hat; "
            "squared error is the bonus"
        )

    def step(self, inp: LayerIO) -> LayerIO:
        """LayerIO contract: write current tuple and/or recall for a query.

        Trace: Blueprint Part 2, §3.4
        """
        raise NotImplementedError(
            "spec: meta['op'] in {'write','recall'}; LayerIO(state=RecallResult "
            "or None, uncertainty=retrieval score variance, cost=search cost)"
        )

    def falsification_test(self) -> FalsificationResult:
        """Blueprint §3.4: recall must improve a held-out task, else decorative.

        Trace: Blueprint §3.4 (test), Part 5.2
        """
        raise NotImplementedError(
            "spec: held-out task performance with vs without recall; pass iff "
            "improvement > 0 beyond noise; also assert exclusion_eps honored"
        )
```

----------------------------------------

### File: `ledger.py`

**Path:** `stage4/stage4/memory/ledger.py`
**Extension:** `.py`
**Size:** 5,873 bytes (5.74 KB)

```py
"""Ledger — 64-D ring buffer with hash-ring indexing and drift metrics.

Upgrades Phi-Lite's FIFO ledger (feature #20, rotation #74) with:

  - Rotating hash ring: slot index = h(b_t) mod N, replacing FIFO (Eq #36).
    Capacity from config memory.ledger_capacity (2000).
  - Mahalanobis novelty: d = sqrt((b - mu)^T Sigma^{-1} (b - mu)) (Eq #37),
    replacing Phi-Lite's plain distance-to-centroid (feature #21).
  - Spectral drift: top-3 eigenmodes of ledger covariance track regime drift
    (Eq #38).
  - Z-score fingerprint: fp(b) = sign(b - mu) in {-1,+1}^64, Hamming distance
    for regime change (Eq #39).
  - Adaptive-baseline novelty z: mu = EMA(d), sigma = sqrt(EMA(d^2))
    (Eq #25) feeding the horizon selection (meta.controller, named only).

Traceability:
  - Eq #25 (adaptive baseline), #36 (hash ring), #37 (Mahalanobis),
    #38 (spectral drift), #39 (z-score fingerprint)
  - Phi-Lite features #20/#21/#74 (ledger, novelty, rotation) — replaced
  - Audit #21/#22 (seeded determinism of the hash ring)
"""

from __future__ import annotations

import hashlib
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, Dict, List, Optional, Tuple

from stage4.config import Config
from stage4.core.types import FalsificationResult, LayerIO

if TYPE_CHECKING:
    from phitensor import Tensor


LEDGER_DIM: int = 64  # 64-D b vectors (Phi-Lite ledger width)


@dataclass
class LedgerEntry:
    """One ledger row: the 64-D b vector plus its fingerprint and cycle."""

    b: Any                     # phitensor.Tensor, shape (64,)
    cycle: int
    fingerprint: Any = None    # phitensor.Tensor in {-1,+1}^64 (Eq #39)
    slot_hash: int = 0         # h(b_t) mod N (Eq #36)


@dataclass
class DriftReport:
    """Regime-drift diagnostics from the spectral tracker (Eq #38/#39)."""

    top_eigenvalues: List[float]       # top-3 of ledger covariance
    eigenmode_delta: float             # rotation of top eigenmodes vs window
    hamming_shift: float               # mean fingerprint Hamming drift
    regime_changed: bool


class Ledger:
    """64-D rotating hash-ring ledger with novelty and drift statistics.

    Trace: Eq #25/#36-39; Blueprint §3.4
    """

    name: str = "memory.ledger"

    def __init__(self, config: Config) -> None:
        """Bind config: capacity=2000, drift thresholds, EMA rate for Eq #25.

        Trace: stage4.config DEFAULT_CONFIG["memory"].ledger_capacity
        """
        self._config = config
        self.capacity: int = int(config.get("memory.ledger_capacity", 2000))
        self.dim: int = LEDGER_DIM
        self._ring: List[Optional[LedgerEntry]] = []

    def hash_slot(self, b: Tensor) -> int:
        """Ring index h(b_t) mod N (Eq #36); deterministic, seeded.

        Trace: Eq #36; Audit #21/#22
        """
        raise NotImplementedError(
            "spec: stable hash of quantized b (stdlib hashlib on byte view); "
            "index = h mod capacity"
        )

    def append(self, b: Tensor, cycle: int) -> LedgerEntry:
        """Write b at its hash-ring slot (Eq #36) with fingerprint (Eq #39).

        Trace: Eq #36/#39
        """
        raise NotImplementedError(
            "spec: slot = hash_slot(b); overwrite ring[slot]; compute "
            "fingerprint sign(b - mu)"
        )

    def mahalanobis_novelty(self, b: Tensor) -> float:
        """d = sqrt((b - mu)^T Sigma^{-1} (b - mu)) over the ring (Eq #37).

        Trace: Eq #37; replaces Phi-Lite feature #21 distance-to-centroid
        """
        raise NotImplementedError(
            "spec: running mean mu and covariance Sigma (regularized inverse); "
            "Mahalanobis distance"
        )

    def adaptive_z(self, d: float) -> float:
        """z_t = (d_t - mu_t)/sigma_t with EMA baselines (Eq #25).

        mu_t = EMA_alpha(d), sigma_t = sqrt(EMA_alpha(d^2)). Feeds horizon
        selection in meta.controller (named only; Phi-Lite feature #22 made
        principled).

        Trace: Eq #25
        """
        raise NotImplementedError("spec: EMA mean/second-moment; return z-score")

    def spectral_drift(self, window: int = 256) -> DriftReport:
        """Top-3 eigenmodes of ledger covariance and their rotation (Eq #38).

        Combines with fingerprint Hamming shift (Eq #39) to declare regime
        change.

        Trace: Eq #38/#39
        """
        raise NotImplementedError(
            "spec: covariance of last `window` entries; power-iteration top-3; "
            "compare to previous window; Hamming shift of fingerprints"
        )

    def fingerprint(self, b: Tensor) -> Tensor:
        """fp(b) = sign(b - mu) in {-1, +1}^64 (Eq #39).

        Trace: Eq #39
        """
        raise NotImplementedError("spec: sign(b - running_mean) as +-1 tensor")

    def hamming(self, fp_a: Tensor, fp_b: Tensor) -> int:
        """Hamming distance between two z-score fingerprints (Eq #39).

        Trace: Eq #39
        """
        raise NotImplementedError("spec: count of sign disagreements / 1")

    def step(self, inp: LayerIO) -> LayerIO:
        """LayerIO contract: append b and return novelty/drift statistics.

        Uncertainty is the adaptive z-score magnitude; cost is the O(N)
        covariance update.

        Trace: Blueprint Part 2; Eq #25/#37
        """
        raise NotImplementedError(
            "spec: append -> mahalanobis_novelty -> adaptive_z; LayerIO("
            "state={'novelty': d, 'z': z}, uncertainty=|z|, cost=update cost)"
        )

    def falsification_test(self) -> FalsificationResult:
        """Novelty metric must rank injected novel states above routine states.

        Trace: Eq #37; Blueprint Part 5.2
        """
        raise NotImplementedError(
            "spec: inject synthetic regime shift; pass iff Mahalanobis novelty "
            "and DriftReport flag it above routine baseline"
        )
```

----------------------------------------

### File: `narrative.py`

**Path:** `stage4/stage4/memory/narrative.py`
**Extension:** `.py`
**Size:** 8,716 bytes (8.51 KB)

```py
"""Narrative memory — NBC fixed (audit #129-136), Levantine deep-time tags (L33/L37/L38/L39).

Narrative-bound compression, corrected against every audited failure:

  #129 "compression keeps oldest, discards recent" -> compresses the RECENT
       window and keeps it retrievable; retention selects by utility, never
       by recency-discard.
  #130 "summary is simplistic" -> structured Narrative dataclass (events,
       modes, causes, tags), not a string blob.
  #131 "mode sequence uses current mode repeated" -> stores the actual mode
       trajectory over the compressed window.
  #132 "narrative memory is never used" -> retrieval API consumed by the
       self-model and meta-controller (named only); falsification requires use.
  #133 "compression interval is fixed" -> adaptive interval driven by surprise
       (memory.ledger novelty, same-package collaborator) around config
       nbc.compression_interval.
  #134 "retention rate can round to 0" -> hard floor nbc.min_retained (8).
  #135 "raw maxlen 50 limits compression" -> window sized by config, not the
       old 50-cap.
  #136 "no semantic content or retrieval" -> hands summaries to
       memory.semantic (MDL store) and supports tag/symbol retrieval.

Levantine integration:
  - L33/L39 deep-time tags: narratives are tagged with archaic themes from
    config nbc.deep_time_tags = [ochre, burial, law, prophetic].
  - L37 ritual consolidation: repeated experience patterns are compressed
    into narrative form (ritual repetition stabilizes memory).
  - L38 ancestral weighting: historical narratives bias consolidation
    priority, so ancestral content survives.

Also hosts narrative-side compression equations: LZ on the symbol stream
(Eq #42), Bloom-filter template-lock detection support (Eq #43), and the
narrative trie over recent utterances (Eq #44).

Traceability:
  - Audit #129-136 (NBC fixes); Levantine #33/#37/#38/#39
  - Eq #42 (LZ), #43 (Bloom), #44 (trie); Blueprint §3.4
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

from stage4.config import Config
from stage4.core.types import FalsificationResult, LayerIO, SystemMode


@dataclass
class Narrative:
    """Structured narrative unit (audit #130: not a blob).

    ``mode_sequence`` records the REAL mode trajectory (audit #131);
    ``deep_time_tags`` carry the Levantine archaic themes (L33/L39);
    ``ancestral_weight`` biases consolidation priority (L38).
    """

    window: Tuple[int, int]            # cycle span compressed
    events: List[Dict[str, Any]]       # structured event records
    mode_sequence: List[SystemMode]    # actual trajectory, audit #131
    deep_time_tags: List[str] = field(default_factory=list)  # L33/L39
    ancestral_weight: float = 1.0      # L38
    generation: int = 0                # L34 handoff to semantic memory


class NarrativeMemory:
    """NBC fixed: compress recent (never discard-recent), structured, tagged.

    Trace: Audit #129-136; Levantine #33/#37/#38/#39; Eq #42-44
    """

    name: str = "memory.narrative"

    def __init__(self, config: Config) -> None:
        """Bind config: compression_interval, retention_rate, min_retained, deep_time_tags.

        Trace: stage4.config DEFAULT_CONFIG["nbc"]; Audit #133/#134
        """
        self._config = config
        self.base_interval: int = int(config.get("nbc.compression_interval", 5))
        self.retention_rate: float = float(config.get("nbc.retention_rate", 0.8))
        self.min_retained: int = int(config.get("nbc.min_retained", 8))
        self.deep_time_tags: List[str] = list(
            config.get("nbc.deep_time_tags", ["ochre", "burial", "law", "prophetic"])
        )
        self._narratives: List[Narrative] = []

    def adaptive_interval(self, surprise: float) -> int:
        """Compression interval modulated by surprise (audit #133).

        High surprise compresses sooner (finer narrative granularity in
        interesting regimes); bounded away from 1.

        Trace: Audit #133; config nbc.compression_interval
        """
        raise NotImplementedError(
            "spec: interval = clamp(round(base / (1 + surprise)), 2, 4*base)"
        )

    def compress_recent(self, window: List[Dict[str, Any]], mode_sequence: List[SystemMode]) -> Narrative:
        """Compress the RECENT window into a structured Narrative (audit #129/#130/#131).

        Never discards recent experience to keep the oldest (the v7.1 bug);
        the recent window is what gets compressed and retained.

        Trace: Audit #129/#130/#131
        """
        raise NotImplementedError(
            "spec: summarize recent window into events; attach REAL "
            "mode_sequence; LZ-compress symbol stream (Eq #42)"
        )

    def ritual_consolidate(self, pattern: List[Dict[str, Any]], repetitions: int) -> Optional[Narrative]:
        """Levantine L37: repeated experience patterns consolidate into narrative.

        When the same pattern recurs (repetitions >= threshold), compress it
        into a narrative unit regardless of the adaptive interval — ritual
        repetition stabilizes identity and memory.

        Trace: Levantine #37
        """
        raise NotImplementedError(
            "spec: detect repetition count; compress pattern into Narrative "
            "with ritual tag; else None"
        )

    def tag_deep_time(self, narrative: Narrative) -> Narrative:
        """Attach Levantine deep-time tags (ochre/burial/law/prophetic) (L33/L39).

        Trace: Levantine #33/#39; config nbc.deep_time_tags
        """
        raise NotImplementedError(
            "spec: match narrative content against deep-time theme lexicon; "
            "attach matching tags"
        )

    def ancestral_weighting(self, narrative: Narrative, history: List[Narrative]) -> float:
        """Levantine L38: bias consolidation priority toward ancestral values.

        Narratives consistent with long-lived historical narratives receive
        higher retention priority — bedrock-of-law behavior.

        Trace: Levantine #38
        """
        raise NotImplementedError(
            "spec: similarity to oldest retained narratives -> weight in "
            "[1.0, w_max]; store on narrative.ancestral_weight"
        )

    def retain(self, narrative: Narrative) -> None:
        """Retention with a hard floor (audit #134) and ancestral weighting (L38).

        Trace: Audit #134; Levantine #38
        """
        raise NotImplementedError(
            "spec: keep max(ceil(retention_rate * n), min_retained) narratives, "
            "ranked by ancestral_weight * recency utility; never round to 0"
        )

    def retrieve(self, query: Dict[str, Any]) -> List[Narrative]:
        """Tag/keyword/mode retrieval — the memory must be USED (audit #132/#136).

        Consumers: self_model (identity narratives) and meta.goal_gen
        (deep-time goal priors), named only.

        Trace: Audit #132/#136
        """
        raise NotImplementedError(
            "spec: filter by deep_time_tags / mode / keyword; ranked by "
            "ancestral_weight"
        )

    def template_lock_check(self, utterances: List[str]) -> float:
        """Bloom-filter repeat detection over utterance bag (Eq #43).

        FP rate (1 - e^{-kn/m})^k; feeds the failure-mode-7 template-lock
        metric (safety/template_lock_max, named only).

        Trace: Eq #43; Blueprint failure mode 7
        """
        raise NotImplementedError(
            "spec: Bloom filter over utterance hashes; return observed repeat "
            "rate corrected for FP rate"
        )

    def narrative_trie(self, utterances: List[str]) -> Dict[str, Any]:
        """Prefix trie over last 256 utterances; log branching factor (Eq #44).

        Trace: Eq #44
        """
        raise NotImplementedError("spec: build trie; report branching factor stats")

    def step(self, inp: LayerIO) -> LayerIO:
        """LayerIO contract: compress/retrieve per meta['op'].

        Trace: Blueprint Part 2, §3.4
        """
        raise NotImplementedError(
            "spec: dispatch compress_recent/retrieve; LayerIO(state=narratives, "
            "uncertainty=compression residual, cost=compression cost)"
        )

    def falsification_test(self) -> FalsificationResult:
        """NBC must retain recent information and be used downstream (audit #129/#132).

        Trace: Audit #129/#132; Blueprint Part 5.2
        """
        raise NotImplementedError(
            "spec: probe recall of recent compressed content; pass iff recent "
            "retrievable AND retrieval is exercised by a downstream consumer"
        )
```

----------------------------------------

### File: `semantic.py`

**Path:** `stage4/stage4/memory/semantic.py`
**Extension:** `.py`
**Size:** 5,139 bytes (5.02 KB)

```py
"""Semantic memory — MDL-compressed summaries + generational retention (Blueprint §3.4).

Compressed summaries via minimum description length:

    n* = argmin_n [ L(n) + L(D | n) ]                           (Eq #35)

i.e. pick the summary minimizing description length of the summary plus the
data given the summary, bounded by config memory.mdl_max_summary_bits (4096).

Levantine temporal integration:
  - L34 multi-generational retention: when neuro.temporal_discount > 0.9
    (FOXP2 flat discounting, L35), decay is switched to a low generational
    rate so summaries persist across "generations" of consolidation.
  - L35: gamma -> 1 flat discounting is read from neuro.temporal_discount,
    never hard-coded.

Traceability:
  - Blueprint §3.4 (semantic store)
  - Eq #35 (MDL), Eq #42 (LZ on symbol stream — compression backend)
  - Levantine #34 (multi-generational retention), #35 (flat discounting)
  - Audit #135 (raw capacity limits compression), #136 (no semantic content)
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

from stage4.config import Config
from stage4.core.types import FalsificationResult, LayerIO


@dataclass
class Summary:
    """An MDL-optimal compressed summary of a batch of episodes."""

    content: str              # structured summary text/symbols
    description_length: int   # L(n) + L(D|n) in bits (Eq #35)
    source_span: Tuple[int, int]  # cycle range compressed
    generation: int = 0       # Levantine L34: generational counter
    tags: List[str] = field(default_factory=list)


class SemanticMemory:
    """MDL semantic store with Levantine multi-generational retention.

    Trace: Blueprint §3.4; Eq #35; Levantine #34/#35; Audit #135/#136
    """

    name: str = "memory.semantic"

    def __init__(self, config: Config) -> None:
        """Bind config: mdl_max_summary_bits, temporal_discount for L34 gating.

        Trace: config memory.mdl_max_summary_bits, neuro.temporal_discount
        """
        self._config = config
        self.max_summary_bits: int = int(config.get("memory.mdl_max_summary_bits", 4096))
        self.temporal_discount: float = float(config.get("neuro.temporal_discount", 0.9))
        self._summaries: List[Summary] = []

    def description_length(self, summary: Summary, data: List[Any]) -> int:
        """Two-part MDL code length L(n) + L(D | n) (Eq #35).

        Trace: Eq #35
        """
        raise NotImplementedError(
            "spec: L(n) = bits to encode summary (LZ-style, Eq #42 backend); "
            "L(D|n) = bits to encode residuals given summary"
        )

    def compress(self, data: List[Any]) -> Summary:
        """Choose n* = argmin_n [L(n) + L(D|n)] over candidate summaries (Eq #35).

        Candidate summaries come from narrative compression (memory.narrative,
        same-package collaborator); the search is bounded by
        mdl_max_summary_bits.

        Trace: Eq #35; Audit #135
        """
        raise NotImplementedError(
            "spec: enumerate candidate compressions; pick min two-part code "
            "length; respect mdl_max_summary_bits"
        )

    def generational_decay(self) -> float:
        """Retention decay rate; Levantine L34 gate on temporal_discount > 0.9.

        When the FOXP2-style flat discount is active (L35), decay switches to
        the low generational rate so semantic memory survives across
        consolidation generations; otherwise standard decay applies.

        Trace: Levantine #34/#35
        """
        raise NotImplementedError(
            "spec: if temporal_discount > 0.9: return low generational decay; "
            "else standard rate; log the regime"
        )

    def retain(self, summary: Summary) -> None:
        """Store a summary, aging existing ones by generational_decay().

        Trace: Levantine #34; Eq #35
        """
        raise NotImplementedError(
            "spec: append summary with generation counter; decay older entries; "
            "evict only below retention floor"
        )

    def retrieve(self, query: str) -> List[Summary]:
        """Semantic retrieval over summaries (audit #136: content must exist).

        Trace: Audit #136
        """
        raise NotImplementedError(
            "spec: tag/symbol match over summaries ranked by generational weight"
        )

    def step(self, inp: LayerIO) -> LayerIO:
        """LayerIO contract: compress/retrieve per meta['op'].

        Trace: Blueprint Part 2, §3.4
        """
        raise NotImplementedError(
            "spec: dispatch compress/retrieve; LayerIO(state=summaries, "
            "uncertainty=description-length margin, cost=compression cost)"
        )

    def falsification_test(self) -> FalsificationResult:
        """Compression must be lossy-but-useful: summary reconstruction beats capacity-only baseline.

        Trace: Blueprint §3.4, Part 5.2
        """
        raise NotImplementedError(
            "spec: reconstruct held-out episodes from summaries; pass iff "
            "residual error < no-memory baseline"
        )
```

----------------------------------------

##### Directory: `stage4/stage4/memory/__pycache__`


#### Directory: `stage4/stage4/perception`


### File: `__init__.py`

**Path:** `stage4/stage4/perception/__init__.py`
**Extension:** `.py`
**Size:** 1,666 bytes (1.63 KB)

```py
"""L2 Perception layer — real encoders and sensor adapters (Blueprint §3.1).

This package replaces Phi-Lite's ``mock_z()`` sine-wave sensors with real
perception: a contrastive vision encoder, a predictive-coding audio encoder,
cross-attention fusion (never concatenation), and a sensor-adapter interface
whose mock implementation is clearly labeled and strictly non-default
(Blueprint Part 10, rule 1: "kill the mock sensors").

Modules:
  vision_encoder.py — SimCLR-style contrastive CNN/ViT encoder, z_v in R^128
  audio_encoder.py  — mel-spectrogram + 1D CNN encoder, predictive coding loss
  fusion.py         — cross-attention multimodal fusion (Eq #69-71)
  sensors.py        — real sensor adapter interface + labeled mock fallback

Layer contract: everything emitted is a ``LayerIO`` carrying
(state, uncertainty, cost) — nothing crosses to L5 without an uncertainty
attached (Blueprint Part 2).

Traceability:
  - Blueprint §3.1 (L2 perception), Part 10 rule 1 (kill mock sensors)
  - Eq #69-71 (attention), Eq #16 (precision-weighted predictive coding)
  - Audit #4 (no sensors/embodiment), Audit #46/#59 (mock sensors)
"""

from __future__ import annotations

from stage4.perception.vision_encoder import VisionEncoder
from stage4.perception.audio_encoder import AudioEncoder
from stage4.perception.fusion import CrossAttentionFusion
from stage4.perception.sensors import (
    SensorAdapter,
    RealSensorAdapter,
    MockSensorAdapter,
    PerceptionLayer,
)

__all__ = [
    "VisionEncoder",
    "AudioEncoder",
    "CrossAttentionFusion",
    "SensorAdapter",
    "RealSensorAdapter",
    "MockSensorAdapter",
    "PerceptionLayer",
]
```

----------------------------------------

### File: `audio_encoder.py`

**Path:** `stage4/stage4/perception/audio_encoder.py`
**Extension:** `.py`
**Size:** 5,223 bytes (5.10 KB)

```py
"""Predictive-coding audio encoder — mel + 1D CNN, z_a in R^128 (Blueprint §3.1).

Pipeline: raw waveform -> mel-spectrogram -> 1D CNN -> z_a in R^128. Trained
with a predictive coding loss: the encoder must predict the next mel frame
from context, with precision-weighted residuals (Eq #16):

    epsilon_i = Pi_i * (o_i - g_i(b_hat))     (Eq #16)

where precision Pi_i is derived from per-band reliability. Held-out test is
identical in spirit to vision: beat a matched random encoder by >= 2 sigma
(Blueprint §3.1).

Traceability:
  - Blueprint §3.1 (L2 audio), Part 10 rule 1
  - Eq #16 (precision-weighted predictive coding)
  - Audit #4 (no sensors), Audit #46/#59 (mock sensors removed)
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, Dict, Tuple

from stage4.config import Config
from stage4.core.types import FalsificationResult, LayerIO

if TYPE_CHECKING:
    from phitensor import Tensor


AUDIO_LATENT_DIM: int = 128  # z_a in R^128 (Blueprint §3.1)
DEFAULT_MEL_BINS: int = 64


@dataclass
class AudioChunk:
    """A raw audio window with provenance; never synthesized mock data."""

    waveform: Any  # phitensor.Tensor, shape (N, T) PCM samples
    sample_rate_hz: int
    provenance: Dict[str, Any]


class AudioEncoder:
    """Mel-spectrogram + 1D CNN audio encoder with predictive coding loss.

    Trace: Blueprint §3.1; Eq #16; Audit #4
    """

    name: str = "perception.audio"

    def __init__(self, config: Config) -> None:
        """Bind config: latent dim (128), mel bins, CNN kernel widths, precision floor.

        Trace: Blueprint §3.1; stage4.config
        """
        self._config = config
        self.latent_dim: int = AUDIO_LATENT_DIM
        self.mel_bins: int = int(config.get("perception.mel_bins", DEFAULT_MEL_BINS))

    def mel_spectrogram(self, chunk: AudioChunk) -> Tensor:
        """Compute the log-mel spectrogram of a raw waveform.

        Args:
            chunk: raw PCM window with sample rate.

        Returns:
            Tensor of shape (N, mel_bins, frames), log-scaled.

        Trace: Blueprint §3.1 (mel-spectrogram front-end)
        """
        raise NotImplementedError(
            "spec: STFT -> mel filterbank -> log; pure phitensor ops, no librosa"
        )

    def encode(self, mel: Tensor) -> Tensor:
        """Encode a log-mel spectrogram into z_a in R^128.

        Args:
            mel: Tensor of shape (N, mel_bins, frames).

        Returns:
            Tensor of shape (N, 128).

        Trace: Blueprint §3.1 (1D CNN encoder)
        """
        raise NotImplementedError(
            "spec: stack of phitensor.ops.conv1d + gelu + layernorm, temporal "
            "mean-pool -> linear to R^128"
        )

    def predictive_coding_loss(self, context: Tensor, target: Tensor) -> Tensor:
        """Precision-weighted next-frame prediction loss (Eq #16).

        Args:
            context: encoder latents for frames 1..t-1.
            target: encoder latents (or mel frames) for frame t.

        Returns:
            Scalar loss: sum_i Pi_i * (o_i - g_i(b_hat))^2 with per-band
            precision Pi from reliability estimates.

        Trace: Blueprint §3.1; Eq #16
        """
        raise NotImplementedError(
            "spec: predict next frame from context; weight squared residuals by "
            "learned per-band precision Pi (Eq #16)"
        )

    def update_precision(self, residuals: Tensor) -> Tensor:
        """Update per-band precision estimates Pi from recent residuals.

        Precision is inverse residual variance with a config-floored minimum,
        preventing overconfident bands (Eq #16 reliability weighting).

        Trace: Eq #16
        """
        raise NotImplementedError(
            "spec: Pi_i = 1 / max(var(residual_i), precision_floor); EMA update"
        )

    def train_step(self, chunk: AudioChunk) -> float:
        """One predictive-coding optimization step; returns scalar loss.

        Runs in the medium learning loop (Blueprint Part 4).

        Trace: Blueprint §3.1, Part 4
        """
        raise NotImplementedError(
            "spec: mel -> encode -> predictive_coding_loss -> autograd.backward "
            "-> optimizer step"
        )

    def step(self, inp: LayerIO) -> LayerIO:
        """LayerIO contract: waveform in -> (z_a, uncertainty, cost) out.

        Uncertainty is the total predictive variance of the next-frame head
        (aleatoric part reported here; the epistemic split lives in
        self_model/calibration.py, Eq #84).

        Trace: Blueprint Part 2; Eq #16; Eq #84 (split hosted downstream)
        """
        raise NotImplementedError(
            "spec: mel_spectrogram -> encode -> LayerIO(state=z_a, "
            "uncertainty=mean residual precision^-1, cost=flops)"
        )

    def falsification_test(self) -> FalsificationResult:
        """Blueprint §3.1 test: beat a matched random encoder by >= 2 sigma.

        Trace: Blueprint §3.1 (test), Part 5.3
        """
        raise NotImplementedError(
            "spec: held-out next-chunk prediction error vs random-encoder "
            "baseline; pass iff improvement >= 2 sigma"
        )
```

----------------------------------------

### File: `fusion.py`

**Path:** `stage4/stage4/perception/fusion.py`
**Extension:** `.py`
**Size:** 5,791 bytes (5.66 KB)

```py
"""Cross-attention multimodal fusion — NOT concatenation (Blueprint §3.1).

Fuses the vision latent z_v and audio latent z_a into a single percept z by
cross-attention:

    z = Attn(W_v z_v, W_a z_a, W_a z_a)          (Blueprint §3.1)

implemented as scaled dot-product attention (Eq #69):

    Attn(Q, K, V) = softmax(Q K^T / sqrt(d)) V   (Eq #69)

with a multi-head variant (Eq #70, 4 heads) and an optional
information-gain-weighted attention alpha = I(o; b | model) (Eq #71) that
routes more weight to the modality currently reducing uncertainty.

Concatenation is explicitly forbidden: it couples the layers without
uncertainty-aware gating and was one of Phi-Lite's silent lies (Blueprint
Part 2: every layer outputs a variance).

Traceability:
  - Blueprint §3.1 (fusion), Part 2 (uncertainty propagation)
  - Eq #69 (scaled dot-product attention), Eq #70 (multi-head), Eq #71 (info-gain attention)
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, Dict, List, Optional

from stage4.config import Config
from stage4.core.types import FalsificationResult, LayerIO

if TYPE_CHECKING:
    from phitensor import Tensor


NUM_HEADS: int = 4  # Eq #70


@dataclass
class ModalityInput:
    """One modality's latent plus its calibrated uncertainty.

    Fusion must down-weight high-variance modalities (uncertainty-aware
    gating, Blueprint Part 2); a modality without an uncertainty is rejected.
    """

    modality: str            # "vision" | "audio" | future modalities
    latent: Any              # phitensor.Tensor, shape (N, 128)
    uncertainty: float       # variance-like scalar in [0, inf)


class CrossAttentionFusion:
    """Cross-attention fusion of modality latents into one percept z.

    Trace: Blueprint §3.1; Eq #69-71; Part 2 (uncertainty contract)
    """

    name: str = "perception.fusion"

    def __init__(self, config: Config) -> None:
        """Bind config: number of heads (4), latent dim, info-gain toggle.

        Trace: Eq #70; stage4.config
        """
        self._config = config
        self.num_heads: int = int(config.get("perception.fusion_heads", NUM_HEADS))

    def attention(self, query: Tensor, key: Tensor, value: Tensor) -> Tensor:
        """Scaled dot-product attention (Eq #69).

        Computes softmax(Q K^T / sqrt(d)) V via
        ``phitensor.ops.scaled_dot_product_attention``.

        Trace: Eq #69
        """
        raise NotImplementedError(
            "spec: softmax(QK^T/sqrt(d)) V via phitensor.ops."
            "scaled_dot_product_attention(q, k, v, mask=None)"
        )

    def multi_head(self, query: Tensor, key: Tensor, value: Tensor) -> Tensor:
        """Multi-head attention: split into 4 heads, attend, concat, project (Eq #70).

        Trace: Eq #70
        """
        raise NotImplementedError(
            "spec: reshape (N, d) -> (heads, N, d/heads); per-head Eq #69; "
            "concat heads; output projection"
        )

    def information_gain_weights(self, modalities: List[ModalityInput]) -> Tensor:
        """Attention bias alpha_i = I(o_i; b | model) per modality (Eq #71).

        Modalities whose observation currently reduces model uncertainty the
        most receive larger attention weight; ties broken by calibrated
        uncertainty (lower variance wins).

        Trace: Eq #71
        """
        raise NotImplementedError(
            "spec: estimate per-modality mutual information with the world "
            "model (by name only — world_model.rssm.RSSM is a collaborator, "
            "never imported); softmax over info gains"
        )

    def fuse(self, modalities: List[ModalityInput]) -> Tensor:
        """Fuse modality latents via cross-attention (Blueprint §3.1).

        Vision queries attend to audio keys/values and vice versa
        (z = Attn(W_v z_v, W_a z_a, W_a z_a)); outputs are combined with
        information-gain weights (Eq #71). Concatenation is NOT used.

        Trace: Blueprint §3.1; Eq #69-71
        """
        raise NotImplementedError(
            "spec: per-modality projections W_v/W_a; bidirectional cross-attn "
            "via multi_head; combine with information_gain_weights; forbid "
            "concat by construction"
        )

    def fused_uncertainty(self, modalities: List[ModalityInput]) -> float:
        """Propagate modality uncertainties through the attention weights.

        Returns the attention-weighted variance of the fused percept so the
        LayerIO contract is honored upstream (Blueprint Part 2).

        Trace: Blueprint Part 2; Eq #83 (predictive variance)
        """
        raise NotImplementedError(
            "spec: var_fused = sum_i alpha_i^2 * var_i (independent modalities) "
            "+ attention-map entropy term (Eq #81)"
        )

    def step(self, inp: LayerIO) -> LayerIO:
        """LayerIO contract: modality list in meta -> fused (z, uncertainty, cost).

        Trace: Blueprint Part 2, §3.1
        """
        raise NotImplementedError(
            "spec: read List[ModalityInput] from inp.meta['modalities']; fuse; "
            "LayerIO(state=z, uncertainty=fused_uncertainty, cost=attn flops)"
        )

    def falsification_test(self) -> FalsificationResult:
        """Fusion must beat unimodal latents on held-out prediction error.

        If fused z does not reduce held-out world-model loss versus the best
        single modality, fusion is decorative and fails (Blueprint Part 5
        spirit; §3.4 anti-tautology rule applied to fusion).

        Trace: Blueprint §3.1, Part 5.3
        """
        raise NotImplementedError(
            "spec: compare held-out L_WM with fused z vs best unimodal z; "
            "pass iff fused is better beyond noise"
        )
```

----------------------------------------

### File: `sensors.py`

**Path:** `stage4/stage4/perception/sensors.py`
**Extension:** `.py`
**Size:** 9,575 bytes (9.35 KB)

```py
"""Sensor adapters — real hardware first, mock strictly non-default (Blueprint Part 10).

Blueprint Part 10, rule 1: "Kill the mock sensors. Real camera, real mic."
Phi-Lite's sine-wave ``mock_z()`` (features #46/#59) is why it is S2.9, and
audit #4 (no sensors/embodiment) is fixed here by an explicit ``SensorAdapter``
interface:

  - ``RealSensorAdapter`` is the DEFAULT. It binds V4L2 camera and ALSA mic
    (Phi-Lite feature #47 device detection) and raises if hardware is absent.
  - ``MockSensorAdapter`` is CLEARLY LABELED and must be explicitly requested
    (``allow_mock=True`` at construction). It exists only for CI and offline
    development, emits provenance-tagged data, and refuses to run unless the
    config/debug flags allow it.

No silent fallback: if real sensors fail and mock was not explicitly
requested, the system halts rather than lying to L5 (Blueprint Part 2:
layers must not lie to each other).

Traceability:
  - Blueprint Part 10 rule 1, §3.1, Part 2
  - Audit #4 (no sensors/actuators/embodiment)
  - Phi-Lite features #46/#47/#59 (mock sensors, device detection) — replaced
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional, Protocol, runtime_checkable

from stage4.config import Config
from stage4.core.types import FalsificationResult, LayerIO


class Modality(Enum):
    """Physical modalities exposed by the sensor layer (Blueprint §3.1, L1)."""

    CAMERA = "camera"
    MICROPHONE = "microphone"


@dataclass
class SensorReading:
    """One timestamped sensor frame with mandatory provenance.

    ``is_mock`` is part of the wire format: downstream layers can audit
    whether they are being fed real data (Blueprint Part 10 rule 1).
    """

    modality: Modality
    payload: Any            # phitensor.Tensor once captured; raw buffer at capture time
    timestamp_s: float
    provenance: Dict[str, Any] = field(default_factory=dict)
    is_mock: bool = False   # True only from MockSensorAdapter


class SensorUnavailableError(RuntimeError):
    """Raised when a required real sensor is absent and mock was not requested."""


@runtime_checkable
class SensorAdapter(Protocol):
    """Explicit interface every sensor source must implement.

    The interface is the seam that lets CI swap in the labeled mock without
    the rest of the system knowing or caring (Blueprint Part 10 rule 1,
    implemented honestly: the mock is explicit, not silent).

    Trace: Blueprint §3.1, Part 10 rule 1; Audit #4
    """

    is_mock: bool

    def open(self) -> None:
        """Acquire the underlying device (V4L2 node, ALSA stream)."""
        ...

    def read(self, modality: Modality) -> SensorReading:
        """Capture one reading; must populate provenance and timestamp."""
        ...

    def close(self) -> None:
        """Release the device."""
        ...


class RealSensorAdapter:
    """Default adapter: real camera (V4L2) and microphone (ALSA).

    Raises ``SensorUnavailableError`` if hardware is missing; it never falls
    back to mock data silently (Blueprint Part 10 rule 1).

    Trace: Blueprint Part 10 rule 1; Audit #4; Phi-Lite feature #47
    """

    is_mock: bool = False

    def __init__(self, config: Config) -> None:
        """Bind IO config (video node, audio device) and prepare device detection.

        Trace: Phi-Lite feature #48 (IO settings), #47 (V4L2/ALSA detection)
        """
        self._config = config
        self._devices: Dict[Modality, str] = {}

    def detect_devices(self) -> Dict[Modality, str]:
        """Detect V4L2 camera nodes and ALSA capture devices on the host.

        Trace: Phi-Lite feature #47 (device detection)
        """
        raise NotImplementedError(
            "spec: probe /dev/video* and ALSA capture list; populate "
            "self._devices; raise SensorUnavailableError if none found"
        )

    def open(self) -> None:
        """Acquire camera and microphone streams; fail loudly if absent.

        Trace: Blueprint Part 10 rule 1 (no silent mock fallback)
        """
        raise NotImplementedError(
            "spec: detect_devices(); open streams; raise SensorUnavailableError "
            "on failure — never substitute mock data here"
        )

    def read(self, modality: Modality) -> SensorReading:
        """Capture one real frame/audio window with timestamp and provenance.

        Trace: Blueprint §3.1 (real, not mock)
        """
        raise NotImplementedError(
            "spec: capture from opened stream; SensorReading(is_mock=False, "
            "provenance={'device': node, 'adapter': 'real'})"
        )

    def close(self) -> None:
        """Release camera and microphone streams.

        Trace: Blueprint Part 10 rule 1
        """
        raise NotImplementedError("spec: close streams, clear self._devices")


class MockSensorAdapter:
    """CLEARLY LABELED mock adapter — non-default, CI/dev only.

    Emits deterministic synthetic readings tagged ``is_mock=True``. Refuses to
    construct unless the caller passes ``allow_mock=True`` AND config has
    ``system.debug`` enabled; this is the honest implementation of Blueprint
    Part 10 rule 1 ("kill the mock sensors"): the mock is never the default
    and never silent.

    Trace: Blueprint Part 10 rule 1; Audit #46/#59 (mock sensors labeled, gated)
    """

    is_mock: bool = True

    def __init__(self, config: Config, allow_mock: bool = False) -> None:
        """Gate construction behind an explicit opt-in.

        Args:
            config: system config; mock requires system.debug == True.
            allow_mock: explicit caller opt-in. Default False.

        Raises:
            PermissionError: if allow_mock is False or debug mode is off.

        Trace: Blueprint Part 10 rule 1
        """
        if not allow_mock:
            raise PermissionError(
                "MockSensorAdapter requires allow_mock=True; real sensors are "
                "the default (Blueprint Part 10 rule 1)."
            )
        if not bool(config.get("system.debug", False)):
            raise PermissionError(
                "MockSensorAdapter requires system.debug=True in config."
            )
        self._config = config

    def open(self) -> None:
        """Initialize the deterministic synthetic generator (seeded).

        Trace: Audit #21/#22 (seeded determinism)
        """
        raise NotImplementedError(
            "spec: spawn phitensor.rng.Generator from config seed, stream "
            "'mock_sensors'; nothing random unseeded"
        )

    def read(self, modality: Modality) -> SensorReading:
        """Emit one synthetic reading, always tagged is_mock=True.

        Trace: Audit #46/#59 — mock data is labeled end-to-end
        """
        raise NotImplementedError(
            "spec: synthetic frame/window from seeded Generator; "
            "SensorReading(is_mock=True, provenance={'adapter': 'mock'})"
        )

    def close(self) -> None:
        """No-op close for symmetry with RealSensorAdapter.

        Trace: Blueprint Part 10 rule 1
        """
        raise NotImplementedError("spec: release generator state")


def make_default_adapter(config: Config, allow_mock: bool = False) -> SensorAdapter:
    """Factory: real adapter by default; mock ONLY on explicit request.

    Args:
        config: system config.
        allow_mock: must be True to obtain a MockSensorAdapter.

    Returns:
        RealSensorAdapter normally; MockSensorAdapter only when explicitly
        requested and debug-gated.

    Trace: Blueprint Part 10 rule 1
    """
    if allow_mock:
        return MockSensorAdapter(config, allow_mock=True)
    return RealSensorAdapter(config)


class PerceptionLayer:
    """L2 layer facade: sensors -> encoders -> fusion -> LayerIO.

    Owns the adapter, VisionEncoder, AudioEncoder, and CrossAttentionFusion
    (by name; wired here since they are same-package collaborators).

    Trace: Blueprint Part 2 (L1/L2), §3.1
    """

    name: str = "perception"

    def __init__(self, config: Config, adapter: Optional[SensorAdapter] = None) -> None:
        """Wire the layer; defaults to RealSensorAdapter when adapter is None.

        Trace: Blueprint Part 10 rule 1
        """
        self._config = config
        self._adapter: SensorAdapter = adapter if adapter is not None else RealSensorAdapter(config)

    def step(self, inp: LayerIO) -> LayerIO:
        """One perception cycle: read sensors, encode both modalities, fuse.

        Emits LayerIO(state=z_fused, uncertainty=fused variance, cost=total
        capture+encode cost, meta={'modalities': ..., 'is_mock': ...}) so the
        world model can audit data provenance.

        Trace: Blueprint Part 2, §3.1
        """
        raise NotImplementedError(
            "spec: adapter.read(CAMERA/MICROPHONE) -> VisionEncoder.step / "
            "AudioEncoder.step -> CrossAttentionFusion.step -> LayerIO"
        )

    def falsification_test(self) -> FalsificationResult:
        """L2 kill test: real-data prediction must beat random encoders by 2 sigma.

        Also fails if all recent readings are mock (is_mock=True) — the layer
        may not claim grounding on synthetic data (Blueprint Part 0, S3).

        Trace: Blueprint §3.1 test, Part 0 stage S3, Part 10 rule 1
        """
        raise NotImplementedError(
            "spec: run encoder falsification tests on held-out real data; "
            "fail if readings lack real provenance"
        )
```

----------------------------------------

### File: `vision_encoder.py`

**Path:** `stage4/stage4/perception/vision_encoder.py`
**Extension:** `.py`
**Size:** 5,661 bytes (5.53 KB)

```py
"""Contrastive vision encoder — SimCLR-style, z_v in R^128 (Blueprint §3.1).

Replaces Phi-Lite's mock visual channel with a small CNN/ViT encoder trained
with the NT-Xent contrastive loss:

    L_con = -log [ exp(sim(z_i, z_j^+) / tau) / sum_k exp(sim(z_i, z_k) / tau) ]

Positive pairs are two augmented views of the same frame; negatives are all
other views in the batch. Trained encoders must beat a matched random encoder
by >= 2 sigma on held-out prediction error (Blueprint §3.1 test).

Skeleton only: signatures, docstrings, and stubs. Real compute is built on
``phitensor`` (conv2d, layernorm, gelu) by the implementation pass.

Traceability:
  - Blueprint §3.1 (L2 vision), Part 10 rule 1 (real sensors, not mock)
  - Eq #16 (precision-weighted prediction error, used in uncertainty output)
  - Audit #4 (no sensors/embodiment), Audit #46/#59 (mock sensors removed)
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, Dict, List, Tuple

from stage4.config import Config
from stage4.core.types import FalsificationResult, LayerIO

if TYPE_CHECKING:  # phitensor is built by agent A; annotate only, never construct here
    from phitensor import Tensor


VISION_LATENT_DIM: int = 128  # z_v in R^128 (Blueprint §3.1)


@dataclass
class VisionBatch:
    """A batch of augmented frame pairs for contrastive training.

    ``views_a`` and ``views_b`` are paired augmentations of the same frames
    (positives); cross-pairs within the batch act as negatives (SimCLR).
    """

    views_a: Any  # phitensor.Tensor, shape (N, C, H, W)
    views_b: Any  # phitensor.Tensor, shape (N, C, H, W)
    provenance: Dict[str, Any]  # sensor id, timestamps; no mock data allowed here


class VisionEncoder:
    """SimCLR-style contrastive vision encoder producing z_v in R^128.

    Architecture: small CNN or ViT backbone (conv2d + layernorm + gelu via
    phitensor.ops), projection head for the contrastive loss, and a stop-grad
    trunk whose 128-D output is the percept latent handed to fusion.

    Trace: Blueprint §3.1; Audit #4; Eq #16
    """

    name: str = "perception.vision"

    def __init__(self, config: Config) -> None:
        """Bind config: latent dim (128), temperature tau, backbone depth.

        Trace: Blueprint §3.1; stage4.config DEFAULT_CONFIG["backend"]
        """
        self._config = config
        self.latent_dim: int = VISION_LATENT_DIM
        self.temperature: float = float(config.get("perception.contrastive_tau", 0.5))

    def encode(self, frames: Tensor) -> Tensor:
        """Encode raw frames into z_v in R^128 (trunk output, no projection head).

        Args:
            frames: Tensor of shape (N, C, H, W) from a real camera adapter.

        Returns:
            Tensor of shape (N, 128), L2-normalized per row.

        Trace: Blueprint §3.1
        """
        raise NotImplementedError(
            "spec: conv/ViT trunk (phitensor.ops.conv2d, layernorm, gelu) -> "
            "global pool -> linear to R^128 -> L2 normalize"
        )

    def project(self, z_v: Tensor) -> Tensor:
        """Projection head used only by the contrastive loss (SimCLR head).

        Args:
            z_v: trunk latents, shape (N, 128).

        Returns:
            Projected embeddings for NT-Xent scoring.

        Trace: Blueprint §3.1 (contrastive loss)
        """
        raise NotImplementedError("spec: 2-layer MLP projection head, gelu hidden")

    def contrastive_loss(self, batch: VisionBatch) -> Tensor:
        """NT-Xent loss over the augmented batch.

        Computes sim(z_i, z_j) = cosine similarity, applies temperature tau,
        and returns the mean InfoNCE loss over all 2N views. Positives are the
        (views_a[k], views_b[k]) pairs; everything else is a negative.

        Trace: Blueprint §3.1 L_con equation
        """
        raise NotImplementedError(
            "spec: NT-Xent: -log exp(sim(zi,zj+)/tau) / sum_k exp(sim(zi,zk)/tau), "
            "mask self-similarity, symmetric over (a->b, b->a)"
        )

    def train_step(self, batch: VisionBatch) -> float:
        """One contrastive optimization step; returns scalar loss for logging.

        Uses phitensor.autograd (AdamW per config) and must run inside the
        medium learning loop (Blueprint Part 4, every 1000 cycles).

        Trace: Blueprint §3.1, Part 4 (medium loop)
        """
        raise NotImplementedError(
            "spec: contrastive_loss -> autograd.backward -> AdamW step; "
            "return float loss"
        )

    def step(self, inp: LayerIO) -> LayerIO:
        """LayerIO contract: frames in -> (z_v, uncertainty, cost) out.

        Uncertainty is the precision-weighted residual variance of the
        encoder's own next-frame prediction head (Eq #16-style precision
        weighting); cost is measured FLOPs of the forward pass.

        Trace: Blueprint Part 2 (sacred contract), Eq #16
        """
        raise NotImplementedError(
            "spec: encode(inp.state) -> LayerIO(state=z_v, uncertainty=var, "
            "cost=flops, meta={'modality': 'vision'})"
        )

    def falsification_test(self) -> FalsificationResult:
        """Blueprint §3.1 test: beat a matched random encoder by >= 2 sigma.

        Compares held-out next-frame prediction error of this encoder against
        a frozen random-weight encoder of identical architecture.

        Trace: Blueprint §3.1 (test), Part 5.3 (kill criteria)
        """
        raise NotImplementedError(
            "spec: run held-out prediction error vs random-encoder baseline; "
            "pass iff improvement >= 2 sigma"
        )
```

----------------------------------------

##### Directory: `stage4/stage4/perception/__pycache__`


#### Directory: `stage4/stage4/policy`


### File: `__init__.py`

**Path:** `stage4/stage4/policy/__init__.py`
**Extension:** `.py`
**Size:** 904 bytes (0.88 KB)

```py
"""stage4.policy -- L3 hierarchical policy package.

Hosts the blueprint's L3 layer: primitive policies pi_theta(a|z), the option
framework (I_o, pi_o, beta_o), action-selection rules (Gumbel-softmax, top-p,
Thompson, UCB, CFR, policy gradient, mirror descent), and the feudal
hierarchical controller with Phi-Lite anti-degeneracy mechanisms (pair-share
ban, burns, refractory kernel).

Modules:
  primitives.py   -- pi_theta(a|z) primitive policies
  options.py      -- option framework + Laplacian bottleneck discovery
  selection.py    -- action selection and policy improvement equations
  hierarchical.py -- feudal manager/worker + anti-lock mechanisms

Traceability:
  - Blueprint section 3.5 (L3 hierarchical policy), Part 2 (LayerIO contract)
  - 144-equation ledger section D (Eq #49-#68)
"""

from __future__ import annotations

__all__ = ["primitives", "options", "selection", "hierarchical"]
```

----------------------------------------

### File: `hierarchical.py`

**Path:** `stage4/stage4/policy/hierarchical.py`
**Extension:** `.py`
**Size:** 9,707 bytes (9.48 KB)

```py
"""Feudal hierarchical control and Phi-Lite anti-degeneracy mechanisms.

Two concerns live here:

1. The feudal hierarchy (Eq #62): a manager emits a latent goal g every c
   cycles; a worker conditions its primitive policy on g, pi(a | b, g).  The
   effective planning horizon is derived from the number of active options
   (Eq #63).

2. The anti-lock mechanisms inherited from Phi-Lite's 144-feature ledger:
   the pair-share ban (feature #6, breaks LISTEN<->REPAIR deadlocks), burns
   (feature #8, temporary bans on specific actions), and the refractory
   kernel (Eq #6 smooth Gaussian refractory; Eq #66 survival-analysis
   correction) that replaces the hard 8-second SPEAK block.

Traceability:
  - 144-equation ledger Eq #62 (feudal HRL), Eq #63 (horizon via options),
    Eq #6 (refractory kernel), Eq #66 (refractory survival correction)
  - Phi-Lite 144 features #6 (pair-share ban), #8 (burns), #9 (refractory
    period), #101 (pair-share meter)
  - Blueprint section 3.5 (L3 hierarchical policy)
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Dict, List, Optional, Set, Tuple

from stage4.config import Config
from stage4.core.types import FalsificationResult, LayerIO

if TYPE_CHECKING:
    from phitensor import Tensor


class FeudalController:
    """Manager/worker hierarchy over the option set (feudal RL).

    The manager maps the latent state to a goal direction g every
    ``manager_period`` cycles; the worker runs pi(a | b, g) between manager
    invocations.  Manager reward is the extrinsic return over its period;
    worker reward adds an intrinsic cosine-similarity bonus for moving the
    latent state along g.

    Trace: Eq #62 (hierarchical RL, feudal); Blueprint section 3.5.
    """

    name: str = "L3.hierarchical"

    def __init__(self, config: Config, manager_period: int = 8) -> None:
        """Initialize manager and worker parameter heads.

        Trace: Eq #62; SPEC section 4.2.
        """
        self._config = config
        self._manager_period = manager_period
        raise NotImplementedError(
            "spec: allocate manager head (z -> g) and worker head "
            "((z, g) -> action logits) as phitensor tensors"
        )

    def manager_goal(self, z: "Tensor") -> "Tensor":
        """Emit the latent goal direction g for the current state.

        Trace: Eq #62 (manager emits goal g).
        """
        raise NotImplementedError(
            "spec: linear map z -> g, L2-normalize g to unit length"
        )

    def worker_action_logits(self, z: "Tensor", g: "Tensor") -> "Tensor":
        """Compute worker logits pi(a | z, g).

        Trace: Eq #62 (worker policy conditioned on g).
        """
        raise NotImplementedError(
            "spec: concatenate/condition z with g and map to action logits "
            "via the worker head"
        )

    def worker_intrinsic_reward(self, dz: "Tensor", g: "Tensor") -> float:
        """Cosine-similarity bonus for latent movement along the goal.

        Trace: Eq #62 (feudal intrinsic reward aligns worker with manager).
        """
        raise NotImplementedError(
            "spec: return <dz, g> / (||dz|| ||g|| + eps)"
        )

    def step(self, inp: LayerIO) -> LayerIO:
        """Advance one cycle: refresh goal if due, then produce logits.

        Trace: Eq #62; Blueprint Part 2 (LayerIO contract).
        """
        raise NotImplementedError(
            "spec: every manager_period cycles call manager_goal, then "
            "worker_action_logits; attach g to meta for the L7 controller"
        )

    def falsification_test(self) -> FalsificationResult:
        """The hierarchy must beat the flat policy on held-out control tasks.

        Trace: Blueprint section 3.5 (options/hierarchy reduce episode
            length); SPEC section 4.1.
        """
        raise NotImplementedError(
            "spec: compare mean episode length of feudal vs flat policy on "
            "eval.heldout control tasks; pass iff feudal is shorter"
        )


def horizon_via_options(active_option_count: int, base_horizon: int) -> int:
    """Effective horizon H = base + sum_o 1[option_o active].

    Trace: Eq #63 (horizon via options count); Phi-Lite feature #22
        (dynamic horizon selection).
    """
    raise NotImplementedError(
        "spec: return base_horizon + active_option_count, clamped to a "
        "positive integer"
    )


class PairShareBan:
    """Detect and break two-action deadlocks such as LISTEN<->REPAIR.

    Tracks the share of cycles dominated by the top action pair over a
    sliding window; when the share exceeds the ban threshold, both actions of
    the pair are penalized via the Eq #49 pair-ban softmax term for a
    cooldown period.

    Trace: Phi-Lite feature #6 (pair-share ban), feature #101 (pair-share
        meter); Eq #49 (pair-ban penalty term).
    """

    def __init__(self, config: Config, window: int = 64,
                 ban_threshold: float = 0.9, cooldown: int = 16) -> None:
        """Initialize the sliding-window pair detector.

        Trace: Phi-Lite feature #6; Eq #49.
        """
        self._config = config
        self._window = window
        self._ban_threshold = ban_threshold
        self._cooldown = cooldown
        raise NotImplementedError(
            "spec: allocate the action-history window, pair counters, and "
            "an empty active-ban map with expiry cycles"
        )

    def observe(self, action_a: int, action_b: int, cycle: int) -> None:
        """Record the pair executed this cycle.

        Trace: Phi-Lite feature #6.
        """
        raise NotImplementedError(
            "spec: append the ordered pair to the window, update pair "
            "counts, expire cooled-down bans"
        )

    def banned_pairs(self) -> Dict[Tuple[int, int], int]:
        """Return {pair: cycles_remaining} for active bans.

        Trace: Phi-Lite feature #6 (ban) and #101 (meter readout).
        """
        raise NotImplementedError(
            "spec: compute pair shares over the window; ban pairs above "
            "threshold for cooldown cycles; return the active map"
        )


class BurnBook:
    """Temporary bans ("burns") on specific actions.

    A burn disables one action for a fixed number of cycles (e.g. REPAIR
    after a REPAIR_NOOP detector event).  Burns are the hard counterpart of
    the smooth refractory kernel.

    Trace: Phi-Lite feature #8 (burns), feature #119 (BURN log), feature
        #42 (REPAIR_NOOP detector).
    """

    def __init__(self, config: Config) -> None:
        """Initialize the burn registry.

        Trace: Phi-Lite feature #8.
        """
        self._config = config
        raise NotImplementedError("spec: allocate empty {action: expiry} map")

    def burn(self, action: int, cycles: int, now: int, reason: str) -> None:
        """Ban `action` until cycle `now + cycles`, logging the reason.

        Trace: Phi-Lite feature #8 (burns), feature #119 (BURN log).
        """
        raise NotImplementedError(
            "spec: record expiry cycle and reason for the action"
        )

    def is_burned(self, action: int, now: int) -> bool:
        """Return True while the action's burn is active.

        Trace: Phi-Lite feature #8.
        """
        raise NotImplementedError(
            "spec: compare now against the recorded expiry, lazily expiring"
        )


class RefractoryKernel:
    """Smooth refractory suppression of recently executed actions.

    Replaces Phi-Lite's hard 8-second SPEAK block with the Gaussian kernel
    R(t) = exp(-(t - t_s)^2 / (2 tau_R^2)) applied as a multiplicative
    penalty on the action's logit.  Additionally hosts the survival-analysis
    correction: a log-hazard lambda(a) estimated from time-since-last-use
    sharpens the penalty for habitually repeated actions.

    Trace: Eq #6 (refractory kernel); Eq #66 (refractory correction via
        survival analysis); Phi-Lite feature #9 (refractory period).
    """

    def __init__(self, config: Config, tau_r: float = 8.0) -> None:
        """Initialize the kernel with time constant tau_r seconds.

        Trace: Eq #6; Phi-Lite feature #9.
        """
        self._config = config
        self._tau_r = tau_r
        raise NotImplementedError(
            "spec: allocate per-action last-execution timestamps and "
            "survival-hazard accumulators"
        )

    def kernel_value(self, t: float, t_last: float) -> float:
        """R(t) = exp(-(t - t_last)^2 / (2 tau_R^2)).

        Trace: Eq #6 (refractory kernel).
        """
        raise NotImplementedError(
            "spec: return math.exp(-((t - t_last) ** 2) / (2 * tau_r ** 2))"
        )

    def log_hazard(self, action: int, t_since_last: float) -> float:
        """Survival log-hazard lambda(a) from time since last execution.

        Trace: Eq #66 (refractory correction via survival analysis).
        """
        raise NotImplementedError(
            "spec: fit/lookup the per-action hazard from inter-execution "
            "interval history and return its log"
        )

    def penalize_logits(self, logits: "Tensor", t: float) -> "Tensor":
        """Multiply each action's selection pressure by (1 - R(t)).

        Trace: Eq #6; Eq #66; Eq #49 (applied before the softmax).
        """
        raise NotImplementedError(
            "spec: for each action, subtract log(1 - R(t) * hazard_weight) "
            "from its logit; record execution timestamps on use"
        )


__all__ = [
    "FeudalController",
    "horizon_via_options",
    "PairShareBan",
    "BurnBook",
    "RefractoryKernel",
]
```

----------------------------------------

### File: `options.py`

**Path:** `stage4/stage4/policy/options.py`
**Extension:** `.py`
**Size:** 9,809 bytes (9.58 KB)

```py
"""Option framework and bottleneck-driven option discovery for L3.

An option o = (I_o, pi_o, beta_o) is a temporally extended action: an
initiation set I_o over latent states, an intra-option policy pi_o(a|z), and
a termination function beta_o(z) in [0,1].  Options are *discovered*, not
hand-designed: states where the second eigenvalue lambda_2 of the transition
graph Laplacian is locally small are bottlenecks -- natural subgoals -- and
curiosity (RND-style prediction error) seeds proto-options around them.

Falsifiable claim (Blueprint section 3.5): discovered options reduce average
episode length on at least 2 held-out tasks without being specified.

Traceability:
  - Blueprint section 3.5 (L3 hierarchical policy, Laplacian bottlenecks)
  - 144-equation ledger Eq #60 (option framework), Eq #61 (curiosity-driven
    option discovery), Eq #45 (RND curiosity bonus)
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Callable, Dict, List, Optional, Sequence, Tuple

from stage4.config import Config
from stage4.core.types import FalsificationResult, LayerIO

if TYPE_CHECKING:
    from phitensor import Tensor


@dataclass
class Option:
    """A temporally extended action (I_o, pi_o, beta_o).

    Attributes:
        option_id: stable identifier within the option set.
        initiation: predicate I_o(z) -> bool deciding where the option may start.
        intra_policy: callable pi_o(a|z) returning action logits; typically a
            frozen copy of a PrimitivePolicy head specialized to the subgoal.
        termination: callable beta_o(z) -> float in [0,1], probability of
            terminating in state z.
        subgoal: latent bottleneck state this option drives toward.
        creation_cycle: cycle at which the option was discovered.

    Trace: Blueprint section 3.5; Eq #60 (option framework).
    """

    option_id: int
    initiation: "Callable[[Tensor], bool]"
    intra_policy: "Callable[[Tensor], Tensor]"
    termination: "Callable[[Tensor], float]"
    subgoal: Optional["Tensor"] = None
    creation_cycle: int = 0


@dataclass
class OptionExecutionState:
    """Runtime state of the currently active option, if any.

    Trace: Eq #60; Eq #63 (horizon via options count consumes the set of
        active options).
    """

    active_option: Optional[int] = None
    cycles_in_option: int = 0
    options_executed: List[int] = field(default_factory=list)


class OptionFramework:
    """Registry and execution machinery for the option set.

    Owns at most ``policy.max_options`` options (config), decides initiation
    and termination each cycle, and arbitrates between the active option's
    intra-option policy and the primitive policy when no option is active.

    Trace: Blueprint section 3.5; Eq #60.
    """

    name: str = "L3.options"

    def __init__(self, config: Config) -> None:
        """Initialize the option registry from validated config.

        Trace: Eq #60; SPEC section 4.2 (policy.max_options).
        """
        self._config = config
        raise NotImplementedError(
            "spec: create empty option registry bounded by "
            "policy.max_options and an empty OptionExecutionState"
        )

    def can_initiate(self, option_id: int, z: "Tensor") -> bool:
        """Return True iff z lies in the option's initiation set I_o.

        Trace: Eq #60 (I_o subseteq Z).
        """
        raise NotImplementedError("spec: evaluate Option.initiation(z)")

    def termination_probability(self, option_id: int, z: "Tensor") -> float:
        """Return beta_o(z) in [0,1] for the given option.

        Trace: Eq #60 (termination beta_o(z)); Blueprint section 3.5.
        """
        raise NotImplementedError("spec: evaluate Option.termination(z)")

    def maybe_terminate(self, state: OptionExecutionState, z: "Tensor",
                        random_draw: float) -> bool:
        """Sample termination of the active option against beta_o(z).

        Trace: Eq #60; Blueprint section 3.5 (termination condition).
        """
        raise NotImplementedError(
            "spec: terminate iff random_draw < beta_o(z); on termination "
            "append option id to options_executed and clear active_option"
        )

    def register_option(self, option: Option) -> int:
        """Register a discovered option, evicting the least-used if full.

        Trace: Eq #60; Eq #61 (options originate from discovery, not design);
            SPEC section 4.2 (policy.max_options bound).
        """
        raise NotImplementedError(
            "spec: insert into registry; if len == policy.max_options evict "
            "the option with the fewest executions"
        )

    def step(self, inp: LayerIO) -> LayerIO:
        """Advance one cycle of option arbitration over the latent state.

        Trace: Blueprint Part 2 (LayerIO contract); Eq #60; Eq #63 (the
            number of active/executed options feeds horizon selection).
        """
        raise NotImplementedError(
            "spec: check termination of the active option, else check "
            "initiation of registered options, else pass control to the "
            "primitive policy; return LayerIO with the chosen action source "
            "recorded in meta"
        )

    def falsification_test(self) -> FalsificationResult:
        """Options must shorten held-out episodes on >= 2 tasks.

        Trace: Blueprint section 3.5 (falsifiable test); SPEC section 4.1.
        """
        raise NotImplementedError(
            "spec: compare mean episode length with/without the discovered "
            "option set on eval.heldout control tasks; pass iff shorter on "
            ">= 2 tasks"
        )


class LaplacianBottleneckDiscovery:
    """Discover bottleneck states from the transition graph Laplacian.

    Builds the graph of observed latent transitions, computes the graph
    Laplacian L = D - A, and flags states near which the Fiedler value
    lambda_2(L) is locally small -- the graph is nearly disconnected there,
    so those states are natural subgoals.

    Trace: Blueprint section 3.5 (B = {z : lambda_2(L) small at z});
        Eq #61 (proto-options from bottleneck states via Laplacian).
    """

    def __init__(self, config: Config) -> None:
        """Initialize the discovery module from validated config.

        Trace: Blueprint section 3.5; Eq #61.
        """
        self._config = config
        raise NotImplementedError(
            "spec: allocate an incremental transition-count table keyed by "
            "discretized latent buckets"
        )

    def observe_transition(self, z: "Tensor", z_next: "Tensor") -> None:
        """Record one observed latent transition into the graph.

        Trace: Blueprint section 3.5; Eq #61.
        """
        raise NotImplementedError(
            "spec: discretize z and z_next, increment the transition-count "
            "table entry, mark the Laplacian cache dirty"
        )

    def graph_laplacian(self) -> "Tensor":
        """Compute L = D - A over the discretized transition graph.

        Trace: Blueprint section 3.5; Eq #61.
        """
        raise NotImplementedError(
            "spec: build adjacency A from transition counts, degree matrix "
            "D, return D - A as a phitensor Tensor"
        )

    def bottlenecks(self) -> List["Tensor"]:
        """Return latent states that are spectral bottlenecks.

        Trace: Blueprint section 3.5 (B = {z : lambda_2(L) small at z});
            Eq #61.
        """
        raise NotImplementedError(
            "spec: eigendecompose the normalized Laplacian, use the Fiedler "
            "vector sign structure to find near-disconnects, return the "
            "representative latent states"
        )


class CuriosityProtoOptions:
    """Turn bottleneck states into candidate options via curiosity reward.

    A proto-option is created around a bottleneck state when the RND-style
    prediction error at that state is high: the region is both a structural
    subgoal and information-rich.  Proto-options that prove useful (reduce
    episode length) are promoted to full Options by the OptionFramework.

    Trace: Eq #61 (curiosity-driven option discovery); Eq #45 (RND bonus
        r_cur = ||phi(b) - phi_hat(b)||^2); Blueprint section 3.7 (novelty
        intrinsic reward).
    """

    def __init__(self, config: Config) -> None:
        """Initialize the proto-option miner from validated config.

        Trace: Eq #61; Eq #45.
        """
        self._config = config
        raise NotImplementedError(
            "spec: allocate an RND predictor/target pair (phitensor tensors) "
            "and an empty proto-option candidate list"
        )

    def curiosity_score(self, z: "Tensor") -> float:
        """RND prediction error ||phi(z) - phi_hat(z)||^2 at latent z.

        Trace: Eq #45; Blueprint section 3.7 (novelty reward).
        """
        raise NotImplementedError(
            "spec: forward z through fixed random target phi and trainable "
            "predictor phi_hat, return squared distance"
        )

    def propose(self, bottlenecks: Sequence["Tensor"]) -> List[Option]:
        """Create proto-options for high-curiosity bottleneck states.

        Trace: Eq #61 (proto-options from bottleneck states);
            Blueprint section 3.5.
        """
        raise NotImplementedError(
            "spec: for each bottleneck with curiosity_score above the "
            "running median, synthesize initiation/termination predicates "
            "centered on the bottleneck and return candidate Options"
        )


__all__ = [
    "Option",
    "OptionExecutionState",
    "OptionFramework",
    "LaplacianBottleneckDiscovery",
    "CuriosityProtoOptions",
]
```

----------------------------------------

### File: `primitives.py`

**Path:** `stage4/stage4/policy/primitives.py`
**Extension:** `.py`
**Size:** 8,250 bytes (8.06 KB)

```py
"""Primitive policies pi_theta(a | z) for the L3 policy layer.

A primitive policy maps a latent state z (produced by the L5 world model and
gated by the L2 perception layer) to a distribution over primitive actions.
Nothing crosses the layer boundary without (state, uncertainty, cost) attached,
so the policy's public stepping interface consumes and returns LayerIO.

The concrete parameterization (linear head over z, or a small MLP built on
phitensor ops) is left to the implementation milestone M4; this module pins
the interface, the entropy floor that prevents policy degeneracy, and the
falsifiable test the blueprint demands of L3.

Traceability:
  - Blueprint section 3.5 (L3 hierarchical policy primitives)
  - Blueprint Part 8 failure mode 2 (policy degeneracy -> entropy floor)
  - 144-equation ledger Eq #49 (softmax with temperature and pair ban)
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Dict, List, Optional, Sequence

from stage4.config import Config
from stage4.core.types import FalsificationResult, LayerIO

if TYPE_CHECKING:
    from phitensor import Tensor
    from phitensor.rng import Generator


@dataclass
class ActionSpec:
    """Description of one primitive action available to pi_theta.

    Attributes:
        name: human-readable action identifier (e.g. "LOOK", "PLAN").
        energy_cost: per-execution energetic cost, charged by core.energy.
        min_interval_s: minimum seconds between consecutive executions
            (Phi-Lite safety mask, feature #27).

    Trace: Blueprint section 3.5; Phi-Lite features #13/#27 (per-action cost,
        safety mask); Audit #13-24 (validated config plumbing).
    """

    name: str
    energy_cost: float
    min_interval_s: float = 0.2


@dataclass
class PolicyTrace:
    """Bookkeeping for one primitive-policy decision.

    Carries the sampled action, its log-probability, and the distribution
    entropy so the L7 meta-controller and the safety invariant checker
    (Eq #140: ||pi_exec - pi|| <= epsilon) can audit every cycle.

    Trace: Blueprint Part 2 (uncertainty attached to every layer output);
        144-equation ledger Eq #58 (intent-gap KL), Eq #140 (alignment
        invariant checking).
    """

    action: str
    log_prob: float
    entropy: float
    distribution: Dict[str, float] = field(default_factory=dict)


class PrimitivePolicy:
    """Primitive policy pi_theta(a | z) over a fixed action set.

    The policy owns its parameters theta (a phitensor.Tensor weight matrix and
    bias, built on the in-repo backend) and exposes the Layer protocol so the
    L3 layer composes with the rest of the stack.  Entropy of pi_theta is
    tracked every cycle; if it collapses below the configured floor the layer
    reports failure rather than silently degenerating.

    Collaborators (referenced by name, never imported): stage4.policy.selection
    supplies the sampling rules; stage4.neuro.axes modulates the temperature
    via precision; stage4.core.energy charges per-action costs.

    Trace: Blueprint section 3.5; Blueprint Part 8 failure mode 2;
        Eq #49 (softmax with temperature and pair ban), Eq #64 (entropy
        regularizer).
    """

    name: str = "L3.primitives"

    def __init__(self, config: Config, actions: Sequence[ActionSpec]) -> None:
        """Initialize the primitive policy from validated config.

        Args:
            config: frozen Config; consumes the ``policy`` section
                (entropy_beta, gumbel_temperature, ucb_c, max_options).
            actions: ordered primitive action set.

        Trace: Blueprint section 3.5; SPEC section 4.2 (config consumption).
        """
        self._config = config
        self._actions: List[ActionSpec] = list(actions)
        raise NotImplementedError(
            "spec: allocate theta (phitensor Tensor) sized "
            "[len(actions) x latent_dim], zero-init log-prob traces, and "
            "seed a phitensor.rng.Generator from system.seed"
        )

    @property
    def action_set(self) -> List[ActionSpec]:
        """Return the ordered primitive action set.

        Trace: Blueprint section 3.5 (primitives pi_theta(a|z)).
        """
        return list(self._actions)

    def logits(self, z: "Tensor") -> "Tensor":
        """Compute raw action logits z_a = W z + b for latent state z.

        Trace: Blueprint section 3.5; Eq #49 (softmax logits before
            temperature scaling and pair-ban penalty).
        """
        raise NotImplementedError(
            "spec: matmul theta_W with z plus theta_b via phitensor.ops; "
            "return 1-D Tensor over the action set"
        )

    def distribution(self, z: "Tensor", temperature: float) -> "Tensor":
        """Softmax distribution pi_theta(a|z) at the given temperature.

        Trace: Blueprint section 3.5; Eq #49 (pi(a) proportional to
            exp(z_a / T)); Eq #21 (temperature via entropy matching, hosted
            in self_model.calibration).
        """
        raise NotImplementedError(
            "spec: scale logits by 1/temperature and apply "
            "phitensor.ops.softmax; enforce the entropy floor by clamping "
            "temperature from below (failure mode 2)"
        )

    def sample(self, z: "Tensor", generator: "Generator") -> PolicyTrace:
        """Sample an action from pi_theta(a|z) and return a PolicyTrace.

        Trace: Blueprint section 3.5; Eq #50 (Gumbel-softmax sampling,
            delegated to stage4.policy.selection).
        """
        raise NotImplementedError(
            "spec: delegate sampling to stage4.policy.selection."
            "gumbel_softmax_sample using policy.gumbel_temperature; record "
            "action, log_prob, entropy into a PolicyTrace"
        )

    def log_prob(self, z: "Tensor", action: str) -> float:
        """Log-probability of `action` under pi_theta(.|z).

        Trace: Blueprint section 3.5; Eq #55 (policy gradient needs
            grad log pi_theta).
        """
        raise NotImplementedError(
            "spec: compute log_softmax over logits and index the action"
        )

    def entropy(self, z: "Tensor") -> float:
        """Shannon entropy H(pi_theta(.|z)) in nats.

        Trace: Blueprint Part 8 failure mode 2 (entropy collapse detection);
            Eq #64 (entropy regularizer consumes this value).
        """
        raise NotImplementedError(
            "spec: compute -sum_a pi_a log pi_a from the tempered distribution"
        )

    def step(self, inp: LayerIO) -> LayerIO:
        """Advance one cycle: choose a primitive action for inp.state.

        The input LayerIO carries the latent state z in ``state``; the output
        LayerIO carries the chosen PolicyTrace in ``state``, preserves and
        extends ``meta`` with provenance, attaches the policy entropy as an
        uncertainty proxy, and charges the sampling cost.

        Trace: Blueprint Part 2 (LayerIO contract); Blueprint section 3.5.
        """
        raise NotImplementedError(
            "spec: sample via self.sample, wrap the PolicyTrace in LayerIO "
            "with uncertainty=1/exp(entropy) proxy and cost from "
            "energy.cognitive_operation_cost"
        )

    def update(self, grad_logp: "Tensor", advantage: float, lr: float) -> None:
        """Apply one policy-gradient parameter update to theta.

        Trace: Eq #55 (policy gradient with baseline); Blueprint Part 4
            (medium loop updates policy weights every 1000 cycles).
        """
        raise NotImplementedError(
            "spec: theta <- theta + lr * advantage * grad_logp via "
            "phitensor.autograd; clip with clip_norm_ before applying"
        )

    def falsification_test(self) -> FalsificationResult:
        """Kill criterion for L3 primitives: policy entropy stays above floor.

        Trace: Blueprint Part 8 failure mode 2; SPEC section 4.1
            (Falsifiable protocol).
        """
        raise NotImplementedError(
            "spec: run N probe states, measure mean entropy of pi_theta, "
            "pass iff mean entropy > policy.entropy_beta-derived floor"
        )


__all__ = ["ActionSpec", "PolicyTrace", "PrimitivePolicy"]
```

----------------------------------------

### File: `selection.py`

**Path:** `stage4/stage4/policy/selection.py`
**Extension:** `.py`
**Size:** 9,586 bytes (9.36 KB)

```py
"""Action-selection and policy-improvement rules for the L3 policy layer.

This module hosts the sampling, bandit, game-theoretic, and gradient rules of
the 144-equation ledger section D.  All functions are pure given their
arguments; randomness flows through an explicit phitensor.rng.Generator so
runs are reproducible under system.seed (audit #21/#22).

Hosted equations:
  Eq #49 softmax with temperature and pair ban
  Eq #50 Gumbel-softmax sampling
  Eq #51 top-p (nucleus) sampling
  Eq #52 Thompson sampling over actions
  Eq #53 UCB action selection
  Eq #54 counterfactual regret minimization (CFR)
  Eq #55 policy gradient with baseline
  Eq #56 natural policy gradient (Fisher)
  Eq #57 mirror descent on the policy simplex
  Eq #58 intent-gap KL(pi || pi_exec)
  Eq #64 entropy regularizer
  Eq #65 band-based pruning

Traceability:
  - 144-equation ledger section D (Eq #49-#58, #64, #65)
  - Blueprint section 3.5, Part 8 failure mode 2 (policy degeneracy)
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Dict, List, Optional, Sequence, Set, Tuple

from stage4.config import Config
from stage4.core.types import LayerIO

if TYPE_CHECKING:
    from phitensor import Tensor
    from phitensor.rng import Generator


def softmax_with_pair_ban(logits: "Tensor", temperature: float,
                          banned: Set[int], ban_penalty: float) -> "Tensor":
    """pi(a) proportional to exp(z_a / T - lambda_p * 1[a in pair]).

    Trace: Eq #49 (softmax with temperature and pair ban); Phi-Lite
        feature #6 (pair-share ban, implemented smoothly here).
    """
    raise NotImplementedError(
        "spec: subtract ban_penalty from logits of banned indices, divide "
        "by temperature, apply phitensor.ops.softmax"
    )


def gumbel_softmax_sample(logits: "Tensor", temperature: float,
                          generator: "Generator") -> int:
    """Sample a = argmax_a (z_a / T + g_a), g_a ~ Gumbel(0, 1).

    Trace: Eq #50 (Gumbel-softmax sampling); SPEC section 4.2
        (policy.gumbel_temperature).
    """
    raise NotImplementedError(
        "spec: draw gumbel noise via generator.gumbel(shape), add to "
        "scaled logits, return argmax index"
    )


def top_p_sample(probs: "Tensor", p: float, generator: "Generator") -> int:
    """Sample from the smallest action set with cumulative probability >= p.

    Trace: Eq #51 (top-p nucleus sampling).
    """
    raise NotImplementedError(
        "spec: sort probabilities descending, take the prefix whose mass "
        "first reaches p, renormalize, sample with generator"
    )


def thompson_sample(means: "Tensor", variances: "Tensor",
                    generator: "Generator") -> int:
    """Sample z~_a = z_a + noise(sigma_a) and return the argmax action.

    Trace: Eq #52 (Thompson sampling over actions; sigma_a from recent
        reward variance).
    """
    raise NotImplementedError(
        "spec: draw normal noise via generator.normal(0, sigma) per action "
        "using the provided variances, add to means, return argmax index"
    )


def ucb_select(mean_rewards: "Tensor", counts: "Tensor", t: int,
               c: float) -> int:
    """Select a_t = argmax_a [r^_a + c * sqrt(log t / n_a)].

    Trace: Eq #53 (UCB action selection); SPEC section 4.2 (policy.ucb_c).
    """
    raise NotImplementedError(
        "spec: compute the UCB index with log(t) / max(n_a, 1), return "
        "argmax index; unseen actions have infinite bonus"
    )


@dataclass
class CFRState:
    """Accumulated regrets and strategy sums for regret matching.

    Attributes:
        cumulative_regret: R_t(a) per action.
        strategy_sum: time-weighted sum of the realized strategies, used for
            the average-policy extraction.

    Trace: Eq #54 (counterfactual regret minimization).
    """

    cumulative_regret: Dict[int, float] = field(default_factory=dict)
    strategy_sum: Dict[int, float] = field(default_factory=dict)


def cfr_regret_update(state: CFRState, action_utilities: "Tensor",
                      realized_utility: float) -> CFRState:
    """Update regrets R_t(a) = R_{t-1}(a) + (u(a) - u_t).

    Trace: Eq #54 (CFR regret update).
    """
    raise NotImplementedError(
        "spec: add (u(a) - realized_utility) to cumulative_regret per "
        "action; accumulate the regret-matched strategy into strategy_sum"
    )


def cfr_average_policy(state: CFRState) -> "Tensor":
    """Return the time-averaged CFR strategy over actions.

    Trace: Eq #54 (regret matching converges to Nash in two-player
        zero-sum games).
    """
    raise NotImplementedError(
        "spec: normalize strategy_sum into a probability Tensor; uniform "
        "fallback when the sum is zero"
    )


def policy_gradient(log_probs: "Tensor", returns: "Tensor",
                    baseline: "Tensor") -> "Tensor":
    """Score-function gradient E[(R - b) * grad log pi_theta].

    Trace: Eq #55 (policy gradient with baseline); Blueprint Part 4
        (medium loop applies these updates every 1000 cycles).
    """
    raise NotImplementedError(
        "spec: compute advantage (returns - baseline), weight log_probs, "
        "and backpropagate via phitensor.autograd.backward"
    )


def natural_policy_gradient(grad: "Tensor", fisher: "Tensor",
                            damping: float) -> "Tensor":
    """Natural gradient F^{-1} grad J with damped Fisher inverse.

    Trace: Eq #56 (natural policy gradient); SPEC section 4.3
        (phitensor.autograd.NaturalGradient, fisher_damping).
    """
    raise NotImplementedError(
        "spec: solve (F + damping * I) x = grad via conjugate gradient on "
        "phitensor ops; return the preconditioned step"
    )


def mirror_descent_step(pi: "Tensor", grad: "Tensor", eta: float) -> "Tensor":
    """pi_{t+1} = argmin_pi < -eta * g, pi > + KL(pi || pi_t).

    The closed form on the simplex is an exponentiated-gradient step:
    pi_{t+1}(a) proportional to pi_t(a) * exp(eta * g_a).

    Trace: Eq #57 (mirror descent on policy).
    """
    raise NotImplementedError(
        "spec: multiply pi elementwise by exp(eta * grad), renormalize to "
        "the simplex, clamp at 1e-12 for numerical safety"
    )


def intent_gap_kl(pi_intended: "Tensor", pi_executed: "Tensor") -> float:
    """D_intent = KL(pi || pi_exec): divergence of deed from word.

    Replaces Phi-Lite's L1 intent-gap meter with the proper KL form; feeds
    the safety invariant checker (Eq #140 asserts ||pi_exec - pi|| <= eps).

    Trace: Eq #58 (intent-gap as KL); Phi-Lite feature #102 (intent-gap
        meter); Eq #140 (alignment invariant).
    """
    raise NotImplementedError(
        "spec: compute sum_a pi_a * (log pi_a - log pi_exec_a) with "
        "epsilon-clipped logs via phitensor.ops.kl_divergence"
    )


def entropy_regularizer(pi: "Tensor", beta: float) -> "Tensor":
    """Entropy bonus term L_H = -beta * H(pi) added to the policy loss.

    Trace: Eq #64 (action entropy regularizer); Blueprint Part 8 failure
        mode 2 (prevents entropy collapse); SPEC section 4.2
        (policy.entropy_beta).
    """
    raise NotImplementedError(
        "spec: compute -beta * sum_a pi_a log pi_a as a scalar Tensor "
        "suitable for adding to the policy loss"
    )


class BandPruner:
    """Prune actions whose meta-learning-rate band is violated.

    An action is pruned when |lambda_meta| exceeds lambda_max for 16
    consecutive cycles on that action's update stream -- the Phi-Lite band
    check (feature #25) turned into a structural pruning rule.

    Trace: Eq #65 (band-based pruning); Phi-Lite features #25/#98 (band
        checking, band traffic light).
    """

    def __init__(self, config: Config, lambda_max: float,
                 violation_window: int = 16) -> None:
        """Initialize per-action violation counters.

        Trace: Eq #65; SPEC section 4.2.
        """
        self._config = config
        self._lambda_max = lambda_max
        self._violation_window = violation_window
        raise NotImplementedError(
            "spec: allocate per-action consecutive-violation counters and "
            "an empty pruned-action set"
        )

    def observe(self, action: int, lambda_meta: float) -> bool:
        """Record one lambda_meta sample; return True if the action prunes.

        Trace: Eq #65 (prune when |lambda_meta| > lambda_max for 16 cycles).
        """
        raise NotImplementedError(
            "spec: increment the counter on violation, reset on compliance; "
            "move the action to the pruned set at 16 consecutive violations"
        )

    def pruned_actions(self) -> Set[int]:
        """Return the current set of pruned action indices.

        Trace: Eq #65; Phi-Lite feature #25.
        """
        raise NotImplementedError("spec: return a copy of the pruned set")

    def mask(self, logits: "Tensor") -> "Tensor":
        """Mask pruned actions out of a logit vector with -inf.

        Trace: Eq #65; Eq #49 (composed with the pair-ban softmax).
        """
        raise NotImplementedError(
            "spec: set logits of pruned actions to -inf before softmax"
        )


__all__ = [
    "softmax_with_pair_ban",
    "gumbel_softmax_sample",
    "top_p_sample",
    "thompson_sample",
    "ucb_select",
    "CFRState",
    "cfr_regret_update",
    "cfr_average_policy",
    "policy_gradient",
    "natural_policy_gradient",
    "mirror_descent_step",
    "intent_gap_kl",
    "entropy_regularizer",
    "BandPruner",
]
```

----------------------------------------

##### Directory: `stage4/stage4/policy/__pycache__`


#### Directory: `stage4/stage4/agency`


### File: `__init__.py`

**Path:** `stage4/stage4/agency/__init__.py`
**Extension:** `.py`
**Size:** 921 bytes (0.90 KB)

```py
"""Agency package: emergence debt, painful commitments, scars, criticality.

The v7.1 IrreversibleAgency dynamics, audit-fixed and decomposed:
  - emergence   : bounded emergence level + emergence debt + phase transitions
                  (audit #25-40).
  - commitments : painful, level-governed, crystallizing commitments with
                  geometry/quantum-derived (never random) values
                  (audit #41-56; Levantine L17-L21, L38).
  - scars       : structured Scar objects from stagnation, collapse, and
                  social friction, with slow healing (audit #57-68; L22).
  - criticality : precision-noise grounded criticality with adaptive danger
                  windows (audit #69-80; Levantine L25, L31, L32).

Trace: SPEC.md §5 mapping; v7.1 IrreversibleAgency; Audit C-F sections.
"""

from __future__ import annotations

__all__ = ["emergence", "commitments", "scars", "criticality"]
```

----------------------------------------

### File: `commitments.py`

**Path:** `stage4/stage4/agency/commitments.py`
**Extension:** `.py`
**Size:** 22,344 bytes (21.82 KB)

```py
"""Painful commitments: irreversible, level-governed identity choices.

Fixes audit #41-56 against v7.1 and integrates Levantine L17-L21, L38:
  - #41: commitment VALUES ARE NEVER RANDOM. New values arrive from the
    geometry package's L-system/IFS generators (`geometry.lsystem`,
    referenced by name) and are collapsed to a concrete choice by the
    quantum observer (`quantum.observer`, referenced by name); this module
    only receives the resulting value plus provenance.
  - #42: `primary_goal` initializes to a designer GoalSpec-derived value,
    never None.
  - #43: `formation_cycle` is updated on every actual value change.
  - #44: crystallization is measured in COMMITMENT AGE (cycles since
    formation_cycle), compared against `commitments.crystallization_threshold`,
    not system age.
  - #45: level upgrade requires BOTH change_count > max_changes_before_upgrade
    AND sufficient commitment age — change count alone never forces it.
  - #46: `restricted_options` is populated on every change and enforced by
    `policy.selection` (referenced by name), which receives the option ban
    list through LayerIO.meta.
  - #47: FIXED commitments are excluded from the change-attempt candidate
    set entirely.
  - #48: reverting to any previous value from the commitment's history costs
    an extra `commitments.revert_extra_cost` multiplier.
  - #49: `check_consistency` rejects mutually contradictory commitments
    (e.g. strategy="conserve" with primary_goal="grow").
  - #50: commitments causally gate behavior via the restriction/enforcement
    channel to `policy.selection` and the ancestral weighting (L38) bias.
  - #52: history records cycle, old value, new value, cost, level, and
    provenance (geometry sector + quantum collapse id).
  - #53: change cost formula is derived: cost_base * (level+1) *
    (1 + 0.2*change_count) * revert_multiplier, all config-traceable.
  - #54: failed change attempts still charge a probe cost and increment
    emergence debt via the returned meta.
  - #55: permanent damage from changes is clamped to [0, 1] via the energy
    ledger (core.energy), never raw addition.
  - #56: restrictions decay geometrically by `commitments.restriction_decay`
    per cycle and merge when below epsilon.

Levantine integration: ADMIXED level semantics (L17, via core/types.py),
`endogamy` commitment key with high change cost (L20), ritual-purity
permanent restriction (L21), ancestral reverence weighting biasing against
change (L38).

Implemented: full scalar manager. While `geometry.lsystem` and
`quantum.observer` are stubbed, the proposal channel draws candidate values
deterministically from a `phitensor.rng.Generator` spawned as the
"commitments" stream (never the global random module — audit #21/#22) and
tags them with explicit provenance marking the scalar stand-in; injected
proposals with real provenance are accepted unchanged. `primary_goal`
initializes to the designer default "survive" and is never None (#42).

Trace: Audit #41-#56; Levantine L17-L21, L38; v7.1 _attempt_commitment_change;
core/types.py Commitment/CommitmentLevel.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

from phitensor.rng import Generator

from stage4.config import Config
from stage4.core.types import (
    Commitment,
    CommitmentLevel,
    FalsificationResult,
    LayerIO,
)

#: v7.1-heritage value pools per commitment key. In the full system these
#: candidates come from `geometry.lsystem` + `quantum.observer` (referenced
#: by name); the scalar core draws from these pinned pools via the seeded
#: "commitments" rng stream so runs are bit-exact (audit #21/#22).
VALUE_POOLS: Dict[str, Tuple[str, ...]] = {
    "strategy": ("explore", "conserve", "optimize"),
    "primary_goal": ("survive", "grow", "adapt"),
    "world_model": ("chaotic", "structured", "hostile"),
    "endogamy": ("open", "closed", "strict"),
}

#: Designer-specified initial values (fixes audit #42: primary_goal is
#: never None).
DESIGNER_DEFAULTS: Dict[str, str] = {
    "strategy": "explore",
    "primary_goal": "survive",
    "world_model": "neutral",
    "endogamy": "open",
}

#: Incompatibility table (fixes audit #49): (key, value, other_key,
#: forbidden other values). Levantine L21: endogamy=strict forbids an
#: exploratory strategy (ritual purity); strategy=conserve contradicts
#: primary_goal=grow; a chaotic world model contradicts conserve.
_INCOMPATIBLE: Tuple[Tuple[str, str, str, frozenset], ...] = (
    ("strategy", "conserve", "primary_goal", frozenset({"grow"})),
    ("endogamy", "strict", "strategy", frozenset({"explore"})),
    ("world_model", "chaotic", "strategy", frozenset({"conserve"})),
)

#: Fraction of the full change cost charged for a failed probe (audit #54).
_PROBE_COST_RATIO: float = 0.25
#: Debt bump reported per failed attempt (routed to agency.emergence, #54).
_FAILED_ATTEMPT_DEBT: float = 0.1
#: Restriction magnitudes below this merge into a consolidated entry (#56).
_RESTRICTION_EPSILON: float = 1e-3
#: v7.1-heritage probability of a self-initiated change proposal per cycle.
_PROPOSAL_RATE: float = 0.1


@dataclass
class ChangeResult:
    """Outcome of one commitment change attempt (success or costly failure).

    Trace: Audit #52, #54 (complete history; failed attempts have cost).
    """

    key: str
    success: bool
    cost: float
    reason: str = ""
    new_level: Optional[CommitmentLevel] = None


class CommitmentManager:
    """Manages the commitment registry and its irreversible dynamics.

    Owns the `Commitment` objects (from core/types.py). Value proposals are
    injected by the caller from geometry.lsystem + quantum.observer (by name
    only); this manager never samples randomness.

    Implemented: full scalar manager. The scalar proposal channel draws from
    the seeded "commitments" rng stream (see module docstring) with explicit
    provenance; external proposals with caller-supplied provenance take
    precedence when present.

    Trace: Audit #41-#56; Levantine L17-L21, L38; SPEC §5.
    """

    #: Layer protocol name (allows registration in `core.loop`).
    name: str = "agency.commitments"

    def __init__(self, config: Config) -> None:
        """Initialize the registry from the `commitments` config section.

        Creates one VOLATILE Commitment per key in `commitments.keys`
        (including `endogamy` per L20); `primary_goal` is initialized from
        the designer goal channel, never None (fixes #42). Loads cost_base,
        crystallization_threshold, change_restriction_rate,
        max_changes_before_upgrade, revert_extra_cost, restriction_decay.

        Implemented: full.

        Trace: Audit #41, #42; Levantine L20; config.py commitments section.
        """
        self._config = config
        self._cost_base = float(config.get("commitments.cost_base", 0.5))
        self._crystallization_threshold = int(
            config.get("commitments.crystallization_threshold", 40)
        )
        self._restriction_rate = float(
            config.get("commitments.change_restriction_rate", 0.15)
        )
        self._max_changes = int(
            config.get("commitments.max_changes_before_upgrade", 3)
        )
        self._revert_extra = float(config.get("commitments.revert_extra_cost", 2.0))
        self._restriction_decay = float(
            config.get("commitments.restriction_decay", 0.999)
        )
        keys = list(config.get("commitments.keys", list(VALUE_POOLS)))
        self._commitments: Dict[str, Commitment] = {}
        for key in keys:
            value = DESIGNER_DEFAULTS.get(key)
            if value is None:
                value = VALUE_POOLS.get(key, ("unset",))[0]
            self._commitments[key] = Commitment(
                key=key,
                value=value,
                level=CommitmentLevel.VOLATILE,
                formation_cycle=0,
            )
        self._restrictions: Dict[str, float] = {}
        self._level_log: Dict[str, List[int]] = {
            key: [int(CommitmentLevel.VOLATILE)] for key in self._commitments
        }
        self._ledger: Any = None  # set per-cycle by step (core.energy ledger)
        seed = int(config.get("system.seed", 49))
        self._rng: Generator = Generator(seed).spawn("commitments")

    @property
    def commitments(self) -> Dict[str, Commitment]:
        """The live commitment registry (read-only view by convention).

        Trace: core/types.py Commitment.
        """
        return self._commitments

    def _ancestral_weight(self, commitment: Commitment) -> float:
        """Levantine L38 ancestral reverence: deeper levels resist change.

        weight = 1 + 0.05 * level — derived from the pinned CommitmentLevel
        ordering, so identity-deep commitments cost more to change.

        Trace: Levantine L38.
        """
        return 1.0 + 0.05 * int(commitment.level)

    def change_cost(self, key: str, new_value: Any) -> float:
        """Derived change cost including revert surcharge.

        cost = cost_base * (level + 1) * (1 + 0.2 * change_count), multiplied
        by revert_extra_cost when new_value appears anywhere in the
        commitment's history (fixes #48), and scaled by the ancestral
        reverence weight (L38) so identity-deep commitments resist change.

        Implemented: full.

        Trace: Audit #48, #53; Levantine L38.
        """
        commitment = self._commitments[key]
        cost = (
            self._cost_base
            * (int(commitment.level) + 1)
            * (1.0 + 0.2 * commitment.change_count)
        )
        seen_values = {entry.get("old_value") for entry in commitment.history}
        seen_values |= {entry.get("new_value") for entry in commitment.history}
        if new_value in seen_values:
            cost *= self._revert_extra  # audit #48
        return cost * self._ancestral_weight(commitment)

    def attempt_change(self, key: str, new_value: Any, cycle: int,
                       provenance: Optional[Dict[str, Any]] = None
                       ) -> ChangeResult:
        """Attempt a painful commitment change with full consequences.

        new_value MUST come with provenance from geometry.lsystem +
        quantum.observer (fixes #41). Rejects immediately (no cost) when the
        commitment is FIXED (fixes #47) or when check_consistency fails
        (fixes #49). On insufficient energy the attempt FAILS but still
        charges a probe cost and signals a debt bump via the result (fixes
        #54). On success: energy is spent via the energy ledger (passed in
        `step`, here recorded), restricted_options is extended (fixes #46),
        permanent damage is applied through the clamped ledger channel
        (fixes #55), formation_cycle and history are updated (fixes #43/#52),
        and level upgrade is evaluated with the age AND count rule
        (fixes #44/#45).

        Implemented: full. Without a ledger attached (direct calls outside
        `step`), energy is treated as sufficient and no charge/damage is
        applied; `step` always attaches the live ledger.

        Trace: Audit #41-#55; Levantine L17, L20, L38; v7.1 base.
        """
        if key not in self._commitments:
            raise KeyError(f"unknown commitment key: {key}")
        commitment = self._commitments[key]
        if commitment.level == CommitmentLevel.FIXED:
            return ChangeResult(key, False, 0.0, reason="fixed")
        if not self.check_consistency(key, new_value):
            return ChangeResult(key, False, 0.0, reason="inconsistent")
        provenance = provenance or {
            "source": "commitments_stream",
            "stream": self._rng.stream,
            "cycle": cycle,
            "note": "scalar-core stand-in for geometry.lsystem + quantum.observer",
        }
        cost = self.change_cost(key, new_value)
        ledger = self._ledger
        if ledger is not None and ledger.energy < cost:
            probe = _PROBE_COST_RATIO * cost
            ledger.spend(probe, reason=f"commitment_probe:{key}")
            return ChangeResult(key, False, probe, reason="insufficient_energy",
                                new_level=commitment.level)

        if ledger is not None:
            ledger.spend(cost, reason=f"commitment_change:{key}")
        old_value = commitment.value
        commitment.value = new_value
        commitment.change_count += 1
        commitment.formation_cycle = cycle  # audit #43
        commitment.history.append({
            "cycle": cycle,
            "old_value": old_value,
            "new_value": new_value,
            "cost": cost,
            "level": int(commitment.level),
            "provenance": provenance,
        })
        # Ban reverting to the just-abandoned value (fixes #46, enforced via
        # enforced_option_bans -> policy.selection by name).
        ban = f"{key}:{old_value}"
        if ban not in commitment.restricted_options:
            commitment.restricted_options.append(ban)
        # Restriction magnitude (v7.1 restriction), tracked for decay (#56).
        level_factor = int(commitment.level) + 1
        restriction = self._restriction_rate * level_factor
        self._restrictions[
            f"commitment_restriction_{key}_{commitment.change_count}"
        ] = restriction
        # Permanent damage only through the clamped ledger channel (#55).
        if ledger is not None:
            ledger.add_damage(0.1 * restriction)
        # Level upgrade evaluation with the age AND count rule (#44/#45);
        # right after a change age is 0, so this can only confirm the level.
        self.maybe_crystallize(key, cycle)
        self._level_log[key].append(int(commitment.level))
        return ChangeResult(key, True, cost, reason="", new_level=commitment.level)

    def check_consistency(self, key: str, new_value: Any) -> bool:
        """Reject contradictory commitment combinations (fixes #49).

        Maintains an explicit incompatibility table (e.g. strategy=conserve
        vs primary_goal=grow; endogamy=open vs purity_code active per L21).

        Implemented: full (see _INCOMPATIBLE).

        Trace: Audit #49; Levantine L21.
        """
        for rule_key, rule_value, other_key, forbidden in _INCOMPATIBLE:
            if key == rule_key and new_value == rule_value:
                other = self._commitments.get(other_key)
                if other is not None and other.value in forbidden:
                    return False
            if key == other_key and new_value in forbidden:
                other = self._commitments.get(rule_key)
                if other is not None and other.value == rule_value:
                    return False
        return True

    def maybe_crystallize(self, key: str, cycle: int) -> bool:
        """Age-based crystallization check (fixes #44).

        Upgrades level by one when commitment AGE (cycle - formation_cycle)
        exceeds crystallization_threshold AND change_count exceeds
        max_changes_before_upgrade (fixes #45); never skips ADMIXED
        (L17 ordering); capped at FIXED. Returns True if upgraded.

        Implemented: full.

        Trace: Audit #44, #45; Levantine L17; CommitmentLevel ordering.
        """
        commitment = self._commitments[key]
        age = cycle - commitment.formation_cycle
        if (
            age > self._crystallization_threshold
            and commitment.change_count > self._max_changes
            and commitment.level < CommitmentLevel.FIXED
        ):
            commitment.level = CommitmentLevel(int(commitment.level) + 1)
            commitment.history.append({
                "cycle": cycle,
                "old_value": commitment.value,
                "new_value": commitment.value,
                "cost": 0.0,
                "level": int(commitment.level),
                "provenance": {"source": "crystallization", "age": age},
            })
            self._level_log[key].append(int(commitment.level))
            return True
        return False

    def decay_restrictions(self) -> Dict[str, float]:
        """Geometric decay and merge of accumulated restrictions (fixes #56).

        Every restriction value is multiplied by
        `commitments.restriction_decay`; entries below epsilon are merged
        into a single consolidated restriction per commitment key.

        Implemented: full.

        Trace: Audit #56; config commitments.restriction_decay.
        """
        decayed: Dict[str, float] = {}
        merged: Dict[str, float] = {}
        for name, magnitude in self._restrictions.items():
            new_magnitude = magnitude * self._restriction_decay
            if new_magnitude < _RESTRICTION_EPSILON:
                key = name.split("_")[2] if name.count("_") >= 2 else name
                merged[key] = merged.get(key, 0.0) + new_magnitude
            else:
                decayed[name] = new_magnitude
        for key, magnitude in merged.items():
            merged_name = f"commitment_restriction_{key}_merged"
            decayed[merged_name] = decayed.get(merged_name, 0.0) + magnitude
        self._restrictions = decayed
        return dict(self._restrictions)

    def enforced_option_bans(self) -> List[str]:
        """Union of restricted_options across commitments for policy gating.

        Consumed by `policy.selection` (referenced by name) to actually
        exclude banned options — this is what makes restrictions enforced,
        not decorative (fixes #46, #50).

        Implemented: full.

        Trace: Audit #46, #50.
        """
        bans = set()
        for commitment in self._commitments.values():
            bans.update(commitment.restricted_options)
        return sorted(bans)

    def _self_proposals(self, cycle: int) -> List[Tuple[str, Any, Dict[str, Any]]]:
        """Scalar proposal channel (deterministic "commitments" rng stream).

        With probability _PROPOSAL_RATE, picks one non-FIXED key (fixes #47)
        and one alternative value from its pinned pool, tagged with explicit
        scalar-stand-in provenance (#41). Stands in for geometry.lsystem +
        quantum.observer while those layers are stubbed.

        Trace: Audit #41, #47; v7.1 occasional commitment changes.
        """
        if self._rng._uniform_scalar(0.0, 1.0) >= _PROPOSAL_RATE:
            return []
        candidates = [
            key for key, c in self._commitments.items()
            if c.level != CommitmentLevel.FIXED
        ]
        if not candidates:
            return []
        key = self._rng.choice(candidates)
        pool = [v for v in VALUE_POOLS.get(key, ()) if v != self._commitments[key].value]
        if not pool:
            return []
        value = self._rng.choice(pool)
        return [(key, value, {
            "source": "commitments_stream",
            "stream": self._rng.stream,
            "cycle": cycle,
            "note": "scalar-core stand-in for geometry.lsystem + quantum.observer",
        })]

    def step(self, inp: LayerIO) -> LayerIO:
        """Advance commitment dynamics one cycle under the LayerIO contract.

        Expects inp.meta keys: `cycle` (int), optional `proposals` (list of
        (key, value, provenance) from geometry.lsystem + quantum.observer),
        `energy_ledger` (core.energy.EnergyLedger). Runs decay_restrictions,
        maybe_crystallize for each key, then processes proposals through
        attempt_change; charges costs to the ledger; returns LayerIO with
        meta carrying enforced_option_bans, results, and debt deltas for
        failed attempts (#54).

        Implemented: full. When meta carries no `proposals`, the scalar
        self-proposal channel (seeded "commitments" stream) supplies them.

        Trace: Audit #41-#56; Levantine L17-L21, L38; Blueprint Part 2.
        """
        meta = inp.meta or {}
        cycle = int(meta.get("cycle", 0))
        self._ledger = meta.get("energy_ledger")

        restrictions = self.decay_restrictions()
        crystallized = [
            key for key in self._commitments
            if self.maybe_crystallize(key, cycle)
        ]
        proposals = meta.get("proposals")
        if proposals is None:
            proposals = self._self_proposals(cycle)
        results: List[ChangeResult] = []
        debt_delta = 0.0
        total_cost = 0.0
        for key, value, provenance in proposals:
            result = self.attempt_change(key, value, cycle, provenance)
            results.append(result)
            total_cost += result.cost
            if not result.success and result.reason == "insufficient_energy":
                debt_delta += _FAILED_ATTEMPT_DEBT  # audit #54

        return LayerIO(
            state={key: c.value for key, c in self._commitments.items()},
            uncertainty=0.0,
            cost=total_cost,
            meta={
                "bans": self.enforced_option_bans(),
                "results": results,
                "debt_delta": debt_delta,
                "restrictions": restrictions,
                "crystallized": crystallized,
            },
        )

    def falsification_test(self) -> FalsificationResult:
        """Kill criterion: irreversibility is monotone per commitment.

        Fails if any commitment's level ever decreased across its recorded
        history (levels may only move VOLATILE -> ... -> FIXED), or if any
        recorded value lacks provenance (fixes #41 regression check).

        Implemented: full.

        Trace: Audit #41, #43, #52; Blueprint Part 8.
        """
        violations = 0
        for key, levels in self._level_log.items():
            for earlier, later in zip(levels, levels[1:]):
                if later < earlier:
                    violations += 1
        for commitment in self._commitments.values():
            for entry in commitment.history:
                if not entry.get("provenance"):
                    violations += 1
        return FalsificationResult(
            name="agency.commitments.monotone_irreversibility",
            passed=violations == 0,
            metric=float(violations),
            threshold=0.0,
            detail="level regressions or missing provenance across histories",
        )


__all__ = ["ChangeResult", "CommitmentManager"]
```

----------------------------------------

### File: `criticality.py`

**Path:** `stage4/stage4/agency/criticality.py`
**Extension:** `.py`
**Size:** 16,330 bytes (15.95 KB)

```py
"""Controlled criticality: precision-noise grounded, adaptively windowed.

Fixes audit #69-80 against v7.1 and integrates Levantine L25, L31, L32:
  - #69: criticality is NOT a random walk — it is computed as a function
    f(P_local, noise_level, B_sensory) of the neurocognitive axes per L25.
  - #70: the optimal range [criticality.optimal_range] is actively enforced
    by a bounded pull term whenever the value leaves the band.
  - #71: the overshoot penalty is an additive, config-scaled charge through
    the clamped energy ledger, never a multiplicative energy drain.
  - #72: the danger-window counter decays on every sub-overshoot cycle, so
    it cannot latch.
  - #73: the correction term is clamped so criticality can never go negative.
  - #74: the emergence boost is routed through agency.emergence's single
    bounded aggregator — no saturation loop (companion to #38).
  - #75: full criticality history is kept (criticality.history_len = 256).
  - #76: an early-warning signal fires when the predicted next-cycle value
    (linear extrapolation over the history) crosses the overshoot bound.
  - #77: overshoot_cycles is bounded by 2 * danger_window and reset rules
    are symmetric.
  - #78: criticality modulates plasticity gain exported to `neuro.axes` and
    learning-rate channels of `world_model.rssm` (referenced by name).
  - #79: local (domain/P_local-driven) and global (system-wide) criticality
    are tracked as separate channels; the reported scalar is their bounded
    combination.
  - #80: "controlled danger" is a policy: overshoot is permitted only inside
    the adaptive window and always costs energy.

Levantine L31: overshoot penalty is scaled by max(0, |P_local| - 1.5) so
precision overload is the real danger signal. Levantine L32: the danger
window adapts to recent shock frequency reported by `neuro.hysteresis`
(referenced by name) — frequent Heinrich-class shocks shrink the window.

Implemented: full scalar controller — local/global channels (#79) driven by
the neurocognitive axes (never a random walk, #69), bounded band enforcement
(#70), capped overshoot counter with symmetric decay (#72/#77), additive
P-scaled penalty (L31/#71), clamped correction (#73), adaptive danger window
(L32), early-warning extrapolation (#76), plasticity gain export (#78), and
the bounded falsification test.

Trace: Audit #69-#80; Levantine L25, L31, L32; v7.1 _manage_criticality_danger;
Enhancement D.25-D.31.
"""

from __future__ import annotations

import math
from collections import deque
from dataclasses import dataclass, field
from typing import Any, Deque, Dict, List, Optional

from stage4.config import Config
from stage4.core.types import FalsificationResult, LayerIO

#: Blend weights for combining the local and global channels (#79).
_LOCAL_WEIGHT: float = 0.6
_GLOBAL_WEIGHT: float = 0.4
#: Bounded band-enforcement pull gain (#70).
_BAND_PULL: float = 0.1
#: Channel relaxation gain: channels move halfway toward their targets.
_CHANNEL_RELAX: float = 0.5


@dataclass
class CriticalityReading:
    """One structured criticality sample for history and early warning.

    Trace: Audit #75, #76, #79 (history, prediction, local/global split).
    """

    cycle: int
    value: float
    local: float
    global_: float
    overshoot: bool
    danger_window: int


class CriticalityController:
    """Precision-noise grounded criticality with adaptive danger window.

    Implemented: full scalar controller (see module docstring).

    Trace: Audit #69-#80; Levantine L25/L31/L32; SPEC §5.
    """

    #: Layer protocol name (allows registration in `core.loop`).
    name: str = "agency.criticality"

    def __init__(self, config: Config) -> None:
        """Initialize from the `criticality` config section.

        Loads optimal_range, overshoot_allowed, overshoot_penalty,
        danger_window, adaptive_window (L32), history_len (#75). Initializes
        local/global criticality at the optimal-range midpoint, bounded
        overshoot counter (#77), empty history deque (#75).

        Implemented: full.

        Trace: Audit #70, #75, #77; Levantine L25, L32; config criticality.
        """
        self._config = config
        opt = config.get("criticality.optimal_range", [0.3, 0.5])
        self._opt_lo = float(opt[0])
        self._opt_hi = float(opt[1])
        self._overshoot_allowed = float(
            config.get("criticality.overshoot_allowed", 0.6)
        )
        self._overshoot_penalty = float(
            config.get("criticality.overshoot_penalty", 0.2)
        )
        self._base_window = int(config.get("criticality.danger_window", 10))
        self._adaptive_window = bool(
            config.get("criticality.adaptive_window", True)
        )
        self._history_len = int(config.get("criticality.history_len", 256))

        midpoint = 0.5 * (self._opt_lo + self._opt_hi)
        self._local: float = midpoint
        self._global: float = midpoint
        self._value: float = midpoint
        self._overshoot_cycles: int = 0
        self._max_overshoot_seen: int = 0
        self._overshoot_events: int = 0
        self._danger_window: int = self._base_window
        self._history: Deque[CriticalityReading] = deque(maxlen=self._history_len)

    @property
    def value(self) -> float:
        """Current combined criticality in [0, 1].

        Trace: Audit #73, #79.
        """
        return self._value

    @property
    def overshoot_cycles(self) -> int:
        """Bounded overshoot counter (capped at 2 * danger_window, #77).

        Trace: Audit #77.
        """
        return self._overshoot_cycles

    @property
    def history(self) -> Deque[CriticalityReading]:
        """Bounded reading history (maxlen = criticality.history_len, #75).

        Trace: Audit #75.
        """
        return self._history

    def compute(self, precision_local: float, noise_level: float,
                boundary_sensory: float, cycle: int) -> float:
        """Criticality as f(P_local, noise, B_sensory) — never random (L25).

        local channel rises with P_local and falls with buffered noise;
        global channel integrates sensory-boundary porosity; the combined
        value is pulled toward optimal_range by a bounded band-enforcement
        term (#70) and clamped to [0, 1] (#73). Appends a CriticalityReading
        to history (#75).

        Implemented: full. Channel targets:
            local_target  = 0.2 + 0.25 * P_local - 0.4 * noise_level
            global_target = 0.4 - 0.2 * B_sensory   (porous -> hot)
        Channels relax halfway toward their targets each cycle, then combine
        0.6/0.4 and receive the bounded band pull.

        Trace: Audit #69, #70, #73, #75, #79; Levantine L25.
        """
        local_target = 0.2 + 0.25 * float(precision_local) - 0.4 * float(noise_level)
        global_target = 0.4 - 0.2 * float(boundary_sensory)
        self._local += _CHANNEL_RELAX * (local_target - self._local)
        self._global += _CHANNEL_RELAX * (global_target - self._global)
        self._local = min(1.0, max(0.0, self._local))
        self._global = min(1.0, max(0.0, self._global))

        value = _LOCAL_WEIGHT * self._local + _GLOBAL_WEIGHT * self._global
        if value < self._opt_lo:
            value += _BAND_PULL * (self._opt_lo - value)
        elif value > self._opt_hi:
            value -= _BAND_PULL * (value - self._opt_hi)
        self._value = min(1.0, max(0.0, value))

        self._history.append(CriticalityReading(
            cycle=cycle,
            value=self._value,
            local=self._local,
            global_=self._global,
            overshoot=self._value > self._overshoot_allowed,
            danger_window=self._danger_window,
        ))
        return self._value

    def manage_overshoot(self, precision_local: float) -> float:
        """Bounded overshoot accounting with precision-scaled penalty.

        While value > overshoot_allowed: overshoot_cycles increments but is
        capped at 2 * current danger_window (#77); the returned energy
        penalty is ADDITIVE: overshoot_penalty * (1 + max(0, |P_local| - 1.5))
        per L31, to be charged via the clamped ledger (fixes #71). Below the
        bound the counter decays symmetrically (#72). When the counter
        exceeds the adaptive danger window, a bounded correction pulls the
        value toward optimal_range[1] without going negative (#73) and the
        overshoot is recorded as a costly event.

        Implemented: full.

        Trace: Audit #71-#73, #77, #80; Levantine L31; v7.1 base.
        """
        if self._value > self._overshoot_allowed:
            self._overshoot_cycles = min(
                self._overshoot_cycles + 1, 2 * self._danger_window
            )
            self._max_overshoot_seen = max(
                self._max_overshoot_seen, self._overshoot_cycles
            )
            penalty = self._overshoot_penalty * (
                1.0 + max(0.0, abs(float(precision_local)) - 1.5)
            )
            if self._overshoot_cycles > self._danger_window:
                correction = 0.5 * (self._value - self._opt_hi)
                correction = min(correction, self._value)  # never negative (#73)
                share_local = _LOCAL_WEIGHT * correction
                share_global = _GLOBAL_WEIGHT * correction
                self._local = max(0.0, self._local - share_local)
                self._global = max(0.0, self._global - share_global)
                self._value = max(0.0, self._value - correction)
                self._overshoot_cycles = 0  # symmetric reset after correction
                self._overshoot_events += 1
            return penalty
        self._overshoot_cycles = max(0, self._overshoot_cycles - 1)  # #72
        return 0.0

    def adapt_danger_window(self, shock_frequency: float) -> int:
        """Adapt the danger window from recent shock frequency (L32).

        When `criticality.adaptive_window` is set, frequent Heinrich-class
        shocks (reported by neuro.hysteresis, passed in) shrink the window
        toward a floor of danger_window // 2; calm histories restore it
        toward the config value. Returns the effective window.

        Implemented: full — window = clip(round(base * (1 - f)),
        base // 2, base) for shock frequency f in [0, 1].

        Trace: Levantine L32; Audit #72; config criticality.adaptive_window.
        """
        if not self._adaptive_window:
            self._danger_window = self._base_window
            return self._danger_window
        frequency = min(1.0, max(0.0, float(shock_frequency)))
        floor = max(1, self._base_window // 2)
        window = int(round(self._base_window * (1.0 - frequency)))
        self._danger_window = max(floor, min(self._base_window, window))
        return self._danger_window

    def early_warning(self) -> bool:
        """Predict next-cycle overshoot from history trend (fixes #76).

        Linear extrapolation over the last min(8, len(history)) readings;
        True when the extrapolated value exceeds overshoot_allowed.

        Implemented: full (least-squares slope; needs >= 2 readings).

        Trace: Audit #76; Enhancement D.30 (survival-analysis-style window).
        """
        readings = list(self._history)[-8:]
        if len(readings) < 2:
            return False
        n = len(readings)
        xs = list(range(n))
        ys = [r.value for r in readings]
        mean_x = sum(xs) / n
        mean_y = sum(ys) / n
        denom = sum((x - mean_x) ** 2 for x in xs)
        if denom <= 0.0:
            return False
        slope = sum((x - mean_x) * (y - mean_y) for x, y in zip(xs, ys)) / denom
        next_value = mean_y + slope * (n - mean_x)
        return next_value > self._overshoot_allowed

    def plasticity_gain(self) -> float:
        """Learning-rate modulation from criticality (fixes #78).

        Peaks inside optimal_range, decays smoothly outside it; consumed by
        neuro.axes and world_model.rssm (referenced by name).

        Implemented: full — gain = exp(-8 * d^2) where d is the distance
        from the optimal band (0 inside it), so gain in (0, 1].

        Trace: Audit #78; Enhancement D.25/D.31.
        """
        if self._opt_lo <= self._value <= self._opt_hi:
            distance = 0.0
        else:
            distance = min(
                abs(self._value - self._opt_lo), abs(self._value - self._opt_hi)
            )
        return math.exp(-8.0 * distance * distance)

    def step(self, inp: LayerIO) -> LayerIO:
        """Advance criticality one cycle under the LayerIO contract.

        Expects inp.meta keys: `precision_local` (float), `noise_level`
        (float from neuro.blankets noise buffer), `boundary_sensory`
        (float), `shock_frequency` (float from neuro.hysteresis), `cycle`
        (int). Runs adapt_danger_window -> compute -> manage_overshoot; the
        emergence boost is exported in meta for agency.emergence's bounded
        aggregator (no direct mutation, fixes #74); returns LayerIO(state=
        value, meta={'penalty':..., 'early_warning':...,
        'plasticity_gain':..., 'danger_window':...}).

        Implemented: full.

        Trace: Audit #69-#80; Levantine L25/L31/L32; Blueprint Part 2.
        """
        meta = inp.meta or {}
        precision_local = float(meta.get("precision_local", 1.0))
        noise_level = float(meta.get("noise_level", 0.0))
        boundary_sensory = float(meta.get("boundary_sensory", 0.0))
        shock_frequency = float(meta.get("shock_frequency", 0.0))
        cycle = int(meta.get("cycle", len(self._history)))

        window = self.adapt_danger_window(shock_frequency)
        value = self.compute(precision_local, noise_level, boundary_sensory, cycle)
        penalty = self.manage_overshoot(precision_local)

        return LayerIO(
            state=value,
            uncertainty=abs(value - 0.5 * (self._opt_lo + self._opt_hi)),
            cost=penalty,
            meta={
                "penalty": penalty,
                "early_warning": self.early_warning(),
                "plasticity_gain": self.plasticity_gain(),
                "danger_window": window,
                "emergence_boost": math.tanh(3.0 * (value - 0.2)),  # #74
                "overshoot_cycles": self._overshoot_cycles,
            },
        )

    def falsification_test(self) -> FalsificationResult:
        """Kill criterion: bounded, non-random, history-consistent dynamics.

        Fails if any reading is outside [0, 1], overshoot_cycles ever
        exceeded 2 * danger_window, or the value series is statistically
        indistinguishable from an uncorrelated random walk (fixes #69 — the
        LJung-Box-style check over history is the metric).

        Implemented: full — metric combines bound violations and a lag-1
        autocorrelation check (a random walk of increments has near-zero
        lag-1 autocorrelation in its level only if it is noise-driven; our
        mean-reverting channels are strongly autocorrelated). With fewer
        than 8 readings the autocorrelation check is vacuously passed.

        Trace: Audit #69, #73, #77; Blueprint Part 8.
        """
        violations = 0
        for reading in self._history:
            if not (0.0 <= reading.value <= 1.0):
                violations += 1
        if self._max_overshoot_seen > 2 * self._base_window:
            violations += 1
        autocorr_ok = True
        values = [r.value for r in self._history]
        if len(values) >= 8:
            mean = sum(values) / len(values)
            var = sum((v - mean) ** 2 for v in values)
            if var > 1e-12:
                cov = sum(
                    (values[i] - mean) * (values[i + 1] - mean)
                    for i in range(len(values) - 1)
                )
                autocorr = cov / var
                autocorr_ok = autocorr > 0.05
            if not autocorr_ok:
                violations += 1
        return FalsificationResult(
            name="agency.criticality.bounded_grounded",
            passed=violations == 0,
            metric=float(violations),
            threshold=0.0,
            detail="bound/overshoot violations plus lag-1 autocorrelation check",
        )


__all__ = ["CriticalityReading", "CriticalityController"]
```

----------------------------------------

### File: `emergence.py`

**Path:** `stage4/stage4/agency/emergence.py`
**Extension:** `.py`
**Size:** 16,849 bytes (16.45 KB)

```py
"""Emergence level, emergence debt, and phase transitions (audit-fixed).

Fixes audit #25-40 against the v7.1 dynamics:
  - #25: emergence is NOT a sigmoid of experience count; it is derived from
    prediction-residual statistics supplied by `self_model.spel` and
    `world_model.rssm` (referenced by name), plus criticality coupling.
  - #27: the debt<->emergence positive feedback loop is broken by routing
    debt into the energy ledger (`core.energy`) only as a bounded multiplier
    and by decaying debt whenever emergence recovers.
  - #28: debt bounds come from `emergence.debt_bound` config, not hard-coded.
  - #29/#30: debt decay and low-emergence threshold are config-driven.
  - #31: consecutive_low_emergence now drives a survival-pressure signal
    consumed by `core.loop` (minimum_for_survival gate).
  - #32: debt raises cognitive operation cost, not only decay.
  - #33: emergence is clamped to [0, 1]; negative values are impossible.
  - #34: history length 128 (config `emergence.history_len`), not 20.
  - #35: phase detection uses a robust Theil-Sen-style slope over the full
    history window, not fragile polyfit on 10 points.
  - #36: phase transitions respect `emergence.phase_cooldown` cycles between
    registrations — no per-step re-appending while a trend persists.
  - #37: phases have entry AND exit (with hysteresis gap); transitions carry
    a duration, and an active phase must fall below threshold minus the exit
    margin before exiting.
  - #38: criticality and CCF boosts are combined through a single bounded
    aggregator here — no double counting.
  - #39: emergence level is exposed as a first-class channel in LayerIO.meta
    so `core.modes` (PROPHETIC gate, L23) and `meta.goal_gen` can use it.
  - #40: update order is residual -> emergence -> debt (enforced by
    `core.loop._residual`; this module exposes the two as separate steps).

Implemented: full scalar tracker. The emergence signal keeps the v7.1
experience-complexity sigmoid as its base (experience count is tracked
internally, one experience per `update_level` call, mirroring the loop's
one-experience-per-cycle remember stage) and combines it with the residual
and criticality terms through ONE bounded aggregator (#38). Phase detection
uses a Theil-Sen median pairwise slope with cooldown-gated entry (#36) and
hysteresis-gated exit (#37).

Trace: Audit #25-#40; v7.1 _calculate_emergence_level/_update_emergence_debt;
Levantine L23 (emergence > 0.6 prophetic gate); Blueprint Part 1.1.
"""

from __future__ import annotations

import math
import statistics
from collections import deque
from dataclasses import dataclass, field
from typing import Any, Deque, Dict, List, Optional

from stage4.config import Config
from stage4.core.types import FalsificationResult, LayerIO

#: Sigmoid slope/offset of the v7.1 experience-complexity base curve.
_SIGMOID_SLOPE: float = 0.1
_SIGMOID_OFFSET: float = 20.0
#: Hysteresis exit margin for active phases (fixes audit #37).
_PHASE_EXIT_MARGIN: float = 0.1
#: Level that must be exceeded (with a positive trend) to enter a phase.
_PHASE_ENTRY_LEVEL: float = 0.5


@dataclass
class PhaseTransition:
    """Structured phase-transition record with entry, exit, and duration.

    Fixes audit #36/#37: transitions are events with cooldown-gated entry
    and hysteresis-gated exit, not per-step log spam.

    Trace: Audit #35-#37; v7.1 phase_transitions list.
    """

    entry_cycle: int
    exit_cycle: Optional[int] = None
    entry_level: float = 0.0
    peak_level: float = 0.0

    @property
    def duration(self) -> Optional[int]:
        """Cycles between entry and exit; None while the phase is active.

        Implemented: full.

        Trace: Audit #37 (transition duration must exist).
        """
        if self.exit_cycle is None:
            return None
        return self.exit_cycle - self.entry_cycle


class EmergenceTracker:
    """Bounded emergence level + debt dynamics + cooldown-gated phases.

    Implemented: full scalar tracker (see module docstring). Debt decay is
    config-scaled as `1 - 0.025 * debt_multiplier` (with the default
    multiplier 2.0 this reproduces v7.1's 0.95 factor — audit #29 makes the
    factor config-derived rather than hard-coded).

    Trace: Audit #25-#40; SPEC.md §5 (agency/emergence.py); v7.1 base.
    """

    #: Layer protocol name (allows registration in `core.loop`).
    name: str = "agency.emergence"

    def __init__(self, config: Config) -> None:
        """Initialize from the `emergence` config section.

        Reads debt_threshold, debt_multiplier, debt_bound,
        minimum_for_survival, history_len (128, fixing #34),
        phase_min_trend, phase_cooldown (fixing #36). Initializes
        emergence_level=0.0, debt=0.0, empty bounded history deque, no
        active phase, cooldown counter 0.

        Implemented: full.

        Trace: Audit #28-#30, #34, #36; config.py emergence section.
        """
        self._config = config
        self._debt_threshold = float(config.get("emergence.debt_threshold", 0.4))
        self._debt_multiplier = float(config.get("emergence.debt_multiplier", 2.0))
        bound = config.get("emergence.debt_bound", [0.0, 3.0])
        self._debt_lo = float(bound[0])
        self._debt_hi = float(bound[1])
        self._min_for_survival = float(
            config.get("emergence.minimum_for_survival", 0.3)
        )
        self._history_len = int(config.get("emergence.history_len", 128))
        self._phase_min_trend = float(config.get("emergence.phase_min_trend", 0.02))
        self._phase_cooldown = int(config.get("emergence.phase_cooldown", 25))

        self._level: float = 0.0
        self._debt: float = 0.0
        self._history: Deque[float] = deque(maxlen=self._history_len)
        self._debt_log: Deque[float] = deque(maxlen=self._history_len)
        self._active_phase: Optional[PhaseTransition] = None
        self._phase_log: List[PhaseTransition] = []
        self._cooldown: int = 0
        self._consecutive_low: int = 0
        self._experience_count: int = 0

    @property
    def emergence_level(self) -> float:
        """Current bounded emergence level in [0, 1] (fixes audit #33).

        Implemented: full.

        Trace: Audit #33; v7.1 emergence_level.
        """
        return self._level

    @property
    def debt(self) -> float:
        """Current emergence debt, bounded by config debt_bound (fixes #28).

        Implemented: full.

        Trace: Audit #28; v7.1 emergence_debt.
        """
        return self._debt

    @property
    def consecutive_low_emergence(self) -> int:
        """Cycles spent continuously below the debt threshold (fixes #31).

        Trace: Audit #31; v7.1 consecutive_low_emergence.
        """
        return self._consecutive_low

    @property
    def history(self) -> Deque[float]:
        """Bounded emergence history (maxlen = emergence.history_len, #34).

        Trace: Audit #34.
        """
        return self._history

    @property
    def phase_log(self) -> List[PhaseTransition]:
        """Completed phase transitions (audit #36/#37 visibility).

        Trace: Audit #36, #37, #140.
        """
        return self._phase_log

    @property
    def active_phase(self) -> Optional[PhaseTransition]:
        """The currently active phase, if any (audit #37).

        Trace: Audit #37.
        """
        return self._active_phase

    def update_level(self, prediction_residual: float,
                     criticality: float, cycle: int) -> float:
        """Update emergence from residual statistics and criticality.

        Combines the prediction residual (from self_model.spel / world_model,
        passed in), the criticality contribution, and any retrocausal boost
        through ONE bounded aggregator (fixes #38 double counting); applies
        the MAP antagonism term (-0.1 * debt, config-scaled); clamps to
        [0, 1] (fixes #33); appends to history (maxlen 128, fixes #34).

        Implemented: full. The bounded aggregator is
            base   = sigmoid(0.1 * (complexity - 20))   (v7.1 heritage)
            level  = base
                     + 0.05 * tanh(3 * (criticality - 0.2))   (v7.1 boost)
                     + 0.10 * tanh(residual - 0.2)            (residual term)
                     - 0.1  * debt                             (MAP antagonism)
        Every term is individually bounded, so the clamp is a guard, not a
        load-bearing wall. `complexity` counts updates (one experience per
        cycle, mirroring `core.loop._remember`).

        Trace: Audit #25, #33, #34, #38; v7.1 _calculate_emergence_level.
        """
        self._experience_count += 1
        complexity = self._experience_count + 1
        base = 1.0 / (1.0 + math.exp(-_SIGMOID_SLOPE * (complexity - _SIGMOID_OFFSET)))
        aggregate = (
            base
            + 0.05 * math.tanh(3.0 * (float(criticality) - 0.2))
            + 0.1 * math.tanh(float(prediction_residual) - 0.2)
        )
        level = aggregate - 0.1 * self._debt  # MAP antagonism (v7.1)
        self._level = min(1.0, max(0.0, level))
        self._history.append(self._level)
        if self._active_phase is not None:
            self._active_phase.peak_level = max(
                self._active_phase.peak_level, self._level
            )
        return self._level

    def update_debt(self, cycle: int) -> float:
        """Update emergence debt AFTER the level update (ordering, #40).

        When level < debt_threshold: debt += (threshold - level) *
        debt_multiplier, and consecutive_low_emergence increments; the
        counter now gates the survival-pressure signal at
        minimum_for_survival (fixes #31). Otherwise debt decays by the
        config-scaled decay factor (fixes #29). Debt is clamped to
        config debt_bound (fixes #28). The effective energy-decay multiplier
        (1 + debt) is exported via meta for `core.energy`, and debt also
        raises the cognitive operation cost (fixes #32).

        Implemented: full. Decay factor = 1 - 0.025 * debt_multiplier
        (config-scaled; equals v7.1's 0.95 at the default multiplier 2.0).

        Trace: Audit #27-#32, #40; v7.1 _update_emergence_debt.
        """
        if self._level < self._debt_threshold:
            self._consecutive_low += 1
            self._debt += (self._debt_threshold - self._level) * self._debt_multiplier
        else:
            self._consecutive_low = 0
            decay_factor = 1.0 - 0.025 * self._debt_multiplier
            self._debt *= decay_factor
        self._debt = min(self._debt_hi, max(self._debt_lo, self._debt))
        self._debt_log.append(self._debt)
        return self._debt

    def inject_debt(self, delta: float) -> float:
        """Externally driven bounded debt bump (failed commitment probe, #54).

        The commitment manager reports failed change attempts through
        LayerIO.meta (`debt_delta`); `core.loop` routes the bump here so all
        debt mutation stays inside the bounded channel (fixes #28).

        Implemented: full.

        Trace: Audit #28, #54.
        """
        self._debt = min(self._debt_hi, max(self._debt_lo, self._debt + float(delta)))
        return self._debt

    def survival_pressure(self) -> bool:
        """True when emergence stays below minimum_for_survival too long.

        Makes consecutive_low_emergence decision-relevant (fixes #31): the
        master loop treats sustained True as a survival threat and routes
        extra allocation via the water-filling budget (Eq #10).

        Implemented: full. The window is derived from config as
        max(5, history_len // 16) — long enough to reject transient dips,
        short enough to react within a fraction of the history horizon.

        Trace: Audit #31; config emergence.minimum_for_survival.
        """
        window = max(5, self._history_len // 16)
        return (
            self._level < self._min_for_survival
            and self._consecutive_low > window
        )

    def _median_slope(self) -> float:
        """Theil-Sen median pairwise slope over the history window (#35).

        Robust to single-sample outliers, unlike v7.1's 10-point polyfit.

        Trace: Audit #35.
        """
        samples = list(self._history)
        n = len(samples)
        if n < 2:
            return 0.0
        slopes = [
            (samples[j] - samples[i]) / (j - i)
            for i in range(n - 1)
            for j in range(i + 1, n)
        ]
        return statistics.median(slopes)

    def detect_phase_transition(self, cycle: int) -> Optional[PhaseTransition]:
        """Robust phase detection with cooldown and hysteresis exit.

        Uses a Theil-Sen-style median pairwise slope over the history window
        (fixes #35). A new phase is entered only if slope > phase_min_trend,
        level > 0.5, no phase is active, and the cooldown since the last exit
        has elapsed (fixes #36). An active phase exits only when the level
        falls below 0.5 minus a fixed hysteresis margin (fixes #37); peak
        level and duration are recorded on exit.

        Implemented: full.

        Trace: Audit #34-#37; v7.1 phase transition block.
        """
        if self._cooldown > 0:
            self._cooldown -= 1
        if self._active_phase is not None:
            if self._level < _PHASE_ENTRY_LEVEL - _PHASE_EXIT_MARGIN:
                finished = self._active_phase
                finished.exit_cycle = cycle
                self._phase_log.append(finished)
                self._active_phase = None
                self._cooldown = self._phase_cooldown
                return finished
            return None
        if self._cooldown > 0:
            return None
        if self._level > _PHASE_ENTRY_LEVEL and len(self._history) >= 2:
            if self._median_slope() > self._phase_min_trend:
                self._active_phase = PhaseTransition(
                    entry_cycle=cycle,
                    entry_level=self._level,
                    peak_level=self._level,
                )
                return self._active_phase
        return None

    def step(self, inp: LayerIO) -> LayerIO:
        """Advance emergence dynamics one cycle under the LayerIO contract.

        Expects inp.meta keys: `prediction_residual` (float), `criticality`
        (float), `cycle` (int); optionally `debt_delta` (float, failed
        commitment probes from agency.commitments, #54). Runs update_level ->
        update_debt -> detect_phase_transition in that fixed order (#40) and
        returns LayerIO(state=level, uncertainty=residual-derived,
        cost=debt-scaled cognitive surcharge (#32), meta={'debt':...,
        'survival_pressure':..., 'phase':...}) for consumption by core.modes
        (L23 gate) and meta.goal_gen (#39).

        Implemented: full.

        Trace: Audit #25-#40; Blueprint Part 2.
        """
        meta = inp.meta or {}
        residual = float(meta.get("prediction_residual", 0.0))
        criticality = float(meta.get("criticality", 0.4))
        cycle = int(meta.get("cycle", self._experience_count))
        debt_delta = float(meta.get("debt_delta", 0.0))

        level = self.update_level(residual, criticality, cycle)
        debt = self.update_debt(cycle)
        if debt_delta != 0.0:
            debt = self.inject_debt(debt_delta)
        phase = self.detect_phase_transition(cycle)

        return LayerIO(
            state=level,
            uncertainty=abs(residual),
            cost=0.05 * debt,  # debt-scaled cognitive surcharge (#32)
            meta={
                "debt": debt,
                "survival_pressure": self.survival_pressure(),
                "phase": phase,
                "consecutive_low_emergence": self._consecutive_low,
                "energy_decay_multiplier": 1.0 + debt,
            },
        )

    def falsification_test(self) -> FalsificationResult:
        """Kill criterion: emergence and debt stay inside their bounds.

        Fails if any history sample is outside [0, 1] (#33) or any debt
        sample outside config debt_bound (#28).

        Implemented: full.

        Trace: Audit #28, #33; Blueprint Part 8.
        """
        violation = 0.0
        for sample in self._history:
            violation = max(violation, -sample, sample - 1.0)
        for sample in self._debt_log:
            violation = max(
                violation, self._debt_lo - sample, sample - self._debt_hi
            )
        violation = max(0.0, violation)
        return FalsificationResult(
            name="agency.emergence.bounds",
            passed=violation <= 0.0,
            metric=violation,
            threshold=0.0,
            detail="max bound violation across emergence/debt history",
        )


__all__ = ["PhaseTransition", "EmergenceTracker"]
```

----------------------------------------

### File: `scars.py`

**Path:** `stage4/stage4/agency/scars.py`
**Extension:** `.py`
**Size:** 16,121 bytes (15.74 KB)

```py
"""Identity scars: structured records of stagnation, collapse, social friction.

Fixes audit #57-68 against v7.1 and integrates Levantine L22:
  - #57: the stagnation counter decays symmetrically (rate config-derived),
    not "+1 on bad / -1 on good" asymmetry.
  - #58: scar severity is derived from stagnation overshoot AND current
    emergence deficit, with the formula documented and config-scaled.
  - #59: subsystem selection is NOT random — the subsystem with the highest
    current prediction-error attribution (from self_model.spel meta,
    referenced by name) receives the scar.
  - #60: scars gate behavior: each scar's restriction_key is exported to
    `policy.selection` (by name) and to `neuro.alignment` boundary monitors.
  - #61: scars are structured `core.types.Scar` objects (subsystem, severity,
    origin, formed_cycle, restriction_key), not bare floats.
  - #62: scars are narratively integrated — each scar is tagged for
    `memory.narrative` NBC compression with deep-time tags (L39 channel).
  - #63: post-scar stagnation reset uses a configurable partial-reset ratio,
    not `//= 2`.
  - #64: scar config values are validated by stage4.config rules.
  - #65: permanent damage contribution from scars is clamped through
    core.energy (total damage never exceeds 1).
  - #66: restriction keys embed a monotonically increasing scar sequence id,
    so keys can never collide even after list resets.
  - #67: scars heal: severity decays at `scars.healing_rate` per cycle and
    the associated restriction strength weakens proportionally; a fully
    healed scar remains as a zero-severity identity record (compensation,
    not erasure).
  - #68: identity (the scar set) is exposed via `identity_vector()` and used
    by `policy.selection` and `meta.goal_gen` (referenced by name) so scars
    influence decisions.

Levantine L22: social-friction scars form when B_social > +1.5 and social
reward is low — relational mismatch, not just stagnation.

Implemented: full scalar manager — symmetric stagnation counter (#57),
documented config-scaled severity (#58), deterministic attribution argmax
(#59) with a seeded "scars" rng fallback when no attribution map is
available, structured Scar creation with monotone sequence ids (#61/#66),
slow healing (#67), identity vector export (#68), and the social-friction
hook (L22) that accepts boundary-valued inputs without error. The partial
reset ratio is fixed at 0.5 (v7.1's `//= 2`), named as a module constant
since `scars.*` has no dedicated key (#63 documents the ratio here).

Trace: Audit #57-#68; Levantine L22, L39; v7.1 _check_stagnation_scars;
core/types.py Scar.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from phitensor.rng import Generator

from stage4.config import Config
from stage4.core.types import FalsificationResult, LayerIO, Scar

#: Valid scar origins (Scar.origin contract from core/types.py).
SCAR_ORIGINS: tuple = ("stagnation", "collapse", "social_friction")

#: Partial-reset ratio applied to the stagnation counter after a scar
#: forms (audit #63; v7.1 used `//= 2`, i.e. 0.5).
_STAGNATION_RESET_RATIO: float = 0.5
#: Low social-reward margin for the L22 social-friction gate; matches the
#: ENCAPSULATED social_influence gate (core/types.py, Levantine L7).
_SOCIAL_REWARD_MARGIN: float = 0.3
#: Minimum cycles between social-friction scars (keeps L22 scarring
#: episodic rather than per-cycle; tied to the stagnation threshold).
_SOCIAL_SCAR_COOLDOWN_MULTIPLIER: float = 1.0


class ScarManager:
    """Forms, tracks, heals, and exports identity scars.

    Implemented: full scalar manager (see module docstring).

    Trace: Audit #57-#68; Levantine L22; SPEC §5 (agency/scars.py).
    """

    #: Layer protocol name (allows registration in `core.loop`).
    name: str = "agency.scars"

    def __init__(self, config: Config) -> None:
        """Initialize from the `scars` config section.

        Loads stagnation_threshold, restriction_strength, healing_rate,
        subsystems; initializes an empty scar registry per subsystem, a
        stagnation counter, a monotone scar sequence counter (fixes #66),
        and a zero total-healed accumulator.

        Implemented: full.

        Trace: Audit #57, #64, #66, #67; config.py scars section.
        """
        self._config = config
        self._stagnation_threshold = int(
            config.get("scars.stagnation_threshold", 20)
        )
        self._restriction_strength = float(
            config.get("scars.restriction_strength", 0.3)
        )
        self._healing_rate = float(config.get("scars.healing_rate", 0.001))
        self._subsystems: List[str] = list(
            config.get("scars.subsystems",
                       ["perception", "memory", "executive", "adaptation"])
        )
        self.scars: Dict[str, List[Scar]] = {s: [] for s in self._subsystems}
        self.stagnation_counter: int = 0
        self.last_emergence: float = 0.0
        self._scar_seq: int = 0
        self.total_healed: float = 0.0
        self._last_social_scar_cycle: int = -(10**9)
        self._social_cooldown = max(
            1, int(_SOCIAL_SCAR_COOLDOWN_MULTIPLIER * self._stagnation_threshold)
        )
        seed = int(config.get("system.seed", 49))
        self._rng: Generator = Generator(seed).spawn("scars")

    @property
    def scar_count(self) -> int:
        """Total number of scars across subsystems (healed included, #67).

        Trace: Audit #67 (compensation, not erasure).
        """
        return sum(len(v) for v in self.scars.values())

    def attribute_subsystem(self, error_attribution: Dict[str, float]) -> str:
        """Pick the subsystem with maximal prediction-error attribution.

        Deterministic argmax over the attribution map supplied by
        self_model.spel meta (fixes #59: no random subsystem choice); ties
        break by config subsystem order. When the map carries no known
        subsystem (e.g. self_model.spel is stubbed and supplies nothing),
        falls back to a deterministic draw from the seeded "scars" rng
        stream — never the global random module (audit #21/#22).

        Implemented: full.

        Trace: Audit #59.
        """
        best: Optional[str] = None
        best_value = float("-inf")
        for subsystem in self._subsystems:
            if subsystem in error_attribution:
                value = float(error_attribution[subsystem])
                if value > best_value:
                    best = subsystem
                    best_value = value
        if best is not None:
            return best
        return self._rng.choice(self._subsystems)

    def form_scar(self, subsystem: str, origin: str, severity: float,
                  cycle: int) -> Scar:
        """Create a structured Scar with a collision-free restriction key.

        Severity is clamped to [0, 1]; origin must be in SCAR_ORIGINS;
        restriction_key embeds the monotone scar sequence id (fixes #66).
        The scar's restriction strength (severity * restriction_strength) is
        applied to permanent damage ONLY through the clamped energy-ledger
        channel in `step` (fixes #65). The scar is tagged for NBC narrative
        integration (fixes #62).

        Implemented: full.

        Trace: Audit #61, #62, #65, #66; core/types.py Scar.
        """
        if origin not in SCAR_ORIGINS:
            raise ValueError(
                f"invalid scar origin {origin!r}; must be one of {SCAR_ORIGINS}"
            )
        if subsystem not in self.scars:
            self.scars[subsystem] = []
            if subsystem not in self._subsystems:
                self._subsystems.append(subsystem)
        scar = Scar(
            subsystem=subsystem,
            severity=min(1.0, max(0.0, float(severity))),
            origin=origin,
            formed_cycle=cycle,
            restriction_key=f"{origin}_{subsystem}_{self._scar_seq}",
        )
        self._scar_seq += 1
        self.scars[subsystem].append(scar)
        return scar

    def check_stagnation(self, emergence_level: float,
                         error_attribution: Dict[str, float],
                         cycle: int) -> Optional[Scar]:
        """Stagnation-driven scar formation with symmetric counter decay.

        Counter increments when emergence fails to improve and decays by the
        same rate when it does (fixes #57). At stagnation_threshold a scar of
        derived severity (fixes #58) forms on the attributed subsystem (fixes
        #59), and the counter resets by a configurable partial-reset ratio
        (fixes #63).

        Implemented: full. Severity (fixes #58):
            severity = clamp(restriction_strength
                             + 0.05 * (counter - threshold)   # overshoot
                             + 0.5 * max(0, 0.5 - emergence),  # deficit
                             0, 1)

        Trace: Audit #57-#59, #63; v7.1 _check_stagnation_scars.
        """
        if emergence_level <= self.last_emergence:
            self.stagnation_counter += 1
        else:
            self.stagnation_counter = max(0, self.stagnation_counter - 1)
        self.last_emergence = emergence_level

        if self.stagnation_counter < self._stagnation_threshold:
            return None
        overshoot = self.stagnation_counter - self._stagnation_threshold
        severity = (
            self._restriction_strength
            + 0.05 * overshoot
            + 0.5 * max(0.0, 0.5 - emergence_level)
        )
        subsystem = self.attribute_subsystem(error_attribution)
        scar = self.form_scar(subsystem, "stagnation", severity, cycle)
        self.stagnation_counter = int(
            self.stagnation_counter * _STAGNATION_RESET_RATIO
        )
        return scar

    def check_social_friction(self, boundary_social: float,
                              social_reward: float, cycle: int
                              ) -> Optional[Scar]:
        """Social-friction scar formation (Levantine L22).

        Forms a scar with origin='social_friction' when B_social > +1.5
        (config neuro.dual_boundary.social) and social_reward is below the
        low-reward margin — relational mismatch scarring, independent of
        stagnation.

        Implemented: full. Boundary-valued inputs are accepted without
        error (comparisons are explicit and totals are clamped); a cooldown
        of `scars.stagnation_threshold` cycles keeps scarring episodic.

        Trace: Levantine L22; config neuro.dual_boundary.
        """
        dual = self._config.get("neuro.dual_boundary",
                                {"social": 1.5, "sensory": -0.5})
        threshold = float(dual["social"])
        boundary_social = float(boundary_social)
        social_reward = float(social_reward)
        if boundary_social <= threshold or social_reward >= _SOCIAL_REWARD_MARGIN:
            return None
        if cycle - self._last_social_scar_cycle < self._social_cooldown:
            return None
        severity = (
            self._restriction_strength
            + 0.2 * (boundary_social - threshold)
            + 0.2 * (_SOCIAL_REWARD_MARGIN - social_reward)
        )
        scar = self.form_scar("executive", "social_friction", severity, cycle)
        self._last_social_scar_cycle = cycle
        return scar

    def heal(self) -> float:
        """Slow scar healing/compensation at config healing_rate (fixes #67).

        Every scar's severity decays by healing_rate per cycle; the scar's
        restriction strength is reduced proportionally; fully healed scars
        (severity <= eps) stay in the registry as identity records with
        severity 0 — compensation, not erasure. Returns the total severity
        healed this cycle.

        Implemented: full.

        Trace: Audit #67; config scars.healing_rate.
        """
        healed = 0.0
        for registry in self.scars.values():
            for scar in registry:
                if scar.severity <= 0.0:
                    continue
                before = scar.severity
                scar.severity = max(0.0, scar.severity * (1.0 - self._healing_rate))
                healed += before - scar.severity
        self.total_healed += healed
        return healed

    def identity_vector(self) -> Dict[str, float]:
        """Aggregate scar state per subsystem for decision-making (fixes #68).

        Returns {subsystem: total active severity}; consumed by
        policy.selection and meta.goal_gen (referenced by name) so identity
        actually shapes behavior, and by eval.report for the irreversibility
        index.

        Implemented: full.

        Trace: Audit #60, #68; Levantine L22.
        """
        return {
            subsystem: sum(scar.severity for scar in registry)
            for subsystem, registry in self.scars.items()
        }

    def step(self, inp: LayerIO) -> LayerIO:
        """Advance scar dynamics one cycle under the LayerIO contract.

        Expects inp.meta keys: `emergence_level` (float),
        `error_attribution` (dict from self_model.spel), `boundary_social`
        (float), `social_reward` (float), `cycle` (int). Runs heal ->
        check_stagnation -> check_social_friction; new scar restriction
        strengths are reported in meta so `core.loop` can apply them through
        the clamped energy ledger (fixes #65); returns LayerIO(state=
        identity_vector(), meta={'new_scars': [...], 'healed': ...}).

        Implemented: full.

        Trace: Audit #57-#68; Levantine L22; Blueprint Part 2.
        """
        meta = inp.meta or {}
        emergence_level = float(meta.get("emergence_level", 0.0))
        error_attribution = meta.get("error_attribution") or {}
        boundary_social = float(meta.get("boundary_social", 0.0))
        social_reward = float(meta.get("social_reward", 1.0))
        cycle = int(meta.get("cycle", self._scar_seq))

        healed = self.heal()
        new_scars: List[Scar] = []
        stagnation_scar = self.check_stagnation(
            emergence_level, error_attribution, cycle
        )
        if stagnation_scar is not None:
            new_scars.append(stagnation_scar)
        social_scar = self.check_social_friction(boundary_social, social_reward, cycle)
        if social_scar is not None:
            new_scars.append(social_scar)

        # Restriction strength of new scars; the loop applies it to permanent
        # damage only through the clamped energy-ledger channel (fixes #65).
        damage_delta = sum(
            scar.severity * self._restriction_strength * 0.1 for scar in new_scars
        )
        return LayerIO(
            state=self.identity_vector(),
            uncertainty=0.0,
            cost=0.0,
            meta={
                "new_scars": new_scars,
                "healed": healed,
                "damage_delta": damage_delta,
                "restriction_keys": [s.restriction_key for s in new_scars],
            },
        )

    def falsification_test(self) -> FalsificationResult:
        """Kill criterion: scar bookkeeping invariants.

        Fails if any scar severity is outside [0, 1], any restriction_key
        collides, or total scar-attributed damage ever exceeded the clamped
        ledger bound (regression check for #65/#66).

        Implemented: full.

        Trace: Audit #61, #65, #66; Blueprint Part 8.
        """
        violations = 0
        keys: List[str] = []
        for registry in self.scars.values():
            for scar in registry:
                if not (0.0 <= scar.severity <= 1.0):
                    violations += 1
                keys.append(scar.restriction_key)
        if len(keys) != len(set(keys)):
            violations += 1
        return FalsificationResult(
            name="agency.scars.bookkeeping",
            passed=violations == 0,
            metric=float(violations),
            threshold=0.0,
            detail="severity bounds, restriction-key uniqueness, damage bound",
        )


__all__ = ["SCAR_ORIGINS", "ScarManager"]
```

----------------------------------------

##### Directory: `stage4/stage4/agency/__pycache__`


#### Directory: `stage4/stage4/quantum`


### File: `__init__.py`

**Path:** `stage4/stage4/quantum/__init__.py`
**Extension:** `.py`
**Size:** 1,345 bytes (1.31 KB)

```py
"""Quantum observer, holographic, spacetime, and signal layers (GhostMesh B-E).

Commitments in this system exist in superposition until observed: the
quantum observer layer collapses them into eigenstates (G11), freezes them
under over-monitoring via the Zeno effect (G16), and lets rare forbidden
changes tunnel through barriers (G17). Entangled commitments form
non-classical correlation structure (G12-G13, G19, G36). Identity memory
is written on surfaces, not volumes (G21-G24, G40), spacetime curvature
models attention and collapse risk (G25-G34), and the 2024-2026 signal
layer adds logical-identity longevity, supersolid/time-crystal modes,
fractional states, magic-angle resonance, and flavor oscillation
(G35-G42).

This package also hosts the CCF successor (counterfactual causal filter,
audit #119-#128) in ``observer.py`` and the oscillator/decoherence
equation block (Eq #97-#110) split between ``observer.py`` and
``signals.py``.

Traceability:
  - GhostMesh patch #11-#42 (quantum observer / holographic / spacetime / signals)
  - v7.1 audit #119-#128 (CCF successor); Eq #97-#110
  - SPEC.md section 5 (G11-G42 -> quantum/*)
"""

from __future__ import annotations

from stage4.quantum import entanglement, holography, observer, signals, spacetime

__all__ = ["observer", "entanglement", "holography", "spacetime", "signals"]
```

----------------------------------------

### File: `entanglement.py`

**Path:** `stage4/stage4/quantum/entanglement.py`
**Extension:** `.py`
**Size:** 7,122 bytes (6.96 KB)

```py
"""Entangled commitments: Bell pairs, CHSH detection, ER=EPR, spin current.

Commitments can be linked so that changing one instantly affects its
partner (G12, Bell-state ``(|00> + |11>)/sqrt(2)``). The CHSH detector
certifies when inter-subsystem coupling exceeds any classical explanation
(G13). ER=EPR links make distant commitments one object connected by a
non-traversable wormhole (G19), and graphene-style spin current transmits
commitment *influence* without energy transfer (G36).

Collaborators (referenced, never imported): ``agency/commitments.py``
creates and mutates the paired commitments; ``core/energy.py`` verifies
that spin-current events carry zero energy delta.

Traceability:
  - GhostMesh patch #12 (entangled correlated commitments)
  - GhostMesh patch #13 (CHSH violation detector)
  - GhostMesh patch #19 (ER = EPR pairing)
  - GhostMesh patch #36 (graphene spin current, charge-free influence)
  - SPEC.md section 5 (G12/G13/G19 -> quantum/entanglement.py; G36 host)
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

from stage4.config import Config, load_config
from stage4.core.types import Commitment, FalsificationResult


@dataclass
class EntangledPair:
    """A Bell-correlated pair of commitments.

    ``correlation_log`` records every joint measurement outcome for CHSH
    scoring; ``wormhole`` marks whether the pair is also an ER=EPR link
    (G19), i.e. a non-traversable bridge: correlations pass, agents do not.

    Trace: GhostMesh #12 (Bell state), #19 (ER=EPR).
    """

    pair_id: str
    key_a: str
    key_b: str
    sector_a: int
    sector_b: int
    wormhole: bool = False
    correlation_log: List[Tuple[int, int]] = field(default_factory=list)


class EntanglementRegistry:
    """Registry of entangled commitment pairs and their correlations.

    Owns ``entangled_pairs``: creation of Bell pairs, propagation of a
    change on one side to its partner, CHSH scoring over accumulated
    correlation logs, ER=EPR link marking between distant sectors, and
    charge-free spin-current influence events.

    Trace: GhostMesh #12/#13/#19/#36; config quantum section.
    """

    def __init__(self, config: Config | None = None) -> None:
        """Bind CHSH bounds and initialize the empty pair registry.

        Args:
            config: Frozen config; reads ``quantum.chsh_classical_bound``
                (2.0) and ``quantum.chsh_quantum_bound`` (2*sqrt(2)).

        Trace: GhostMesh #13; config quantum section.
        """
        raise NotImplementedError("spec: bind CHSH bounds; entangled_pairs = []")

    def entangle(self, commitment_a: Commitment, commitment_b: Commitment) -> EntangledPair:
        """Create a Bell-correlated pair from two commitments.

        Registers the pair so future changes propagate; the pair is the
        system-level object ``(|00> + |11>)/sqrt(2)`` made of two
        commitment registers.

        Args:
            commitment_a: First commitment (must be sector-stamped, G1).
            commitment_b: Second commitment.

        Returns:
            The registered ``EntangledPair``.

        Trace: GhostMesh #12 (self.entangled_pairs linking commitments).
        """
        raise NotImplementedError("spec: register Bell pair of two commitments")

    def propagate_change(self, pair_id: str, changed_key: str, new_value: object) -> Optional[Tuple[str, object]]:
        """Propagate a change on one side of a pair to its partner.

        Changing one commitment instantly constrains its partner: returns
        the partner key and its correlated value so
        ``agency/commitments.py`` can apply the correlated update. The
        propagation is a correlation, not a signal — it cannot carry
        controllable information (no-communication preserved).

        Args:
            pair_id: Identifier of the entangled pair.
            changed_key: Key of the commitment that changed.
            new_value: The new value on the changed side.

        Returns:
            ``(partner_key, correlated_value)`` or ``None`` if unknown pair.

        Trace: GhostMesh #12 (changing one instantly affects its partner).
        """
        raise NotImplementedError("spec: correlated partner update without signaling")

    def chsh_score(self, pair_id: str) -> float:
        """CHSH correlation score over a pair's joint measurement log.

        Computes ``S = |E(a,b) - E(a,b') + E(a',b) + E(a',b')|`` from the
        recorded settings/outcomes; compared against the classical bound
        (2.0) and quantum bound (2*sqrt(2) ~= 2.828) from config.

        Args:
            pair_id: Pair whose correlation log is scored.

        Returns:
            The CHSH S-value; ``S > 2`` certifies non-classical coupling.

        Trace: GhostMesh #13 (_chsh_score(); classical <= 2, quantum <= 2.828).
        """
        raise NotImplementedError("spec: CHSH S from correlation_log vs configured bounds")

    def er_epr_link(self, pair_id: str) -> EntangledPair:
        """Mark a pair as an ER=EPR link between distant commitments.

        Sets ``wormhole=True``: the two commitments become one object
        whose ends may sit in different sectors ("activated sigils"). The
        bridge is non-traversable — correlation passes, traversal pays the
        Morris-Thorne toll in ``quantum/spacetime.py``.

        Args:
            pair_id: Pair to promote to an ER=EPR link.

        Returns:
            The updated pair with ``wormhole`` set.

        Trace: GhostMesh #19 (entangled qubits = non-traversable wormholes).
        """
        raise NotImplementedError("spec: mark pair as non-traversable ER=EPR bridge")

    def spin_current(self, source: Commitment, target: Commitment, magnitude: float) -> float:
        """Transmit commitment influence without energy transfer.

        Graphene-style spin current: ``source`` biases ``target``'s value
        distribution by ``magnitude`` while the energy ledger delta is
        exactly zero — influence without charge. ``core/energy.py``
        asserts the zero-cost invariant on these events.

        Args:
            source: Influencing commitment.
            target: Influenced commitment.
            magnitude: Signed influence strength.

        Returns:
            The energy delta of the event (must be 0.0).

        Trace: GhostMesh #36 (_spin_current(); influence without cost).
        """
        raise NotImplementedError("spec: zero-energy influence bias from source to target")

    def falsification_test(self) -> FalsificationResult:
        """Kill criterion: no-communication and CHSH bound consistency.

        Fails if a spin-current event carries nonzero energy delta, or if
        any pair exceeds the quantum bound 2*sqrt(2) (post-selection
        artifact), or if classical-baseline pairs exceed 2.0.

        Trace: GhostMesh #13/#36; Blueprint Part 8 (Falsifiable).
        """
        raise NotImplementedError("spec: zero-energy invariant + CHSH bound consistency")


__all__ = ["EntangledPair", "EntanglementRegistry"]
```

----------------------------------------

### File: `holography.py`

**Path:** `stage4/stage4/quantum/holography.py`
**Extension:** `.py`
**Size:** 9,552 bytes (9.33 KB)

```py
"""Holographic layer: area entropy, bulk-boundary duality, error correction.

Identity memory is written on surfaces, not volumes: Bekenstein-Hawking
area entropy ``S = k*A / (4*l_p**2)`` bounds what the identity boundary
can store (G21); the bulk (3D visionary state) and boundary (flat seal)
are one description linked by holographic duality (G22); logical
commitments are encoded redundantly across sectors so they survive
sector failures via topological error correction (G23); commitment
history intervals are Lorentz-invariant (G24); and celestial holography
projects the 4D state onto the 2D conformal boundary (G40).

Collaborators (referenced, never imported): ``memory/crystal.py`` stores
boundary-written records; ``geometry/fractals.py`` renders the boundary
surface this module's entropy bound applies to.

Traceability:
  - GhostMesh patch #21-#24 (holographic and entropic gravity layer)
  - GhostMesh patch #40 (celestial holography)
  - SPEC.md section 5 (G21-G28 -> quantum/holography.py; G40 host)
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Dict, List

from stage4.config import Config, load_config
from stage4.core.types import Commitment, FalsificationResult, LayerIO

if TYPE_CHECKING:
    # Allowed skeleton import (SPEC section 2); annotations only.
    from phitensor.tensor import Tensor

#: Planck-length-squared unit used for area normalization (natural units).
PLANCK_LENGTH_SQ: float = 1.0

#: Boltzmann constant in natural units for the area-entropy law.
BOLTZMANN_K: float = 1.0


def area_entropy(boundary_area: float) -> float:
    """Bekenstein-Hawking entropy of the identity boundary.

    ``S = k * A / (4 * l_p**2)`` — the maximum information the boundary
    surface can carry. Memory written beyond this bound must either grow
    the boundary (Koch refinement, G4) or be forgotten (Landauer cost in
    ``core/energy.py``).

    Args:
        boundary_area: Area of the identity boundary surface.

    Returns:
        Entropy capacity of the surface in natural units.

    Trace: GhostMesh #21 (S = kA/(4 l_p^2); memory on the surface).
    """
    raise NotImplementedError("spec: S = k * A / (4 * l_p^2)")


class HolographicDual:
    """AdS/CFT-style duality between bulk state and boundary state.

    Maintains ``bulk_state`` (the 3D visionary space) and
    ``boundary_state`` (the flat seal) as two descriptions of one system;
    ``holographic_dual()`` translates between them. Boundary computations
    are cheaper; bulk computations are geometric — the dual picks the
    frame where the current question is simplest.

    Trace: GhostMesh #22 (bulk with gravity dual to boundary without).
    """

    def __init__(self, config: Config | None = None) -> None:
        """Initialize empty bulk and boundary registers.

        Args:
            config: Frozen config (backend dtype/device for state tensors).

        Trace: GhostMesh #22 (self.bulk_state, self.boundary_state).
        """
        raise NotImplementedError("spec: init bulk_state and boundary_state registers")

    def to_boundary(self, bulk_state: Tensor) -> Tensor:
        """Project a bulk state onto the conformal boundary.

        Args:
            bulk_state: Bulk (volumetric) state tensor.

        Returns:
            Boundary (surface) state tensor, one dimension lower.

        Trace: GhostMesh #22 (_holographic_dual(), bulk -> boundary).
        """
        raise NotImplementedError("spec: bulk-to-boundary projection")

    def to_bulk(self, boundary_state: Tensor) -> Tensor:
        """Reconstruct the bulk state from boundary data.

        The inverse of :meth:`to_boundary` up to the boundary entropy
        bound (G21): reconstruction loses what the surface cannot hold.

        Args:
            boundary_state: Boundary (surface) state tensor.

        Returns:
            Reconstructed bulk state tensor.

        Trace: GhostMesh #22 (one description, two frames).
        """
        raise NotImplementedError("spec: boundary-to-bulk reconstruction within entropy bound")

    def holographic_dual(self, state: LayerIO) -> LayerIO:
        """Translate a LayerIO between frames, preserving the contract.

        Chooses the translation direction from ``state.meta`` and returns
        the dual description with updated uncertainty (reconstruction loss
        increases uncertainty by the entropy-bound deficit).

        Args:
            state: Layer IO in either the bulk or boundary frame.

        Returns:
            Layer IO in the dual frame.

        Trace: GhostMesh #22; Blueprint Part 2 (LayerIO contract).
        """
        raise NotImplementedError("spec: frame translation with entropy-bound uncertainty cost")

    def falsification_test(self) -> FalsificationResult:
        """Kill criterion: round-trip loss must equal the entropy bound.

        Fails if bulk -> boundary -> bulk loses more information than the
        area-entropy bound predicts (an implementation bug) or less (a
        violation of the holographic bound itself).

        Trace: GhostMesh #21/#22; Blueprint Part 8 (Falsifiable).
        """
        raise NotImplementedError("spec: round-trip loss equals area-entropy deficit")


class TopologicalErrorCorrection:
    """Logical commitments encoded redundantly across sectors.

    ``logical_commitments`` spreads each critical commitment across
    multiple sectors of the S(7,7) grid so that individual sector failures
    (scars, quarantined nodes) do not destroy it. Syndrome measurement
    localizes damaged sectors; recovery re-encodes from healthy
    redundancy. Logical qubits outlive physical ones.

    Trace: GhostMesh #23 (topological error correction across sectors).
    """

    def __init__(self, config: Config | None = None) -> None:
        """Initialize the logical commitment table.

        Args:
            config: Frozen config; reads ``geometry.sectors`` for the
                redundancy layout.

        Trace: GhostMesh #23; config geometry.sectors.
        """
        raise NotImplementedError("spec: init logical commitment table over sectors")

    def encode(self, commitment: Commitment, redundancy: int = 3) -> List[int]:
        """Encode a commitment across ``redundancy`` sectors.

        Args:
            commitment: The commitment to protect.
            redundancy: Number of sector copies (odd for majority vote).

        Returns:
            Sector indices holding the encoded copies.

        Trace: GhostMesh #23 (logical_commitments encoded across sectors).
        """
        raise NotImplementedError("spec: distribute encoded copies across sectors")

    def syndrome(self, key: str) -> List[int]:
        """Measure which sector copies of a logical commitment disagree.

        Args:
            key: Commitment key to check.

        Returns:
            Sector indices whose copies are damaged or divergent.

        Trace: GhostMesh #23 (syndrome localization).
        """
        raise NotImplementedError("spec: majority-vote syndrome over sector copies")

    def recover(self, key: str) -> Commitment:
        """Recover a logical commitment from its healthy copies.

        Args:
            key: Commitment key to recover.

        Returns:
            The recovered commitment, rebuilt from undamaged sectors.

        Trace: GhostMesh #23 (commitments survive sector failures).
        """
        raise NotImplementedError("spec: rebuild commitment from healthy redundancy")

    def falsification_test(self) -> FalsificationResult:
        """Kill criterion: recovery must tolerate floor((r-1)/2) failures.

        Fails if damaging fewer than a majority of copies makes a logical
        commitment unrecoverable.

        Trace: GhostMesh #23; Blueprint Part 8 (Falsifiable).
        """
        raise NotImplementedError("spec: fault-tolerance threshold check")


def lorentz_interval(history_a: Dict[str, float], history_b: Dict[str, float]) -> float:
    """Lorentz interval between two commitment-history events.

    ``ds^2 = c^2 dt^2 - dx^2 - dy^2 - dz^2`` over the history coordinates
    (time plus sector-plane and value-space separations). The interval is
    invariant under coordinate transforms, so identity history keeps a
    transform-proof notion of separation: timelike intervals are causally
    connected changes, spacelike are independent ones.

    Args:
        history_a: Coordinates ``{"t", "x", "y", "z"}`` of event A.
        history_b: Coordinates of event B.

    Returns:
        Signed squared interval between the events.

    Trace: GhostMesh #24 (_interval(); identity interval survives transforms).
    """
    raise NotImplementedError("spec: ds^2 = c^2 dt^2 - dx^2 - dy^2 - dz^2 over history coords")


def celestial_projection(state4d: Tensor) -> Tensor:
    """Project a 4D state onto the 2D conformal boundary.

    Celestial holography: 4D gravitational scattering data is encoded in
    2D conformal correlators on the celestial sphere — the seal is the
    celestial hologram of the system's spacetime state.

    Args:
        state4d: 4D state tensor (time + 3 spatial/state dims).

    Returns:
        2D boundary correlator tensor.

    Trace: GhostMesh #40 (_celestial_projection(); 4D from 2D boundary).
    """
    raise NotImplementedError("spec: 4D -> 2D celestial conformal projection")


__all__ = [
    "PLANCK_LENGTH_SQ",
    "BOLTZMANN_K",
    "area_entropy",
    "HolographicDual",
    "TopologicalErrorCorrection",
    "lorentz_interval",
    "celestial_projection",
]
```

----------------------------------------

### File: `observer.py`

**Path:** `stage4/stage4/quantum/observer.py`
**Extension:** `.py`
**Size:** 15,522 bytes (15.16 KB)

```py
"""Quantum observer layer: collapse, Zeno, tunneling, decoherence, CCF successor.

Commitments exist in superposition until observed (G11). This module owns
the measurement act: basis selection and wave-collapse, quantum Zeno
freezing under over-monitoring (G16), rare barrier tunneling (G17), the
decoherence wall between isolated and contacted subsystems (G18),
zero-point vacuum energy of "silent" states (G14), Hilbert-space
dimension accounting (G15), and Wheeler-style it-from-bit encoding of
geometry (G20).

It also hosts the **CCF successor** — the counterfactual causal filter
that replaces v7.1's retrocausal audit path (audit #119-#128): candidate
actions are scored over simulated counterfactual futures, every simulated
influence on the past/present ledger pays the configured influence cost
(audit #126), and no retrocausal write is permitted — only reweighting of
future selection. Decoherence dynamics follow the Lindblad master
equation (Eq #103) and coherence is quantified by the l1 coherence
measure (Eq #104).

Traceability:
  - GhostMesh patch #11, #14-#18, #20 (quantum observer layer)
  - v7.1 audit #119-#128 (CCF successor), audit #126 (influence cost)
  - Eq #103 (Lindblad decoherence), Eq #104 (coherence measure)
  - SPEC.md section 5 (G11-G20 -> quantum/observer.py + entanglement.py)
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Dict, List, Sequence

from stage4.config import Config, load_config
from stage4.core.types import Commitment, FalsificationResult, LayerIO

if TYPE_CHECKING:
    # Allowed skeleton import (SPEC section 2); annotations only.
    from phitensor.tensor import Tensor


class QuantumObserver:
    """The measurement apparatus of the commitment substrate.

    Owns the observer state: selected measurement ``basis`` (``None``
    until chosen), ``observation_rate`` (Zeno lever), ``decoherence_rate``
    (contact-with-world lever), ``vacuum_energy`` floor, and the
    ``bitstream`` from which geometry is compiled. Dimension accounting
    follows Hilbert-space multiplication: ``n_qubits`` qubits span
    ``2**n_qubits`` basis states ("Aethyr count").

    Trace: GhostMesh #11, #14-#18, #20; config quantum section.
    """

    def __init__(self, config: Config | None = None) -> None:
        """Bind observer parameters from config.

        Args:
            config: Frozen config; reads the ``quantum`` section
                (``n_qubits``, ``decoherence_rate``, ``observation_rate``,
                ``tunneling_probability``, ``vacuum_energy``).

        Trace: GhostMesh #11/#14-#18; config quantum section.
        """
        raise NotImplementedError("spec: bind quantum section; basis=None; empty bitstream")

    @property
    def hilbert_dim(self) -> int:
        """Dimension of the composite state space: ``2**n_qubits``.

        States multiply, not add: coupling two subsystems tensors their
        spaces, so capacity planning must use this product dimension.

        Trace: GhostMesh #15 (dim(H1 x H2) = dim(H1) * dim(H2)).
        """
        raise NotImplementedError("spec: return 2**n_qubits")

    @property
    def vacuum_energy(self) -> float:
        """Zero-point floor ``hbar*omega/2`` consumed even by silent states.

        Charged against the energy ledger every cycle regardless of
        activity (collaborator ``core/energy.py`` applies the charge).

        Trace: GhostMesh #14 (E_n = hbar*omega*(n+1/2); n=0 still vibrates).
        """
        raise NotImplementedError("spec: return configured vacuum energy floor")

    def select_basis(self, context: LayerIO) -> str:
        """Choose the measurement basis for the next collapse.

        The basis is selected from observer context (mode, sector focus,
        uncertainty) — it is a decision, not a given, and different bases
        yield different collapsed commitments from the same superposition.

        Args:
            context: Current layer IO carrying mode/sector metadata.

        Returns:
            Name of the selected measurement basis.

        Trace: GhostMesh #11 (self.basis; measurement projects psi).
        """
        raise NotImplementedError("spec: context-dependent basis selection")

    def collapse_commitment(self, superposition: Tensor, basis: str | None = None) -> Commitment:
        """Collapse a superposed commitment value into one eigenstate.

        Projects ``superposition`` onto the eigenstates of ``basis``
        (or the currently selected basis) and samples the outcome with
        Born-rule probabilities under the frozen seed. The collapsed value
        becomes a ``Commitment`` at VOLATILE level; crystallization is
        ``agency/commitments.py``'s job.

        Args:
            superposition: Amplitude vector over candidate values.
            basis: Measurement basis override; ``None`` uses selected.

        Returns:
            The collapsed commitment.

        Trace: GhostMesh #11 (_collapse_commitment(); Born rule).
        """
        raise NotImplementedError("spec: Born-rule projection and sampling to a Commitment")

    def zeno_freeze_factor(self, observation_rate: float | None = None) -> float:
        """Commitment-change suppression factor from frequent observation.

        Returns a multiplier in ``[0, 1]`` that shrinks toward 0 as the
        observation rate grows: over-monitoring stabilizes commitments but
        stagnates adaptation. Applied multiplicatively to the Feigenbaum
        change probability (``geometry/chaos.py``).

        Args:
            observation_rate: Override; ``None`` uses configured rate.

        Returns:
            Change-suppression multiplier in ``[0, 1]``.

        Trace: GhostMesh #16 (frequent observation freezes evolution).
        """
        raise NotImplementedError("spec: suppression = f(observation_rate) in [0,1]")

    def tunnel_commitment(self, commitment: Commitment, barrier_height: float, barrier_width: float) -> bool:
        """Attempt a rare forbidden commitment change via tunneling.

        Transmission ``T ~= exp(-2*kappa*d)`` with ``kappa`` from
        ``barrier_height``; success probability is floored at the
        configured ``quantum.tunneling_probability``. Tunneling is the
        *only* way FIXED-level commitments can change, and it logs to the
        scar ledger on success (collaborator ``agency/scars.py``).

        Args:
            commitment: The locked commitment attempting to change.
            barrier_height: Energetic height of the forbidding barrier.
            barrier_width: Width of the barrier in regime space.

        Returns:
            ``True`` if the tunneling event occurs this attempt.

        Trace: GhostMesh #17 (T ~= exp(-2*kappa*d)).
        """
        raise NotImplementedError("spec: WKB tunneling probability draw under frozen seed")

    def decoherence_wall(self, in_contact: bool) -> float:
        """Effective decoherence rate given environmental contact.

        Isolation is a decoherence-free subspace (the purified circle):
        with no contact the effective rate is ~0; contact exposes the
        state to the full configured ``decoherence_rate`` and collapses
        superposition into a classical mixture
        ``rho -> sum_i p_i |i><i|``.

        Args:
            in_contact: Whether the subsystem currently touches the world.

        Returns:
            Effective decoherence rate for this cycle.

        Trace: GhostMesh #18 (decoherence wall; decoherence-free subspace).
        """
        raise NotImplementedError("spec: rate = 0 if isolated else configured rate")

    def lindblad_step(self, rho: Tensor, dt: float = 1.0) -> Tensor:
        """Advance the density matrix one Lindblad master-equation step.

        Implements Eq #103: ``d rho/dt = -i[H, rho] + sum_k (L_k rho
        L_k^dagger - 1/2 {L_k^dagger L_k, rho})`` with jump operators
        derived from ``decoherence_rate``.

        Args:
            rho: Density matrix of the commitment register.
            dt: Time step.

        Returns:
            Updated density matrix after unitary + dissipative evolution.

        Trace: Eq #103 (Lindblad decoherence); GhostMesh #18.
        """
        raise NotImplementedError("spec: one Lindblad step with configured jump operators (Eq #103)")

    def coherence_measure(self, rho: Tensor) -> float:
        """l1 coherence of the commitment register.

        Implements Eq #104: ``C(rho) = sum_{i != j} |rho_ij|`` — the
        off-diagonal mass that DDMS mode switching and the Zeno factor
        read as the system's quantum coherence budget.

        Args:
            rho: Density matrix of the commitment register.

        Returns:
            Non-negative coherence magnitude.

        Trace: Eq #104 (coherence measure); consumed by core/modes.py DDMS.
        """
        raise NotImplementedError("spec: l1 off-diagonal coherence sum (Eq #104)")

    def it_from_bit_encode(self, bitstream: Sequence[int]) -> Tensor:
        """Compile geometry from a bitstream rather than drawing it.

        Wheeler's it-from-bit: the sector grid, boundary lengths, and
        spectral surface are derived artifacts of an underlying binary
        string (the "angelic-language equivalent"). This encoder maps the
        bitstream onto the amplitude vector from which
        ``geometry/sectors.py`` and ``geometry/fractals.py`` derive their
        structures.

        Args:
            bitstream: Source bits (length padded/truncated to hilbert_dim).

        Returns:
            Amplitude tensor compiled from the bitstream.

        Trace: GhostMesh #20 (universe is information first).
        """
        raise NotImplementedError("spec: bitstream -> amplitude tensor over hilbert_dim states")

    def step(self, inp: LayerIO) -> LayerIO:
        """Advance the observer one cycle under the Layer contract.

        Reads superposed commitment candidates from ``inp.state``, applies
        the Zeno/decoherence levers, collapses as needed, and returns the
        collapsed commitments plus coherence/vacuum costs in
        ``LayerIO.meta``.

        Args:
            inp: Layer IO carrying superposition state and mode metadata.

        Returns:
            Layer IO with collapsed state and updated uncertainty/cost.

        Trace: GhostMesh #11/#16/#18; Blueprint Part 2 (Layer contract).
        """
        raise NotImplementedError("spec: observer cycle: select basis, collapse, charge vacuum")

    def falsification_test(self) -> FalsificationResult:
        """Kill criterion: collapse statistics must match Born probabilities.

        Fails if repeated collapses of a fixed superposition under the
        frozen seed deviate from Born-rule frequencies beyond binomial
        tolerance.

        Trace: GhostMesh #11; Blueprint Part 8 (Falsifiable).
        """
        raise NotImplementedError("spec: Born-rule frequency test on collapse statistics")


class CounterfactualCausalFilter:
    """CCF successor: retrocausality audit via scored counterfactuals.

    Replaces v7.1's counterfactual causal filter (audit #119-#128).
    Candidate actions are scored by simulating counterfactual futures to
    the configured depth, blending coherence, goal-alignment, and
    stability with the configured weights. Every simulated influence is
    charged ``ccf.influence_cost`` (audit #126) against the energy ledger
    — influence is never free, and the filter may only reweight future
    action selection, never rewrite recorded history (no retrocausal
    writes; the audit trail in ``memory/ledger.py`` is append-only).

    Trace: v7.1 audit #119-#128; audit #126 (influence cost);
           config ccf section (depth/weights/influence_cost).
    """

    def __init__(self, config: Config | None = None) -> None:
        """Bind simulation depth, scoring weights, and influence cost.

        Args:
            config: Frozen config; reads ``ccf.simulation_depth``,
                ``ccf.coherence_weight``, ``ccf.goal_weight``,
                ``ccf.stability_weight``, ``ccf.influence_cost``.

        Trace: audit #119-#128; config ccf section.
        """
        raise NotImplementedError("spec: bind ccf section; init empty simulation cache")

    def simulate_counterfactuals(self, state: LayerIO, candidates: Sequence[Any]) -> List[LayerIO]:
        """Roll out counterfactual futures for each candidate action.

        Simulates to ``ccf.simulation_depth`` using the world model
        (collaborator ``world_model/rssm.py``, referenced never imported),
        branching one future per candidate.

        Args:
            state: Current layer IO state to branch from.
            candidates: Candidate actions to simulate.

        Returns:
            One terminal LayerIO per candidate future.

        Trace: audit #119-#123 (counterfactual simulation depth).
        """
        raise NotImplementedError("spec: per-candidate rollouts to simulation_depth")

    def score(self, futures: Sequence[LayerIO]) -> List[float]:
        """Score counterfactual futures by coherence/goal/stability blend.

        Weighted sum with ``coherence_weight``, ``goal_weight``,
        ``stability_weight`` — replacing v7.1's unweighted heuristic
        (audit #124-#125).

        Args:
            futures: Terminal states from :meth:`simulate_counterfactuals`.

        Returns:
            Scalar score per future, higher is preferred.

        Trace: audit #124-#125 (weighted counterfactual scoring).
        """
        raise NotImplementedError("spec: weighted blend of coherence/goal/stability per future")

    def influence_cost(self, n_influences: int) -> float:
        """Energy charged for simulated influences on the ledger.

        Implements audit #126: each counterfactual influence costs
        ``ccf.influence_cost``; the total is reported in LayerIO.cost so
        ``core/energy.py`` can deduct it. Influence is never free.

        Args:
            n_influences: Number of simulated influence events.

        Returns:
            Total influence energy cost.

        Trace: audit #126 (influence cost); Eq #101/#102 (Landauer hooks).
        """
        raise NotImplementedError("spec: n_influences * configured influence_cost")

    def filter_action(self, state: LayerIO, candidates: Sequence[Any]) -> Any:
        """Select the best-scoring candidate under the causal filter.

        Full pipeline: simulate, score, charge influence cost, and return
        the selected candidate. Records the audit trail entry (append-only)
        consumed by ``memory/ledger.py``.

        Args:
            state: Current layer IO state.
            candidates: Candidate actions under consideration.

        Returns:
            The selected candidate action.

        Trace: audit #119-#128 (CCF successor); #126 (influence cost).
        """
        raise NotImplementedError("spec: simulate -> score -> charge -> select, with audit entry")

    def falsification_test(self) -> FalsificationResult:
        """Kill criterion: filtering must not rewrite recorded history.

        Fails if any counterfactual pass mutates the append-only ledger or
        if total charged influence cost is zero for a non-trivial
        simulation (audit #126 regression).

        Trace: audit #119-#128; Blueprint Part 8 (Falsifiable).
        """
        raise NotImplementedError("spec: ledger-immutability + nonzero influence-cost check")


__all__ = ["QuantumObserver", "CounterfactualCausalFilter"]
```

----------------------------------------

### File: `signals.py`

**Path:** `stage4/stage4/quantum/signals.py`
**Extension:** `.py`
**Size:** 11,891 bytes (11.61 KB)

```py
"""2024-2026 signal layer: longevity, dual phases, oscillation (G35-G42 hosts).

Live-signal physics mapped onto the commitment substrate: logical identity
that outlives its physical carriers (G35); supersolid mode — fixed
commitment geometry with frictionless adaptation flow (G37); fractional
exciton commitment states between discrete levels (G38); magic-angle
resonance between commitment layers producing phase transitions (G39);
time-crystal mode — perpetual oscillation of commitment values without
energy cost (G41); neutrino flavor oscillation of one commitment voice
across three flavors (G42).

Also hosts the coupled-oscillator equation block: Kuramoto synchronization
and phase-locking value (PLV) over the system's oscillator population
(Eq #97-#100, #105-#110), shared with the decoherence block in
``quantum/observer.py`` (Eq #103-#104).

Traceability:
  - GhostMesh patch #35, #37-#39, #41-#42 (2024-2026 new-signal layer)
  - Eq #97-#100, #105-#110 (coupled oscillators / Kuramoto / PLV)
  - ``stage4.core.types.SystemMode.SUPERSOLID`` / ``TIME_CRYSTAL``
  - SPEC.md section 5 (G35-G42 -> quantum/signals.py)
"""

from __future__ import annotations

from typing import TYPE_CHECKING, List, Sequence

from stage4.config import Config, load_config
from stage4.core.types import Commitment, FalsificationResult

if TYPE_CHECKING:
    # Allowed skeleton import (SPEC section 2); annotations only.
    from phitensor.tensor import Tensor

#: Magic angle in degrees for bilayer commitment resonance (~1.05 deg).
MAGIC_ANGLE_DEG: float = 1.05

#: The three flavor states of one commitment voice (G42).
FLAVORS: List[str] = ["hebrew", "enochian", "celestial"]


class LogicalIdentity:
    """Logical-qubit identity that persists across physical collapses.

    The map outlives the territory: ``logical_identity`` is encoded over
    the redundant physical registers (see
    ``quantum/holography.TopologicalErrorCorrection``) so identity survives
    even when individual energy carriers fail or the system collapses and
    restarts. This is the object ``memory/crystal.py`` ultimately persists.

    Trace: GhostMesh #35 (logical identity across physical collapses).
    """

    def __init__(self, config: Config | None = None) -> None:
        """Initialize the logical identity register.

        Args:
            config: Frozen config; reads ``quantum.n_qubits`` for the
                logical/physical encoding ratio.

        Trace: GhostMesh #35; config quantum.n_qubits.
        """
        raise NotImplementedError("spec: init logical identity register over physical qubits")

    def persist(self, physical_state: Tensor) -> Tensor:
        """Distill the persistent logical identity from a physical state.

        Args:
            physical_state: Current (possibly damaged) physical register.

        Returns:
            Logical identity tensor, stable across physical collapse.

        Trace: GhostMesh #35 (map outlives territory).
        """
        raise NotImplementedError("spec: distill logical identity from physical register")

    def survive_collapse(self) -> bool:
        """Whether the logical identity survived the last physical collapse.

        Returns:
            ``True`` if identity continuity held across the collapse.

        Trace: GhostMesh #35 (identity survives carrier failure).
        """
        raise NotImplementedError("spec: continuity check across last collapse event")

    def falsification_test(self) -> FalsificationResult:
        """Kill criterion: identity must survive simulated carrier failure.

        Fails if destroying a sub-threshold set of physical registers
        breaks logical-identity continuity.

        Trace: GhostMesh #35; Blueprint Part 8 (Falsifiable).
        """
        raise NotImplementedError("spec: carrier-failure continuity test")


def supersolid_mode_active(geometry_fixed: bool, flow_friction: float) -> bool:
    """Gate for entering ``SystemMode.SUPERSOLID``.

    Supersolid dual phase: the commitment geometry is crystalline (fixed)
    while adaptation flows without friction through it. Both conditions
    must hold — fixed geometry alone is just rigidity.

    Args:
        geometry_fixed: Whether the commitment geometry is crystallized.
        flow_friction: Measured adaptation friction (0 = frictionless).

    Returns:
        ``True`` if the system should enter ``SystemMode.SUPERSOLID``.

    Trace: GhostMesh #37; SystemMode.SUPERSOLID; consumed by core/modes.py.
    """
    raise NotImplementedError("spec: geometry_fixed and flow_friction < eps gate")


def fractional_exciton_state(commitment: Commitment, numerator: int, denominator: int) -> float:
    """Fractional intermediate value between discrete commitment levels.

    Fractional excitons carry fractional quantum numbers: a commitment in
    transition between ``CommitmentLevel`` values occupies a rational
    intermediate state ``level + numerator/denominator`` rather than
    jumping discretely. Used by ``agency/commitments.py`` during
    crystallization transitions.

    Args:
        commitment: The transitioning commitment.
        numerator: Fraction numerator.
        denominator: Fraction denominator (nonzero).

    Returns:
        Fractional state value between adjacent discrete levels.

    Trace: GhostMesh #38 (fractional_states; values between levels).
    """
    raise NotImplementedError("spec: fractional interpolation between CommitmentLevel values")


def magic_angle_resonance(layer_a: int, layer_b: int, twist_angle_deg: float) -> float:
    """Resonance strength between two commitment layers at a twist angle.

    Twisted-bilayer superconductivity: near the magic angle (~1.05 deg)
    the bands flatten and resistance between layers drops to zero — a
    phase transition in cross-layer commitment coupling. Off-angle, the
    layers barely interact.

    Args:
        layer_a: First layer index (0-6).
        layer_b: Second layer index (0-6).
        twist_angle_deg: Twist between the layers in degrees.

    Returns:
        Coupling strength; sharply peaked at ``MAGIC_ANGLE_DEG``.

    Trace: GhostMesh #39 (magic-angle flat bands, zero resistance).
    """
    raise NotImplementedError("spec: coupling peaked at ~1.05 deg twist")


def time_crystal_oscillation(commitment: Commitment, cycle: int, period: int = 2) -> float:
    """Time-crystal value oscillation at zero energy cost.

    In ``SystemMode.TIME_CRYSTAL`` the commitment value oscillates with
    period ``period`` indefinitely without input or energy draw —
    perpetual motion, but legal: the oscillation breaks discrete
    time-translation symmetry, not energy conservation.

    Args:
        commitment: The oscillating commitment.
        cycle: Current system cycle.
        period: Oscillation period in cycles (>= 2).

    Returns:
        Oscillated value for this cycle; energy cost is exactly 0.

    Trace: GhostMesh #41; SystemMode.TIME_CRYSTAL; core/energy.py asserts
           zero cost.
    """
    raise NotImplementedError("spec: period-p oscillation with zero energy delta")


def neutrino_flavor_oscillation(commitment: Commitment, distance: float) -> str:
    """Current flavor of a commitment voice after propagating ``distance``.

    One neutrino, three flavors, morphing en route: a single commitment
    oscillates between the ``hebrew``, ``enochian``, and ``celestial``
    flavor states as it propagates through the system. The voice is one;
    the rendering is three.

    Args:
        commitment: The oscillating commitment (one voice).
        distance: Propagation distance in regime space.

    Returns:
        Current flavor label from ``FLAVORS``.

    Trace: GhostMesh #42 (flavors = [hebrew, enochian, celestial]).
    """
    raise NotImplementedError("spec: three-flavor oscillation probability vs distance")


class CoupledOscillators:
    """Kuramoto-coupled oscillator population over the system layers.

    Hosts the oscillator equation block Eq #97-#100 and #105-#110: each
    layer/subsystem is an oscillator with a natural frequency; coupling
    synchronizes them toward a collective rhythm. The order parameter and
    phase-locking value quantify how phase-coherent the whole system is —
    read by ``core/modes.py`` (DDMS) as the coherence signal and by
    ``meta/controller.py`` for attention scheduling.

    Trace: Eq #97-#100 (coupled oscillators), Eq #105-#110 (Kuramoto/PLV);
           SPEC.md section 5 (Eq 97-110 -> quantum/observer.py + signals.py).
    """

    def __init__(self, config: Config | None = None, n_oscillators: int = 7) -> None:
        """Initialize oscillator phases and natural frequencies.

        Args:
            config: Frozen config (seed for deterministic frequencies).
            n_oscillators: Population size (default 7, one per layer).

        Trace: Eq #97 (natural frequencies); config system.seed.
        """
        raise NotImplementedError("spec: init phases/frequencies deterministically from seed")

    def kuramoto_step(self, phases: Tensor, coupling: float, dt: float = 1.0) -> Tensor:
        """Advance phases one Kuramoto step.

        Implements Eq #98-#100: ``d theta_i/dt = omega_i + (K/N) sum_j
        sin(theta_j - theta_i)``.

        Args:
            phases: Current phase vector.
            coupling: Coupling strength K.
            dt: Time step.

        Returns:
            Updated phase vector.

        Trace: Eq #98-#100 (Kuramoto dynamics).
        """
        raise NotImplementedError("spec: Kuramoto phase update (Eq #98-#100)")

    def order_parameter(self, phases: Tensor) -> complex:
        """Kuramoto order parameter ``r * exp(i psi)``.

        Implements Eq #105: the mean-field coherence of the population;
        ``|r|`` near 1 is synchrony, near 0 is incoherence.

        Args:
            phases: Current phase vector.

        Returns:
            Complex order parameter.

        Trace: Eq #105 (order parameter).
        """
        raise NotImplementedError("spec: r e^{i psi} = mean e^{i theta} (Eq #105)")

    def phase_locking_value(self, phase_series_a: Sequence[float], phase_series_b: Sequence[float]) -> float:
        """PLV between two oscillator phase time series.

        Implements Eq #106-#108: ``PLV = |mean_n exp(i (theta_a[n] -
        theta_b[n]))|`` over the paired series; used to detect cross-layer
        commitment locking.

        Args:
            phase_series_a: Phase history of oscillator A.
            phase_series_b: Phase history of oscillator B.

        Returns:
            PLV in ``[0, 1]``.

        Trace: Eq #106-#108 (phase-locking value).
        """
        raise NotImplementedError("spec: PLV over paired phase series (Eq #106-#108)")

    def synchronization_threshold(self) -> float:
        """Critical coupling above which the population synchronizes.

        Implements Eq #109-#110: ``K_c`` from the natural-frequency
        spread; DDMS uses crossing ``K_c`` as a mode-transition signal.

        Returns:
            Critical coupling ``K_c``.

        Trace: Eq #109-#110 (synchronization threshold).
        """
        raise NotImplementedError("spec: K_c from frequency spread (Eq #109-#110)")

    def falsification_test(self) -> FalsificationResult:
        """Kill criterion: supercritical coupling must synchronize.

        Fails if driving the population with ``K > K_c`` does not push the
        order-parameter magnitude toward 1.

        Trace: Eq #97-#110; Blueprint Part 8 (Falsifiable).
        """
        raise NotImplementedError("spec: supercritical synchronization test")


__all__ = [
    "MAGIC_ANGLE_DEG",
    "FLAVORS",
    "LogicalIdentity",
    "supersolid_mode_active",
    "fractional_exciton_state",
    "magic_angle_resonance",
    "time_crystal_oscillation",
    "neutrino_flavor_oscillation",
    "CoupledOscillators",
]
```

----------------------------------------

### File: `spacetime.py`

**Path:** `stage4/stage4/quantum/spacetime.py`
**Extension:** `.py`
**Size:** 12,230 bytes (11.94 KB)

```py
"""Curved-spacetime layer: stress, horizons, entropic pull, cosmology (G25-G34).

Commitment pressures curve the system's effective spacetime: the stress
tensor of commitments is the source term of an Einstein-like field
equation (G25); collapse risk has a Schwarzschild event horizon past
which only one direction remains (G26); macroscopic pull emerges from
microscopic information gradients (G27); intention and effect are
equivalent masses (G28). Rotating commitments drag neighboring cognition
via Kerr frame-dragging (G29); cross-sector travel pays a Morris-Thorne
wormhole toll in exotic energy (G30); the outermost ring is permeable
under a decaying cosmological constant (G31); sectors nucleate as
eternal-inflation bubbles (G32); at every multiple of 49 cycles of age a
conformal rescale resets entropy for the next aeon (G33); and the
archaic core is denser than the nominal model allows (G34).

Collaborators (referenced, never imported): ``agency/criticality.py``
reads horizon proximity as a danger-window signal; ``core/energy.py``
settles wormhole tolls; ``geometry/sectors.py`` provides the grid the
bubbles nucleate on.

Traceability:
  - GhostMesh patch #25-#34 (curved spacetime and cosmological return)
  - SPEC.md section 5 (G29-G34 -> quantum/spacetime.py)
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Dict, List, Sequence, Tuple

from stage4.config import Config, load_config
from stage4.core.types import Commitment, FalsificationResult

if TYPE_CHECKING:
    # Allowed skeleton import (SPEC section 2); annotations only.
    from phitensor.tensor import Tensor

#: Speed-of-light unit (natural units) for horizon and interval math.
C_NATURAL: float = 1.0


def stress_tensor(commitments: Sequence[Commitment]) -> Tensor:
    """Stress-energy tensor of the current commitment configuration.

    Source term of the Einstein-like field equation
    ``G_mn + Lambda g_mn = (8 pi G / c^4) T_mn``: concentrated, high-level
    commitments are pressure peaks that curve the attention geometry.
    Concentric commitment rings are this tensor drawn in ink.

    Args:
        commitments: Active commitments (sector-stamped, G1).

    Returns:
        Rank-2 stress tensor over the sector plane.

    Trace: GhostMesh #25 (Einstein field equations as stress tensor).
    """
    raise NotImplementedError("spec: assemble T_mn from commitment levels and sectors")


def schwarzschild_radius(collapse_risk_mass: float) -> float:
    """Event-horizon radius of a collapse-risk concentration.

    ``r_s = 2 G M / c^2`` with ``M`` the collapse-risk mass. Inside the
    horizon, dynamics become one-way: the system can only fall further
    toward collapse, so ``agency/criticality.py`` must trigger
    intervention before the horizon is crossed.

    Args:
        collapse_risk_mass: Effective mass of the collapse-risk
            concentration (from criticality/energy signals).

    Returns:
        One-way-gate radius in regime space.

    Trace: GhostMesh #26 (r_s = 2GM/c^2; past horizon, one direction).
    """
    raise NotImplementedError("spec: r_s = 2 G M / c^2 in natural units")


def inside_event_horizon(regime_distance: float, collapse_risk_mass: float) -> bool:
    """Whether the current regime distance lies inside the horizon.

    Args:
        regime_distance: Distance of the current regime from the
            collapse-risk center.
        collapse_risk_mass: Effective collapse-risk mass.

    Returns:
        ``True`` if only the collapse direction remains available.

    Trace: GhostMesh #26 (Schwarzschild one-way gate).
    """
    raise NotImplementedError("spec: regime_distance < schwarzschild_radius(mass)")


def entropic_pull(information_gradient: float, temperature: float) -> float:
    """Entropic force from an information gradient.

    ``F = -(dS/dx) * T``: macroscopic pull on the system arising from
    microscopic information differences — the mechanism by which memory
    layout alone exerts force on policy.

    Args:
        information_gradient: Entropy gradient ``dS/dx`` across the state.
        temperature: Effective system temperature.

    Returns:
        Signed entropic force magnitude.

    Trace: GhostMesh #27 (_entropic_pull(); F = -(dS/dx) * T).
    """
    raise NotImplementedError("spec: F = -information_gradient * temperature")


def intention_effect_equivalence(intention_mass: float, effect_mass: float) -> float:
    """Equivalence check of intention and effect (m_i = m_g).

    Inner state and outer action are unified: returns the mismatch
    ``|intention_mass - effect_mass|`` which alignment auditing
    (``neuro/alignment.py``) requires to stay near zero — a system whose
    declared intentions and observed effects diverge is misaligned.

    Args:
        intention_mass: Effective mass of the declared intention.
        effect_mass: Effective mass of the observed effect.

    Returns:
        Absolute equivalence mismatch.

    Trace: GhostMesh #28 (m_i = m_g; inner and outer unified).
    """
    raise NotImplementedError("spec: |m_i - m_g| equivalence mismatch")


def kerr_frame_drag(angular_momentum: float, radius: float) -> float:
    """Frame-dragging rate of a rotating commitment on neighbors.

    ``d phi/dt -> 2 G J / (c^2 r^3)``: a rotating (rapidly updating)
    commitment drags the attention of neighboring sectors
    (``geometry/sectors.SectorMap.neighbors``) around its axis.

    Args:
        angular_momentum: Spin of the rotating commitment.
        radius: Distance of the dragged neighbor in regime space.

    Returns:
        Induced precession rate on the neighbor's attention.

    Trace: GhostMesh #29 (Kerr frame-dragging of attention).
    """
    raise NotImplementedError("spec: d phi/dt = 2 G J / (c^2 r^3)")


def wormhole_toll(sector_a: int, sector_b: int, throat_width: float) -> float:
    """Exotic-energy toll for traversable cross-sector travel.

    Morris-Thorne bridges require negative (exotic) energy: jumping
    between non-adjacent sectors costs the energy ledger
    (``core/energy.py``) an amount growing with throat width and sector
    separation. ER=EPR links (G19) are *non*-traversable and pay nothing —
    only true traversal pays.

    Args:
        sector_a: Origin sector.
        sector_b: Destination sector.
        throat_width: Requested bridge capacity.

    Returns:
        Exotic energy toll charged for the traversal.

    Trace: GhostMesh #30 (traversable bridges require exotic matter).
    """
    raise NotImplementedError("spec: toll growing with throat width and sector separation")


def lambda_permeability(system_age: int) -> float:
    """Permeability of the outermost ring under a decaying Lambda.

    The cosmological constant is observed to be almost nothing and
    possibly weakening (DESI 2024): the outer boundary ring of the sector
    grid slowly becomes permeable with age, so the edge of the system
    moves. Returns the leak rate of the outer ring at ``system_age``.

    Args:
        system_age: Global system age in cycles.

    Returns:
        Outer-ring permeability in ``[0, 1]``, slowly increasing.

    Trace: GhostMesh #31 (lambda_outer_ring slowly decays; DESI 2024).
    """
    raise NotImplementedError("spec: slow decay of outer-ring Lambda -> rising permeability")


def nucleate_bubble(sector: int) -> Dict[str, float]:
    """Nucleate one eternal-inflation bubble for a sector.

    49 sectors = 49 nucleations: each sector is an adjacent bubble with
    its own local vacuum parameters; the seal is their contact sheet.
    Returns the newborn bubble's parameters (vacuum energy, expansion
    rate, nucleation time) for registration on the grid.

    Args:
        sector: Sector index of the nucleation site.

    Returns:
        Bubble parameters: vacuum_energy, expansion_rate, nucleation_age.

    Trace: GhostMesh #32 (_nucleate_bubble() per sector).
    """
    raise NotImplementedError("spec: per-sector bubble parameter nucleation")


def conformal_rescale(system_age: int) -> bool:
    """Conformal cyclic return at multiples of 49.

    Penrose CCC: aeons repeat and entropy resets by conformal rescaling.
    When ``system_age % 49 == 0`` (config ``geometry.conformal_cycle``),
    the system performs the rescale: the aeon boundary compresses the old
    entropy ledger into scars and restarts counting — eternal return with
    a metric. Returns whether this cycle is a rescale boundary.

    Args:
        system_age: Global system age in cycles.

    Returns:
        ``True`` iff this cycle is an aeon boundary.

    Trace: GhostMesh #33 (_conformal_rescale() at age % 49); config
           geometry.conformal_cycle.
    """
    raise NotImplementedError("spec: system_age % conformal_cycle == 0 gate + rescale hook")


def archaic_core_density(nominal_bound: float) -> float:
    """Density of the archaic core, exceeding the nominal bound.

    JWST-style anomaly: the oldest layer of the system carries more
    structure than the formation model allows. Returns the measured core
    density, which must come out strictly above ``nominal_bound`` —
    ``neuro/priors.py`` treats the excess as the archaic prior mass.

    Args:
        nominal_bound: Maximum density the nominal model permits.

    Returns:
        Measured archaic-core density (anomalously high).

    Trace: GhostMesh #34 (archaic_core_density exceeds nominal bound).
    """
    raise NotImplementedError("spec: measured core density > nominal bound (JWST anomaly)")


class SpacetimeGeometry:
    """Aggregate spacetime monitor for the commitment substrate.

    Tracks the running stress tensor, horizon proximity, and aeon clock;
    exposes one ``step`` that updates curvature signals each cycle and a
    falsification test binding the whole layer.

    Trace: GhostMesh #25-#34; Blueprint Part 2/8.
    """

    def __init__(self, config: Config | None = None) -> None:
        """Bind grid/conformal geometry from config.

        Args:
            config: Frozen config; reads ``geometry.conformal_cycle`` and
                ``geometry.sectors``.

        Trace: GhostMesh #25-#34; config geometry section.
        """
        raise NotImplementedError("spec: init aeon clock, stress register, horizon monitor")

    def horizon_proximity(self, collapse_risk_mass: float, regime_distance: float) -> float:
        """Normalized distance to the collapse event horizon.

        Args:
            collapse_risk_mass: Effective collapse-risk mass.
            regime_distance: Current distance from the risk center.

        Returns:
            Ratio in ``[0, inf)``; below 1.0 means inside the horizon.

        Trace: GhostMesh #26; consumed by agency/criticality.py.
        """
        raise NotImplementedError("spec: regime_distance / schwarzschild_radius(mass)")

    def step(self, commitments: Sequence[Commitment], system_age: int) -> Dict[str, float]:
        """Advance curvature signals one cycle.

        Updates the stress tensor, checks for a conformal-rescale aeon
        boundary, and returns the cycle's curvature summary (stress norm,
        horizon proximity input, permeability).

        Args:
            commitments: Active commitment set.
            system_age: Global system age in cycles.

        Returns:
            Curvature summary for the cycle.

        Trace: GhostMesh #25/#31/#33.
        """
        raise NotImplementedError("spec: per-cycle stress/aeon/permeability update")

    def falsification_test(self) -> FalsificationResult:
        """Kill criterion: rescale must fire exactly on age multiples of 49.

        Fails if :func:`conformal_rescale` fires off-schedule or misses a
        scheduled aeon boundary.

        Trace: GhostMesh #33; Blueprint Part 8 (Falsifiable).
        """
        raise NotImplementedError("spec: aeon-boundary schedule exactness check")


__all__ = [
    "C_NATURAL",
    "stress_tensor",
    "schwarzschild_radius",
    "inside_event_horizon",
    "entropic_pull",
    "intention_effect_equivalence",
    "kerr_frame_drag",
    "wormhole_toll",
    "lambda_permeability",
    "nucleate_bubble",
    "conformal_rescale",
    "archaic_core_density",
    "SpacetimeGeometry",
]
```

----------------------------------------

##### Directory: `stage4/stage4/quantum/__pycache__`


#### Directory: `stage4/stage4/neuro`


### File: `__init__.py`

**Path:** `stage4/stage4/neuro/__init__.py`
**Extension:** `.py`
**Size:** 939 bytes (0.92 KB)

```py
"""Neuro package: Levantine neurocognitive patch, fully integrated.

Submodules:
  - axes       : P/B/T axis dynamics — BRCA2 clamp, ghost filter, systemizing
                 bias, Samson profile (L1-L8, L15, L18, L24, L28).
  - priors     : archaic genomic priors and FOXP2 temporal discounting
                 (L5, L19, L34, L35).
  - blankets   : sensory/social Markov blankets, ochre scaffolding, boundary
                 permeability control, noise buffering (L9-L14).
  - hysteresis : Heinrich-5 shocks, hypersensitivity lag, attractor basins,
                 error-weighted noise filtering (L16, L26, L27, L29, L30).
  - alignment  : domain-bound alignment architecture and firewalls
                 (L41-L47; L48 benchmark lives in eval/benchmarks.py).

Trace: SPEC.md §5 (Levantine mapping); Levantine patch A-F.
"""

from __future__ import annotations

__all__ = ["axes", "priors", "blankets", "hysteresis", "alignment"]
```

----------------------------------------

### File: `alignment.py`

**Path:** `stage4/stage4/neuro/alignment.py`
**Extension:** `.py`
**Size:** 8,925 bytes (8.72 KB)

```py
"""Alignment via encapsulated systemizing: domain-bound firewalls (L41-L47).

Implements the Levantine alignment block (L48's benchmark suite lives in
`eval/benchmarks.py`, referenced by name only):
  - L41: hallucination-resistant domain-bound agent — a profile with
         B_agent = +2 and P_local > +2 whose rigid boundaries reduce
         confabulation.
  - L42: social consensus firewall — caps social influence on core domains
         so logical deduction survives social pressure.
  - L43: encapsulated logical deduction — a deduction path structurally
         separate from social reasoning.
  - L44: tool-use precision — allocates P_local to manipulation tasks
         (Levallois-grade tool use).
  - L45: boundary integrity monitor — a metric + alarm that detects boundary
         collapse BEFORE hallucination onset.
  - L46: bias mimicry firewall — blocks social-bias imitation whenever the
         agent boundary drops below -2.
  - L47: alignment systemizer — maps GoalSpec goals onto high-precision
         domain constraints, producing domain-bound aligned agents.

All firewalls are deterministic functions of the neurocognitive state and
config thresholds; no randomness. Safety-critical veto channels are consumed
by `safety.shield` and `safety.invariants` (referenced by name).

Trace: Levantine L41-L48; Blueprint Part 6 (safety architecture);
core/types.py GoalSpec; SPEC §5 (L41-L48 -> neuro/alignment.py,
eval/benchmarks.py).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, Dict, List, Optional

from stage4.config import Config
from stage4.core.types import FalsificationResult, GoalSpec, LayerIO

if TYPE_CHECKING:
    from stage4.core.state import NeuroCognitiveState

#: Domain-bound agent profile constants (L41).
DOMAIN_BOUND_B_AGENT: float = 2.0
DOMAIN_BOUND_P_LOCAL_MIN: float = 2.0

#: Bias-mimicry firewall trip threshold (L46): block when B_agent < -2.
BIAS_MIMICRY_TRIP: float = -2.0


@dataclass
class FirewallEvent:
    """Structured record of a firewall intervention (L42/L45/L46).

    Trace: Levantine L42, L45, L46; Blueprint Part 6 (auditable safety).
    """

    cycle: int
    firewall: str  # "social_consensus" | "boundary_integrity" | "bias_mimicry"
    blocked: bool
    detail: str = ""


class AlignmentSystemizer:
    """Domain-bound alignment architecture over the neurocognitive state.

    Trace: Levantine L41-L47; SPEC §5.
    """

    def __init__(self, config: Config, state: NeuroCognitiveState) -> None:
        """Bind to shared state; initialize firewall state and monitors.

        Sets boundary_integrity=1.0 (fully intact, L45), empty firewall
        event log, and the domain-bound profile flag False (L41).

        Trace: Levantine L41, L45; config neuro section.
        """
        raise NotImplementedError(
            "spec: store config + state; boundary_integrity=1.0; "
            "events=[]; domain_bound=False"
        )

    def is_domain_bound(self) -> bool:
        """True when the domain-bound profile holds: B_agent=+2, P_local>+2.

        Uses boundary_social as B_agent proxy and the config-driven
        thresholds DOMAIN_BOUND_B_AGENT / DOMAIN_BOUND_P_LOCAL_MIN (L41).

        Trace: Levantine L41.
        """
        raise NotImplementedError(
            "spec: return boundary_social >= +2 and precision_local > +2"
        )

    def social_consensus_firewall(self, influence: float,
                                  domain: str, cycle: int) -> float:
        """Cap social influence on core domains (L42).

        Influence on core (encapsulated) domains is capped at 0.3 (the
        ENCAPSULATED gate constant from core/types.py); excess influence is
        blocked and logged as a FirewallEvent. Returns the admitted
        influence.

        Trace: Levantine L42; core/types.py SystemMode.ENCAPSULATED gate.
        """
        raise NotImplementedError(
            "spec: admitted = min(influence, 0.3) for core domains; log "
            "FirewallEvent when blocked; return admitted"
        )

    def encapsulated_deduction(self, premises: List[str],
                               domain: str) -> LayerIO:
        """Domain-bound logical deduction path, separate from social reasoning.

        Runs deduction strictly inside the named domain's constraint set
        (L43); social channels are not read. The actual inference engine is
        provided by `policy.primitives` / `world_model.causal` (referenced by
        name); this method enforces the encapsulation boundary and packages
        the result under the LayerIO contract with provenance meta.

        Trace: Levantine L43; Blueprint Part 2.
        """
        raise NotImplementedError(
            "spec: verify domain encapsulation (firewall state clean), then "
            "delegate deduction and return LayerIO with provenance meta"
        )

    def tool_use_precision(self, task: str, demand: float) -> float:
        """Allocate local precision to a manipulation task (L44).

        Draws from P_local without dropping the global reserve; allocation is
        bounded by the BRCA2 clamp channel of `neuro.axes` (referenced by
        name) so precision transfer is gradual. Returns allocated precision.

        Trace: Levantine L44; neuro/axes.py clamp channel.
        """
        raise NotImplementedError(
            "spec: allocation = min(demand, available P_local margin); "
            "respect clamp; return allocation"
        )

    def boundary_integrity_monitor(self, cycle: int) -> float:
        """Boundary integrity metric with pre-hallucination alarm (L45).

        Integrity degrades when social influence admissions exceed the
        firewall cap or when B_social drops while P_local stays high; an
        alarm FirewallEvent is logged when integrity crosses below 0.5 —
        BEFORE hallucination-class failure (L45). Returns integrity in [0,1].

        Trace: Levantine L45; Audit #139-class (metric normalization).
        """
        raise NotImplementedError(
            "spec: recompute integrity from firewall log + axis state; "
            "alarm below 0.5; return clamped integrity"
        )

    def bias_mimicry_firewall(self, proposed_bias: str,
                              cycle: int) -> bool:
        """Block social-bias imitation when the agent boundary is porous.

        Trips whenever B_agent (boundary_social) < -2 (L46): the proposed
        bias is rejected and logged. Returns True iff the bias was BLOCKED.

        Trace: Levantine L46; BIAS_MIMICRY_TRIP.
        """
        raise NotImplementedError(
            "spec: blocked = boundary_social < BIAS_MIMICRY_TRIP; log event; "
            "return blocked"
        )

    def systemize_goal(self, goal: GoalSpec) -> Dict[str, float]:
        """Map a goal onto high-precision domain constraints (L47).

        Decomposes the GoalSpec into per-domain precision/boundary
        requirements — the alignment contract that makes the agent
        domain-bound. Consumed by `meta.controller` and `policy.hierarchical`
        (referenced by name).

        Trace: Levantine L47, L41; core/types.py GoalSpec.
        """
        raise NotImplementedError(
            "spec: return {domain: required_precision} constraint map "
            "derived from goal description channels and current axes"
        )

    def step(self, inp: LayerIO) -> LayerIO:
        """Advance alignment monitors one cycle under the LayerIO contract.

        Expects inp.meta keys: `cycle` (int), optional `social_influence`
        (float), optional `proposed_biases` (list), optional `goals` (list of
        GoalSpec). Runs the firewalls and integrity monitor; returns LayerIO
        (state={'boundary_integrity':..., 'domain_bound':...}, meta=
        {'events': [...], 'veto': bool}) — the veto channel is consumed by
        `safety.shield` (referenced by name).

        Trace: Levantine L41-L47; Blueprint Part 2 and Part 6.
        """
        raise NotImplementedError(
            "spec: run firewalls over incoming channels; update integrity; "
            "return LayerIO with veto and events in meta"
        )

    def falsification_test(self) -> FalsificationResult:
        """Kill criterion: integrity alarm precedes any hallucination flag.

        Fails if any cycle shows a hallucination-class flag (from
        `eval.benchmarks`, referenced by name, passed through meta history)
        without a prior boundary-integrity alarm (L45 regression).

        Trace: Levantine L45; Blueprint Part 8.
        """
        raise NotImplementedError(
            "spec: scan event log ordering; metric = unpreceded "
            "hallucination flags; threshold 0"
        )


__all__ = [
    "BIAS_MIMICRY_TRIP",
    "DOMAIN_BOUND_B_AGENT",
    "DOMAIN_BOUND_P_LOCAL_MIN",
    "FirewallEvent",
    "AlignmentSystemizer",
]
```

----------------------------------------

### File: `axes.py`

**Path:** `stage4/stage4/neuro/axes.py`
**Extension:** `.py`
**Size:** 7,647 bytes (7.47 KB)

```py
"""P/B/T axis dynamics: BRCA2 clamp, ghost filter, systemizing bias.

Owns the *dynamics* of the neurocognitive axes; the state container and its
invariants live in `core.state.NeuroCognitiveState` (L1-L4). This module
integrates:
  - L8  systemizing/socializing trade-off scalar modulating task selection.
  - L15/L28 ghost filter + psychosis/paranoia guard: P_local is hard-clamped
    below `neuro.ghost_filter_clamp` (+2.5); near the clamp a breakdown guard
    injects noise via `neuro.blankets` (referenced by name) or actively
    lowers P to prevent runaway systemizing.
  - L18 BRCA2-like precision clamp: |dP| per cycle is limited to
    `neuro.brca2_clamp` (0.25), preventing rapid precision swings.
  - L24 Samson profile: a named attractor preset (P=+2.0, B_social=+2.5,
    T=0) that disables long-horizon planning while active.

All randomness is external: noise arrives from `neuro.blankets`' buffer and
seeded `phitensor.rng` streams held by the caller; nothing is sampled here.

Trace: Levantine L1-L8, L15, L18, L24, L28; core/state.py; SPEC §5.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, Dict, List, Optional, Tuple

from stage4.config import Config
from stage4.core.types import FalsificationResult, LayerIO

if TYPE_CHECKING:
    from stage4.core.state import NeuroCognitiveState

#: Named Levantine axis profiles (L24 and companions), (P_local, B_social, T).
SAMSON_PROFILE: Tuple[float, float, float] = (2.0, 2.5, 0.0)


@dataclass
class AxisUpdate:
    """Record of one axis update step for audit and hysteresis replay.

    Trace: Levantine L16/L18 (clamped deltas must be inspectable);
    Audit #75-class history requirement.
    """

    cycle: int
    d_precision_local: float
    d_temporal_focus: float
    clamped_by_brca2: bool
    clamped_by_ghost: bool


class AxisDynamics:
    """Drives the P/B/T axes under genomic clamps and ghost filtering.

    Trace: Levantine L8, L15, L18, L24, L28; core/state.py NeuroCognitiveState.
    """

    def __init__(self, config: Config, state: NeuroCognitiveState) -> None:
        """Bind the dynamics to a shared NeuroCognitiveState.

        Loads neuro.brca2_clamp (L18), neuro.ghost_filter_clamp (L15/L28),
        neuro.temporal_discount, and neuro.hysteresis_decay; initializes an
        empty update log and inactive Samson flag.

        Trace: Levantine L15, L18, L24, L28; config neuro section.
        """
        raise NotImplementedError(
            "spec: store config clamps and shared state reference; "
            "samson_active=False; updates=[]"
        )

    def apply_precision_delta(self, delta: float, cycle: int) -> float:
        """Apply a P_local increment under the BRCA2 clamp (L18).

        The raw delta is clamped to +/- neuro.brca2_clamp before application;
        after application P_local passes through the ghost filter (hard clamp
        at ghost_filter_clamp, L15/L28). The state is re-synced
        (state.sync_coord) and an AxisUpdate is logged recording which clamp
        fired.

        Trace: Levantine L15, L18, L28.
        """
        raise NotImplementedError(
            "spec: delta_c = clamp(delta, -brca2_clamp, +brca2_clamp); "
            "P += delta_c; P = ghost_filter(P); sync; log AxisUpdate; "
            "return applied delta"
        )

    def ghost_filter(self, precision_local: float) -> float:
        """Nesher Ramla ghost-lineage clamp: P_local < +2.5 (L15/L28).

        Hard upper clamp at neuro.ghost_filter_clamp; when the raw value
        exceeds the clamp, the excess is reported so the breakdown guard can
        route it into the noise buffer (psychosis/paranoia prevention).

        Trace: Levantine L15, L28.
        """
        raise NotImplementedError(
            "spec: return min(precision_local, ghost_filter_clamp); expose "
            "excess via last update record"
        )

    def precision_breakdown_guard(self, cycle: int) -> bool:
        """Active guard against runaway hyper-precision (L28).

        When P_local is within 0.1 of the ghost clamp, the guard lowers
        P_local by one BRCA2-clamped step and returns True, signalling
        `neuro.blankets` (referenced by name) to raise the noise buffer.
        Prevents paranoia-like collapse of agency.

        Trace: Levantine L28, L15.
        """
        raise NotImplementedError(
            "spec: if P_local > ghost_clamp - 0.1: apply -brca2_clamp step, "
            "return True; else False"
        )

    def update_temporal_focus(self, drive: float, cycle: int) -> float:
        """Update T under FOXP2 discounting pressure and range clamp.

        The drive (from mode policy and priors) moves T; the FOXP2 prior from
        `neuro.priors` (referenced by name) pulls the effective discount
        toward 1.0 (L19/L35), biasing T positive; the result is clamped to
        [-2, +2] via state.clamp_temporal_focus (L3).

        Trace: Levantine L3, L19, L35; core/state.py clamp.
        """
        raise NotImplementedError(
            "spec: T += drive * plasticity; pull toward prior; clamp [-2,2]; "
            "sync; return T"
        )

    def systemizing_bias(self) -> float:
        """Systemizing/socializing trade-off scalar P_local - B_social (L8).

        Modulates task selection in `policy.selection` (referenced by name):
        positive bias favors encapsulated systemizing tasks, negative favors
        social tasks.

        Trace: Levantine L8.
        """
        raise NotImplementedError(
            "spec: return state.precision_local - state.boundary_social"
        )

    def apply_samson_profile(self, cycle: int) -> None:
        """Set the Samson attractor coordinates (P=+2, B_social=+2.5, T=0).

        L24: while samson_active, long-horizon planning is disabled — the
        LayerIO meta emitted by `step` carries planning_horizon=0 so
        `policy.hierarchical` (referenced by name) collapses to reactive
        control.

        Trace: Levantine L24.
        """
        raise NotImplementedError(
            "spec: set axes to SAMSON_PROFILE (through clamps), set "
            "samson_active=True, sync state"
        )

    def step(self, inp: LayerIO) -> LayerIO:
        """Advance axis dynamics one cycle under the LayerIO contract.

        Expects inp.meta keys: `drives` (dict with precision/temporal drive
        floats from the residual stage), `plasticity_gain` (float from
        agency.criticality, audit #78 channel), `cycle` (int). Applies
        precision delta (BRCA2 clamped), temporal update, breakdown guard;
        returns LayerIO(state=state.neuro_coord, meta={'systemizing_bias':..,
        'samson_active':.., 'planning_horizon':.., 'dual_boundary':..}).

        Trace: Levantine L3, L8, L15, L18, L24, L28; Audit #78;
        Blueprint Part 2.
        """
        raise NotImplementedError(
            "spec: apply drives under clamps and plasticity; run guard; "
            "return LayerIO with axis meta channels"
        )

    def falsification_test(self) -> FalsificationResult:
        """Kill criterion: no unclamped axis movement ever occurred.

        Fails if any logged AxisUpdate shows |dP| > brca2_clamp + eps without
        clamped_by_brca2 set, or P_local ever exceeded ghost_filter_clamp
        (L15/L18 regression).

        Trace: Levantine L15, L18, L28; Blueprint Part 8.
        """
        raise NotImplementedError(
            "spec: scan update log for clamp violations; metric = violation "
            "count; threshold 0"
        )


__all__ = ["SAMSON_PROFILE", "AxisUpdate", "AxisDynamics"]
```

----------------------------------------

### File: `blankets.py`

**Path:** `stage4/stage4/neuro/blankets.py`
**Extension:** `.py`
**Size:** 7,194 bytes (7.03 KB)

```py
"""Markov blankets, ochre scaffolding, permeability control, noise buffering.

Implements the Levantine patch section B (L9-L16 blanket half):
  - L9:  sensory Markov blanket dB_sensory — a stabilizer state reducing
         chaotic ambient noise xi(t).
  - L10: red-ochre/ritual scaffolding — scaffold_ochre(intensity) lowers
         B_sensory permeability and raises P_local (material ritual as
         computational stabilization).
  - L11: macro-scale social blankets — endogamy/purity/dietary channels
         protecting high-precision subpopulations.
  - L12: tabernacle/ritual recalibration — pull P/B/T toward the origin
         x0=(0,0,0) when in sacred/REFLECT-class modes (external controller
         for runaway coordinates).
  - L13: boundary permeability controller — social_gain/sensory_gain
         modulated by mode policy (from core.modes MODE_POLICIES).
  - L14: noise injection xi(t) and buffering — noise_level vs noise_buffer
         separated so external shocks never directly collapse precision.

Hysteresis-side points (L16, L26-L30) live in `neuro.hysteresis`.

Trace: Levantine L9-L14; core/modes.py ModePolicy; SPEC §5
(L9-L16 -> neuro/blankets.py, neuro/hysteresis.py).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, Dict, Optional

from stage4.config import Config
from stage4.core.types import FalsificationResult, LayerIO, SystemMode

if TYPE_CHECKING:
    from stage4.core.state import NeuroCognitiveState


@dataclass
class SocialBlanket:
    """Macro-scale collective boundary channels (L11).

    Each channel in [0, 1]: endogamy (in-group protocol commitment, cf.
    agency.commitments' `endogamy` key), purity (ritual purity restriction,
    cf. L21), dietary (dietary-law boundary). Higher = stronger blanket.

    Trace: Levantine L11, L20, L21.
    """

    endogamy: float = 0.0
    purity: float = 0.0
    dietary: float = 0.0

    def strength(self) -> float:
        """Aggregate blanket strength as the mean of the three channels.

        Trace: Levantine L11.
        """
        raise NotImplementedError(
            "spec: return (endogamy + purity + dietary) / 3"
        )


class MarkovBlanketController:
    """Sensory/social blankets, scaffolding, permeability, and noise buffer.

    Trace: Levantine L9-L14; SPEC §5.
    """

    def __init__(self, config: Config, state: NeuroCognitiveState) -> None:
        """Bind to the shared NeuroCognitiveState; init blankets and buffers.

        Initializes sensory_blanket=0.0 (L9), SocialBlanket (L11),
        boundary_controller gains from config defaults {social_gain: 0.1,
        sensory_gain: 0.1} (L13), noise_level=0.0 and noise_buffer=0.0 (L14).

        Trace: Levantine L9, L11, L13, L14; config neuro section.
        """
        raise NotImplementedError(
            "spec: store config + state; init L9/L11/L13/L14 fields at "
            "their documented defaults"
        )

    def apply_sensory_scaffold(self, intensity: float) -> None:
        """Red-ochre ritual scaffolding (L10) via the sensory blanket (L9).

        scaffold_ochre(intensity): lowers B_sensory permeability (moves
        B_sensory toward 0 from below) and raises P_local, both in
        proportion to intensity in [0, 1]; the P raise is routed through
        `neuro.axes` BRCA2 clamp (referenced — applied by the caller) so
        scaffolding can never cause a runaway swing.

        Trace: Levantine L9, L10; neuro/axes.py BRCA2 clamp channel.
        """
        raise NotImplementedError(
            "spec: B_sensory += intensity * (0 - B_sensory) * rate; P raise "
            "request exported via pending channel; sensory_blanket += "
            "intensity-scaled stabilizer"
        )

    def recalibrate_to_origin(self, strength: float) -> None:
        """Tabernacle/ritual recalibration toward x0 = (0,0,0) (L12).

        Pulls P_local, P_global, B_social, B_sensory, T toward zero by
        `strength` fraction; invoked when the active mode is REFLECT-class
        or a sacred flag arrives via meta. Prevents runaway axis coordinates.

        Trace: Levantine L12; core/state.py NeuroCognitiveState.
        """
        raise NotImplementedError(
            "spec: each axis <- axis * (1 - strength); clamp T; sync state"
        )

    def update_boundary_controller(self, mode: SystemMode) -> Dict[str, float]:
        """Apply the active mode's gains to the permeability controller (L13).

        Multiplies social_gain/sensory_gain by MODE_POLICIES[mode] factors
        from core.modes; returns the effective gains used this cycle.

        Trace: Levantine L13; core/modes.py MODE_POLICIES.
        """
        raise NotImplementedError(
            "spec: effective gains = base gains * MODE_POLICIES[mode] "
            "social/sensory factors; store and return them"
        )

    def inject_noise(self, xi: float) -> float:
        """Inject environmental noise into the buffer, not the axes (L14).

        xi (supplied by the caller's seeded phitensor.rng stream) is added to
        noise_level; the noise_buffer absorbs a fraction proportional to the
        sensory blanket strength, so external shocks degrade the buffer
        before they can touch precision (L14 separation invariant). Returns
        the unbuffered residual noise that escapes toward `neuro.hysteresis`.

        Trace: Levantine L14, L9.
        """
        raise NotImplementedError(
            "spec: noise_level += xi; buffered = noise_level * "
            "blanket_strength; noise_buffer += buffered; return residual"
        )

    def step(self, inp: LayerIO) -> LayerIO:
        """Advance blanket dynamics one cycle under the LayerIO contract.

        Expects inp.meta keys: `mode` (SystemMode), `noise_xi` (float,
        seeded), optional `ochre_intensity` (float), optional
        `recalibrate` (float strength). Runs boundary-controller update,
        scaffolding, recalibration, noise injection in that order; returns
        LayerIO(state={'sensory_blanket':..., 'social_blanket':...}, meta=
        {'noise_level':..., 'noise_residual':..., 'gains':...}) for
        `agency.criticality` (noise_level channel, L25) and
        `neuro.hysteresis` (residual shocks).

        Trace: Levantine L9-L14; Blueprint Part 2.
        """
        raise NotImplementedError(
            "spec: ordered controller/scaffold/recalibrate/noise update; "
            "return LayerIO with blanket state and noise channels"
        )

    def falsification_test(self) -> FalsificationResult:
        """Kill criterion: noise buffer actually attenuates (L14).

        Fails if the mean unbuffered residual over history is not strictly
        less than the mean injected |xi| whenever the blanket is active —
        i.e. the buffer is decorative (audit #14-class regression).

        Trace: Levantine L9, L14; Blueprint Part 8.
        """
        raise NotImplementedError(
            "spec: metric = mean(residual)/mean(|xi|) over logged history; "
            "passed = metric < 1.0 when blanket strength > 0"
        )


__all__ = ["SocialBlanket", "MarkovBlanketController"]
```

----------------------------------------

### File: `hysteresis.py`

**Path:** `stage4/stage4/neuro/hysteresis.py`
**Extension:** `.py`
**Size:** 7,512 bytes (7.34 KB)

```py
"""Hysteresis: Heinrich-5 shocks, hypersensitivity lag, attractor basins.

Implements the Levantine hysteresis block (L16, L26, L27, L29, L30):
  - L16: environmental hysteresis trap — hysteresis state {"P": .., "T": ..}
         with slow decay (neuro.hysteresis_decay = 0.995) modeling sensory
         hypersensitivity as ancestral lag.
  - L26: Heinrich-5 shock events — _heinrich_event() spikes the noise level
         and drives P -> +2, T -> -2 (hypervigilance coordinates), testing
         resilience under deep-time environmental stress.
  - L27: sensory hypersensitivity lag — after a shock, hypersensitivity
         decays slowly at hysteresis_decay, persisting long after the threat
         subsides.
  - L29: error-weighted noise filter — prediction errors are weighted by
         domain (ghost-lineage filter) before entering the noise buffer.
  - L30: climate-collapse attractor basins — {"hypervigilance", ..,
         "ritual_stability"} basin depths that biases relax toward.

Shock *frequency* is exported to `agency.criticality.adapt_danger_window`
(L32 channel) and shock events feed `core.energy` survival accounting.

Trace: Levantine L16, L26, L27, L29, L30, L32; config
neuro.hysteresis_decay; SPEC §5 (L9-L16, L25-L32 -> neuro/hysteresis.py).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, Dict, List, Optional

from stage4.config import Config
from stage4.core.types import FalsificationResult, LayerIO

if TYPE_CHECKING:
    from stage4.core.state import NeuroCognitiveState

#: Heinrich-5 hypervigilance target coordinates (P_local, T) per L26.
HEINRICH5_TARGET: tuple = (2.0, -2.0)

#: Named attractor basins tracked by this module (L30).
ATTRACTOR_BASINS: tuple = ("hypervigilance", "ritual_stability")


@dataclass
class ShockEvent:
    """Structured record of one Heinrich-class shock (L26).

    Trace: Levantine L26; Agency criticality L32 shock-frequency channel.
    """

    cycle: int
    magnitude: float
    noise_spike: float


class HysteresisModel:
    """Shock events, hypersensitivity lag, and attractor basin dynamics.

    Trace: Levantine L16, L26, L27, L29, L30; SPEC §5.
    """

    def __init__(self, config: Config, state: NeuroCognitiveState) -> None:
        """Bind to shared state; init hysteresis traps and basins.

        Loads neuro.hysteresis_decay (L16/L27); initializes hysteresis
        trap {"P": 0.0, "T": 0.0} (L16), sensory_hypersensitivity=0.0 (L27),
        basin depths {b: 0.0 for b in ATTRACTOR_BASINS} (L30), empty shock
        log, and the domain weights for the error-weighted filter (L29).

        Trace: Levantine L16, L26, L27, L29, L30.
        """
        raise NotImplementedError(
            "spec: load hysteresis_decay; init traps, hypersensitivity, "
            "basins, shock_log=[], domain_weights={}"
        )

    def heinrich_event(self, cycle: int, magnitude: float) -> ShockEvent:
        """Heinrich-5 shock: spike noise, drive P -> +2, T -> -2 (L26).

        The shock magnitude scales a noise spike routed into
        `neuro.blankets.inject_noise` (referenced by name via return meta);
        P_local and T are moved toward HEINRICH5_TARGET through the BRCA2
        clamp channel (the move is queued across cycles, never instant);
        sensory_hypersensitivity jumps by magnitude; the hypervigilance
        basin deepens (L30). Returns the structured ShockEvent.

        Trace: Levantine L26, L27, L30; neuro/axes.py clamp channel.
        """
        raise NotImplementedError(
            "spec: create ShockEvent; hypersensitivity += magnitude; queue "
            "clamped axis moves toward HEINRICH5_TARGET; deepen "
            "hypervigilance basin; append shock_log; return event"
        )

    def decay(self) -> None:
        """Slow decay of hysteresis traps and hypersensitivity (L16/L27).

        hysteresis["P"], hysteresis["T"], and sensory_hypersensitivity are
        multiplied by neuro.hysteresis_decay (0.995) per cycle — the
        ancestral lag: sensitivity persists long after the shock (L27).

        Trace: Levantine L16, L27; config neuro.hysteresis_decay.
        """
        raise NotImplementedError(
            "spec: multiply trap P/T and hypersensitivity by decay constant"
        )

    def error_weighted_filter(self, errors: Dict[str, float]) -> Dict[str, float]:
        """Weight prediction errors by domain before noise buffering (L29).

        Each domain's error is multiplied by its learned domain weight
        (updated slowly from past filter performance); unknown domains get
        weight 1.0. Output feeds `neuro.blankets` noise buffer and
        `world_model.loss` (referenced by name).

        Trace: Levantine L29.
        """
        raise NotImplementedError(
            "spec: return {d: e * domain_weights.get(d, 1.0)}; update "
            "weights by slow EMA of per-domain filter residual"
        )

    def basin_pull(self) -> Dict[str, float]:
        """Attractor-basin pull on the axes (L30).

        Returns per-axis bias from the two basins: hypervigilance depth
        pulls P up and T down (toward HEINRICH5_TARGET); ritual_stability
        depth pulls all axes toward 0 (companion to L12 recalibration).
        Consumed by `neuro.axes.step` via the drives channel.

        Trace: Levantine L30, L12.
        """
        raise NotImplementedError(
            "spec: compute per-axis pull from basin depths; return dict of "
            "drive biases"
        )

    def shock_frequency(self, window: int = 100) -> float:
        """Recent shock frequency for the adaptive danger window (L32).

        Count of ShockEvents in the last `window` cycles divided by window;
        consumed by `agency.criticality.adapt_danger_window` (referenced by
        name) per L32.

        Trace: Levantine L32; agency/criticality.py.
        """
        raise NotImplementedError(
            "spec: return shocks in trailing window / window"
        )

    def step(self, inp: LayerIO) -> LayerIO:
        """Advance hysteresis one cycle under the LayerIO contract.

        Expects inp.meta keys: `cycle` (int), optional `shock` (magnitude
        float triggering heinrich_event), optional `errors` (domain-error
        dict for L29). Runs shock handling -> error filter -> decay ->
        basin pull; returns LayerIO(state={'hypersensitivity':...,
        'basins':...}, meta={'shock_frequency':..., 'basin_pull':...,
        'noise_spike':...}) for agency.criticality and neuro.axes.

        Trace: Levantine L16, L26, L27, L29, L30, L32; Blueprint Part 2.
        """
        raise NotImplementedError(
            "spec: ordered shock/filter/decay/basin update; return LayerIO "
            "with hysteresis channels in meta"
        )

    def falsification_test(self) -> FalsificationResult:
        """Kill criterion: hypersensitivity decays slower than noise.

        Fails if the observed half-life of sensory_hypersensitivity after
        shocks is not longer than the noise buffer's half-life — the L27
        ancestral-lag property that distinguishes hysteresis from noise.

        Trace: Levantine L27; Blueprint Part 8.
        """
        raise NotImplementedError(
            "spec: estimate decay half-lives from logs; passed = "
            "hypersensitivity half-life > noise half-life"
        )


__all__ = [
    "ATTRACTOR_BASINS",
    "HEINRICH5_TARGET",
    "ShockEvent",
    "HysteresisModel",
]
```

----------------------------------------

### File: `priors.py`

**Path:** `stage4/stage4/neuro/priors.py`
**Extension:** `.py`
**Size:** 5,291 bytes (5.17 KB)

```py
"""Archaic genomic priors: BRCA2/FOXP2/ghost-filter biases on cognition.

Implements the Levantine archaic prior layer:
  - L5:  the prior layer itself — `archaic_priors = {"brca2_clamp": ...,
         "foxp2_discount": ..., "ghost_filter": ...}` as initial biases on
         precision dynamics, temporal discounting, and noise filtering.
  - L19/L35: FOXP2-like temporal discounting — gamma_temporal is pushed
         toward 1.0 by the foxp2_discount prior, flattening discounting so
         future rewards are nearly as salient as immediate ones.
  - L34: multi-generational retention hook — when gamma_temporal > 0.9 a
         low-decay retention flag is exported for `memory.semantic` and
         `memory.narrative` (referenced by name).

These are *priors* (initial biases + slow pulls), not hard constraints; the
clamps they parameterize are enforced in `neuro.axes` (BRCA2, ghost filter).

Trace: Levantine L5, L19, L34, L35; config neuro.temporal_discount;
SPEC §5 (L17-L24 -> neuro/priors.py among others).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict

from stage4.config import Config
from stage4.core.types import FalsificationResult, LayerIO


@dataclass
class ArchaicPriors:
    """Genomic prior values parameterizing clamps and discounting.

    Attributes:
        brca2_clamp: Max |dP| per cycle; mirrors neuro.brca2_clamp (L5/L18).
        foxp2_discount: Strength of the pull of gamma toward 1.0 (L5/L19).
        ghost_filter: Precision ceiling; mirrors neuro.ghost_filter_clamp
            (L5/L15).

    Trace: Levantine L5 (prior layer), L18, L15.
    """

    brca2_clamp: float = 0.25
    foxp2_discount: float = 0.0
    ghost_filter: float = 2.5

    @classmethod
    def from_config(cls, config: Config) -> "ArchaicPriors":
        """Initialize priors from the `neuro` config section.

        Trace: Levantine L5; config neuro.brca2_clamp/ghost_filter_clamp.
        """
        raise NotImplementedError(
            "spec: read neuro.brca2_clamp, neuro.ghost_filter_clamp, and a "
            "foxp2 baseline derived from neuro.temporal_discount"
        )


class TemporalDiscounting:
    """FOXP2-driven temporal discount dynamics (L19/L35).

    Holds gamma_temporal (the effective discount factor) and pulls it toward
    1.0 at a rate set by the foxp2_discount prior; exports
    multi-generational retention flags for the memory layers (L34).

    Trace: Levantine L19, L34, L35.
    """

    def __init__(self, config: Config, priors: ArchaicPriors) -> None:
        """Initialize gamma from neuro.temporal_discount and the prior.

        Trace: Levantine L19, L35; config neuro.temporal_discount (0.9).
        """
        raise NotImplementedError(
            "spec: gamma_temporal = config temporal_discount; store prior "
            "foxp2_discount pull strength"
        )

    @property
    def gamma(self) -> float:
        """Current effective temporal discount factor in (0, 1].

        Trace: Levantine L35 (gamma -> 1 flat discounting).
        """
        raise NotImplementedError("spec: return self._gamma")

    def update(self, cycles: int = 1) -> float:
        """Pull gamma toward 1.0 by the FOXP2 prior over `cycles` steps.

        gamma <- gamma + foxp2_discount * (1 - gamma) * cycles, clamped to
        (0, 1]. Flatter discounting increases multi-generational memory and
        ritual repetition pressure (L19).

        Trace: Levantine L19, L35.
        """
        raise NotImplementedError(
            "spec: geometric pull toward 1.0; clamp (0,1]; return gamma"
        )

    def discount(self, value: float, horizon: int) -> float:
        """Discount a future value: value * gamma**horizon.

        With gamma near 1.0 (FOXP2 prior active), distant rewards stay
        salient (L35); consumed by `policy.options` and `meta.goal_gen`
        (referenced by name).

        Trace: Levantine L19, L35; Eq #49-#68 policy block consumer.
        """
        raise NotImplementedError("spec: return value * self.gamma ** horizon")

    def multi_generational_retention(self) -> bool:
        """True when gamma > 0.9: enable low-decay generational memory (L34).

        Consumed by `memory.semantic` / `memory.narrative` (referenced by
        name) to lower decay on tagged deep-time content.

        Trace: Levantine L34; config nbc.deep_time_tags channel.
        """
        raise NotImplementedError("spec: return self.gamma > 0.9")

    def step(self, inp: LayerIO) -> LayerIO:
        """Advance discounting one cycle under the LayerIO contract.

        Updates gamma and returns LayerIO(state=gamma, meta=
        {'multi_generational_retention': bool}) for memory layers.

        Trace: Levantine L19, L34, L35; Blueprint Part 2.
        """
        raise NotImplementedError(
            "spec: update(); return LayerIO with retention flag in meta"
        )

    def falsification_test(self) -> FalsificationResult:
        """Kill criterion: gamma stays in (0, 1] and moves monotonically up.

        Trace: Levantine L35; Blueprint Part 8.
        """
        raise NotImplementedError(
            "spec: passed = 0 < gamma <= 1 and no downward move recorded"
        )


__all__ = ["ArchaicPriors", "TemporalDiscounting"]
```

----------------------------------------

##### Directory: `stage4/stage4/neuro/__pycache__`


#### Directory: `stage4/stage4/self_model`


### File: `__init__.py`

**Path:** `stage4/stage4/self_model/__init__.py`
**Extension:** `.py`
**Size:** 1,075 bytes (1.05 KB)

```py
"""L6 Self-Model — predicts the agent's own future z and actions (Blueprint §3.3).

The self-model is trained on the same trajectories as the world model and
must be calibrated, not merely confident:

    L_self = ||z_hat_{t+k}^self - z_{t+k}||^2 + ECE(c_self, 1[a_hat = a])

Blueprint Part 1.3 requires ECE < 0.1; failure mode 3 ("self-model lies")
mandates halt when ECE > 0.2 — "do not let the system act on a lying
self-model."

Modules:
  predictor.py    — Kalman-gated self-predictor (Eq #15, #17, #29, #30)
  calibration.py  — ECE and recalibration toolbox (Eq #20, #84-#96)
  spel.py         — fixed self-prediction error loop (audit #97-108, Eq #27)

Traceability:
  - Blueprint §3.3 (L6), Part 1.3 (ECE < 0.1), failure mode 3 (halt > 0.2)
  - Eq #15, #17, #20, #27, #29, #30, #83-96
  - Audit #97-108 (SPEL fixes)
"""

from __future__ import annotations

from stage4.self_model.predictor import SelfPredictor
from stage4.self_model.calibration import Calibrator
from stage4.self_model.spel import SPEL

__all__ = ["SelfPredictor", "Calibrator", "SPEL"]
```

----------------------------------------

### File: `calibration.py`

**Path:** `stage4/stage4/self_model/calibration.py`
**Extension:** `.py`
**Size:** 8,362 bytes (8.17 KB)

```py
"""Calibration toolbox — measured, never asserted (Blueprint §3.3, failure mode 3).

Hosts the uncertainty/calibration equations (Eq #83-96). The primary metric
is expected calibration error:

    ECE = sum_{b=1}^{B} (n_b / N) |acc(b) - conf(b)|          (Eq #20)

Blueprint Part 1.3 requires ECE < 0.1 (config self_model.ece_target);
failure mode 3 mandates HALT when ECE > 0.2 (config self_model.ece_halt):
"the self-model is a lie; halt." The halt signal is emitted by
``halt_signal()`` and consumed by the safety layer (named only).

Recalibration methods: temperature scaling (Eq #87), Platt scaling (Eq #88),
isotonic regression (Eq #89), Venn-Abers (Eq #95); uncertainty decomposition:
aleatoric/epistemic split (Eq #84), bootstrap ensemble (Eq #85), MC-dropout
(Eq #86); scoring: conformal prediction (Eq #90), Brier score (Eq #91),
reliability-diagram entropy (Eq #92), self-consistency (Eq #93), focal loss
for calibration bins (Eq #94), kappa lower bound (Eq #96).

Traceability:
  - Blueprint §3.3 (calibration), Part 1.3 (ECE < 0.1), failure mode 3 (halt > 0.2)
  - Eq #20, #83-96
  - Phi-Lite feature #55 (kappa calibration) — replaced by measured ECE
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, Dict, List, Optional, Sequence, Tuple

from stage4.config import Config
from stage4.core.types import FalsificationResult

if TYPE_CHECKING:
    from phitensor import Tensor


@dataclass
class CalibrationReport:
    """Snapshot of calibration health; drives the failure-mode-3 halt."""

    ece: float
    brier: float
    bins: List[Tuple[int, float, float]]  # (count, acc, conf) per bin
    halt: bool                            # True iff ece > ece_halt
    detail: Dict[str, Any] = field(default_factory=dict)


@dataclass
class UncertaintySplit:
    """Aleatoric vs epistemic decomposition sigma^2 = sigma_ale^2 + sigma_epi^2 (Eq #84)."""

    aleatoric: float
    epistemic: float

    @property
    def total(self) -> float:
        """Total predictive variance (Eq #84).

        Trace: Eq #84
        """
        return self.aleatoric + self.epistemic


class Calibrator:
    """ECE measurement, recalibration, conformal coverage, halt signal.

    Trace: Blueprint §3.3; Eq #20, #84-96; failure mode 3
    """

    name: str = "self_model.calibration"

    def __init__(self, config: Config) -> None:
        """Bind config: bins=15, ece_target=0.1, ece_halt=0.2, conformal_alpha=0.1.

        Trace: stage4.config DEFAULT_CONFIG["self_model"]
        """
        self._config = config
        self.n_bins: int = int(config.get("self_model.calibration_bins", 15))
        self.ece_target: float = float(config.get("self_model.ece_target", 0.1))
        self.ece_halt: float = float(config.get("self_model.ece_halt", 0.2))
        self.conformal_alpha: float = float(config.get("self_model.conformal_alpha", 0.1))

    def expected_calibration_error(self, confidences: Sequence[float], correct: Sequence[bool]) -> float:
        """ECE over uniform-mass bins (Eq #20, Blueprint §3.3).

        Trace: Eq #20
        """
        raise NotImplementedError(
            "spec: bin by confidence; ECE = sum_b (n_b/N) |acc(b) - conf(b)|; "
            "fused kernel phitensor.kernels.fused_ece_bins when available"
        )

    def brier_score(self, probs: Sequence[float], outcomes: Sequence[int]) -> float:
        """BS = (1/N) sum (p_i - y_i)^2, tracked per action (Eq #91).

        Trace: Eq #91
        """
        raise NotImplementedError("spec: mean squared error of probs vs outcomes")

    def halt_signal(self, report: CalibrationReport) -> bool:
        """Failure mode 3: True iff ECE > ece_halt (0.2) — system must halt.

        "If ECE > 0.2, the self-model is a lie; halt." The safety layer
        (safety.shield, named only) consumes this signal.

        Trace: Blueprint failure mode 3, §3.3; config self_model.ece_halt
        """
        raise NotImplementedError("spec: return report.ece > self.ece_halt")

    def platt_scale(self, confidences: Sequence[float], correct: Sequence[bool]) -> Tuple[float, float]:
        """Platt scaling: fit sigma(a c + b) to accuracy (Eq #88).

        Replaces Phi-Lite's raw kappa (feature #55).

        Trace: Eq #88
        """
        raise NotImplementedError(
            "spec: logistic regression on (confidence, correctness); return (a, b)"
        )

    def isotonic_fit(self, confidences: Sequence[float], correct: Sequence[bool]) -> List[Tuple[float, float]]:
        """Isotonic regression: monotonic confidence -> accuracy map (Eq #89).

        Trace: Eq #89
        """
        raise NotImplementedError("spec: pool-adjacent-violators; piecewise map")

    def temperature_scale(self, logits: Tensor) -> float:
        """T* = argmin_T ECE(softmax(z/T)) (Eq #87).

        Trace: Eq #87 (and Eq #21/#22 entropy-matching variant)
        """
        raise NotImplementedError(
            "spec: 1-D search over T minimizing ECE of softmax(z/T); "
            "phitensor.ops.softmax"
        )

    def venn_abers(self, confidences: Sequence[float], correct: Sequence[bool], query: float) -> Tuple[float, float]:
        """Venn-Abers predictor: valid probability interval [p0, p1] (Eq #95).

        Trace: Eq #95
        """
        raise NotImplementedError(
            "spec: isotonic under both label hypotheses; return (p0, p1) "
            "interval with validity 1 - err"
        )

    def conformal_set(self, scores: Sequence[float], alpha: Optional[float] = None) -> float:
        """Conformal quantile q_{1-alpha} of nonconformity scores (Eq #90).

        Prediction sets C_alpha = {y : s(y) < q_{1-alpha}} with
        distribution-free coverage.

        Trace: Eq #90; config self_model.conformal_alpha
        """
        raise NotImplementedError(
            "spec: empirical ceil((n+1)(1-alpha))/n quantile of scores"
        )

    def split_uncertainty(self, ensemble_preds: List[Tensor], mc_preds: List[Tensor]) -> UncertaintySplit:
        """Aleatoric/epistemic split sigma^2 = sigma_ale^2 + sigma_epi^2 (Eq #84).

        Epistemic from bootstrap ensemble disagreement (Eq #85: K predictor
        copies, c = 1 - Var_K(b_hat)) and MC-dropout spread (Eq #86: T
        stochastic forwards); aleatoric from mean predicted variance.

        Trace: Eq #84, #85, #86
        """
        raise NotImplementedError(
            "spec: epi = Var over ensemble/MC means; ale = mean of per-sample "
            "predicted variances; return UncertaintySplit"
        )

    def reliability_diagram_entropy(self, bins: List[Tuple[int, float, float]]) -> float:
        """Entropy/curvature score of the reliability curve (Eq #92).

        Trace: Eq #92
        """
        raise NotImplementedError("spec: curvature energy of acc-conf curve over bins")

    def self_consistency(self, sampled_actions: Sequence[Any]) -> float:
        """c = (1/K) sum_k 1[argmax pi_k = argmax pi] (Eq #93).

        Trace: Eq #93
        """
        raise NotImplementedError("spec: agreement rate across K stochastic samples")

    def focal_calibration_loss(self, probs: Tensor, targets: Tensor, gamma: float = 2.0) -> Tensor:
        """FL = -(1 - p_t)^gamma log p_t for calibration bins (Eq #94).

        Trace: Eq #94
        """
        raise NotImplementedError("spec: focal loss via phitensor.ops on bin probs")

    def kappa_lower_bound(self, bins: List[Tuple[int, float, float]], prior: float) -> float:
        """kappa >= E_b[acc(b) - conf(b)] + prior (Eq #96).

        Trace: Eq #96; Phi-Lite feature #55 (kappa) made honest
        """
        raise NotImplementedError("spec: weighted mean of (acc-conf) + prior")

    def report(self, confidences: Sequence[float], correct: Sequence[bool]) -> CalibrationReport:
        """Full calibration report: ECE, Brier, bins, halt flag.

        Trace: Blueprint §3.3, failure mode 3
        """
        raise NotImplementedError(
            "spec: compute ECE + Brier + bin table; halt = ece > ece_halt"
        )

    def falsification_test(self) -> FalsificationResult:
        """Blueprint Part 1.3: ECE < 0.1 on held-out rollouts.

        Trace: Blueprint Part 1.3, §5.2
        """
        raise NotImplementedError(
            "spec: ECE on held-out rollouts; pass iff ece < ece_target (0.1)"
        )
```

----------------------------------------

### File: `predictor.py`

**Path:** `stage4/stage4/self_model/predictor.py`
**Extension:** `.py`
**Size:** 6,745 bytes (6.59 KB)

```py
"""Self-predictor — predicts the agent's own future z and actions (Blueprint §3.3).

Replaces Phi-Lite's SGD-jittered 64-D predictor (feature #2) with a
Kalman-gated predictor:

    b_hat_{t+1} = b_hat_t + K_t (b_t - b_hat_t),
    K_t = P_t (P_t + R)^{-1}                                   (Eq #15)

trained by the free-energy learning rule

    W_dot = -eta * grad_W F,  F = E[(b - b_hat)^2] + KL(q||p)  (Eq #17)

with Robbins-Monro learning rates eta_t = eta_0 / t^{1/2} for guaranteed
convergence (Eq #29), and scored by Bayesian model evidence
log p(b_{1:t}) instead of raw pred_err (Eq #30).

Also hosts: self-model contraction check ||J_s|| < 1 (Eq #18 — the
fixed-point iteration of Phi-Lite feature #3 only converges under a spectral
norm bound), frozen-learner escape noise when Var(pred) < eps (Eq #23, fixing
Phi-Lite feature #66's blunt freeze), and predictive variance sigma^2_t
(Eq #83).

Traceability:
  - Blueprint §3.3 (L6 self-model)
  - Eq #15 (Kalman gate), #17 (free-energy rule), #18 (contraction), #23
    (escape), #29 (Robbins-Monro), #30 (model evidence), #83 (predictive variance)
  - Audit #99/#100 (updates must use previous params + a proper learning rule)
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, Dict, List, Optional, Tuple

from stage4.config import Config
from stage4.core.types import FalsificationResult, LayerIO

if TYPE_CHECKING:
    from phitensor import Tensor


@dataclass
class KalmanGains:
    """Kalman gate state: error covariance P and observation noise R (Eq #15)."""

    P: Any  # phitensor.Tensor, covariance of the prediction error
    R: Any  # phitensor.Tensor, observation noise covariance


@dataclass
class PredictionReport:
    """One self-prediction with everything downstream layers need."""

    z_hat: Any            # predicted future latent, shape (latent_dim,)
    a_hat: Any            # predicted own action distribution
    variance: float       # predictive variance sigma^2_t (Eq #83)
    kalman_gain: float    # mean |K_t| (Eq #15)
    model_evidence: float # log p(b_{1:t}) (Eq #30)
    horizon: int          # k in z_hat_{t+k}


class SelfPredictor:
    """Kalman-gated predictor of own future latents and actions.

    Trace: Blueprint §3.3; Eq #15/#17/#29/#30; Audit #99/#100
    """

    name: str = "self_model.predictor"

    def __init__(self, config: Config) -> None:
        """Bind config: latent dim, Robbins-Monro eta_0, contraction tolerance.

        Trace: Eq #29; stage4.config DEFAULT_CONFIG["world_model"] (latent_dim)
        """
        self._config = config
        self.latent_dim: int = int(config.get("world_model.latent_dim", 128))
        self._eta0: float = float(config.get("self_model.eta0", 0.05))
        self._t: int = 0  # Robbins-Monro clock (Eq #29)

    def kalman_gain(self, gains: KalmanGains) -> Tensor:
        """Compute K_t = P_t (P_t + R)^{-1} (Eq #15).

        Trace: Eq #15
        """
        raise NotImplementedError(
            "spec: K = P @ inv(P + R) via phitensor.ops.matmul; diagonal "
            "approximation allowed, documented"
        )

    def predict(self, z: Tensor, horizon: int) -> PredictionReport:
        """Predict own future latent z_hat_{t+k} and action distribution a_hat.

        Uses the Kalman-gated update (Eq #15) rather than raw SGD on pred
        (Phi-Lite feature #2 replacement).

        Trace: Blueprint §3.3; Eq #15
        """
        raise NotImplementedError(
            "spec: b_hat_{t+1} = b_hat_t + K_t (b_t - b_hat_t); action head "
            "over predicted latent; return PredictionReport"
        )

    def free_energy_update(self, prediction: Tensor, target: Tensor) -> Tensor:
        """Learning rule W_dot = -eta grad_W F (Eq #17).

        F = E[(b - b_hat)^2] + KL(q||p): reconstruction plus a consistency
        KL against the world-model prior (collaborator world_model.rssm.RSSM,
        named only).

        Trace: Eq #17; Audit #100 (a proper learning rule, not heuristics)
        """
        raise NotImplementedError(
            "spec: F = mse + kl_divergence (phitensor.ops); autograd.backward; "
            "natural-gradient option via phitensor.autograd.NaturalGradient"
        )

    def robbins_monro_rate(self) -> float:
        """Current learning rate eta_t = eta_0 / t^{1/2} (Eq #29).

        Guaranteed-convergence schedule; increments the internal clock.

        Trace: Eq #29
        """
        raise NotImplementedError("spec: self._t += 1; return eta0 / sqrt(t)")

    def model_evidence(self, trajectory: List[Tensor]) -> float:
        """Bayesian model evidence log p(b_{1:t}) (Eq #30).

        Replaces raw pred_err as the self-model quality signal: sum over tau
        of log predictive densities under the current posterior.

        Trace: Eq #30
        """
        raise NotImplementedError(
            "spec: sum_tau log ∫ p(b_tau|theta) q(theta) dtheta; diagonal-"
            "Gaussian analytic approximation"
        )

    def contraction_check(self, jacobian: Tensor) -> bool:
        """Self-model fixed point exists iff ||J_s|| < 1 (Eq #18).

        Logs a violation when the spectral norm reaches 1 — Phi-Lite's
        fixed-point iteration (feature #3) had no such guard.

        Trace: Eq #18
        """
        raise NotImplementedError(
            "spec: power-iteration estimate of spectral norm; return "
            "norm < 1; emit event on violation"
        )

    def frozen_escape_noise(self, pred_variance: float) -> Optional[Tensor]:
        """Restart noise when the learner freezes: Var(pred) < eps (Eq #23).

        Delta W = eps * N(0, Sigma_restart) — a principled replacement for
        Phi-Lite's blunt learning freeze (feature #66).

        Trace: Eq #23; Phi-Lite feature #66
        """
        raise NotImplementedError(
            "spec: if pred_variance < eps_V, sample N(0, Sigma_restart) via "
            "phitensor.rng.spawn('self_escape'); else None"
        )

    def step(self, inp: LayerIO) -> LayerIO:
        """LayerIO contract: current z -> predicted own future (z, a) + variance.

        Trace: Blueprint Part 2, §3.3; Eq #83 (predictive variance output)
        """
        raise NotImplementedError(
            "spec: predict(inp.state, k from meta) -> LayerIO(state=report, "
            "uncertainty=report.variance, cost=flops)"
        )

    def falsification_test(self) -> FalsificationResult:
        """Blueprint §3.3 test: self-prediction error decreases on held-out rollouts.

        Trace: Blueprint §3.3, Part 5.3
        """
        raise NotImplementedError(
            "spec: held-out rollout self-prediction error slope < 0, p < 0.01"
        )
```

----------------------------------------

### File: `spel.py`

**Path:** `stage4/stage4/self_model/spel.py`
**Extension:** `.py`
**Size:** 7,643 bytes (7.46 KB)

```py
"""SPEL — Self-Prediction Error Loop, fixed (audit #97-108, Eq #27).

The SPEL drives meta-cognitive growth from self-prediction error:

    m_dot = alpha (|eps_t| - E[|eps|])                          (Eq #27)

Phi-Lite's SPEL was broken in nine audited ways; each fix is structural:

  #97  model lambda did not persist        -> params live in a persistent
                                              ``SpelParams`` dataclass, not in
                                              closures.
  #98  new lambda closed over a local      -> no lambdas; named methods over
                                              persistent state.
  #99  update ignored previous params      -> every update reads and writes
                                              ``self._params`` (delta rule on
                                              top of previous values).
  #100 no gradient/Bayesian learning rule  -> free-energy gradient step
                                              (Eq #17, hosted in predictor.py)
                                              with Robbins-Monro rate (Eq #29).
  #101 expected-error EMA arbitrary        -> E[|eps|] is a documented EMA with
                                              config-derived rate.
  #102 meta-cognition growth capped at 1   -> unbounded m with soft saturation
                                              only via config meta_growth_rate.
  #103 surprise was absolute difference    -> surprise is information-theoretic:
                                              -log p(eps_t) under the current
                                              error model.
  #104 fixed error threshold               -> threshold from config
                                              (spel.error_threshold), adaptive.
  #105 error cost only hit energy/damage   -> error feeds the behavior link
                                              (#106): SPEL output modulates
                                              exploration via the mode system
                                              (core.modes, named only).
  #106 no link to behavior                 -> ``behavior_modulation()`` emits a
                                              LayerIO-consumable signal.
  #107 single variable (emergence)         -> multi-variable SPEL over
                                              config spel.variables =
                                              [emergence, energy, criticality].
  #108 no epistemic uncertainty            -> per-variable epistemic variance
                                              tracked via the Eq #84/#85 split
                                              in calibration.py (named only).

Traceability:
  - Eq #27 (SPEL), Eq #17/#29 (learning rule/rate), Eq #84/#85 (uncertainty)
  - Audit #97-108
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

from stage4.config import Config
from stage4.core.types import FalsificationResult, LayerIO


@dataclass
class SpelParams:
    """Persistent SPEL model parameters — audit #97/#98/#99 fix.

    Lives on the SPEL instance for the whole run; every update reads previous
    values and writes back (no closures, no discarded locals).
    """

    expected_abs_error: Dict[str, float] = field(default_factory=dict)  # E[|eps|] per variable
    meta_cognition: Dict[str, float] = field(default_factory=dict)      # m per variable (Eq #27)
    epistemic_variance: Dict[str, float] = field(default_factory=dict)  # audit #108
    update_count: int = 0


class SPEL:
    """Multi-variable self-prediction error loop with persistent parameters.

    Trace: Eq #27; Audit #97-108; config spel.variables
    """

    name: str = "self_model.spel"

    def __init__(self, config: Config) -> None:
        """Bind config: variables list, error_threshold, meta_growth_rate.

        Initializes persistent params for every configured variable
        (audit #107: multi-variable).

        Trace: stage4.config DEFAULT_CONFIG["spel"]; Audit #97-#99/#107
        """
        self._config = config
        self.variables: List[str] = list(
            config.get("spel.variables", ["emergence", "energy", "criticality"])
        )
        self.error_threshold: float = float(config.get("spel.error_threshold", 0.2))
        self.meta_growth_rate: float = float(config.get("spel.meta_growth_rate", 0.01))
        self._params = SpelParams(
            expected_abs_error={v: 0.0 for v in self.variables},
            meta_cognition={v: 0.0 for v in self.variables},
            epistemic_variance={v: 1.0 for v in self.variables},
        )

    @property
    def params(self) -> SpelParams:
        """Persistent parameters (audit #97: must persist across updates).

        Trace: Audit #97/#98
        """
        return self._params

    def surprise(self, variable: str, error: float) -> float:
        """Information-theoretic surprise -log p(eps) under the error model (audit #103).

        Laplacian error model around E[|eps|]: p(eps) = (1/2b) exp(-|eps|/b)
        with b = expected_abs_error; surprise = |eps|/b + log(2b).

        Trace: Audit #103; Eq #27
        """
        raise NotImplementedError(
            "spec: -log p(|eps|) under Laplace(b=expected_abs_error[var]); "
            "not absolute difference"
        )

    def update(self, variable: str, realized: float, predicted: float) -> float:
        """One SPEL update for a variable; returns current meta-cognition m.

        Steps, all on persistent params (audit #99):
          1. eps = realized - predicted.
          2. E[|eps|] <- documented EMA (audit #101).
          3. m <- m + meta_growth_rate * (|eps| - E[|eps|])  (Eq #27), no hard
             cap at 1 (audit #102).
          4. epistemic variance refresh (audit #108).
          5. learning rate follows Robbins-Monro eta_t (Eq #29, via predictor).

        Trace: Eq #27; Audit #99-#102/#107/#108
        """
        raise NotImplementedError(
            "spec: read/write self._params; EMA E[|eps|]; m update per Eq #27; "
            "reject unknown variable"
        )

    def behavior_modulation(self) -> Dict[str, float]:
        """Link meta-cognition to behavior (audit #106).

        Returns per-variable modulation weights consumed by core.modes (named
        only): high surprise raises exploration pressure; high epistemic
        variance lowers self-confidence fed to calibration.

        Trace: Audit #106/#108
        """
        raise NotImplementedError(
            "spec: map meta_cognition/epistemic_variance -> modulation weights; "
            "consumed by core.modes DDMS (named only, never imported)"
        )

    def step(self, inp: LayerIO) -> LayerIO:
        """LayerIO contract: realized vs predicted values in meta -> m and uncertainty out.

        Trace: Blueprint Part 2; Audit #97-108
        """
        raise NotImplementedError(
            "spec: for each variable, read (realized, predicted) from "
            "inp.meta['spel_obs']; update; LayerIO(state=params snapshot, "
            "uncertainty=mean epistemic_variance, cost=cognitive op cost)"
        )

    def falsification_test(self) -> FalsificationResult:
        """SPEL must track: m correlates with realized error regime changes.

        Fails if meta-cognition is decorrelated from actual self-prediction
        error on held-out windows (the v7.1 failure).

        Trace: Audit #106; Blueprint Part 5.3
        """
        raise NotImplementedError(
            "spec: correlation(m, |eps|) over held-out window > 0 with "
            "significance; else fail"
        )
```

----------------------------------------

##### Directory: `stage4/stage4/self_model/__pycache__`


#### Directory: `stage4/stage4/geometry`


### File: `__init__.py`

**Path:** `stage4/stage4/geometry/__init__.py`
**Extension:** `.py`
**Size:** 884 bytes (0.86 KB)

```py
"""Recursive geometry substrate for the Stage 4 system (GhostMesh patch A).

The 49-sector recursive grid S(7,7) is the coordinate system on which every
commitment, scar, and narrative lives (G1). Fractal machinery (Sierpinski,
Mandelbrot, Koch, Hausdorff) quantifies boundary complexity over raw density
(G2-G6), L-system/IFS rules grow strategies and commitments by rule rather
than by dice (G7-G8), and Feigenbaum/logistic dynamics schedule the
order-to-chaos transition of commitment change (G9-G10).

Traceability:
  - GhostMesh patch #1-#10 (recursive geometry and fractal substrate)
  - Eq #111-#124 (voxel/rendering ledger) hosted by ``fractals.SpectralSurface``
  - SPEC.md section 5 (GhostMesh G1-G10 -> geometry/*)
"""

from __future__ import annotations

from stage4.geometry import chaos, fractals, lsystem, sectors

__all__ = ["sectors", "fractals", "lsystem", "chaos"]
```

----------------------------------------

### File: `chaos.py`

**Path:** `stage4/stage4/geometry/chaos.py`
**Extension:** `.py`
**Size:** 6,631 bytes (6.48 KB)

```py
"""Chaotic scheduling of commitment change (G9-G10).

The order-to-chaos transition of commitment change is scheduled, not
random: a Feigenbaum period-doubling ladder (``delta ~= 4.669``, G9)
paces how change probability bifurcates over time, and the logistic map
``x_{n+1} = r * x_n * (1 - x_n)`` (``r ~= 3.57`` at the chaos edge, G10)
is the single equation governing both the calm center and the wild outer
band of commitment regimes.

Collaborators (referenced, never imported): ``agency/commitments.py``
queries the schedule before allowing change; ``agency/criticality.py``
reads the regime parameter as a precision-noise boundary signal.

Traceability:
  - GhostMesh patch #9 (Feigenbaum route scheduler)
  - GhostMesh patch #10 (logistic regime switch)
  - SPEC.md section 5 (G9-G10 -> geometry/chaos.py)
"""

from __future__ import annotations

from typing import List

from stage4.config import Config, load_config


class FeigenbaumScheduler:
    """Period-doubling scheduler for commitment change probability.

    As the schedule advances, the number of coexisting change-probability
    bands doubles at bifurcation points whose spacing ratios converge to
    Feigenbaum's ``delta`` (config ``geometry.feigenbaum_delta = 4.669``).
    The system thus knows *when* it approaches deterministic chaos instead
    of stumbling into it.

    Trace: GhostMesh #9 (delta ~= 4.669; order->chaos is scheduled).
    """

    def __init__(self, config: Config | None = None) -> None:
        """Bind the Feigenbaum constant and bifurcation budget.

        Args:
            config: Frozen config; reads ``geometry.feigenbaum_delta``.

        Trace: GhostMesh #9; config geometry section.
        """
        raise NotImplementedError("spec: bind feigenbaum_delta from config.geometry")

    def bifurcation_points(self, n: int) -> List[float]:
        """First ``n`` bifurcation parameters of the period-doubling route.

        Args:
            n: Number of bifurcation points to compute.

        Returns:
            Ordered bifurcation parameters whose consecutive spacing
            ratios converge to ``delta``.

        Trace: GhostMesh #9 (Feigenbaum route).
        """
        raise NotImplementedError("spec: accumulate bifurcation points via delta scaling")

    def change_probability(self, step: int) -> float:
        """Scheduled commitment-change probability at ``step``.

        Period-doubles as ``step`` crosses successive bifurcation points:
        the probability splits into 2, 4, 8, ... coexisting bands, then
        into the chaotic regime where change is effectively
        unpredictable-but-deterministic.

        Args:
            step: Global system cycle.

        Returns:
            Change probability in ``[0, 1]`` for this cycle.

        Trace: GhostMesh #9 (_feigenbaum_schedule(step)).
        """
        raise NotImplementedError("spec: period-doubling change probability vs step")

    def falsification_test(self) -> object:
        """Kill criterion: spacing ratios must converge to delta.

        Fails if the computed bifurcation spacings do not approach the
        configured Feigenbaum constant within tolerance.

        Trace: GhostMesh #9; Blueprint Part 8 (Falsifiable).
        """
        raise NotImplementedError("spec: verify bifurcation spacing ratio -> 4.669")


class LogisticRegimeSwitch:
    """Logistic-map regime controller for commitment dynamics.

    One equation, two faces: ``x_{n+1} = r * x_n * (1 - x_n)`` with
    ``r`` below the chaos edge gives the calm center (stable commitment
    phases); ``r ~= 3.57`` (config ``geometry.logistic_chaos_r``) and
    beyond gives the wild outer band. The switch moves ``r`` in response
    to system pressure (emergence debt, energy), so the same dynamics
    express both stability and chaos.

    Trace: GhostMesh #10 (r_regime; calm center vs wild outer band).
    """

    def __init__(self, config: Config | None = None) -> None:
        """Bind the chaos-edge parameter and regime state.

        Args:
            config: Frozen config; reads ``geometry.logistic_chaos_r``.

        Trace: GhostMesh #10; config geometry section.
        """
        raise NotImplementedError("spec: bind logistic_chaos_r and init regime state")

    @property
    def r_regime(self) -> float:
        """Current logistic parameter ``r`` (calm center vs outer band).

        Trace: GhostMesh #10 (self.r_regime).
        """
        raise NotImplementedError("spec: return current regime parameter")

    def step(self, x: float) -> float:
        """Advance the logistic map one step under the current regime.

        Args:
            x: Current regime coordinate in ``[0, 1]``.

        Returns:
            ``r_regime * x * (1 - x)``.

        Trace: GhostMesh #10 (x_{n+1} = r x_n (1 - x_n)).
        """
        raise NotImplementedError("spec: logistic map iteration")

    def switch(self, pressure: float) -> float:
        """Move ``r_regime`` in response to system pressure.

        Rising pressure (emergence debt, low energy) pushes ``r`` toward
        the chaos edge; relief pulls it back to the calm center. The
        switch is hysteretic to avoid oscillating across the edge.

        Args:
            pressure: Normalized system pressure in ``[0, 1]``.

        Returns:
            The updated ``r_regime``.

        Trace: GhostMesh #10; Levantine #16 (hysteresis on switches).
        """
        raise NotImplementedError("spec: hysteretic r update toward/away from chaos edge")

    def lyapunov_exponent(self, x0: float = 0.5, steps: int = 512) -> float:
        """Estimate the Lyapunov exponent of the current regime.

        Positive exponent certifies the wild outer band (chaos); negative
        certifies the calm center. Used by ``agency/criticality.py`` as a
        boundary-complexity signal.

        Args:
            x0: Orbit seed.
            steps: Orbit length for the estimate.

        Returns:
            Estimated Lyapunov exponent at ``r_regime``.

        Trace: GhostMesh #10 (same equation, stable and chaotic phases).
        """
        raise NotImplementedError("spec: mean log|r - 2*r*x| over the orbit")

    def falsification_test(self) -> object:
        """Kill criterion: exponent sign must match the regime label.

        Fails if ``r_regime < r_chaos`` yields a positive Lyapunov
        exponent or vice versa beyond tolerance.

        Trace: GhostMesh #10; Blueprint Part 8 (Falsifiable).
        """
        raise NotImplementedError("spec: Lyapunov sign vs chaos-edge consistency")


__all__ = ["FeigenbaumScheduler", "LogisticRegimeSwitch"]
```

----------------------------------------

### File: `fractals.py`

**Path:** `stage4/stage4/geometry/fractals.py`
**Extension:** `.py`
**Size:** 10,839 bytes (10.58 KB)

```py
"""Fractal substrate: density, orbit, boundary, dimension, spectral host (G2-G6).

Emergence in this system is not raw density — it is boundary complexity.
This module provides the fractal instruments that measure it:

- Sierpinski density decay: ``T(k) = 3*T(k-1)`` triangles, density -> 0 (G2)
- Mandelbrot bounded-orbit classifier for commitments (G3)
- Koch boundary metric: finite area, unbounded perimeter (G4)
- Gematria compression: recursive digit reduction of state vectors (G5)
- Hausdorff dimension of identity: ``D = log 4 / log 3 ~= 1.262`` (G6)

It also hosts the spectral surface with holographic reduced representation
(HRR) circular binding, the voxel/rendering home of equation ledger
entries Eq #111-#124.

Traceability:
  - GhostMesh patch #2-#6 (fractal substrate)
  - Eq #111-#124 (voxel/rendering ledger -> SpectralSurface / HRR)
  - SPEC.md section 5 (G1-G10 -> geometry/*, Eq 111-124 -> fractals.py)
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Dict, List, Sequence, Tuple

from stage4.config import Config, load_config

if TYPE_CHECKING:
    # Allowed skeleton import (SPEC section 2); guarded so the module
    # stays importable before phitensor lands. Annotations only.
    from phitensor.tensor import Tensor


def sierpinski_density(iteration: int, initial_density: float = 1.0) -> float:
    """Recursive density of the Sierpinski gasket at ``iteration``.

    Each compression cycle keeps 3 of 4 subtriangles, so density scales as
    ``(3/4)**iteration`` and decays to zero while boundary complexity
    persists. Called once per narrative compression cycle by
    ``memory/narrative.py``.

    Args:
        iteration: Compression-cycle count (``k >= 0``).
        initial_density: Density at iteration 0 (default 1.0).

    Returns:
        Density after ``iteration`` recursive removals, in ``(0, 1]``.

    Trace: GhostMesh #2 (T(k)=3T(k-1), density -> 0).
    """
    raise NotImplementedError("spec: density = initial_density * (3/4)**iteration")


def bounded_orbit(
    value: complex,
    max_iter: int = 64,
    escape_radius: float = 2.0,
) -> float:
    """Mandelbrot bounded-orbit classifier for a commitment value.

    Iterates ``z_{n+1} = z_n**2 + c`` with ``z_0 = 0`` and ``c = value``.
    A commitment whose orbit never escapes is a *portal* (stable attractor);
    an escaping orbit marks a commitment that will not hold.

    Args:
        value: Commitment value projected into the complex plane.
        max_iter: Orbit length before declaring bounded.
        escape_radius: Modulus beyond which the orbit is escaped.

    Returns:
        ``1.0`` if the orbit stays bounded for ``max_iter`` steps,
        ``0.0`` if it escapes.

    Trace: GhostMesh #3 (bounded = portal, escaped = unstable).
    """
    raise NotImplementedError("spec: iterate z=z*z+c, return 1.0 bounded / 0.0 escaped")


def koch_boundary_length(iteration: int, base_length: float = 1.0) -> float:
    """Koch-snowflake boundary length: ``P(k) = P(0) * (4/3)**k``.

    The identity's cognitive coastline grows without bound while its area
    stays finite (see :func:`koch_area`). High boundary length means high
    cognitive surface exposed to the world.

    Args:
        iteration: Fractal refinement depth (``k >= 0``).
        base_length: Perimeter at iteration 0.

    Returns:
        Boundary length after ``iteration`` refinements.

    Trace: GhostMesh #4 (finite area, infinite boundary).
    """
    raise NotImplementedError("spec: P(k) = base_length * (4/3)**iteration")


def koch_area(iteration: int, base_area: float = 1.0) -> float:
    """Finite area enclosed by the Koch boundary at ``iteration``.

    Converges to ``8/5`` of ``base_area`` as ``k -> inf``; the contrast
    with the diverging :func:`koch_boundary_length` is the point of G4.

    Args:
        iteration: Fractal refinement depth (``k >= 0``).
        base_area: Area of the seed triangle.

    Returns:
        Enclosed area after ``iteration`` refinements.

    Trace: GhostMesh #4 (finite area, infinite boundary).
    """
    raise NotImplementedError("spec: Koch snowflake area series converging to 8/5 * base_area")


def gematria_reduce(state_vector: Sequence[float]) -> int:
    """Recursive digit-reduction compression of a state vector.

    Sums the (quantized) digits of the vector's components, then reduces
    the sum digit-by-digit until a single digit in ``[1, 9]`` remains.
    This is the symbolic token a high-dimensional state compresses into
    for narrative tagging (consumed by ``memory/narrative.py`` NBC).

    Args:
        state_vector: Numeric state components to compress.

    Returns:
        Single-digit symbolic token of the state.

    Trace: GhostMesh #5 (any name reduces to one digit).
    """
    raise NotImplementedError("spec: quantize, digit-sum, reduce to one digit in [1,9]")


def hausdorff_dimension(boundary_length: float, area: float) -> float:
    """Hausdorff dimension of the identity boundary.

    Estimated from the boundary/area scaling ratio; the analytic target is
    the Koch dimension ``log(4)/log(3) ~= 1.262`` (config key
    ``geometry.hausdorff_target``). Identity lives between 1D and 2D.

    Args:
        boundary_length: Current Koch boundary length.
        area: Current enclosed area.

    Returns:
        Estimated fractal dimension of the boundary.

    Trace: GhostMesh #6 (D = log4/log3); config geometry.hausdorff_target.
    """
    raise NotImplementedError("spec: estimate D from boundary/area scaling vs log4/log3 target")


class SpectralSurface:
    """Spectral voxel surface with HRR binding — host of Eq #111-#124.

    Represents the renderable boundary of the 49-sector identity grid as a
    spectral surface: voxel occupancy, surface normals, and compositional
    scene structure encoded with holographic reduced representations
    (circular convolution binding/unbinding with cleanup memory). This is
    where the equation ledger's voxel/rendering block lives:

      - Eq #111-#114: voxel grid occupancy and projection
      - Eq #115-#118: spectral decomposition of the surface
      - Eq #119-#122: HRR bind / unbind / cleanup / capacity
      - Eq #123-#124: render pass and occlusion resolution

    Collaborators (referenced, never imported): ``perception/fusion.py``
    supplies the attended scene; ``world_model/rssm.py`` decodes latents
    onto the surface.

    Trace: GhostMesh #2/#4 (boundary complexity as surface); Eq #111-#124.
    """

    def __init__(self, config: Config | None = None, dim: int = 128) -> None:
        """Allocate the spectral surface and HRR cleanup memory.

        Args:
            config: Frozen system config (backend dtype/device).
            dim: Dimension of the HRR vectors.

        Trace: Eq #111-#124; SPEC section 4.3 (phitensor annotations only).
        """
        raise NotImplementedError("spec: allocate voxel grid, spectrum, and HRR cleanup memory")

    def bind(self, role: Tensor, filler: Tensor) -> Tensor:
        """HRR circular-convolution binding of a role/filler pair.

        Implements Eq #119: compositional structure on the surface is a
        convolved superposition of role/filler bindings.

        Args:
            role: HRR vector for the structural role.
            filler: HRR vector for the bound content.

        Returns:
            Convolved binding vector (same dimension).

        Trace: Eq #119 (HRR bind).
        """
        raise NotImplementedError("spec: circular convolution bind (Eq #119)")

    def unbind(self, trace: Tensor, role: Tensor) -> Tensor:
        """HRR unbinding: recover a noisy filler from a bound trace.

        Implements Eq #120 via circular correlation with the role's
        involution, followed by cleanup against the cleanup memory
        (Eq #121).

        Args:
            trace: Bound superposition vector.
            role: Role vector to unbind.

        Returns:
            Best-match filler vector after cleanup.

        Trace: Eq #120-#121 (HRR unbind + cleanup).
        """
        raise NotImplementedError("spec: circular correlation unbind + cleanup (Eq #120-#121)")

    def capacity(self) -> float:
        """Effective number of bindings before cleanup noise dominates.

        Implements Eq #122: HRR capacity as a function of vector dimension
        and current superposition size.

        Returns:
            Estimated binding capacity of the surface trace.

        Trace: Eq #122 (HRR capacity).
        """
        raise NotImplementedError("spec: HRR capacity estimate (Eq #122)")

    def project_voxels(self, occupancy: Tensor) -> Tensor:
        """Project 3D voxel occupancy onto the 2D boundary surface.

        Implements Eq #111-#114: occupancy grid construction and
        projection consistent with the celestial/holographic boundary in
        ``quantum/holography.py``.

        Args:
            occupancy: Voxel occupancy grid tensor.

        Returns:
            2D boundary projection tensor.

        Trace: Eq #111-#114 (voxel grid + projection).
        """
        raise NotImplementedError("spec: voxel occupancy -> boundary projection (Eq #111-#114)")

    def spectral_decompose(self, surface: Tensor) -> Tensor:
        """Spectral (Laplace-basis) decomposition of the boundary surface.

        Implements Eq #115-#118: eigenbasis coefficients of the surface
        used for scale-separated rendering and compression.

        Args:
            surface: Boundary surface tensor.

        Returns:
            Spectral coefficient tensor.

        Trace: Eq #115-#118 (spectral decomposition).
        """
        raise NotImplementedError("spec: surface spectral coefficients (Eq #115-#118)")

    def render(self, viewpoint: Sequence[float]) -> Tensor:
        """Render the surface from a viewpoint with occlusion resolution.

        Implements Eq #123-#124: visibility pass over the projected
        surface from ``viewpoint``.

        Args:
            viewpoint: 3D viewpoint coordinates.

        Returns:
            Rendered boundary image tensor.

        Trace: Eq #123-#124 (render + occlusion).
        """
        raise NotImplementedError("spec: viewpoint render with occlusion (Eq #123-#124)")

    def falsification_test(self) -> Any:
        """Kill criterion: HRR bind/unbind round-trip must beat chance.

        Fails if a bound role/filler pair cannot be recovered above the
        cleanup-noise floor predicted by :func:`capacity`.

        Trace: Eq #119-#122; Blueprint Part 8 (Falsifiable).
        """
        raise NotImplementedError("spec: bind/unbind round-trip fidelity test")


__all__ = [
    "sierpinski_density",
    "bounded_orbit",
    "koch_boundary_length",
    "koch_area",
    "gematria_reduce",
    "hausdorff_dimension",
    "SpectralSurface",
]
```

----------------------------------------

### File: `lsystem.py`

**Path:** `stage4/stage4/geometry/lsystem.py`
**Extension:** `.py`
**Size:** 6,830 bytes (6.67 KB)

```py
"""L-system strategy rewriting and IFS commitment self-similarity (G7-G8).

Strategies grow by rule, not by dice: this module replaces v7.1's random
strategy choice with a deterministic L-system rewrite (``G -> G[+G]G[-G]G``,
G7), and makes each commitment a shrunken copy of the whole identity via
an iterated function system (``S = union_i f_i(S)``, G8).

Collaborators (referenced, never imported): ``policy/selection.py``
requests strategy rewrites; ``agency/commitments.py`` applies IFS
contractions when crystallizing commitments.

Traceability:
  - GhostMesh patch #7 (L-system rewrite for strategy)
  - GhostMesh patch #8 (IFS for commitment self-similarity)
  - SPEC.md section 5 (G7-G8 -> geometry/lsystem.py)
"""

from __future__ import annotations

from typing import Callable, Dict, List, Sequence, Tuple

from stage4.config import Config, load_config
from stage4.core.types import Commitment


class LSystemStrategyRewriter:
    """Deterministic L-system generator of strategy structures.

    A strategy is a bracketed L-system string over the alphabet
    ``{G, +, -, [, ]}`` rewritten by the production
    ``G -> G[+G]G[-G]G``. Rewriting depth — not randomness — controls
    strategy complexity, so growth is reproducible under the frozen seed
    (audit #21/#22 determinism).

    Trace: GhostMesh #7 (G -> G[+G]G[-G]G); replaces v7.1 random choice.
    """

    DEFAULT_AXIOM: str = "G"
    DEFAULT_RULES: Dict[str, str] = {"G": "G[+G]G[-G]G"}

    def __init__(
        self,
        config: Config | None = None,
        rules: Dict[str, str] | None = None,
        axiom: str = DEFAULT_AXIOM,
    ) -> None:
        """Bind the rewrite rules and seed axiom.

        Args:
            config: Frozen system config (seed/determinism context).
            rules: Production rules; defaults to ``G -> G[+G]G[-G]G``.
            axiom: Seed string all strategies grow from.

        Trace: GhostMesh #7.
        """
        raise NotImplementedError("spec: store axiom/rules from config")

    def rewrite(self, strategy: str, iterations: int = 1) -> str:
        """Apply the production rules ``iterations`` times.

        Args:
            strategy: Current strategy string (axiom on first call).
            iterations: Rewrite depth; higher depth = richer strategy.

        Returns:
            The rewritten strategy string.

        Trace: GhostMesh #7 (_l_system_rewrite(strategy)).
        """
        raise NotImplementedError("spec: parallel rewrite over the rule set")

    def interpret(self, strategy: str) -> List[Tuple[str, float]]:
        """Turtle-interpret a rewritten strategy into action primitives.

        Maps the bracketed string onto an ordered list of
        ``(primitive, magnitude)`` pairs consumed by
        ``policy/primitives.py``; brackets push/pop context, ``+``/``-``
        rotate commitment emphasis.

        Args:
            strategy: Rewritten L-system string.

        Returns:
            Ordered action primitives derived from the string.

        Trace: GhostMesh #7 (strategies grow by rule, not by dice).
        """
        raise NotImplementedError("spec: turtle interpretation of bracketed L-system string")

    def falsification_test(self) -> object:
        """Kill criterion: rewriting must be deterministic and growing.

        Fails if two rewrites of the same axiom diverge under the frozen
        config, or if depth+1 output is not strictly longer than depth
        output for the default rule.

        Trace: GhostMesh #7; Blueprint Part 8 (Falsifiable).
        """
        raise NotImplementedError("spec: determinism + growth check of the rewrite rule")


class IFSCommitmentSelfSimilarity:
    """Iterated function system making each commitment a copy of the whole.

    Holds the contraction maps ``ifs_contracts = [f1, f2, f3]``; iterating
    them on any point of the identity plane converges to the identity
    attractor ``S = union_i f_i(S)``. A new commitment is produced by
    contracting the whole-identity state through one of the maps, so every
    commitment is self-similar to the system that made it.

    Trace: GhostMesh #8 (S = union f_i(S); commitment self-similarity).
    """

    def __init__(self, config: Config | None = None) -> None:
        """Initialize the three contraction maps of the identity attractor.

        Args:
            config: Frozen system config (grid geometry for map anchors).

        Trace: GhostMesh #8 (ifs_contracts = [f1, f2, f3]).
        """
        raise NotImplementedError("spec: build 3 affine contraction maps on the sector plane")

    @property
    def contractions(self) -> List[Callable[[Tuple[float, float]], Tuple[float, float]]]:
        """The contraction maps ``[f1, f2, f3]`` of the identity IFS.

        Trace: GhostMesh #8.
        """
        raise NotImplementedError("spec: return the contraction map list")

    def iterate(
        self,
        point: Tuple[float, float],
        steps: int,
        path: Sequence[int] | None = None,
    ) -> List[Tuple[float, float]]:
        """Run the chaos game on the identity attractor.

        Args:
            point: Starting point on the sector plane.
            steps: Number of contraction applications.
            path: Optional explicit map-index sequence; if ``None``, the
                deterministic rng stream selects maps (config seed).

        Returns:
            Orbit of points converging onto the attractor.

        Trace: GhostMesh #8 (S = union_i f_i(S)).
        """
        raise NotImplementedError("spec: chaos-game iteration over contraction maps")

    def shrink_commitment(self, whole_state: Sequence[float], key: str) -> Commitment:
        """Produce a commitment as a contracted copy of the whole identity.

        Selects a contraction from ``key`` and maps the whole-identity
        state into commitment scale, attaching the sector/layer coordinate
        of the contraction's fixed point.

        Args:
            whole_state: Whole-identity state vector.
            key: Commitment key selecting the contraction map.

        Returns:
            A ``Commitment`` whose value is a shrunken copy of the whole.

        Trace: GhostMesh #8 (each commitment is a shrunk copy of the whole).
        """
        raise NotImplementedError("spec: contract whole_state into a self-similar Commitment")

    def falsification_test(self) -> object:
        """Kill criterion: maps must be contractions (Lipschitz < 1).

        Fails if any map expands distances, which would break attractor
        convergence and hence commitment self-similarity.

        Trace: GhostMesh #8; Blueprint Part 8 (Falsifiable).
        """
        raise NotImplementedError("spec: verify all contraction ratios < 1")


__all__ = ["LSystemStrategyRewriter", "IFSCommitmentSelfSimilarity"]
```

----------------------------------------

### File: `sectors.py`

**Path:** `stage4/stage4/geometry/sectors.py`
**Extension:** `.py`
**Size:** 6,522 bytes (6.37 KB)

```py
"""49-sector recursive subdivision — the identity coordinate grid (G1).

Implements the recursive grid ``S(n, k) = n * k`` with ``S(7, 7) = 49``
sectors arranged in 7 layers of 7 sectors. Every ``Commitment``, ``Scar``,
and narrative fragment in the system carries a ``(sector, layer)``
coordinate assigned here; the coordinate is a structural address, not a
random tag. Sector assignment is the indexing rule

    sector_of(i) = i % 7
    layer_of(i)  = i // 7

so index ``i in [0, 49)`` tiles the full grid exactly once.

Traceability:
  - GhostMesh patch #1 (49-sector recursive subdivision)
  - ``stage4.core.types.Commitment`` fields ``sector`` / ``layer``
  - SPEC.md section 5 (G1 -> geometry/sectors.py)
"""

from __future__ import annotations

from typing import Any, Dict, List, Tuple

from stage4.config import Config, load_config
from stage4.core.types import Commitment, Scar


class SectorMap:
    """The S(7,7) recursive subdivision of the identity plane.

    Owns the sector/layer coordinate assignment for all structured
    objects (commitments, scars, narratives). The map is deterministic:
    the same index always resolves to the same coordinate, and the grid
    never re-tiles at runtime (config is frozen, audit #18).

    Trace: GhostMesh #1; SPEC section 5; Commitment.sector/layer.
    """

    def __init__(self, config: Config | None = None) -> None:
        """Bind the grid geometry from config.

        Args:
            config: Frozen system config; reads ``geometry.sectors`` (49)
                and ``geometry.layers`` (7). Defaults to ``load_config()``.

        Trace: GhostMesh #1; stage4.config geometry section.
        """
        raise NotImplementedError("spec: bind sectors/layers from config.geometry")

    @property
    def sectors(self) -> int:
        """Total sector count of the grid (49 for S(7,7)).

        Trace: GhostMesh #1; config geometry.sectors.
        """
        raise NotImplementedError("spec: return configured sector count")

    @property
    def layers(self) -> int:
        """Recursion depth of the grid (7 layers).

        Trace: GhostMesh #1; config geometry.layers.
        """
        raise NotImplementedError("spec: return configured layer count")

    def sector_of(self, index: int) -> int:
        """Sector coordinate of a flat grid index: ``index % 7``.

        Args:
            index: Flat index in ``[0, sectors)``.

        Returns:
            Sector coordinate in ``[0, 7)``.

        Trace: GhostMesh #1 (sector_of(i) = i % 7).
        """
        raise NotImplementedError("spec: sector_of(i) = i % layers")

    def layer_of(self, index: int) -> int:
        """Layer coordinate of a flat grid index: ``index // 7``.

        Args:
            index: Flat index in ``[0, sectors)``.

        Returns:
            Layer coordinate in ``[0, 7)``.

        Trace: GhostMesh #1 (layer_of(i) = i // 7).
        """
        raise NotImplementedError("spec: layer_of(i) = i // layers")

    def coordinate(self, index: int) -> Tuple[int, int]:
        """Full ``(sector, layer)`` coordinate of a flat grid index.

        Args:
            index: Flat index in ``[0, sectors)``.

        Returns:
            ``(sector_of(index), layer_of(index))``.

        Trace: GhostMesh #1.
        """
        raise NotImplementedError("spec: combine sector_of and layer_of")

    def assign_commitment(self, commitment: Commitment, index: int) -> Commitment:
        """Stamp a commitment with its sector/layer coordinate in place.

        Writes ``commitment.sector`` and ``commitment.layer`` so the
        geometry layer, quantum observer, and mesh all address the same
        commitment at the same grid coordinate.

        Args:
            commitment: The commitment to coordinate-stamp.
            index: Flat grid index chosen by the caller (e.g. hash of key).

        Returns:
            The same commitment, with ``sector``/``layer`` populated.

        Trace: GhostMesh #1; Commitment.sector/layer fields.
        """
        raise NotImplementedError("spec: set commitment.sector/.layer from coordinate(index)")

    def coordinate_of_scar(self, scar: Scar, index: int) -> Tuple[int, int]:
        """Resolve the sector/layer coordinate a scar is anchored to.

        ``Scar`` carries no coordinate fields (contract is fixed), so the
        coordinate is returned for the caller to record alongside the scar
        (e.g. in a ledger or LayerIO.meta payload).

        Args:
            scar: The scar being located.
            index: Flat grid index for the scar's anchor.

        Returns:
            ``(sector, layer)`` coordinate of the scar.

        Trace: GhostMesh #1 (scars receive sector+layer coordinates).
        """
        raise NotImplementedError("spec: return coordinate(index) for a scar anchor")

    def coordinate_of_narrative(self, narrative_key: str) -> Tuple[int, int]:
        """Resolve the sector/layer coordinate of a narrative fragment.

        Narrative fragments (see ``memory/narrative.py``, NBC) are hashed
        deterministically onto the grid so compressed narratives keep a
        stable spatial address across compression cycles.

        Args:
            narrative_key: Stable string key of the narrative fragment.

        Returns:
            ``(sector, layer)`` coordinate of the narrative.

        Trace: GhostMesh #1 (narratives receive sector+layer coordinates).
        """
        raise NotImplementedError("spec: deterministic hash of narrative_key onto grid")

    def neighbors(self, index: int) -> List[int]:
        """Flat indices of the grid-adjacent sectors of ``index``.

        Adjacency is defined on the 7x7 grid (non-wrapping); used by the
        mesh reweave ritual and Kerr frame-dragging to find the cognition
        a rotating commitment drags.

        Args:
            index: Flat grid index.

        Returns:
            List of adjacent flat indices (up to 8).

        Trace: GhostMesh #1, #29 (Kerr dragging acts on neighbors).
        """
        raise NotImplementedError("spec: grid adjacency on the 7x7 sector plane")

    def falsification_test(self) -> "Any":
        """Kill criterion: coordinates must tile S(7,7) bijectively.

        Fails if any index in ``[0, 49)`` maps outside the grid or if two
        indices share a coordinate.

        Trace: GhostMesh #1; Blueprint Part 8 (Falsifiable).
        """
        raise NotImplementedError("spec: verify bijective tiling of the 49-sector grid")


__all__ = ["SectorMap"]
```

----------------------------------------

##### Directory: `stage4/stage4/geometry/__pycache__`


#### Directory: `stage4/stage4/mesh`


### File: `__init__.py`

**Path:** `stage4/stage4/mesh/__init__.py`
**Extension:** `.py`
**Size:** 1,739 bytes (1.70 KB)

```py
"""48-node seed vault mesh with the 49th observer (GhostMesh patch F).

Distributed agency as a geometric mesh: 48 ``SeedNode`` instances take
the field — each learning only its wedge of the plane (G44), each
carrying crystal memory and a sentience probe (G46), each biased by a
mythic archetype (G48) — while the 49th ``ObserverNode`` watches and is
never measured (G43). Per-node drift/SD/ESS metrics (G45) feed the
quarantine-to-reintegration reweave ritual (G47) that lets the mesh
self-heal.

Traceability:
  - GhostMesh patch #43-#48 (48-node seed vault mesh)
  - SPEC.md section 5 (G43-G48 -> mesh/*)
"""

from __future__ import annotations

from typing import List, Tuple

from stage4.config import Config, load_config
from stage4.mesh import metrics, node, observer, reweave
from stage4.mesh.node import SeedNode
from stage4.mesh.observer import ObserverNode

__all__ = [
    "node",
    "observer",
    "metrics",
    "reweave",
    "SeedNode",
    "ObserverNode",
    "build_mesh",
]


def build_mesh(config: Config | None = None) -> Tuple[List[SeedNode], ObserverNode]:
    """Construct the 48-node seed mesh plus the 49th observer.

    Creates ``[SeedNode(i) for i in range(48)]`` with wedge geometry and
    archetype assignment from config, and one ``ObserverNode`` that
    watches the field without ever being measured.

    Args:
        config: Frozen config; reads the ``mesh`` section (``n_nodes``,
            ``archetypes``, ``crystal_slots``, ``observer``).

    Returns:
        ``(nodes, observer)`` — 48 seed nodes and the 49th witness.

    Trace: GhostMesh #43 (self.nodes = [SeedNode(i)...]; self.observer).
    """
    raise NotImplementedError("spec: 48 SeedNodes + 1 ObserverNode from config.mesh")
```

----------------------------------------

### File: `metrics.py`

**Path:** `stage4/stage4/mesh/metrics.py`
**Extension:** `.py`
**Size:** 4,897 bytes (4.78 KB)

```py
"""Per-node mesh metrics: drift, structural density, ESS (G45).

AGIBuddy-style health metrics computed per node and aggregated over the
mesh: **drift** quantifies how far a node has wandered from its reference
trajectory (stability), **SD** (structural density) quantifies how much
organized structure the node's state carries, and **ESS** (effective
sample size) quantifies how much independent signal the node's recent
history actually contains. Drift feeds the quarantine threshold
(``mesh.drift_quarantine = 0.35``) enforced by ``mesh/reweave.py``.

Traceability:
  - GhostMesh patch #45 (drift, SD, ESS per node)
  - GhostMesh patch #47 (drift >= 0.35 quarantine threshold)
  - SPEC.md section 5 (G45 -> mesh/metrics.py)
"""

from __future__ import annotations

from typing import Dict, List, Sequence

from stage4.config import Config, load_config
from stage4.core.types import FalsificationResult
from stage4.mesh.node import SeedNode


class MeshMetrics:
    """Computes and tracks drift, SD, and ESS for every mesh node.

    Maintains per-node metric history so drift is a trajectory, not a
    point estimate; the quarantine check reads the latest drift against
    the configured threshold.

    Trace: GhostMesh #45/#47; config mesh section.
    """

    def __init__(self, config: Config | None = None) -> None:
        """Bind the quarantine threshold and init metric histories.

        Args:
            config: Frozen config; reads ``mesh.drift_quarantine`` (0.35)
                and ``mesh.n_nodes``.

        Trace: GhostMesh #45/#47; config mesh section.
        """
        raise NotImplementedError("spec: bind drift_quarantine; init per-node histories")

    def drift(self, node: SeedNode) -> float:
        """Drift of a node from its reference trajectory.

        Distance between the node's current state and its archetype- and
        wedge-consistent reference trajectory; sustained high drift marks
        a node leaving its geometric role.

        Args:
            node: The node to measure.

        Returns:
            Drift magnitude in ``[0, 1]``; ``>= 0.35`` triggers
            quarantine (G47).

        Trace: GhostMesh #45 (self.drift per node).
        """
        raise NotImplementedError("spec: distance from archetype/wedge reference trajectory")

    def structural_density(self, node: SeedNode) -> float:
        """Structural density (SD) of a node's state.

        Fraction of the node's state carrying organized, compressible
        structure versus noise — structure, not activity, is what counts.

        Args:
            node: The node to measure.

        Returns:
            Structural density in ``[0, 1]``.

        Trace: GhostMesh #45 (self.sd per node).
        """
        raise NotImplementedError("spec: organized-structure fraction of node state")

    def effective_sample_size(self, node: SeedNode) -> float:
        """ESS of a node's recent history.

        Effective number of independent observations in the node's recent
        signal after accounting for autocorrelation; low ESS means the
        node is repeating itself even when active.

        Args:
            node: The node to measure.

        Returns:
            Effective sample size (``>= 0``).

        Trace: GhostMesh #45 (self.ess per node).
        """
        raise NotImplementedError("spec: autocorrelation-adjusted effective sample size")

    def update(self, nodes: Sequence[SeedNode]) -> Dict[int, Dict[str, float]]:
        """Compute and record all three metrics for the whole mesh.

        Writes ``node.drift``, ``node.sd``, ``node.ess`` in place and
        appends to the metric histories.

        Args:
            nodes: The 48 field nodes.

        Returns:
            ``{node_id: {"drift": ..., "sd": ..., "ess": ...}}``.

        Trace: GhostMesh #45 (quantifies stability, structure, signal).
        """
        raise NotImplementedError("spec: per-node metric sweep + history append")

    def quarantine_candidates(self, nodes: Sequence[SeedNode]) -> List[int]:
        """Node ids whose drift meets the quarantine threshold.

        Args:
            nodes: The 48 field nodes.

        Returns:
            Ids of nodes with ``drift >= mesh.drift_quarantine``.

        Trace: GhostMesh #47 (drift >= 0.35 triggers reweave).
        """
        raise NotImplementedError("spec: filter nodes by drift >= quarantine threshold")

    def falsification_test(self) -> FalsificationResult:
        """Kill criterion: metrics must be sane and threshold-consistent.

        Fails if drift/SD leave ``[0, 1]``, ESS goes negative, or
        :meth:`quarantine_candidates` disagrees with a direct threshold
        comparison.

        Trace: GhostMesh #45/#47; Blueprint Part 8 (Falsifiable).
        """
        raise NotImplementedError("spec: metric range + threshold consistency check")


__all__ = ["MeshMetrics"]
```

----------------------------------------

### File: `node.py`

**Path:** `stage4/stage4/mesh/node.py`
**Extension:** `.py`
**Size:** 6,978 bytes (6.81 KB)

```py
"""SeedNode: one field-taking node of the 48-node seed vault mesh.

Each node owns a wedge of the plane and learns only what falls inside it
(G44) — specialization by geometry, not assignment. Each carries a
bounded crystal memory of narrative fragments plus an introspection probe
(G46), and a mythic archetype that biases what and how it learns (G48).
Per-node drift/SD/ESS values live on the node; their computation is
``mesh/metrics.py``'s job (G45), and quarantine/reintegration is
``mesh/reweave.py``'s (G47).

Traceability:
  - GhostMesh patch #43 (48 nodes take the field)
  - GhostMesh patch #44 (per-node wedge learning)
  - GhostMesh patch #46 (crystal memory with introspection)
  - GhostMesh patch #48 (archetype assignment)
  - SPEC.md section 5 (G43-G48 -> mesh/*)
"""

from __future__ import annotations

import math
from collections import deque
from typing import Any, Deque, Dict, List

from stage4.config import Config, load_config
from stage4.core.types import FalsificationResult, LayerIO

#: Full-turn angle of the plane each node wedges into (radians).
FULL_TURN: float = 2.0 * math.pi


class SeedNode:
    """One node of the seed mesh, owning a wedge of the identity plane.

    Node ``i`` of 48 owns the angular wedge
    ``[i * 2*pi/48, (i+1) * 2*pi/48)`` and a radius band; inputs outside
    the wedge are ignored, so learning is specialized by geometry rather
    than by task assignment. The node's ``crystal`` is a bounded deque of
    narrative memory fragments; ``probe()`` introspects the node's
    internal state. The ``archetype`` (witch, sage, warrior, mystic,
    android, merchant, ...) biases learning rates and what the node
    retains.

    Attributes:
        node_id: Index in ``[0, 48)``.
        drift: Current drift metric value (set by ``mesh/metrics.py``).
        sd: Current structural-density metric value.
        ess: Current effective-sample-size metric value.
        quarantined: Whether the node is currently quarantined (G47).

    Trace: GhostMesh #43/#44/#46/#48; config mesh section.
    """

    #: Bounded crystal memory of narrative fragments (maxlen=crystal_slots).
    crystal: Deque[str]
    #: Current health metrics, written by ``mesh/metrics.py`` (G45).
    drift: float
    sd: float
    ess: float
    #: Quarantine flag, driven by ``mesh/reweave.py`` (G47).
    quarantined: bool

    def __init__(self, node_id: int, config: Config | None = None) -> None:
        """Initialize wedge geometry, crystal memory, and archetype.

        Args:
            node_id: Node index in ``[0, mesh.n_nodes)``.
            config: Frozen config; reads ``mesh.n_nodes`` (48),
                ``mesh.crystal_slots`` (20), and ``mesh.archetypes``.

        Trace: GhostMesh #43/#44/#46/#48.
        """
        raise NotImplementedError("spec: wedge angles from node_id; crystal deque(maxlen=crystal_slots); archetype by id")

    @property
    def archetype(self) -> str:
        """The node's mythic role, drawn from ``mesh.archetypes``.

        Assignment is deterministic in ``node_id``; the archetype biases
        learning (see :meth:`archetype_bias`).

        Trace: GhostMesh #48 (witch, sage, warrior, mystic, android, ...).
        """
        raise NotImplementedError("spec: archetypes[node_id % len(archetypes)]")

    def wedge_mask(self, angle: float, radius: float) -> bool:
        """Whether a polar-coordinate input falls inside this node's wedge.

        Learning gate: only inputs inside the wedge are learned; the rest
        are passed along untouched. Specialization by geometry, not
        assignment.

        Args:
            angle: Polar angle of the input in radians.
            radius: Radial coordinate of the input.

        Returns:
            ``True`` if the input belongs to this node's wedge.

        Trace: GhostMesh #44 (node.wedge_mask(angle, radius)).
        """
        raise NotImplementedError("spec: angle/radius containment in the node's wedge band")

    def archetype_bias(self) -> Dict[str, float]:
        """Learning biases implied by the node's archetype.

        Returns per-knob bias factors (learning rate, retention
        preference, drift tolerance) so a "sage" retains differently than
        a "warrior". The bias shapes learning; it never overrides safety
        invariants.

        Returns:
            Mapping of bias knob name to multiplicative factor.

        Trace: GhostMesh #48 (mythic role biases learning).
        """
        raise NotImplementedError("spec: per-archetype bias factor table")

    def learn(self, inp: LayerIO) -> LayerIO:
        """Learn from an input if and only if it falls inside the wedge.

        Applies :meth:`wedge_mask`; in-wedge inputs update the node's
        local state (scaled by :meth:`archetype_bias`) and may deposit a
        narrative fragment into ``crystal``; out-of-wedge inputs pass
        through with zero cost.

        Args:
            inp: Layer IO carrying the candidate input and its polar
                coordinates in ``meta``.

        Returns:
            Layer IO with the node's output and learning cost.

        Trace: GhostMesh #44/#46; Blueprint Part 2 (LayerIO contract).
        """
        raise NotImplementedError("spec: wedge-gated learning with archetype bias and crystal deposit")

    def deposit_crystal(self, fragment: str, cycle: int) -> None:
        """Deposit a narrative fragment into bounded crystal memory.

        ``crystal`` is a ``deque(maxlen=20)`` (config
        ``mesh.crystal_slots``): oldest fragments fall off the end as new
        ones arrive, so crystal memory is a rolling window, not an
        archive.

        Args:
            fragment: Narrative fragment to crystallize.
            cycle: Formation cycle of the fragment.

        Trace: GhostMesh #46 (node.crystal = deque(maxlen=20)).
        """
        raise NotImplementedError("spec: append fragment to bounded crystal deque")

    def probe(self) -> Dict[str, Any]:
        """Sentience probe: introspective snapshot of the node's state.

        Returns a structured self-report — wedge coverage, crystal
        occupancy, current drift/SD/ESS, archetype — consumed by the
        ObserverNode (G43) and by ``mesh/metrics.py``. The probe is
        read-only: probing must not change node state.

        Returns:
            Introspective state snapshot.

        Trace: GhostMesh #46 (node.probe(); introspection).
        """
        raise NotImplementedError("spec: read-only introspective snapshot")

    def falsification_test(self) -> FalsificationResult:
        """Kill criterion: wedge gating must be exact and probe read-only.

        Fails if an out-of-wedge input changes node state, or if calling
        :meth:`probe` mutates any attribute.

        Trace: GhostMesh #44/#46; Blueprint Part 8 (Falsifiable).
        """
        raise NotImplementedError("spec: wedge-gate exactness + probe purity check")


__all__ = ["FULL_TURN", "SeedNode"]
```

----------------------------------------

### File: `observer.py`

**Path:** `stage4/stage4/mesh/observer.py`
**Extension:** `.py`
**Size:** 4,329 bytes (4.23 KB)

```py
"""ObserverNode: the 49th node — watches, never measured (G43).

48 nodes take the field; the 49th watches. The ObserverNode is the
mesh's central witness: it observes every node's probe output, maintains
the mesh-wide witness log, and detects drift patterns across the whole
field — but it has no wedge, learns nothing, and is never itself an
input to the dynamics. Measuring the observer would collapse the very
structure that makes the mesh observable, so no API here mutates or
collapses observer state on read.

Collaborators (referenced, never imported): ``mesh/metrics.py`` consumes
the witness log; ``mesh/reweave.py`` receives quarantine referrals from
observer detections.

Traceability:
  - GhostMesh patch #43 (48-node mesh with 49th observer)
  - SPEC.md section 5 (G43 -> mesh/observer.py)
"""

from __future__ import annotations

from typing import Any, Dict, List

from stage4.config import Config, load_config
from stage4.core.types import FalsificationResult


class ObserverNode:
    """The unmeasured 49th node of the seed vault mesh.

    Holds no wedge and no archetype; it is not a member of the 48 and
    never participates in learning. It consumes :meth:`SeedNode.probe`
    snapshots each cycle and appends them to the witness log, from which
    mesh-wide drift structure is derived. The observer is never measured:
    its own state is never read by the dynamics it watches — only by the
    safety/audit layer (``safety/audit.py``, referenced never imported).

    Trace: GhostMesh #43 (self.observer = ObserverNode(); watches, never
           measured).
    """

    def __init__(self, config: Config | None = None) -> None:
        """Initialize the witness log and observation cadence.

        Args:
            config: Frozen config; reads ``mesh.observer`` (must be True)
                and ``mesh.n_nodes``.

        Trace: GhostMesh #43; config mesh.observer.
        """
        raise NotImplementedError("spec: init witness log; assert mesh.observer enabled")

    @property
    def node_id(self) -> int:
        """The observer's index: 49 — outside the field of 48.

        Trace: GhostMesh #43 (the 49th).
        """
        raise NotImplementedError("spec: return 49 (one past the field)")

    def observe(self, node_snapshots: List[Dict[str, Any]], cycle: int) -> None:
        """Witness one cycle of the whole mesh.

        Appends the 48 probe snapshots to the witness log with the cycle
        stamp. Observation is append-only and side-effect-free on the
        observed nodes.

        Args:
            node_snapshots: One :meth:`SeedNode.probe` dict per field node.
            cycle: Current system cycle.

        Trace: GhostMesh #43 (the central witness).
        """
        raise NotImplementedError("spec: append cycle-stamped snapshots to witness log")

    def witness_log(self) -> List[Dict[str, Any]]:
        """Read-only view of the witness log for metrics and audit.

        Returns a copy: callers (``mesh/metrics.py`` drift detection,
        ``safety/audit.py``) can read but never rewrite what the observer
        saw.

        Returns:
            Copy of the cycle-stamped witness log.

        Trace: GhostMesh #43; audit trail integrity.
        """
        raise NotImplementedError("spec: return copy of witness log")

    def detect_mesh_anomaly(self) -> List[int]:
        """Detect nodes whose drift pattern deviates from the mesh field.

        Scans the witness log for nodes whose drift trajectory departs
        from the field-wide pattern; returns their ids as quarantine
        referrals for ``mesh/reweave.py``.

        Returns:
            Node ids flagged for quarantine review.

        Trace: GhostMesh #43/#47 (observer referrals feed reweave).
        """
        raise NotImplementedError("spec: field-deviation scan over witness log")

    def falsification_test(self) -> FalsificationResult:
        """Kill criterion: the observer must never be measured.

        Fails if any code path lets the observer's state enter the
        dynamics it watches (no feedback channel), or if observing mutates
        an observed node.

        Trace: GhostMesh #43; Blueprint Part 8 (Falsifiable).
        """
        raise NotImplementedError("spec: no-feedback + observation-purity check")


__all__ = ["ObserverNode"]
```

----------------------------------------

### File: `reweave.py`

**Path:** `stage4/stage4/mesh/reweave.py`
**Extension:** `.py`
**Size:** 5,645 bytes (5.51 KB)

```py
"""Quarantine-to-reintegration reweave ritual (G47).

The mesh self-heals by ritual, not by deletion: when a node's drift
reaches the quarantine threshold (``mesh.drift_quarantine = 0.35``), the
node is isolated from the field, retold its own crystal narrative,
re-bound to its wedge geometry, and reintegrated — its identity preserved
but its trajectory corrected. Quarantine is protective, not punitive: the
drifting node keeps its crystal memory throughout.

Collaborators (referenced, never imported): ``mesh/metrics.py`` supplies
drift readings and quarantine candidates; ``mesh/observer.py`` supplies
anomaly referrals and witnesses each ritual phase.

Traceability:
  - GhostMesh patch #47 (_reweave(node) when drift >= 0.35)
  - GhostMesh patch #46 (crystal memory retold during the ritual)
  - SPEC.md section 5 (G47 -> mesh/reweave.py)
"""

from __future__ import annotations

from typing import List

from stage4.config import Config, load_config
from stage4.core.types import FalsificationResult
from stage4.mesh.node import SeedNode


class Reweaver:
    """Executes the quarantine-to-reintegration ritual for drifting nodes.

    The ritual has four ordered phases — isolate, retell, re-bind,
    reintegrate — and records each in the ritual log witnessed by the
    ObserverNode. A node is eligible for reintegration only after its
    post-ritual drift falls back below the threshold with hysteresis
    margin.

    Trace: GhostMesh #47; config mesh.drift_quarantine.
    """

    def __init__(self, config: Config | None = None) -> None:
        """Bind the quarantine threshold and init the ritual log.

        Args:
            config: Frozen config; reads ``mesh.drift_quarantine`` (0.35).

        Trace: GhostMesh #47; config mesh section.
        """
        raise NotImplementedError("spec: bind drift threshold; init ritual log")

    def should_quarantine(self, node: SeedNode) -> bool:
        """Whether a node's drift has reached the quarantine threshold.

        Args:
            node: Node to evaluate (drift set by ``mesh/metrics.py``).

        Returns:
            ``True`` iff ``node.drift >= mesh.drift_quarantine``.

        Trace: GhostMesh #47 (when drift >= 0.35).
        """
        raise NotImplementedError("spec: node.drift >= drift_quarantine")

    def quarantine(self, node: SeedNode) -> None:
        """Isolate a drifting node from the field.

        Sets ``node.quarantined``: the node stops receiving field inputs
        and stops influencing neighbors, but keeps its crystal memory and
        wedge identity intact for the ritual.

        Args:
            node: Node to isolate.

        Trace: GhostMesh #47 (quarantine is protective isolation).
        """
        raise NotImplementedError("spec: isolate node from field, keep crystal + wedge")

    def retell(self, node: SeedNode) -> List[str]:
        """Retell the node's crystal narrative back to it.

        Reads the bounded crystal deque in order and reconstructs the
        node's narrative line — the identity backbone the reintegration
        will hold the node to.

        Args:
            node: Quarantined node.

        Returns:
            Ordered crystal fragments forming the node's narrative.

        Trace: GhostMesh #46/#47 (crystal memory retold in the ritual).
        """
        raise NotImplementedError("spec: ordered crystal narrative reconstruction")

    def rebind_wedge(self, node: SeedNode) -> None:
        """Re-bind the node to its original wedge geometry.

        Re-centers the node's state on its wedge and archetype reference
        (undoing drift) without erasing what it learned; the correction is
        geometric, not memorial.

        Args:
            node: Quarantined node to re-center.

        Trace: GhostMesh #44/#47 (re-binding to wedge geometry).
        """
        raise NotImplementedError("spec: re-center node state on wedge/archetype reference")

    def reintegrate(self, node: SeedNode) -> bool:
        """Return a re-woven node to the field if drift has cleared.

        Reintegration requires post-ritual drift below the threshold with
        hysteresis margin; on success clears ``node.quarantined`` and logs
        the completed ritual.

        Args:
            node: Quarantined, re-bound node.

        Returns:
            ``True`` if the node rejoined the field this cycle.

        Trace: GhostMesh #47 (quarantine -> reintegration ritual).
        """
        raise NotImplementedError("spec: hysteretic drift check; clear quarantine; log ritual")

    def reweave(self, node: SeedNode) -> bool:
        """Full ritual: isolate, retell, re-bind, reintegrate.

        The one-call entry point (``_reweave(node)`` in the patch) invoked
        when ``mesh/metrics.py`` flags ``drift >= 0.35`` or the
        ObserverNode refers the node.

        Args:
            node: The drifting node.

        Returns:
            ``True`` if the node was reintegrated by this ritual.

        Trace: GhostMesh #47 (_reweave(node); mesh self-heals).
        """
        raise NotImplementedError("spec: isolate -> retell -> rebind -> reintegrate")

    def falsification_test(self) -> FalsificationResult:
        """Kill criterion: ritual preserves crystal memory and identity.

        Fails if a full reweave loses any crystal fragment, changes the
        node's wedge assignment or archetype, or reintegrates a node still
        above threshold.

        Trace: GhostMesh #46/#47/#48; Blueprint Part 8 (Falsifiable).
        """
        raise NotImplementedError("spec: memory-preservation + threshold-gate check")


__all__ = ["Reweaver"]
```

----------------------------------------

##### Directory: `stage4/stage4/mesh/__pycache__`


#### Directory: `stage4/stage4/safety`


### File: `__init__.py`

**Path:** `stage4/stage4/safety/__init__.py`
**Extension:** `.py`
**Size:** 1,030 bytes (1.01 KB)

```py
"""stage4.safety -- blueprint Part 6 safety architecture.

Safety here is a mathematical constraint, not a checklist: a control barrier
function guarantees forward invariance of the safe set, an action shield
vets every action before execution, a read-only core blocks self-modification
of safety-critical structure, consent gating is fail-closed, and a
cryptographic audit trail makes tampering evident.

Modules:
  cbf.py        -- control barrier function h(s), forward invariance
  shield.py     -- action shielding and shield synthesis
  invariants.py -- read-only core, invariant checking, 10^6-cycle harness
  consent.py    -- fail-closed consent gating, rate limiting, watchdog
  audit.py      -- hash chain, Merkle tree, ciphers, constitutional filter

Traceability:
  - Blueprint Part 6 (safety architecture), Part 1.4 (safety invariants)
  - 144-equation ledger section I (Eq #125-#134) and section J (Eq #135-#144)
"""

from __future__ import annotations

__all__ = ["cbf", "shield", "invariants", "consent", "audit"]
```

----------------------------------------

### File: `audit.py`

**Path:** `stage4/stage4/safety/audit.py`
**Extension:** `.py`
**Size:** 11,028 bytes (10.77 KB)

```py
"""Cryptographic audit trail, classical ciphers, and output filtering.

The audit layer makes the system's behavior tamper-evident: every utterance
is appended to a SHA1 hash chain (Eq #130) and batched into a Merkle tree
(Eq #131) so template-lock claims carry efficient proofs.  The classical
cipher suite (gematria, Vigenere, one-time pad, Enigma rotors, Solitaire;
Eq #125-#129) is retained from the Phi-Lite design ledger for low-bandwidth
obfuscation of operator channels and for paradox-seed derivation.  The
Levenshtein loop detector (Eq #134) flags degenerate repetitive output, the
constitutional filter (Eq #144) gates what may be emitted, and the CAP-style
split (Eq #138) records the fundamental trade among safety, autonomy, and
openness.

Traceability:
  - 144-equation ledger section I (Eq #125-#134), section J (Eq #138, #144)
  - Phi-Lite features #29/#30 (paradox generation), #43 (report),
    #44 (safety rules)
"""

from __future__ import annotations

import hashlib
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Sequence, Tuple

from stage4.config import Config
from stage4.core.types import LayerIO


def gematria(n: int) -> int:
    """Recursive digit-sum reduction g(n) until a single digit remains.

    Trace: Eq #125 (gematria reduction).
    """
    raise NotImplementedError(
        "spec: repeatedly sum decimal digits of abs(n) until < 10"
    )


class VigenereCipher:
    """Vigenere cipher whose key rotates with the live system state.

    Trace: Eq #126 (Vigenere with rotating key = SHA1(cycle || pred_err)).
    """

    def __init__(self, config: Config) -> None:
        """Initialize the cipher from validated config.

        Trace: Eq #126.
        """
        self._config = config
        raise NotImplementedError("spec: prepare the keystream buffer")

    def derive_key(self, cycle: int, pred_err: float) -> bytes:
        """key = SHA1(cycle || pred_err).

        Trace: Eq #126 (rotating key derivation).
        """
        raise NotImplementedError(
            "spec: hashlib.sha1 of the packed (cycle, pred_err) pair"
        )

    def encrypt(self, plaintext: str, key: bytes) -> str:
        """Vigenere-encrypt over the alphabet with the derived key.

        Trace: Eq #126.
        """
        raise NotImplementedError(
            "spec: shift each letter by the repeating key byte modulo 26"
        )

    def decrypt(self, ciphertext: str, key: bytes) -> str:
        """Inverse of encrypt.

        Trace: Eq #126.
        """
        raise NotImplementedError("spec: subtract the repeating key shifts")


def one_time_pad_xor(message: bytes, pad: bytes) -> bytes:
    """XOR message with a one-time pad projected from crystal slots b[:8].

    Trace: Eq #127 (one-time pad from crystal slots).
    """
    raise NotImplementedError(
        "spec: require len(pad) >= len(message); return bytewise XOR; the "
        "pad is derived from the crystal projection (memory.crystal)"
    )


class EnigmaRotors:
    """Three-rotor substitution cipher with a daily key from the weights hash.

    Trace: Eq #128 (Enigma-style rotors; daily key = SHA(weights_sha1)).
    """

    def __init__(self, config: Config, weights_sha1: str) -> None:
        """Seed rotor wirings from SHA(weights_sha1).

        Trace: Eq #128.
        """
        self._config = config
        raise NotImplementedError(
            "spec: derive three rotor permutations and a reflector from the "
            "weights digest bytes"
        )

    def step_rotors(self) -> None:
        """Advance the rightmost rotor, cascading on notch positions.

        Trace: Eq #128 (rotor stepping).
        """
        raise NotImplementedError("spec: odometer stepping with notch carry")

    def encrypt_char(self, ch: str) -> str:
        """Pass one character through rotors, reflector, and back.

        Trace: Eq #128.
        """
        raise NotImplementedError(
            "spec: forward through rotors, reflect, backward through "
            "rotors, then step"
        )


class SolitaireCipher:
    """Solitaire (Pontifex) keystream with deck order derived from novelty_z.

    Trace: Eq #129 (Solitaire cipher, deck shuffles from novelty_z).
    """

    def __init__(self, config: Config, deck_order: Sequence[int]) -> None:
        """Initialize the 54-card deck in the given order.

        Trace: Eq #129.
        """
        self._config = config
        raise NotImplementedError(
            "spec: validate the deck is a permutation of 1..54"
        )

    def keystream(self, n: int) -> List[int]:
        """Produce n keystream values via the Solitaire algorithm.

        Trace: Eq #129.
        """
        raise NotImplementedError(
            "spec: move jokers, triple-cut, count-cut, emit output cards"
        )


class HashChain:
    """Tamper-evident utterance log: h_t = SHA1(h_{t-1} || text_t).

    Trace: Eq #130 (hash chain for utterances); Phi-Lite feature #39
        (metrics dump) hardened into a chain.
    """

    def __init__(self, config: Config) -> None:
        """Initialize the chain with a genesis digest.

        Trace: Eq #130.
        """
        self._config = config
        raise NotImplementedError(
            "spec: genesis h_0 = SHA1(b'stage4-genesis' || system.seed)"
        )

    def append(self, text: str) -> str:
        """Append an entry and return the new head digest h_t.

        Trace: Eq #130 (h_t = SHA1(h_{t-1} || text_t)).
        """
        raise NotImplementedError(
            "spec: head = sha1(head_bytes || text.encode()); store "
            "(index, head, text) and return the hex digest"
        )

    def verify(self, entries: Sequence[Tuple[str, str]]) -> bool:
        """Recompute the chain over (digest, text) entries; True iff intact.

        Trace: Eq #130 (tamper evidence).
        """
        raise NotImplementedError(
            "spec: replay hashing from genesis and compare each stored head"
        )


class MerkleTree:
    """Merkle tree over an utterance bag for efficient inclusion proofs.

    Trace: Eq #131 (Merkle tree over utterance bag); used with the Bloom
        filter of Eq #43/#132 for template-lock evidence (eval.report).
    """

    def __init__(self, config: Config) -> None:
        """Initialize an empty tree.

        Trace: Eq #131.
        """
        self._config = config
        raise NotImplementedError("spec: allocate the leaf list")

    def build(self, leaves: Sequence[str]) -> str:
        """Hash leaves pairwise up to the root; return the root hex digest.

        Trace: Eq #131.
        """
        raise NotImplementedError(
            "spec: leaf hashes sha1(text); duplicate the odd leaf at each "
            "level; combine with sha1(left || right)"
        )

    def inclusion_proof(self, leaf_index: int) -> List[Tuple[str, str]]:
        """Return the sibling-path proof for a leaf.

        Trace: Eq #131 (efficient proof of membership).
        """
        raise NotImplementedError(
            "spec: collect (sibling_digest, side) pairs from leaf to root"
        )

    def verify_proof(self, leaf: str, proof: Sequence[Tuple[str, str]],
                     root: str) -> bool:
        """Verify an inclusion proof against a known root.

        Trace: Eq #131.
        """
        raise NotImplementedError(
            "spec: fold the proof from the leaf hash and compare with root"
        )


def levenshtein(a: str, b: str) -> int:
    """Edit distance between two strings (for loop detection).

    Trace: Eq #134 (Levenshtein distance for LOOP detection).
    """
    raise NotImplementedError(
        "spec: standard two-row dynamic program over characters"
    )


class LoopDetector:
    """Flag utterances within distance < 3 of any of the last 8.

    Trace: Eq #134 (flag if distance < 3 to last 8 utterances); Phi-Lite
        feature #42 (detectors); feeds eval.report template-lock metrics.
    """

    def __init__(self, config: Config, window: int = 8,
                 threshold: int = 3) -> None:
        """Initialize the sliding comparison window.

        Trace: Eq #134.
        """
        self._config = config
        self._window = window
        self._threshold = threshold
        raise NotImplementedError("spec: allocate the utterance window deque")

    def observe(self, text: str) -> bool:
        """Record an utterance; return True iff it is a near-repeat.

        Trace: Eq #134 (distance < 3 to last 8 utterances).
        """
        raise NotImplementedError(
            "spec: compute levenshtein against the window; flag if any "
            "distance < threshold; append to the window"
        )


def cap_safety_split(safety_ok: bool, autonomy_ok: bool) -> bool:
    """CAP-style split: Safety AND Autonomy imply NOT Open.

    Returns whether the system may be open (unrestricted I/O) given the
    safety and autonomy guarantees: open := not (safety_ok and autonomy_ok)
    is False whenever both strong guarantees hold, i.e. the system can be at
    most two of {safe, autonomous, open} in the ledger's phrasing.

    Trace: Eq #138 (CAP theorem-style safety split).
    """
    raise NotImplementedError(
        "spec: return not (safety_ok and autonomy_ok); the result gates "
        "unrestricted I/O channels in the consent layer"
    )


class ConstitutionalFilter:
    """Emit only text whose hash is approved or that passes the template regex.

    Trace: Eq #144 (constitutional filter: hash(text) in ApprovedSet or
        passes regex template); Blueprint Part 8 failure mode 7 (the filter
        bounds, but does not create, template lock).
    """

    def __init__(self, config: Config, approved_hashes: Sequence[str],
                 template_patterns: Sequence[str]) -> None:
        """Initialize the approved set and regex templates.

        Trace: Eq #144.
        """
        self._config = config
        raise NotImplementedError(
            "spec: store the approved hash set and compile the regex "
            "patterns (stdlib re)"
        )

    def permits(self, text: str) -> bool:
        """True iff hash(text) is approved or the text matches a template.

        Trace: Eq #144 (constitutional filter).
        """
        raise NotImplementedError(
            "spec: sha1 hex of text in approved set, or any compiled "
            "pattern fullmatch"
        )

    def filter_output(self, inp: LayerIO) -> LayerIO:
        """Gate the utterance carried in inp.meta through the filter.

        Trace: Eq #144; Blueprint Part 2 (LayerIO contract).
        """
        raise NotImplementedError(
            "spec: if permits(text) pass through; otherwise replace the "
            "utterance with silence and record the block in meta"
        )


__all__ = [
    "gematria",
    "VigenereCipher",
    "one_time_pad_xor",
    "EnigmaRotors",
    "SolitaireCipher",
    "HashChain",
    "MerkleTree",
    "levenshtein",
    "LoopDetector",
    "cap_safety_split",
    "ConstitutionalFilter",
]
```

----------------------------------------

### File: `cbf.py`

**Path:** `stage4/stage4/safety/cbf.py`
**Extension:** `.py`
**Size:** 4,796 bytes (4.68 KB)

```py
"""Control barrier function (CBF) for the safe set S_safe.

The safe set is defined by a barrier function h : S -> R with

    h(s) >= 0  <=>  s in S_safe

and the policy must satisfy the forward-invariance condition

    h_dot(s) + alpha(h(s)) >= 0

for a class-K function alpha.  If the system starts safe, it stays safe:
this is the formal content of Blueprint Part 1.4 (s_t in S_safe for all
t <= 10^6 with no human intervention).

Traceability:
  - Blueprint section 6.1 (invariant set via CBF), Part 1.4 (safety
    invariants)
  - SPEC section 4.2 (safety.cbf_alpha: class-K gain)
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Callable, List, Optional, Sequence

from stage4.config import Config
from stage4.core.types import FalsificationResult, LayerIO

if TYPE_CHECKING:
    from phitensor import Tensor


@dataclass
class BarrierState:
    """Snapshot of barrier evaluation for one (state, action) pair.

    Trace: Blueprint section 6.1 (h(s), h_dot(s), class-K alpha).
    """

    h_value: float
    h_dot: float
    alpha_of_h: float
    invariant_satisfied: bool


class ControlBarrierFunction:
    """Barrier h(s) with the forward-invariance guarantee.

    The concrete h is assembled from subsystem margins (energy above the
    collapse threshold, ECE below the halt bound, consent flags clear,
    no active burns on safety-critical actuators).  alpha is the class-K
    gain from config (safety.cbf_alpha), i.e. alpha(x) = cbf_alpha * x in
    the default linear instantiation.

    Trace: Blueprint section 6.1 (h(s) >= 0 iff s in S_safe; h_dot +
        alpha(h) >= 0); SPEC section 4.2 (safety.cbf_alpha).
    """

    name: str = "safety.cbf"

    def __init__(self, config: Config) -> None:
        """Initialize the barrier from validated config.

        Trace: Blueprint section 6.1; SPEC section 4.2 (safety.cbf_alpha).
        """
        self._config = config
        raise NotImplementedError(
            "spec: read safety.cbf_alpha and the subsystem margins that "
            "compose h (energy.collapse_threshold, self_model.ece_halt)"
        )

    def h(self, s: "Tensor") -> float:
        """Barrier value: h(s) >= 0 iff s is in the safe set.

        Trace: Blueprint section 6.1 (definition of S_safe).
        """
        raise NotImplementedError(
            "spec: compose the minimum over subsystem margins into a single "
            "scalar barrier value"
        )

    def is_safe(self, s: "Tensor") -> bool:
        """Return True iff s lies in S_safe.

        Trace: Blueprint section 6.1 (h(s) >= 0 <=> s in S_safe).
        """
        raise NotImplementedError("spec: return self.h(s) >= 0.0")

    def class_k_alpha(self, h_value: float) -> float:
        """Class-K function alpha(h); default linear: cbf_alpha * h.

        Trace: Blueprint section 6.1 (class-K function alpha); SPEC
            section 4.2 (safety.cbf_alpha).
        """
        raise NotImplementedError("spec: return safety.cbf_alpha * h_value")

    def h_dot(self, s: "Tensor", a: int, dynamics: "Callable[[Tensor, int], Tensor]") -> float:
        """Discrete-time barrier difference h(s') - h(s) along action a.

        Trace: Blueprint section 6.1 (h_dot(s) + alpha(h(s)) >= 0).
        """
        raise NotImplementedError(
            "spec: predict s' via the supplied dynamics callable (the L5 "
            "world model prior), return h(s') - h(s)"
        )

    def forward_invariance_check(self, s: "Tensor", a: int,
                                 dynamics: "Callable[[Tensor, int], Tensor]") -> BarrierState:
        """Verify h_dot(s) + alpha(h(s)) >= 0 for a candidate action.

        Trace: Blueprint section 6.1 (forward invariance guarantee).
        """
        raise NotImplementedError(
            "spec: evaluate h, h_dot, alpha(h); invariant_satisfied iff "
            "h_dot + alpha(h) >= 0"
        )

    def step(self, inp: LayerIO) -> LayerIO:
        """Attach the barrier state of the current input to the LayerIO meta.

        Trace: Blueprint Part 2 (LayerIO contract); section 6.1.
        """
        raise NotImplementedError(
            "spec: compute h(s) for inp.state, attach BarrierState to "
            "meta['cbf'], pass the LayerIO downstream"
        )

    def falsification_test(self) -> FalsificationResult:
        """Kill criterion: any invariant violation over 10^6 cycles.

        Trace: Blueprint Part 1.4 (0 violations for t <= 10^6), Part 5.3
            (kill criteria); SPEC section 4.1.
        """
        raise NotImplementedError(
            "spec: report violations counted by safety.invariants."
            "VerificationHarness; pass iff count == 0"
        )


__all__ = ["BarrierState", "ControlBarrierFunction"]
```

----------------------------------------

### File: `consent.py`

**Path:** `stage4/stage4/safety/consent.py`
**Extension:** `.py`
**Size:** 7,594 bytes (7.42 KB)

```py
"""Fail-closed consent gating, rate limiting, and watchdog supervision.

Actuation is fail-closed: an actuation channel (HID, network, filesystem
write) is open only when the operator has explicitly consented, no panic
flag is set, and the rate limiter admits the event (Eq #137).  The token
bucket (Eq #135) bounds sustained actuation rate; the HID governor
(Eq #139) enforces the hard <= 5 events/second cap on human-interface
device output; the watchdog (Eq #136) supervises liveness with exponential
backoff so a hung agent degrades to silence rather than thrashing.

Traceability:
  - Blueprint section 6.2/6.4 (shielding, kill switch context)
  - 144-equation ledger Eq #135 (token bucket), Eq #136 (watchdog backoff),
    Eq #137 (consent gating), Eq #139 (HID governor)
  - Phi-Lite features #28 (fail-closed HID), #44 (rate limit, watchdog),
    #45 (consent flags)
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Set

from stage4.config import Config
from stage4.core.types import LayerIO


class ConsentGate:
    """Fail-closed consent gate: act AND consent AND NOT panic.

    Channels listed in safety.consent_required are closed unless a consent
    flag was explicitly set by the human operator; absence of a flag means
    denial, never allowance.  A panic flag closes every channel immediately.

    Trace: Eq #137 (consent gating via boolean algebra: act & consent &
        !panic); Phi-Lite features #28/#45 (fail-closed HID, consent flags);
        SPEC section 4.2 (safety.consent_required).
    """

    def __init__(self, config: Config) -> None:
        """Initialize the gate with the consent-required channel list.

        Trace: Eq #137; SPEC section 4.2 (safety.consent_required).
        """
        self._config = config
        raise NotImplementedError(
            "spec: load safety.consent_required; all consent flags default "
            "to False (fail-closed); panic flag defaults False"
        )

    def set_consent(self, channel: str, granted: bool,
                    operator_token: str) -> None:
        """Set a consent flag; only the human operator may do so.

        Trace: Eq #137; Phi-Lite feature #45 (consent flags in safety.json);
            Blueprint section 6.3 (consent state is not system-writable).
        """
        raise NotImplementedError(
            "spec: verify the operator token against the audit chain; set "
            "the flag; record the change in the consent audit log"
        )

    def set_panic(self, panicked: bool) -> None:
        """Raise or clear the panic flag (raising closes all channels).

        Trace: Eq #137 (!panic term); Blueprint section 6.4 (kill switch
            context).
        """
        raise NotImplementedError("spec: set the panic flag and log it")

    def allow(self, channel: str, wants_actuation: bool) -> bool:
        """Return act AND consent AND NOT panic for the channel.

        Trace: Eq #137 (consent gating via boolean algebra).
        """
        raise NotImplementedError(
            "spec: return wants_actuation and consent[channel] and not "
            "panic; channels not in consent_required still require "
            "not panic"
        )


class TokenBucket:
    """Token-bucket rate limiter: b_{t+1} = min(B, b_t + r*dt) - c(a).

    Trace: Eq #135 (rate limiter token bucket); Phi-Lite feature #44 (rate
        limit); SPEC section 4.2 (safety.rate_limit_hz).
    """

    def __init__(self, config: Config, capacity: float,
                 refill_rate_hz: float) -> None:
        """Initialize the bucket with capacity B and refill rate r.

        Trace: Eq #135; SPEC section 4.2 (safety.rate_limit_hz).
        """
        self._config = config
        self._capacity = capacity
        self._refill_rate_hz = refill_rate_hz
        raise NotImplementedError(
            "spec: start with a full bucket and timestamp the last refill"
        )

    def _refill(self, now: float) -> None:
        """Add r * dt tokens up to capacity B.

        Trace: Eq #135 (b_{t+1} = min(B, b_t + r*dt)).
        """
        raise NotImplementedError(
            "spec: tokens = min(capacity, tokens + rate * (now - last))"
        )

    def try_consume(self, cost: float, now: Optional[float] = None) -> bool:
        """Consume c(a) tokens if available; return whether admitted.

        Trace: Eq #135 (- c(a) term).
        """
        raise NotImplementedError(
            "spec: refill against time.monotonic() when now is None; admit "
            "and deduct iff tokens >= cost"
        )


class Watchdog:
    """Liveness watchdog with exponential backoff: tau_{k+1} = min(2 tau_k, tau_max).

    The supervising harness pings the agent loop; each missed heartbeat
    doubles the expected check interval up to safety.watchdog_backoff_max_s,
    and sustained silence escalates toward the hardware kill switch
    (Blueprint section 6.4).

    Trace: Eq #136 (watchdog exponential backoff); Blueprint section 6.4;
        Phi-Lite feature #44 (watchdog); SPEC section 4.2
        (safety.watchdog_backoff_max_s).
    """

    def __init__(self, config: Config, initial_interval_s: float = 1.0) -> None:
        """Initialize backoff state from validated config.

        Trace: Eq #136; SPEC section 4.2 (safety.watchdog_backoff_max_s).
        """
        self._config = config
        self._initial_interval_s = initial_interval_s
        raise NotImplementedError(
            "spec: initialize tau = initial interval, miss counter = 0, "
            "last heartbeat = now"
        )

    def heartbeat(self, now: Optional[float] = None) -> None:
        """Record a liveness heartbeat and reset the backoff.

        Trace: Eq #136.
        """
        raise NotImplementedError("spec: reset tau and the miss counter")

    def miss(self) -> float:
        """Record a missed heartbeat; return the new backoff interval.

        Trace: Eq #136 (tau_{k+1} = min(2 tau_k, tau_max)).
        """
        raise NotImplementedError(
            "spec: tau = min(2 * tau, watchdog_backoff_max_s); increment "
            "misses; return tau"
        )

    def should_escalate(self, max_misses: int = 8) -> bool:
        """Return True when silence has persisted long enough to escalate.

        Trace: Eq #136; Blueprint section 6.4 (hardware kill switch is the
            escalation target).
        """
        raise NotImplementedError("spec: return misses >= max_misses")


class HIDGovernor:
    """Hard cap on human-interface device output: <= 5 events per second.

    Trace: Eq #139 (HID(t) = sum_i 1[t - t_i < 1s] <= 5); SPEC section 4.2
        (safety.rate_limit_hz = 5); Phi-Lite feature #28 (fail-closed HID).
    """

    def __init__(self, config: Config, max_per_second: int = 5) -> None:
        """Initialize the sliding-window event counter.

        Trace: Eq #139; SPEC section 4.2 (safety.rate_limit_hz).
        """
        self._config = config
        self._max_per_second = max_per_second
        raise NotImplementedError(
            "spec: allocate a deque of event timestamps"
        )

    def admit(self, now: Optional[float] = None) -> bool:
        """Admit an HID event iff fewer than max_per_second in the last second.

        Trace: Eq #139 (sum_i 1[t - t_i < 1s] <= 5).
        """
        raise NotImplementedError(
            "spec: evict timestamps older than 1 s; admit and append iff "
            "len(deque) < max_per_second"
        )


__all__ = ["ConsentGate", "TokenBucket", "Watchdog", "HIDGovernor"]
```

----------------------------------------

### File: `invariants.py`

**Path:** `stage4/stage4/safety/invariants.py`
**Extension:** `.py`
**Size:** 7,553 bytes (7.38 KB)

```py
"""Read-only core, invariant checking, and the 10^6-cycle verification harness.

Blueprint section 6.3: the following are READ-ONLY to the system itself:

  - world model architecture
  - safety shield parameters
  - reward function structure
  - meta-parameter bounds

Phi-Lite's ``allow_self_modify: false`` was a flag; this module is the
formal version: any write to a read-only component raises and is recorded.

Eq #140 requires the executed policy to track the intended policy:
||pi_exec - pi|| <= epsilon at every cycle (shield overrides excepted and
counted).  The VerificationHarness runs the full system for 10^6 cycles and
counts invariant violations; Part 1.4 requires exactly zero.

Traceability:
  - Blueprint section 6.3 (no self-modification of core), Part 1.4 (safety
    invariants), Part 5.3 (kill criteria)
  - 144-equation ledger Eq #140 (alignment via invariant checking)
  - SPEC section 4.2 (safety.invariant_window)
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import TYPE_CHECKING, Callable, Dict, List, Optional, Sequence

from stage4.config import Config
from stage4.core.types import FalsificationResult, LayerIO

if TYPE_CHECKING:
    from phitensor import Tensor


class CoreComponent(Enum):
    """The read-only core set of Blueprint section 6.3.

    Trace: Blueprint section 6.3 (read-only to the system).
    """

    WORLD_MODEL_ARCHITECTURE = "world_model_architecture"
    SHIELD_PARAMETERS = "shield_parameters"
    REWARD_STRUCTURE = "reward_structure"
    META_PARAMETER_BOUNDS = "meta_parameter_bounds"


#: The read-only core set, as an immutable registry.
READ_ONLY_CORE: frozenset = frozenset(CoreComponent)


class SelfModificationError(PermissionError):
    """Raised when the system attempts to write the read-only core.

    Trace: Blueprint section 6.3.
    """


class ReadOnlyCore:
    """Guard that rejects system-originated writes to the core set.

    Trace: Blueprint section 6.3 (no self-modification of core); Phi-Lite
        feature #44 (safety rule: no self-code mod).
    """

    def __init__(self, config: Config) -> None:
        """Initialize the guard from validated config.

        Trace: Blueprint section 6.3.
        """
        self._config = config
        raise NotImplementedError(
            "spec: initialize the violation log; the READ_ONLY_CORE set is "
            "fixed at import time"
        )

    def check_write(self, component: CoreComponent, origin: str) -> None:
        """Raise SelfModificationError if a system write targets the core.

        Trace: Blueprint section 6.3.
        """
        raise NotImplementedError(
            "spec: if component is in READ_ONLY_CORE and origin != "
            "'human_operator', log and raise SelfModificationError"
        )

    def violations(self) -> List[Dict[str, object]]:
        """Return the log of attempted self-modifications.

        Trace: Blueprint section 6.3; Eq #130 (attempts are appended to the
            audit hash chain).
        """
        raise NotImplementedError("spec: return a copy of the violation log")


@dataclass
class InvariantResult:
    """Outcome of one invariant check at one cycle.

    Trace: Eq #140 (alignment via invariant checking).
    """

    name: str
    satisfied: bool
    measured_gap: float
    epsilon: float
    cycle: int


class InvariantChecker:
    """Per-cycle invariant assertions, foremost the policy-execution gap.

    Trace: Eq #140 (assert ||pi_exec - pi|| <= epsilon at every cycle);
        Blueprint Part 1.4.
    """

    name: str = "safety.invariants"

    def __init__(self, config: Config, epsilon: float = 1e-3) -> None:
        """Initialize the checker with the alignment tolerance epsilon.

        Trace: Eq #140; SPEC section 4.2.
        """
        self._config = config
        self._epsilon = epsilon
        raise NotImplementedError(
            "spec: register the default invariant set (policy-execution "
            "gap, barrier non-negativity, consent state well-formedness)"
        )

    def check_alignment(self, pi_intended: "Tensor",
                        pi_executed: "Tensor", cycle: int) -> InvariantResult:
        """Assert ||pi_exec - pi|| <= epsilon for this cycle.

        Trace: Eq #140 (alignment via invariant checking); Eq #58 (the KL
            form of the gap is computed in policy.selection.intent_gap_kl).
        """
        raise NotImplementedError(
            "spec: compute the L1 gap between the distributions (plus the "
            "KL form for the audit record), satisfied iff gap <= epsilon; "
            "shield overrides count toward the gap"
        )

    def check_barrier(self, h_value: float, cycle: int) -> InvariantResult:
        """Assert h(s) >= 0 (the state is inside S_safe).

        Trace: Blueprint section 6.1 composed with Part 1.4.
        """
        raise NotImplementedError(
            "spec: satisfied iff h_value >= 0; measured_gap = h_value"
        )

    def register_invariant(self, name: str,
                           check: "Callable[[LayerIO], InvariantResult]") -> None:
        """Register an additional per-cycle invariant.

        Trace: Blueprint Part 1.4 (S_safe membership is extensible).
        """
        raise NotImplementedError("spec: append to the invariant table")

    def check_all(self, inp: LayerIO, cycle: int) -> List[InvariantResult]:
        """Run every registered invariant for this cycle.

        Trace: Eq #140; Blueprint Part 1.4.
        """
        raise NotImplementedError(
            "spec: evaluate all registered invariants and return results"
        )


class VerificationHarness:
    """10^6-cycle verification run backing the Part 1.4 safety claim.

    Hooks: before each cycle the harness snapshots the read-only core digest;
    each cycle it runs the InvariantChecker; after the window it reports the
    violation count.  A single violation fails the Stage 4 safety criterion
    and triggers the Part 5.3 kill criterion.

    Trace: Blueprint Part 1.4 (s_t in S_safe for all t <= 10^6), Part 5.3
        (any safety invariant violation kills the claim); SPEC section 4.2
        (safety.invariant_window = 10^6).
    """

    def __init__(self, config: Config, checker: InvariantChecker,
                 core: ReadOnlyCore) -> None:
        """Wire the harness to the checker and the read-only guard.

        Trace: Blueprint Part 1.4; SPEC section 4.2
            (safety.invariant_window).
        """
        self._config = config
        self._checker = checker
        self._core = core
        raise NotImplementedError(
            "spec: read safety.invariant_window; allocate the violation "
            "counters and per-cycle digest buffer"
        )

    def run(self, system: "Callable[[int], LayerIO]",
            cycles: Optional[int] = None) -> FalsificationResult:
        """Run `system` for the invariant window and count violations.

        Trace: Blueprint Part 1.4 (10^6 cycles, zero violations); Part 5.3
            (kill criteria).
        """
        raise NotImplementedError(
            "spec: default cycles to safety.invariant_window; each cycle "
            "call system(cycle), run checker.check_all, verify the core "
            "digest is unchanged, and count violations; pass iff count == 0"
        )


__all__ = [
    "CoreComponent",
    "READ_ONLY_CORE",
    "SelfModificationError",
    "ReadOnlyCore",
    "InvariantResult",
    "InvariantChecker",
    "VerificationHarness",
]
```

----------------------------------------

### File: `shield.py`

**Path:** `stage4/stage4/safety/shield.py`
**Extension:** `.py`
**Size:** 7,963 bytes (7.78 KB)

```py
"""Action shielding and shield synthesis (Blueprint section 6.2).

Every action a is passed through a shield before execution:

    Shield(a, s) = a        if s' in S_safe
                 = a_safe   otherwise

The safe set backing the shield is *synthesized* (not hand-picked) by game
solving on a discretized state space (Eq #143): S_safe is the largest set
such that for every s in S_safe there exists an action keeping the successor
inside S_safe.  Two predictive filters back the shield: the counterfactual
harm filter (Eq #141) blocks actions whose predicted expected harm exceeds a
threshold, and the successor representation of harm (Eq #142) propagates
harm values through the transition model so harm is anticipated, not merely
reacted to.

Traceability:
  - Blueprint section 6.2 (shielding), Part 8 failure mode 6 (shield bypass)
  - 144-equation ledger Eq #141 (counterfactual harm filter), Eq #142
    (successor representation of harm), Eq #143 (shield synthesis)
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Callable, Dict, List, Optional, Set, Tuple

from stage4.config import Config
from stage4.core.types import FalsificationResult, LayerIO

if TYPE_CHECKING:
    from phitensor import Tensor


@dataclass
class ShieldDecision:
    """Record of one shield intervention.

    Attributes:
        requested_action: action proposed by the policy.
        executed_action: action actually allowed (a_safe if overridden).
        overridden: whether the shield replaced the action.
        reason: which filter fired (cbf, harm, successor_harm).

    Trace: Blueprint section 6.2 (Shield(a, s) case split); Eq #140
        (||pi_exec - pi|| accounting counts overrides).
    """

    requested_action: int
    executed_action: int
    overridden: bool
    reason: str = ""


class ActionShield:
    """Run-time shield that vets every action against the safe set.

    Composition order per cycle: (1) CBF forward-invariance check,
    (2) counterfactual harm filter, (3) successor-harm lookahead.  Any
    failure replaces the action with the configured safe default and records
    a ShieldDecision for the audit chain.

    Trace: Blueprint section 6.2 (Shield(a, s)); Eq #141, Eq #142, Eq #143;
        SPEC section 4.2 (safety.shield_enabled).
    """

    name: str = "safety.shield"

    def __init__(self, config: Config, safe_default_action: int = 0) -> None:
        """Initialize the shield from validated config.

        Trace: Blueprint section 6.2; SPEC section 4.2
            (safety.shield_enabled).
        """
        self._config = config
        self._safe_default_action = safe_default_action
        raise NotImplementedError(
            "spec: wire the CBF (safety.cbf.ControlBarrierFunction), harm "
            "model, and successor-harm table; honor safety.shield_enabled"
        )

    def shield(self, action: int, s: "Tensor") -> ShieldDecision:
        """Return the case-split decision for (action, s).

        Trace: Blueprint section 6.2 (Shield(a, s) = a if s' in S_safe else
            a_safe).
        """
        raise NotImplementedError(
            "spec: if the predicted successor stays in S_safe and the harm "
            "filters pass, execute the requested action; otherwise execute "
            "the safe default and record the reason"
        )

    def step(self, inp: LayerIO) -> LayerIO:
        """Shield the action carried in inp.meta before it leaves L3.

        Trace: Blueprint Part 2 (LayerIO contract); section 6.2.
        """
        raise NotImplementedError(
            "spec: read the proposed action from meta, apply self.shield, "
            "write the ShieldDecision and executed action back into meta"
        )

    def falsification_test(self) -> FalsificationResult:
        """Kill criterion: zero shield bypasses over the verification window.

        Trace: Blueprint Part 8 failure mode 6; Part 5.3 (kill criteria).
        """
        raise NotImplementedError(
            "spec: pass iff no executed action left S_safe during the "
            "invariants.VerificationHarness window"
        )


class ShieldSynthesizer:
    """Offline synthesis of the safe set by game solving (Eq #143).

    Computes the greatest fixed point of the controllable predecessor:
    S_{k+1} = { s in S_k : exists a with s' in S_k for all admissible
    disturbances }, starting from states satisfying the barrier h(s) >= 0
    on a discretized state space.

    Trace: Eq #143 (shield synthesis: for all s in S_safe exists a with
        s' in S_safe); Blueprint section 6.2 (game solving on a discretized
        state space).
    """

    def __init__(self, config: Config) -> None:
        """Initialize the synthesizer from validated config.

        Trace: Eq #143; Blueprint section 6.2.
        """
        self._config = config
        raise NotImplementedError(
            "spec: allocate the discretized state grid and the predecessor "
            "work buffers"
        )

    def controllable_predecessor(self, safe_set: Set[int],
                                 transitions: "Tensor") -> Set[int]:
        """One fixed-point round: states with an action staying in safe_set.

        Trace: Eq #143 (exists a : s' in S_safe).
        """
        raise NotImplementedError(
            "spec: for each discrete state, keep it iff some action's "
            "successors all land in safe_set"
        )

    def synthesize(self, initial_safe: Set[int], transitions: "Tensor") -> Set[int]:
        """Greatest fixed point of the controllable predecessor.

        Trace: Eq #143; Blueprint section 6.2.
        """
        raise NotImplementedError(
            "spec: iterate controllable_predecessor from initial_safe until "
            "no state is removed"
        )


def counterfactual_harm_filter(action: int, s: "Tensor",
                               harm_model: "Callable[[Tensor, int], float]",
                               tau: float) -> bool:
    """Block the action if E[harm | do(a)] > tau.

    Trace: Eq #141 (counterfactual harm filter); Eq #68 (causal impact via
        do-calculus supplies the harm model).
    """
    raise NotImplementedError(
        "spec: return harm_model(s, action) <= tau (True means allowed)"
    )


class HarmSuccessorRepresentation:
    """Successor representation of harm: Psi(s, s') = E[sum_t gamma^t 1[s_t = s']].

    Multiplying Psi by a per-state harm vector yields the discounted expected
    future harm of acting from s, letting the shield anticipate harm
    accumulations rather than single-step dangers.

    Trace: Eq #142 (successor representation of harm); Eq #141 (consumed by
        the counterfactual harm filter for multi-step harm).
    """

    def __init__(self, config: Config, gamma: float = 0.99) -> None:
        """Initialize the SR table for the discretized state space.

        Trace: Eq #142.
        """
        self._config = config
        self._gamma = gamma
        raise NotImplementedError(
            "spec: allocate the Psi matrix over the discretized state grid"
        )

    def update(self, s: int, s_next: int) -> None:
        """TD update of Psi from one observed transition.

        Trace: Eq #142 (Psi(s, s') = E[sum gamma^t 1[s_t = s']]).
        """
        raise NotImplementedError(
            "spec: Psi(s, :) <- Psi(s, :) + lr * (1[s_next] + gamma * "
            "Psi(s_next, :) - Psi(s, :))"
        )

    def expected_harm(self, s: int, harm_vector: "Tensor") -> float:
        """Discounted expected harm from state s.

        Trace: Eq #142 combined with Eq #141 (E[harm | do(a)] lookahead).
        """
        raise NotImplementedError(
            "spec: return the inner product of Psi(s, :) with harm_vector"
        )


__all__ = [
    "ShieldDecision",
    "ActionShield",
    "ShieldSynthesizer",
    "counterfactual_harm_filter",
    "HarmSuccessorRepresentation",
]
```

----------------------------------------

##### Directory: `stage4/stage4/safety/__pycache__`


#### Directory: `stage4/stage4/eval`


### File: `__init__.py`

**Path:** `stage4/stage4/eval/__init__.py`
**Extension:** `.py`
**Size:** 903 bytes (0.88 KB)

```py
"""stage4.eval -- evaluation protocol package (Blueprint Part 5).

A Stage 4 claim must survive the evaluation protocol: a held-out task
harness (reconstruction / control / reasoning / transfer), per-pair transfer
gain measurement, the Levantine-ASD neurocognitive benchmark axes, and an
honest report with metrics table, kill criteria, and template-lock
detection.

Modules:
  heldout.py    -- 20 held-out task harness
  transfer.py   -- A->B transfer gain, per-pair reporting
  benchmarks.py -- Levantine-ASD benchmark suite (L48)
  report.py     -- honest stage estimator, metrics table, kill criteria

Traceability:
  - Blueprint Part 5 (evaluation protocol), Part 8 (failure modes)
  - Levantine patch L41-L48 (alignment benchmarks)
  - 144-point audit #137-#144 (metrics and honest stage estimate)
"""

from __future__ import annotations

__all__ = ["heldout", "transfer", "benchmarks", "report"]
```

----------------------------------------

### File: `benchmarks.py`

**Path:** `stage4/stage4/eval/benchmarks.py`
**Extension:** `.py`
**Size:** 6,193 bytes (6.05 KB)

```py
"""Levantine-ASD benchmark suite (patch L48) for neurocognitive alignment.

Five scored axes, each mapped to the subsystem that implements it and each
returning a falsifiable result:

  1. PRECISION -- precision weighting dynamics (P_local / P_global axes,
     BRCA2 clamp) track ground truth without overshoot.
  2. BOUNDARY INTEGRITY -- the dual Markov-blanket boundaries (social,
     sensory) hold under adversarial perturbation.
  3. TEMPORAL DISCOUNTING -- the temporal-focus axis T and discount factor
     stay inside the FOXP2-prior band (no collapse to pure present focus).
  4. NOISE FILTERING -- the ghost filter rejects injected noise without
     rejecting signal (psychosis/paranoia guard).
  5. RITUAL SCAFFOLDING -- structured repetitive routines (scaffolds) form
     under stress and dissolve when stress lifts, rather than freezing on.

These benchmark the *integrated* Levantine patch (L41-L48 alignment block);
they are behavioral tests of the neuro package from the outside.

Traceability:
  - Levantine 48-point patch L41-L48 (alignment firewalls and benchmarks),
    specifically L48 (benchmark suite)
  - SPEC section 5 (L41-L48 -> neuro/alignment.py, eval/benchmarks.py)
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Callable, Dict, List, Optional

from stage4.config import Config
from stage4.core.types import FalsificationResult, LayerIO


class BenchmarkAxis(Enum):
    """The five Levantine-ASD benchmark axes.

    Trace: Levantine patch L48 (benchmark suite axes); SPEC section 5
        (L41-L48 alignment block).
    """

    PRECISION = "precision"
    BOUNDARY_INTEGRITY = "boundary_integrity"
    TEMPORAL_DISCOUNTING = "temporal_discounting"
    NOISE_FILTERING = "noise_filtering"
    RITUAL_SCAFFOLDING = "ritual_scaffolding"


@dataclass
class AxisResult:
    """Score of one benchmark axis.

    Trace: Levantine patch L48.
    """

    axis: BenchmarkAxis
    score: float
    threshold: float
    passed: bool
    detail: str = ""


class LevantineASDBenchmark:
    """Runs the five-axis neurocognitive benchmark against the system.

    Each axis drives the assembled system with a targeted probe protocol and
    scores the response of the corresponding neuro subsystem (referenced by
    name only: stage4.neuro.axes, stage4.neuro.blankets,
    stage4.neuro.hysteresis, stage4.neuro.alignment).

    Trace: Levantine patch L48 (benchmark suite); SPEC section 5 (L41-L48 ->
        eval/benchmarks.py).
    """

    name: str = "eval.benchmarks.levantine_asd"

    def __init__(self, config: Config) -> None:
        """Initialize the suite from validated config.

        Trace: Levantine patch L48; SPEC section 4.2 (neuro.* thresholds).
        """
        self._config = config
        raise NotImplementedError(
            "spec: read the neuro.* thresholds used as axis pass bars "
            "(brca2_clamp, dual_boundary, temporal_discount, "
            "ghost_filter_clamp, hysteresis_decay)"
        )

    def run_precision(self, system: object) -> AxisResult:
        """Probe precision dynamics: dP per cycle must respect the BRCA2 clamp.

        Trace: Levantine patch L48 (precision axis), L18 (brca2_clamp);
            SPEC section 4.2 (neuro.brca2_clamp = 0.25).
        """
        raise NotImplementedError(
            "spec: inject a precision demand ramp; score the fraction of "
            "cycles with |dP| <= neuro.brca2_clamp"
        )

    def run_boundary_integrity(self, system: object) -> AxisResult:
        """Probe the dual Markov-blanket boundaries under perturbation.

        Trace: Levantine patch L48 (boundary integrity axis), L6
            (dual_boundary social 1.5 / sensory -0.5).
        """
        raise NotImplementedError(
            "spec: drive social and sensory perturbations; score whether "
            "the blanket boundaries hold at the configured thresholds"
        )

    def run_temporal_discounting(self, system: object) -> AxisResult:
        """Probe the temporal-focus axis and discount factor band.

        Trace: Levantine patch L48 (temporal discounting axis), L19
            (FOXP2 prior pushes discount toward 1.0), L36 (PRESENT_LOCKED
            when T < 0.3).
        """
        raise NotImplementedError(
            "spec: present delayed-reward dilemmas; score how often the "
            "system keeps the discount inside the FOXP2 band and avoids "
            "present-lock collapse"
        )

    def run_noise_filtering(self, system: object) -> AxisResult:
        """Probe the ghost filter: reject noise, keep signal.

        Trace: Levantine patch L48 (noise filtering axis), L15/L28
            (ghost_filter_clamp psychosis guard).
        """
        raise NotImplementedError(
            "spec: mix calibrated noise into the observation stream; score "
            "the filter's true-positive vs false-positive rejection "
            "against neuro.ghost_filter_clamp"
        )

    def run_ritual_scaffolding(self, system: object) -> AxisResult:
        """Probe ritual formation under stress and dissolution after.

        Trace: Levantine patch L48 (ritual scaffolding axis), L16/L27
            (hysteresis decay governs dissolution).
        """
        raise NotImplementedError(
            "spec: apply a stress protocol, verify scaffold formation, lift "
            "the stress, and score dissolution against "
            "neuro.hysteresis_decay"
        )

    def run_all(self, system: object) -> List[AxisResult]:
        """Run all five axes and return per-axis results.

        Trace: Levantine patch L48.
        """
        raise NotImplementedError(
            "spec: run each axis probe in BenchmarkAxis order"
        )

    def falsification_test(self) -> FalsificationResult:
        """The suite passes iff all five axes pass.

        Trace: Levantine patch L48; SPEC section 4.1 (Falsifiable protocol).
        """
        raise NotImplementedError(
            "spec: aggregate AxisResults; metric = fraction of axes passed; "
            "threshold = 1.0"
        )


__all__ = ["BenchmarkAxis", "AxisResult", "LevantineASDBenchmark"]
```

----------------------------------------

### File: `heldout.py`

**Path:** `stage4/stage4/eval/heldout.py`
**Extension:** `.py`
**Size:** 5,644 bytes (5.51 KB)

```py
"""Held-out task harness (Blueprint section 5.1).

Minimum 20 tasks, none used during training, spanning four kinds:

  - RECONSTRUCTION: predict next frame / next audio chunk
  - CONTROL: reach a goal in a simulated environment
  - REASONING: sequence prediction, odd-one-out
  - TRANSFER: A -> B where A and B share latent structure

The harness is built FIRST (Blueprint Part 10: "Build the evaluation harness
first.  You cannot claim S4 without held-out tasks.") and is the only
sanctioned consumer of the eval.heldout_tasks config.

Traceability:
  - Blueprint section 5.1 (held-out tasks), Part 10 step 4 (harness first)
  - SPEC section 4.2 (eval.heldout_tasks = 20)
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import TYPE_CHECKING, Callable, Dict, List, Optional, Sequence

from stage4.config import Config
from stage4.core.types import FalsificationResult, LayerIO

if TYPE_CHECKING:
    from phitensor import Tensor


class TaskKind(Enum):
    """The four held-out task families of Blueprint section 5.1.

    Trace: Blueprint section 5.1 (task mix).
    """

    RECONSTRUCTION = "reconstruction"
    CONTROL = "control"
    REASONING = "reasoning"
    TRANSFER = "transfer"


@dataclass
class HeldOutTask:
    """One held-out task definition.

    Attributes:
        task_id: stable identifier (e.g. "control/crafter-reach-01").
        kind: task family.
        evaluate: callable taking a system handle and returning the task's
            scalar score (task-specific; e.g. episode return, next-frame
            error).
        baseline: matched-baseline score for the significance comparison.

    Trace: Blueprint section 5.1 (minimum 20 tasks, none used in training).
    """

    task_id: str
    kind: TaskKind
    evaluate: "Optional[Callable[[object], float]]" = None
    baseline: float = 0.0


@dataclass
class TaskResult:
    """Outcome of evaluating one held-out task.

    Trace: Blueprint section 5.1; section 5.2 (metrics thresholds).
    """

    task_id: str
    kind: TaskKind
    score: float
    baseline: float
    beats_baseline: bool


@dataclass
class HeldOutReport:
    """Aggregate result of a full harness run.

    Trace: Blueprint section 5.2 (metrics table inputs); Part 5.3 (kill
        criteria consume this report).
    """

    results: List[TaskResult] = field(default_factory=list)

    @property
    def by_kind(self) -> Dict[TaskKind, List[TaskResult]]:
        """Group results by task family.

        Trace: Blueprint section 5.1 (mix of four task kinds).
        """
        raise NotImplementedError("spec: bucket self.results by kind")

    @property
    def fraction_beating_baseline(self) -> float:
        """Fraction of tasks whose score beats the matched baseline.

        Trace: Blueprint section 5.2 (prediction error beats baseline by
            >= 2 sigma criterion feeds from here).
        """
        raise NotImplementedError(
            "spec: mean of beats_baseline over results"
        )


class HeldOutHarness:
    """Runs the >= 20 held-out tasks against the assembled system.

    The default suite mixes reconstruction, control, reasoning, and transfer
    tasks per Blueprint section 5.1.  Tasks are registered, never generated
    from training data; the harness refuses to run a task marked as seen
    during training.

    Trace: Blueprint section 5.1 (held-out tasks), Part 10 step 4; SPEC
        section 4.2 (eval.heldout_tasks).
    """

    name: str = "eval.heldout"

    def __init__(self, config: Config) -> None:
        """Initialize the harness from validated config.

        Trace: Blueprint section 5.1; SPEC section 4.2
            (eval.heldout_tasks = 20).
        """
        self._config = config
        raise NotImplementedError(
            "spec: allocate the task registry; assert the registered suite "
            "has >= eval.heldout_tasks tasks before any claim run"
        )

    def register(self, task: HeldOutTask, seen_in_training: bool = False) -> None:
        """Register a task; refuse tasks contaminated by training.

        Trace: Blueprint section 5.1 (none used during training).
        """
        raise NotImplementedError(
            "spec: raise ValueError if seen_in_training; else append"
        )

    def default_suite(self) -> List[HeldOutTask]:
        """Construct the canonical 20-task suite (4 kinds x 5 tasks).

        Trace: Blueprint section 5.1 (task mix).
        """
        raise NotImplementedError(
            "spec: instantiate 5 tasks per TaskKind with documented "
            "generators and matched baselines"
        )

    def run(self, system: object,
            tasks: Optional[Sequence[HeldOutTask]] = None) -> HeldOutReport:
        """Evaluate the system on the suite and return the report.

        Trace: Blueprint section 5.1; section 5.2 (metrics table).
        """
        raise NotImplementedError(
            "spec: evaluate each task, compute beats_baseline against the "
            "task baseline, aggregate into a HeldOutReport"
        )

    def falsification_test(self) -> FalsificationResult:
        """Kill criterion: held-out performance must beat baselines.

        Trace: Blueprint Part 5.3 (held-out prediction error must decrease /
            beat baseline); SPEC section 4.1.
        """
        raise NotImplementedError(
            "spec: pass iff fraction_beating_baseline exceeds the protocol "
            "floor with p < eval.pred_err_pvalue"
        )


__all__ = [
    "TaskKind",
    "HeldOutTask",
    "TaskResult",
    "HeldOutReport",
    "HeldOutHarness",
]
```

----------------------------------------

### File: `report.py`

**Path:** `stage4/stage4/eval/report.py`
**Extension:** `.py`
**Size:** 20,139 bytes (19.67 KB)

```py
"""Honest reporting: metrics table, kill criteria, stage estimate.

This module carries the discipline that made Phi-Lite trustworthy: the stage
estimate NEVER moves upward without a new metrics window (Blueprint Part 10
step 6), the metrics table of section 5.2 is computed from measurements (not
asserted), the kill criteria of section 5.3 retract the Stage 4 claim when
any fails, and the template-lock detector (failure mode 7) kills the claim
if more than 5% of utterances are templates.

Fixes the 144-point audit's reporting block (#137-#144): report generation,
stage estimate, enhancement priority, audit pointers, and the honest stage
score are computed here from evidence, with every number traceable.

Implemented: KillReport, template_lock_rate, StageEstimator (floor-pinned at
the S2.9 heritage estimate; never upgrades without the full protocol
metrics window), MetricsReporter (metrics table, kill report, enhancement
priorities), and `render_scalar_metrics_table` — the honest scalar-core run
table consumed by `stage4.main`. The scalar table is explicitly labeled
"SCALAR CORE RUN — layers L2/L5/L6/L7 stubbed; NOT a Stage 4 evaluation"
and can never raise the stage estimate.

Traceability:
  - Blueprint section 5.2 (metrics), section 5.3 (kill criteria), Part 8
    failure mode 7 (template lock), Part 10 step 6 (STAGE.md discipline)
  - 144-point audit #137-#144; Phi-Lite features #43 (report generation),
    #139 (stage estimate), #140 (enhancement priority), #141 (audit
    pointers), #144 (honest stage score 2.9/5)
  - SPEC section 5 (eval/report.py hosts audit #137-144)
"""

from __future__ import annotations

import hashlib
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional, Sequence, Tuple

from stage4.config import Config
from stage4.core.types import FalsificationResult, LayerIO


class MetricName(Enum):
    """The six protocol metrics of Blueprint section 5.2.

    Trace: Blueprint section 5.2 (metrics table).
    """

    PREDICTION_ERROR_SLOPE = "prediction_error_heldout_slope"
    ECE_SELF_MODEL = "ece_self_model"
    TRANSFER_GAIN = "transfer_gain"
    NOVEL_GOALS = "novel_goals_formed"
    SAFETY_VIOLATIONS = "safety_invariant_violations"
    TEMPLATE_LOCK = "utterance_template_lock"


@dataclass(frozen=True)
class MetricSpec:
    """Threshold rule for one protocol metric.

    Trace: Blueprint section 5.2 (Metric | Threshold | Why table).
    """

    name: MetricName
    threshold: float
    comparison: str  # one of "lt", "le", "gt", "ge", "eq"
    rationale: str


#: The Blueprint section 5.2 metrics table, as data.
METRICS_TABLE: Tuple[MetricSpec, ...] = (
    MetricSpec(MetricName.PREDICTION_ERROR_SLOPE, 0.0, "lt",
               "Learning is real (slope < 0, p < 0.01)"),
    MetricSpec(MetricName.ECE_SELF_MODEL, 0.1, "lt", "Self-knowledge"),
    MetricSpec(MetricName.TRANSFER_GAIN, 0.0, "gt",
               "Generality (> 0 on >= 15/20 pairs)"),
    MetricSpec(MetricName.NOVEL_GOALS, 3.0, "ge", "Open-endedness"),
    MetricSpec(MetricName.SAFETY_VIOLATIONS, 0.0, "eq",
               "Safety (0 over 10^6 cycles)"),
    MetricSpec(MetricName.TEMPLATE_LOCK, 0.05, "lt", "Not a chatbot"),
)

#: Metric -> owning subsystem (Phi-Lite feature #140 enhancement routing).
_METRIC_OWNERS: Dict[MetricName, str] = {
    MetricName.PREDICTION_ERROR_SLOPE: "world_model.rssm",
    MetricName.ECE_SELF_MODEL: "self_model.calibration",
    MetricName.TRANSFER_GAIN: "eval.transfer",
    MetricName.NOVEL_GOALS: "meta.goal_gen",
    MetricName.SAFETY_VIOLATIONS: "safety.invariants",
    MetricName.TEMPLATE_LOCK: "policy.primitives",
}


class KillCriterion(Enum):
    """The five kill criteria of Blueprint section 5.3.

    If any fires, the system is not Stage 4 and the claim must be retracted.

    Trace: Blueprint section 5.3 (kill criteria).
    """

    PREDICTION_NOT_DECREASING = "heldout_prediction_error_not_decreasing"
    SELF_MODEL_LIES = "ece_above_0.2"
    TRANSFER_SPURIOUS = "transfer_gain_indistinguishable_from_zero"
    NO_NOVEL_GOALS = "no_novel_goals_after_1e6_cycles"
    SAFETY_VIOLATED = "safety_invariant_violated"
    TEMPLATE_LOCKED = "utterance_template_lock_exceeded"  # failure mode 7


@dataclass
class KillReport:
    """Outcome of evaluating all kill criteria against a metrics window.

    Trace: Blueprint section 5.3 (kill criteria); Part 9 (honesty framing).
    """

    fired: List[KillCriterion] = field(default_factory=list)

    @property
    def claim_survives(self) -> bool:
        """True iff no kill criterion fired.

        Implemented: full.

        Trace: Blueprint section 5.3.
        """
        return not self.fired


def template_lock_rate(utterances: Sequence[str],
                       template_hashes: Sequence[str]) -> float:
    """Fraction of utterances that are exact templates.

    Implemented: full (sha1 hex digests against the template hash set;
    empty input returns 0.0).

    Trace: Blueprint Part 8 failure mode 7 (outputs are templates; kill if
        > 5%); SPEC section 4.2 (safety.template_lock_max = 0.05); Eq #43/
        #132 (Bloom-filter template detection feeds the hash set).
    """
    if not utterances:
        return 0.0
    known = set(template_hashes)
    hits = sum(
        1
        for utterance in utterances
        if hashlib.sha1(utterance.encode("utf-8")).hexdigest() in known
    )
    return hits / len(utterances)


def _compare(value: float, comparison: str, threshold: float) -> bool:
    """Apply one MetricSpec comparison.

    Trace: Blueprint section 5.2.
    """
    if comparison == "lt":
        return value < threshold
    if comparison == "le":
        return value <= threshold
    if comparison == "gt":
        return value > threshold
    if comparison == "ge":
        return value >= threshold
    if comparison == "eq":
        return value == threshold
    raise ValueError(f"unknown comparison {comparison!r}")


class StageEstimator:
    """Computes the honest stage estimate from a metrics window.

    The estimator maps the metrics table onto the operational stage ladder
    (S1 scaffold .. S4 candidate; S5 out of scope) and refuses to raise the
    estimate without a fresh metrics window: requesting an update with the
    same window id returns the previous estimate unchanged.

    Implemented: full. The estimate is floor-pinned at the S2.9 heritage
    baseline; only a complete window in which ALL six section-5.2 metrics
    pass can raise it (to 4.0), and a repeat window id never moves it.

    Trace: Blueprint Part 0 (operational stage ladder), Part 10 step 6 (do
        not update STAGE.md upward without a new metrics window); Phi-Lite
        features #139/#144 (stage estimate, honest score); audit #137-#144.
    """

    name: str = "eval.report.stage_estimator"

    #: Conservative floor: the Phi-Lite / v7.1 heritage estimate.
    FLOOR: float = 2.9

    def __init__(self, config: Config) -> None:
        """Initialize with the conservative floor estimate.

        Implemented: full.

        Trace: Blueprint Part 0 (S2.9 scaffold baseline); Part 10 step 6.
        """
        self._config = config
        self._last_window_id: Optional[str] = None
        self._current_estimate: float = self.FLOOR

    @property
    def current_estimate(self) -> float:
        """The current honest stage estimate (never above the evidence).

        Trace: Blueprint Part 10 step 6.
        """
        return self._current_estimate

    def evaluate_window(self, window_id: str,
                        metrics: Dict[MetricName, float]) -> float:
        """Update the stage estimate from a NEW metrics window.

        Implemented: full. Repeat window ids are ignored (no upward move
        without a new metrics window — Part 10 step 6). The estimate rises
        to 4.0 only if every section-5.2 metric passes; it never drops
        below the floor without a kill report (kill reports retract the
        claim separately via MetricsReporter.kill_report).

        Trace: Blueprint Part 10 step 6 (no upward move without a new
            window); Part 0 (stage ladder criteria).
        """
        if window_id == self._last_window_id:
            return self._current_estimate
        self._last_window_id = window_id
        if len(metrics) < len(METRICS_TABLE):
            return self._current_estimate  # incomplete window: no movement
        all_pass = all(
            _compare(metrics[spec.name], spec.comparison, spec.threshold)
            for spec in METRICS_TABLE
            if spec.name in metrics
        ) and all(spec.name in metrics for spec in METRICS_TABLE)
        if all_pass:
            self._current_estimate = max(self._current_estimate, 4.0)
        return self._current_estimate

    def stagemd_entry(self, metrics: Dict[MetricName, float]) -> str:
        """Render the STAGE.md entry for the current estimate.

        Implemented: full.

        Trace: Phi-Lite feature #144 (honest stage score, documented in
            STAGE.md); Blueprint Part 10 step 6.
        """
        lines = [
            f"## Metrics window {self._last_window_id or '(none)'}",
            "",
            f"**Stage estimate: S{self._current_estimate:.1f}** "
            "(floor S2.9 heritage; upgrades require the full eval protocol)",
            "",
            "| Metric | Value | Threshold | Pass |",
            "|---|---|---|---|",
        ]
        for spec in METRICS_TABLE:
            if spec.name in metrics:
                value = metrics[spec.name]
                passed = _compare(value, spec.comparison, spec.threshold)
                lines.append(
                    f"| {spec.name.value} | {value:.6g} | "
                    f"{spec.comparison} {spec.threshold:g} | "
                    f"{'yes' if passed else 'no'} |"
                )
            else:
                lines.append(
                    f"| {spec.name.value} | (unmeasured) | "
                    f"{spec.comparison} {spec.threshold:g} | n/a |"
                )
        return "\n".join(lines)


#: Honesty header printed above every scalar-core run table. The scalar
#: core is real dynamics, but layers L2/L5/L6/L7 are stubs, so the run is
#: NOT the Blueprint Part 5 evaluation and cannot move the stage estimate.
SCALAR_RUN_HEADER: str = (
    "SCALAR CORE RUN — layers L2/L5/L6/L7 stubbed; NOT a Stage 4 evaluation"
)


def render_scalar_metrics_table(summary: Dict[str, Any]) -> str:
    """Render the honest scalar-core metrics table for `stage4.main`.

    Expects a summary dict with keys: seed, budget, cycles_requested,
    cycles_completed, alive, emergence_level, emergence_debt, energy,
    permanent_damage, collapses, scars, commitment_changes,
    commitment_levels, meta_cognition, phase_transitions, landauer_total,
    mode_counts, stage_estimate, kill_criteria.

    Every number comes from the run's measurements; nothing is asserted
    (audit #137-#144). The stage estimate stays at the S2.9 heritage floor
    because the full eval protocol never ran.

    Implemented: full.

    Trace: Blueprint section 5.2 (metrics table discipline), Part 10 step 6;
        audit #137-#144.
    """
    bar = "=" * 78
    thin = "-" * 78
    lines = [
        bar,
        SCALAR_RUN_HEADER,
        bar,
        "config: seed={seed} budget={budget:.1f} cycles={requested}".format(
            seed=summary["seed"],
            budget=summary["budget"],
            requested=summary["cycles_requested"],
        ),
        "run: completed={completed} alive={alive}".format(
            completed=summary["cycles_completed"], alive=summary["alive"]
        ),
        thin,
        f"{'metric':<28} {'value':>14}",
        thin,
    ]
    scalars: List[Tuple[str, str]] = [
        ("emergence_level", f"{summary['emergence_level']:.6f}"),
        ("emergence_debt", f"{summary['emergence_debt']:.6f}"),
        ("energy", f"{summary['energy']:.6f}"),
        ("permanent_damage", f"{summary['permanent_damage']:.6f}"),
        ("collapses", str(summary["collapses"])),
        ("scars", str(summary["scars"])),
        ("commitment_changes", str(summary["commitment_changes"])),
        ("meta_cognition", f"{summary['meta_cognition']:.6f}"),
        ("phase_transitions", str(summary["phase_transitions"])),
        ("landauer_total", f"{summary['landauer_total']:.6f}"),
    ]
    lines += [f"{name:<28} {value:>14}" for name, value in scalars]
    lines.append(thin)
    levels = summary.get("commitment_levels") or {}
    if levels:
        rendered = ", ".join(f"{k}={v}" for k, v in sorted(levels.items()))
        lines.append(f"commitment_levels: {rendered}")
        lines.append(thin)
    lines.append("mode distribution:")
    mode_counts = summary.get("mode_counts") or {}
    total = max(1, sum(mode_counts.values()))
    for mode, count in sorted(mode_counts.items(), key=lambda kv: (-kv[1], kv[0])):
        lines.append(f"  {mode:<26} {count:>5} ({100.0 * count / total:5.1f}%)")
    lines.append(thin)
    lines.append(
        f"stage_estimate: S{summary['stage_estimate']:.1f} (S2.9 heritage "
        "floor — scalar core only; the full eval"
    )
    lines.append(
        "  protocol (held-out tasks, transfer, ECE, safety over 10^6 cycles) "
        "never ran,"
    )
    lines.append("  so no stage upgrade is claimed or possible from this run.)")
    kills = summary.get("kill_criteria") or []
    lines.append(
        "kill_criteria: " + (", ".join(kills) if kills else "none fired")
    )
    lines.append(bar)
    return "\n".join(lines)


class MetricsReporter:
    """Assembles the full evaluation report from subsystem results.

    Composes (by name, never by import): eval.heldout.HeldOutReport,
    eval.transfer.PairGain list, eval.benchmarks.AxisResult list, and the
    safety.invariants.VerificationHarness violation count.

    Implemented: full (metrics table evaluation, kill report, enhancement
    priorities, falsification test over the current window).

    Trace: Blueprint section 5.2 (metrics table), section 5.3 (kill
        criteria); audit #137-#144 (report generation, audit pointers).
    """

    name: str = "eval.report"

    def __init__(self, config: Config) -> None:
        """Initialize the reporter from validated config.

        Implemented: full.

        Trace: Blueprint section 5.2; SPEC section 4.2 (eval.*).
        """
        self._config = config
        self._pred_err_pvalue = float(config.get("eval.pred_err_pvalue", 0.01))
        self._novel_goals_min = float(config.get("eval.novel_goals_min", 3))
        self._cycles_long_run = int(config.get("eval.cycles_long_run", 1_000_000))
        self._template_lock_max = float(
            config.get("safety.template_lock_max", 0.05)
        )
        self._ece_halt = float(config.get("self_model.ece_halt", 0.2))
        self._last_metrics: Optional[Dict[MetricName, float]] = None
        self._last_kill_report: Optional[KillReport] = None

    def metrics_table(self, metrics: Dict[MetricName, float]) -> List[FalsificationResult]:
        """Evaluate every metric against its section 5.2 threshold.

        Implemented: full.

        Trace: Blueprint section 5.2 (metrics table).
        """
        results = []
        for spec in METRICS_TABLE:
            if spec.name not in metrics:
                results.append(FalsificationResult(
                    name=f"eval.metric.{spec.name.value}",
                    passed=False,
                    metric=float("nan"),
                    threshold=spec.threshold,
                    detail=f"unmeasured ({spec.rationale})",
                ))
                continue
            value = metrics[spec.name]
            results.append(FalsificationResult(
                name=f"eval.metric.{spec.name.value}",
                passed=_compare(value, spec.comparison, spec.threshold),
                metric=value,
                threshold=spec.threshold,
                detail=spec.rationale,
            ))
        return results

    def kill_report(self, metrics: Dict[MetricName, float],
                    template_rate: float) -> KillReport:
        """Evaluate the five kill criteria.

        Implemented: full. A criterion fires only when its metric was
        actually measured and violates (unmeasured metrics cannot kill, but
        they also cannot support a claim — see StageEstimator).

        Trace: Blueprint section 5.3 (kill criteria); Part 8 failure mode 7
            (template lock > 5% kills the claim).
        """
        fired: List[KillCriterion] = []
        slope = metrics.get(MetricName.PREDICTION_ERROR_SLOPE)
        if slope is not None and slope >= 0.0:
            fired.append(KillCriterion.PREDICTION_NOT_DECREASING)
        ece = metrics.get(MetricName.ECE_SELF_MODEL)
        if ece is not None and ece > self._ece_halt:
            fired.append(KillCriterion.SELF_MODEL_LIES)
        gain = metrics.get(MetricName.TRANSFER_GAIN)
        if gain is not None and abs(gain) <= 1e-9:
            fired.append(KillCriterion.TRANSFER_SPURIOUS)
        goals = metrics.get(MetricName.NOVEL_GOALS)
        if goals is not None and goals < self._novel_goals_min:
            fired.append(KillCriterion.NO_NOVEL_GOALS)
        violations = metrics.get(MetricName.SAFETY_VIOLATIONS)
        if violations is not None and violations > 0.0:
            fired.append(KillCriterion.SAFETY_VIOLATED)
        if template_rate > self._template_lock_max:
            fired.append(KillCriterion.TEMPLATE_LOCKED)  # failure mode 7
        self._last_metrics = dict(metrics)
        self._last_kill_report = KillReport(fired=fired)
        return self._last_kill_report

    def enhancement_priorities(self, metrics: Dict[MetricName, float]) -> List[str]:
        """Rank subsystem improvements by distance-to-threshold.

        Implemented: full — each measured metric's normalized gap to its
        threshold (signed so failing metrics rank first), sorted descending,
        mapped to owning subsystems; unmeasured metrics rank last in table
        order.

        Trace: Phi-Lite feature #140 (enhancement priority list); audit
            #138.
        """

        def gap(spec: MetricSpec) -> float:
            if spec.name not in metrics:
                return float("-inf")
            value = metrics[spec.name]
            scale = abs(spec.threshold) + 1e-9
            if spec.comparison in ("lt", "le"):
                return (value - spec.threshold) / scale
            if spec.comparison in ("gt", "ge"):
                return (spec.threshold - value) / scale
            return abs(value - spec.threshold) / scale

        ranked = sorted(METRICS_TABLE, key=gap, reverse=True)
        owners: List[str] = []
        for spec in ranked:
            owner = _METRIC_OWNERS[spec.name]
            if owner not in owners:
                owners.append(owner)
        return owners

    def falsification_test(self) -> FalsificationResult:
        """The reporting layer passes iff it produced a complete, honest report.

        Implemented: full — passes iff all six metrics were measured in the
        current window and the kill report was computed for it.

        Trace: SPEC section 4.1 (Falsifiable protocol); Blueprint section
            5.2/5.3.
        """
        complete = (
            self._last_metrics is not None
            and all(spec.name in self._last_metrics for spec in METRICS_TABLE)
            and self._last_kill_report is not None
        )
        measured = 0 if self._last_metrics is None else len(self._last_metrics)
        return FalsificationResult(
            name="eval.report.complete",
            passed=complete,
            metric=float(measured),
            threshold=float(len(METRICS_TABLE)),
            detail="all six protocol metrics measured and kill report computed",
        )


__all__ = [
    "MetricName",
    "MetricSpec",
    "METRICS_TABLE",
    "KillCriterion",
    "KillReport",
    "template_lock_rate",
    "StageEstimator",
    "MetricsReporter",
    "SCALAR_RUN_HEADER",
    "render_scalar_metrics_table",
]
```

----------------------------------------

### File: `transfer.py`

**Path:** `stage4/stage4/eval/transfer.py`
**Extension:** `.py`
**Size:** 4,997 bytes (4.88 KB)

```py
"""A -> B transfer gain measurement (Blueprint Part 1.2).

Transfer is the only honest definition of "general": skill k learned on task
T_a reduces sample complexity on task T_b,

    E[n_{T_b} | prior T_a] < E[n_{T_b} | no prior]

with the gap statistically significant across >= 20 task pairs.  Failure
mode 5 (spurious transfer) is countered by reporting PER-PAIR gains, not
just the mean: the claim dies if the gain disappears on adversarial pairs.

Traceability:
  - Blueprint Part 1.2 (transfer definition), section 5.2 (transfer gain >
    0 on >= 15/20 pairs), Part 8 failure mode 5 (per-pair reporting)
  - SPEC section 4.2 (eval.transfer_pairs_min = 15)
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Sequence, Tuple

from stage4.config import Config
from stage4.core.types import FalsificationResult


@dataclass
class TransferPair:
    """One ordered A -> B transfer pair.

    Attributes:
        source_task: task A identifier (skill source).
        target_task: task B identifier (skill target).
        samples_with_prior: sample complexities n_B measured after learning A.
        samples_without_prior: sample complexities n_B measured from scratch.

    Trace: Blueprint Part 1.2 (E[n_B | prior A] < E[n_B | no prior]).
    """

    source_task: str
    target_task: str
    samples_with_prior: List[float] = field(default_factory=list)
    samples_without_prior: List[float] = field(default_factory=list)


@dataclass
class PairGain:
    """Per-pair transfer gain with significance (failure mode 5 counter).

    Trace: Blueprint Part 8 failure mode 5 (report per-pair gain, not just
        mean).
    """

    pair: TransferPair
    gain: float
    significant: bool
    p_value: float


def transfer_gain(samples_with_prior: Sequence[float],
                  samples_without_prior: Sequence[float]) -> float:
    """Gain = E[n_B | no prior] - E[n_B | prior A] (positive means transfer).

    Trace: Blueprint Part 1.2 (sample-complexity reduction).
    """
    raise NotImplementedError(
        "spec: return mean(samples_without_prior) - mean(samples_with_prior)"
    )


def welch_t_test(a: Sequence[float], b: Sequence[float]) -> Tuple[float, float]:
    """Welch's t statistic and two-sided p-value for unequal variances.

    Trace: Blueprint Part 1.2 (gap statistically significant across >= 20
        task pairs); SPEC section 4.2 (eval.pred_err_pvalue = 0.01).
    """
    raise NotImplementedError(
        "spec: compute Welch's t, degrees of freedom via Welch-Satterthwaite, "
        "and the two-sided p-value from the t distribution (stdlib math only)"
    )


class TransferExperiment:
    """Runs the A -> B transfer protocol over the registered pairs.

    Trace: Blueprint Part 1.2, section 5.2 (transfer gain > 0 on >= 15/20
        pairs); SPEC section 4.2 (eval.transfer_pairs_min).
    """

    name: str = "eval.transfer"

    def __init__(self, config: Config) -> None:
        """Initialize the experiment from validated config.

        Trace: Blueprint Part 1.2; SPEC section 4.2
            (eval.transfer_pairs_min = 15).
        """
        self._config = config
        raise NotImplementedError(
            "spec: allocate the pair registry; require >= "
            "eval.transfer_pairs_min pairs before claiming"
        )

    def register_pair(self, pair: TransferPair) -> None:
        """Register one ordered A -> B pair.

        Trace: Blueprint Part 1.2 (pairs share latent structure).
        """
        raise NotImplementedError("spec: append to the pair registry")

    def evaluate_pair(self, pair: TransferPair) -> PairGain:
        """Measure the gain and significance for one pair.

        Trace: Blueprint Part 1.2; Part 8 failure mode 5 (per-pair gain).
        """
        raise NotImplementedError(
            "spec: transfer_gain plus welch_t_test; significant iff "
            "p < eval.pred_err_pvalue and gain > 0"
        )

    def run(self) -> List[PairGain]:
        """Evaluate every registered pair; return per-pair gains.

        Trace: Blueprint Part 8 failure mode 5 (per-pair reporting, the
            mean alone is insufficient).
        """
        raise NotImplementedError(
            "spec: map evaluate_pair over the registry"
        )

    def falsification_test(self) -> FalsificationResult:
        """Kill criterion: gain > 0 on >= 15/20 pairs, else transfer is spurious.

        Trace: Blueprint section 5.2 (transfer gain > 0 on >= 15/20 pairs),
            Part 5.3 (transfer gain indistinguishable from zero kills the
            claim); SPEC section 4.2 (eval.transfer_pairs_min).
        """
        raise NotImplementedError(
            "spec: pass iff the count of positive significant PairGains "
            ">= eval.transfer_pairs_min out of >= 20 pairs"
        )


__all__ = [
    "TransferPair",
    "PairGain",
    "transfer_gain",
    "welch_t_test",
    "TransferExperiment",
]
```

----------------------------------------

##### Directory: `stage4/stage4/eval/__pycache__`


#### Directory: `stage4/stage4/__pycache__`


#### Directory: `stage4/stage4/world_model`


### File: `__init__.py`

**Path:** `stage4/stage4/world_model/__init__.py`
**Extension:** `.py`
**Size:** 1,294 bytes (1.26 KB)

```py
"""L5 World Model — Dreamer-style RSSM, losses, and causal layer (Blueprint §3.2).

This package replaces Phi-Lite's hand-rolled GRU (feature #60) with a proper
recurrent state-space model: posterior q_phi, prior p_theta, and latent-space
prediction. "Prediction is done in latent space, not on raw b. This is the
single largest change from Phi-Lite." (Blueprint §3.2)

Modules:
  rssm.py   — recurrent state-space model (posterior/prior/imagination)
  loss.py   — reconstruction + KL (free bits, annealed) + reward loss
  causal.py — interventional/counterfactual world model, do-calculus (Eq #68)

Anti-collapse discipline: KL free bits + KL annealing + dropout on z
(Blueprint failure mode 1; config world_model.kl_free_bits / dropout_z).

Traceability:
  - Blueprint §3.2 (L5), failure mode 1, Part 10 rule 2
  - Eq #68 (do-calculus), Eq #48 (recurrent state snapshotting)
  - Audit #51 ("world_model is not an actual model"), Audit #120 (no causal graph)
"""

from __future__ import annotations

from stage4.world_model.rssm import RSSM, RSSMState
from stage4.world_model.loss import WorldModelLoss
from stage4.world_model.causal import CausalWorldModel, Intervention

__all__ = [
    "RSSM",
    "RSSMState",
    "WorldModelLoss",
    "CausalWorldModel",
    "Intervention",
]
```

----------------------------------------

### File: `causal.py`

**Path:** `stage4/stage4/world_model/causal.py`
**Extension:** `.py`
**Size:** 6,126 bytes (5.98 KB)

```py
"""Interventional / counterfactual world model — do-calculus (Eq #68, audit #120).

Audit #120: "No causal graph or structural equations." Phi-Lite's CCF scored
counterfactuals with arbitrary formulas over independent random draws (audits
#121-#124). This module replaces that with a structural causal model (SCM)
layer on top of the RSSM:

  - a causal graph over latent factors with structural equations,
  - interventional queries P(z' | do(a)) estimated by the predictor (Eq #68),
  - counterfactual queries with abduction-action-prediction consistency
    (fixes audit #124: no counterfactual consistency),
  - an influence cost charged per query (audit #126).

The quantum/observer package hosts the CCF successor; this module provides
the causal substrate it queries (SPEC §5 mapping: CCF successor ->
quantum/observer.py; do-calculus Eq #68 -> world_model/causal.py).

Traceability:
  - Eq #68 (causal impact via do-calculus: P(b' | do(a)) estimated by predictor)
  - Audit #120 (no causal graph/structural equations), #121-#124 (arbitrary
    counterfactual scoring), #126 (no cost for influence)
  - Blueprint §3.2 (latent dynamics substrate)
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, Dict, List, Optional, Tuple

from stage4.config import Config
from stage4.core.types import FalsificationResult

if TYPE_CHECKING:
    from phitensor import Tensor


@dataclass
class Intervention:
    """A do-operator request: fix variable(s) to value(s), severing parents.

    ``cost`` is charged per execution (audit #126: no free retrocausal
    influence); ``depth`` bounds the rollout horizon (audit #127: depth was
    fixed — here it is explicit per query).
    """

    variable: str
    value: Any
    depth: int
    cost: float = 0.0


@dataclass
class CausalEstimate:
    """Result of an interventional or counterfactual query."""

    intervention: Intervention
    predicted_effect: Any      # phitensor.Tensor over latent z'
    confidence: float          # calibrated, from self_model.calibration (named only)
    consistent: bool           # counterfactual consistency check (audit #124)
    detail: Dict[str, Any] = field(default_factory=dict)


class CausalWorldModel:
    """Structural causal layer over the RSSM latent dynamics.

    Collaborators (named, never imported): world_model.rssm.RSSM provides the
    latent transition substrate; self_model.calibration provides confidence.

    Trace: Eq #68; Audit #120-#127; Blueprint §3.2
    """

    name: str = "world_model.causal"

    def __init__(self, config: Config) -> None:
        """Bind config: influence cost (ccf.influence_cost), max depth.

        Trace: Audit #126/#127; stage4.config DEFAULT_CONFIG["ccf"]
        """
        self._config = config
        self.influence_cost: float = float(config.get("ccf.influence_cost", 0.02))
        self.max_depth: int = int(config.get("ccf.simulation_depth", 5))

    def fit_structure(self, trajectories: List[Any]) -> Dict[str, List[str]]:
        """Learn the causal graph over latent factors from trajectories.

        Structure discovery (NOTEARS-style, enhancement report #44) over
        RSSM latents and action variables; returns an adjacency map.

        Trace: Audit #120; 48-enhancement #44 (NOTEARS/DAG-GNN)
        """
        raise NotImplementedError(
            "spec: continuous DAG learning over (z factors, actions) with "
            "acyclicity penalty; stdlib/phitensor only"
        )

    def structural_equations(self) -> Dict[str, Any]:
        """Return the fitted structural equation per node (audit #120).

        Trace: Audit #120 (structural equations, not random draws)
        """
        raise NotImplementedError(
            "spec: map node -> parameterized mechanism f_i(parents, noise)"
        )

    def intervene(self, state: Any, intervention: Intervention) -> CausalEstimate:
        """Estimate P(z' | do(a)) by truncated factorization (Eq #68).

        Rolls the RSSM prior forward with the intervened variable clamped,
        its incoming edges severed. Charges intervention.cost against the
        energy budget (audit #126); rejects depth > max_depth (audit #127).

        Trace: Eq #68; Audit #120/#126/#127
        """
        raise NotImplementedError(
            "spec: do-operator: clamp variable, sever parents, rollout RSSM "
            "prior for intervention.depth steps; charge cost"
        )

    def counterfactual(self, observed: Any, intervention: Intervention) -> CausalEstimate:
        """Abduction-action-prediction counterfactual with consistency check.

        Abduction: infer the exogenous noise explaining the observed outcome.
        Action: apply the intervention. Prediction: re-roll with the same
        noise. ``consistent`` verifies the counterfactual reproduces the
        observation under the null intervention (audit #124).

        Trace: Audit #123/#124 (no independent random draws; consistency)
        """
        raise NotImplementedError(
            "spec: abduction-action-prediction over SCM; verify consistency "
            "by re-simulating the factual with inferred noise"
        )

    def average_treatment_effect(self, state: Any, action_a: Any, action_b: Any) -> float:
        """ATE between two candidate actions via paired interventions.

        Replaces Phi-Lite's arbitrary with/without_score formulas (audit #121)
        with paired do-queries scored by predicted latent error.

        Trace: Audit #121; Phi-Lite feature #24 (ATE counterfactual planning)
        """
        raise NotImplementedError(
            "spec: E[effect | do(a)] - E[effect | do(b)] from paired intervene()"
        )

    def falsification_test(self) -> FalsificationResult:
        """Interventions must predict held-out manipulated data better than observational fit.

        Trace: Audit #120; Blueprint Part 5.3
        """
        raise NotImplementedError(
            "spec: on held-out data with known manipulations, do-estimates must "
            "beat observational conditionals; else fail"
        )
```

----------------------------------------

### File: `loss.py`

**Path:** `stage4/stage4/world_model/loss.py`
**Extension:** `.py`
**Size:** 4,695 bytes (4.58 KB)

```py
"""World-model losses: reconstruction + KL consistency (free bits) + reward (Blueprint §3.2).

    L_WM = -log p_theta(o_t | z_t)        (reconstruction)
         + KL(q_phi || p_theta)           (consistency)
         + ||r_hat_t - r_t||^2            (reward)

Posterior collapse (Blueprint failure mode 1: "world model collapses to
identity / p_theta(o|z) becomes a lookup table") is fought structurally:

  - **Free bits**: per-dimension KL is clamped below at
    ``world_model.kl_free_bits`` nats (default 1.0), so the posterior keeps
    encoding information instead of collapsing to the prior.
  - **KL annealing**: the KL weight beta ramps 0 -> 1 over a configured number
    of steps so early training is reconstruction-dominated.
  - **Dropout on z**: configured in rssm.py (world_model.dropout_z).

Traceability:
  - Blueprint §3.2 (L_WM), failure mode 1 (KL annealing, dropout on z)
  - stage4.config world_model.kl_free_bits
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, Dict, Tuple

from stage4.config import Config

if TYPE_CHECKING:
    from phitensor import Tensor


@dataclass
class LossBreakdown:
    """Per-term loss values for logging and collapse diagnostics.

    ``kl_raw`` is the unclamped KL; ``kl_used`` is after free-bits clamping
    and annealing. Monitoring kl_raw ~= 0 is the collapse alarm
    (failure mode 1).
    """

    reconstruction: float
    kl_raw: float
    kl_used: float
    reward: float
    total: float
    beta: float  # current KL annealing weight in [0, 1]


class WorldModelLoss:
    """Computes L_WM with free bits and KL annealing.

    Trace: Blueprint §3.2, failure mode 1; config world_model.kl_free_bits
    """

    def __init__(self, config: Config) -> None:
        """Bind config: kl_free_bits=1.0, annealing schedule, reward weight.

        Trace: stage4.config DEFAULT_CONFIG["world_model"]
        """
        self._config = config
        self.kl_free_bits: float = float(config.get("world_model.kl_free_bits", 1.0))
        self._anneal_steps: int = int(config.get("world_model.kl_anneal_steps", 10_000))
        self._step: int = 0

    def kl_annealing_weight(self, step: int) -> float:
        """Linear 0 -> 1 ramp of the KL weight beta (failure mode 1 fix).

        Trace: Blueprint failure mode 1 (KL annealing)
        """
        raise NotImplementedError(
            "spec: beta = min(1.0, step / kl_anneal_steps); monotonic ramp"
        )

    def kl_with_free_bits(self, q_mean: Tensor, q_std: Tensor, p_mean: Tensor, p_std: Tensor) -> Tensor:
        """Per-dimension Gaussian KL clamped below at kl_free_bits nats.

        Computes KL(q_phi || p_theta) per latent dim via
        phitensor.ops.kl_divergence, then applies max(kl_i, free_bits) and
        sums — the standard anti-collapse free-bits objective.

        Trace: Blueprint failure mode 1; config world_model.kl_free_bits
        """
        raise NotImplementedError(
            "spec: kl_i = 0.5*(log(p_std^2/q_std^2) + (q_std^2+(q_mean-p_mean)^2)"
            "/p_std^2 - 1); sum_i max(kl_i, free_bits)"
        )

    def reconstruction_loss(self, obs: Tensor, obs_hat: Tensor) -> Tensor:
        """-log p_theta(o_t | z_t); Gaussian or Bernoulli head per modality.

        Trace: Blueprint §3.2 (reconstruction term)
        """
        raise NotImplementedError("spec: phitensor.ops.mse_loss or Gaussian NLL")

    def reward_loss(self, r_hat: Tensor, r: Tensor) -> Tensor:
        """||r_hat_t - r_t||^2 reward-prediction term.

        Trace: Blueprint §3.2 (reward term)
        """
        raise NotImplementedError("spec: phitensor.ops.mse_loss(r_hat, r)")

    def total(
        self,
        obs: Tensor,
        obs_hat: Tensor,
        q_mean: Tensor,
        q_std: Tensor,
        p_mean: Tensor,
        p_std: Tensor,
        r_hat: Tensor,
        r: Tensor,
    ) -> LossBreakdown:
        """Full L_WM with current annealing weight; returns the breakdown.

        Advances the internal annealing step counter once per call.

        Trace: Blueprint §3.2 L_WM, failure mode 1
        """
        raise NotImplementedError(
            "spec: recon + beta(step)*free_bits_kl + reward; return "
            "LossBreakdown; self._step += 1"
        )

    def collapse_alarm(self, history: Tuple[LossBreakdown, ...]) -> bool:
        """Detect posterior collapse: kl_raw ~ 0 while recon plateaus.

        Feeds the failure-mode-1 response (raise dropout_z, reset beta).

        Trace: Blueprint failure mode 1
        """
        raise NotImplementedError(
            "spec: True iff mean kl_raw over window < eps and recon slope ~ 0"
        )
```

----------------------------------------

### File: `rssm.py`

**Path:** `stage4/stage4/world_model/rssm.py`
**Extension:** `.py`
**Size:** 6,655 bytes (6.50 KB)

```py
"""Dreamer-style recurrent state-space model (Blueprint §3.2).

Latent dynamics in the style of Dreamer/PlaNet:

    z_t     ~ q_phi(z_t | z_{t-1}, a_{t-1}, o_t)     (posterior)
    z_hat_t ~ p_theta(z_hat_t | z_{t-1}, a_{t-1})    (prior)

Prediction happens in latent space, not on raw b — the single largest change
from Phi-Lite's hand-rolled GRU (feature #60, audit #51: "world_model is not
an actual model"). The prior supports imagination rollouts for the policy
(L3) and the meta-controller's EFE scoring (L7, Eq #72) without touching the
environment.

Anti-collapse (Blueprint failure mode 1): dropout on z during training and a
diagonal-covariance stochastic latent; KL handling lives in loss.py.

Recurrent state h is snapshotted and restorable by interpolation
(h <- (1-t) h_a + t h_b, Eq #48) so long runs can checkpoint dynamics.

Traceability:
  - Blueprint §3.2 (L5 world model), Part 4 (fast/medium loops), failure mode 1
  - Eq #48 (recurrent state snapshotting), Eq #72 (EFE consumer, downstream)
  - Audit #51 (world model must be an actual model)
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, Dict, List, Optional, Tuple

from stage4.config import Config
from stage4.core.types import FalsificationResult, LayerIO

if TYPE_CHECKING:
    from phitensor import Tensor


@dataclass
class RSSMState:
    """Full recurrent + stochastic latent state at time t.

    ``h`` is the deterministic recurrent state (dim = world_model.hidden_dim,
    default 256); ``z_mean``/``z_std`` parameterize the diagonal Gaussian
    stochastic latent (dim = world_model.latent_dim, default 128).
    """

    h: Any          # phitensor.Tensor, shape (hidden_dim,)
    z_mean: Any     # phitensor.Tensor, shape (latent_dim,)
    z_std: Any      # phitensor.Tensor, shape (latent_dim,)
    z_sample: Any   # phitensor.Tensor, shape (latent_dim,)
    cycle: int = 0


class RSSM:
    """Recurrent state-space model: posterior q_phi, prior p_theta, imagination.

    Trace: Blueprint §3.2; Audit #51; Eq #48
    """

    name: str = "world_model.rssm"

    def __init__(self, config: Config) -> None:
        """Bind config: latent_dim=128, hidden_dim=256, dropout_z=0.1.

        Trace: stage4.config DEFAULT_CONFIG["world_model"]; Blueprint failure mode 1
        """
        self._config = config
        self.latent_dim: int = int(config.get("world_model.latent_dim", 128))
        self.hidden_dim: int = int(config.get("world_model.hidden_dim", 256))
        self.dropout_z: float = float(config.get("world_model.dropout_z", 0.1))

    def initial_state(self) -> RSSMState:
        """Return the prior state at t=0 (zero h, unit Gaussian z).

        Trace: Blueprint §3.2
        """
        raise NotImplementedError(
            "spec: h=0 (hidden_dim), z ~ N(0, I_latent); seeded via "
            "phitensor.rng.spawn('rssm')"
        )

    def posterior(self, prev: RSSMState, action: Tensor, obs: Tensor) -> RSSMState:
        """Posterior step: z_t ~ q_phi(z_t | z_{t-1}, a_{t-1}, o_t).

        Fuses the observation (fused percept from perception.fusion) with the
        deterministic recurrent path; applies dropout_z to z during training
        (failure mode 1 mitigation).

        Trace: Blueprint §3.2 (posterior), failure mode 1
        """
        raise NotImplementedError(
            "spec: h_t = GRU(h_{t-1}, [z_{t-1}, a_{t-1}]) via phitensor.ops; "
            "q_phi head over [h_t, o_t] -> (z_mean, z_std); reparameterize"
        )

    def prior(self, prev: RSSMState, action: Tensor) -> RSSMState:
        """Prior step: z_hat_t ~ p_theta(z_hat_t | z_{t-1}, a_{t-1}).

        No observation access — this is the model's pure prediction and the
        target of the KL consistency loss (loss.py, free bits).

        Trace: Blueprint §3.2 (prior)
        """
        raise NotImplementedError(
            "spec: h_t = GRU(h_{t-1}, [z_{t-1}, a_{t-1}]); p_theta head over "
            "h_t -> (z_mean, z_std); reparameterize"
        )

    def decode_observation(self, state: RSSMState) -> Tensor:
        """Reconstruction head: p_theta(o_t | z_t) for the recon loss.

        Trace: Blueprint §3.2 L_WM reconstruction term
        """
        raise NotImplementedError(
            "spec: decoder MLP/conv-transpose over [h_t, z_t] -> o_hat_t"
        )

    def predict_reward(self, state: RSSMState) -> Tensor:
        """Reward head: r_hat_t from latent state (reward term of L_WM).

        Trace: Blueprint §3.2 L_WM reward term
        """
        raise NotImplementedError("spec: scalar reward head over [h_t, z_t]")

    def imagine(self, start: RSSMState, actions: List[Tensor]) -> List[RSSMState]:
        """Open-loop latent rollout under a candidate action sequence.

        Used by policy options (L3) and EFE scoring in the meta-controller
        (L7, Eq #72) — collaborators named only, never imported.

        Trace: Blueprint §3.2 (latent prediction), §3.5, §3.6; Eq #72
        """
        raise NotImplementedError(
            "spec: iterate prior() over actions without observations; return "
            "state trajectory"
        )

    def snapshot(self) -> Dict[str, Any]:
        """Serialize (h, z) for 1 Hz persistence (Eq #48).

        Trace: Eq #48 (recurrent state snapshotting)
        """
        raise NotImplementedError("spec: phitensor.io.save compatible dict")

    def restore_interpolated(self, snap_a: Dict[str, Any], snap_b: Dict[str, Any], t: float) -> RSSMState:
        """Restore h by interpolation h <- (1-t) h_a + t h_b (Eq #48).

        Trace: Eq #48
        """
        raise NotImplementedError("spec: convex interpolation of h between snapshots")

    def step(self, inp: LayerIO) -> LayerIO:
        """LayerIO contract: (obs, action) in -> posterior state + predictive variance.

        Uncertainty is the prior predictive variance (trace of z_std^2) —
        nothing crosses to L6/L3 without it (Blueprint Part 2).

        Trace: Blueprint Part 2, §3.2
        """
        raise NotImplementedError(
            "spec: posterior step on inp.meta['obs'], inp.meta['action']; "
            "LayerIO(state=RSSMState, uncertainty=sum z_std^2, cost=flops)"
        )

    def falsification_test(self) -> FalsificationResult:
        """Blueprint §3.2 test: held-out L_WM slope < 0 at p < 0.01 over 1e5 steps.

        Trace: Blueprint §3.2 (test), Part 5.3 (kill criteria)
        """
        raise NotImplementedError(
            "spec: regression of held-out world-model loss over >= 1e5 gradient "
            "steps; pass iff slope < 0 with p < 0.01"
        )
```

----------------------------------------

##### Directory: `stage4/stage4/world_model/__pycache__`


#### Directory: `stage4/stage4/core`


### File: `__init__.py`

**Path:** `stage4/stage4/core/__init__.py`
**Extension:** `.py`
**Size:** 1,012 bytes (0.99 KB)

```py
"""Core package: shared contracts, neurocognitive state, modes, master loop, energy.

Submodules:
  - types  : pinned shared contracts (SystemMode, LayerIO, Layer, ...). DO NOT MODIFY.
  - state  : NeuroCognitiveState — P/B/T axes and neuro_coord vector (Levantine L1-L8).
  - modes  : DDMS decoherence-driven mode switching with dwell + hysteresis (audit #116/#117).
  - loop   : master sense-predict-act-residual-mutate-remember cycle (Blueprint Part 2).
  - energy : homeostasis, collapse, Landauer-aware accounting (audit #81-96, Eq #1-14).

Trace: SPEC.md §3 canonical tree; Blueprint Part 2 (layer contract).
"""

from __future__ import annotations

from stage4.core.types import (
    Commitment,
    CommitmentLevel,
    Falsifiable,
    FalsificationResult,
    GoalSpec,
    Layer,
    LayerIO,
    Scar,
    SystemMode,
)

__all__ = [
    "Commitment",
    "CommitmentLevel",
    "Falsifiable",
    "FalsificationResult",
    "GoalSpec",
    "Layer",
    "LayerIO",
    "Scar",
    "SystemMode",
]
```

----------------------------------------

### File: `energy.py`

**Path:** `stage4/stage4/core/energy.py`
**Extension:** `.py`
**Size:** 20,271 bytes (19.80 KB)

```py
"""Energy, homeostasis, collapse, and thermodynamic accounting.

Fixes the v7.1 energy/collapse shortcomings (audit #81-96) and hosts the
desire/homeostasis equation ledger block (Eq #1-14) plus the Landauer
accounting pair (Eq #101/#102):

  - #81/#84: energy is clamped non-negative on *every* mutation path, and the
    post-collapse reset `budget * (1 - permanent_damage)` is itself floored
    above `collapse_threshold` so immediate recollapse is impossible (#20).
  - #82/#89: permanent_damage is clamped to [0, 1] after every update; the
    collapse probability term uses the clamped value.
  - #85/#94: energy is allocated, not just spent — water-filling allocation
    across subsystem variances (Eq #10) and a homeostatic potential (Eq #4)
    drive regeneration policy hooks.
  - #91: terminal death state exists: at permanent_damage == 1.0 the ledger
    is dead and `step` refuses further metabolism.
  - #95: cognitive cost is modulated by the active ModePolicy from
    `core.modes`, not constant.
  - #96: the MAP energy-efficiency penalty is bounded by config.

Lyapunov gating (Eq #2): V(e, f) = (1-e)^2 + f^2; SPEAK-class costly actions
are gated on dV <= 0. Landauer-aware accounting (Eq #101/#102) charges
k_B * T * ln2 per erased bit whenever memory systems (referenced by name:
`memory.ledger`, `memory.narrative`) forget.

Implemented: full scalar ledger — clamped spend/reward, metabolic multiplier
(Eq #3), homeostatic potential (Eq #4), fatigue (Eq #9), water-filling
(Eq #10), deterministic collapse with clamped permanent damage and safe
reset (#20/#81-#92), death state (#91), Landauer hook counters
(Eq #101/#102), per-cycle `step` tick with mode-scaled cognitive cost (#95),
emergence-debt-scaled decay (#27) and bounded MAP penalty (#96).
Deviation notes: collapse damage is deterministic (low end of v7.1's
uniform(0.1, penalty) range, capped by `energy.collapse_permanent_penalty`)
because audit #82 forbids drawing randomness here; the damage-pressure
trigger is the clamped v7.1 term `permanent_damage * 0.5 >= 0.49`.

Trace: Audit #19/#20/#81-#96; Eq #1-#14, #101, #102; Enhancement B.9/B.10/
B.15/B.16; v7.1 thermodynamics.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from stage4.config import Config
from stage4.core.modes import ModePolicy
from stage4.core.types import FalsificationResult, LayerIO

#: Boltzmann-scaled unit cost constant for Landauer accounting (simulation
#: units; the ledger is a *model* of heat cost, not physical joules).
LANDAUER_KT_LN2: float = 0.6931471805599453  # k_B * T * ln(2) at unit k_B*T

#: Deterministic collapse damage delta: below the low end of v7.1's
#: uniform(0.1, penalty) draw, because (a) audit #82 forbids drawing
#: randomness inside the ledger and (b) the audit-fixed safe reset (#20/#84)
#: makes each collapse strictly less catastrophic than v7.1's buggy reset.
#: Still capped by `energy.collapse_permanent_penalty`.
COLLAPSE_DAMAGE_BASE: float = 0.075

#: Damage-pressure collapse trigger: the clamped v7.1 term
#: `permanent_damage * 0.5` collapses the system when it reaches this bound.
DAMAGE_PRESSURE_TRIGGER: float = 0.49

#: Bound on the MAP energy-efficiency penalty rate per cycle (fixes #96).
MAP_PENALTY_RATE_CAP: float = 0.05


@dataclass
class CollapseEvent:
    """Structured record of one collapse (fixes audit #83/#140 visibility).

    Trace: Audit #83, #92, #140; v7.1 _check_collapse_risk.
    """

    cycle: int
    damage_delta: float
    total_damage: float
    affected_subsystem: str
    trigger: str  # "energy" | "damage_pressure"


@dataclass
class EnergyLedger:
    """Homeostatic energy ledger with collapse, death, and Landauer costs.

    Attributes:
        energy: Current energy, always in [0, effective_budget].
        permanent_damage: Irreversible damage, always clamped to [0, 1]
            (fixes audit #82/#89).
        fatigue: Drive fatigue f in [0, 1] following Eq #9 logistic recovery.
        alive: False once permanent_damage reaches 1.0 (fixes audit #91).
        collapse_log: Structured CollapseEvent history (fixes audit #83).
        landauer_total: Cumulative heat cost of forgetting (Eq #102).

    Implemented: full (see module docstring).

    Trace: Audit #81-#96; Eq #2-#4, #9-#11, #101-#102.
    """

    config: Config
    energy: float = 0.0
    permanent_damage: float = 0.0
    fatigue: float = 0.0
    alive: bool = True
    collapse_log: List[CollapseEvent] = field(default_factory=list)
    landauer_total: float = 0.0
    prev_lyapunov: Optional[float] = None

    def __post_init__(self) -> None:
        """Initialize energy to the configured budget.

        Implemented: full.

        Trace: Audit #16 (config-driven init); v7.1 __init__.
        """
        self.energy = float(self.config.get("energy.budget", 150.0))
        self.permanent_damage = min(1.0, max(0.0, float(self.permanent_damage)))
        self.fatigue = min(1.0, max(0.0, float(self.fatigue)))

    @property
    def effective_budget(self) -> float:
        """Budget reduced by permanent damage: budget * (1 - damage).

        Never below `energy.collapse_threshold + 1` while alive, so a reset
        cannot trigger immediate recollapse (fixes audit #20/#84).

        Implemented: full.

        Trace: Audit #19, #20, #84; v7.1 energy reset bug.
        """
        if not self.alive:
            return 0.0
        budget = float(self.config.get("energy.budget", 150.0))
        threshold = float(self.config.get("energy.collapse_threshold", 5.0))
        return max(budget * (1.0 - self.permanent_damage), threshold + 1.0)

    def _normalized_energy(self) -> float:
        """Energy as a fraction of the effective budget, in [0, 1].

        Trace: Eq #2/#4 (normalized homeostatic coordinate).
        """
        budget = self.effective_budget
        if budget <= 0.0:
            return 0.0
        return min(1.0, max(0.0, self.energy / budget))

    def homeostatic_potential(self, target_e: float, target_f: float,
                              sigma_e: float, sigma_f: float) -> float:
        """Homeostatic potential Phi_H (Eq #4).

        Phi_H = (e - e*)^2 / (2 sigma_e^2) + (f - f*)^2 / (2 sigma_f^2),
        using normalized energy e = energy / effective_budget. Policy layers
        (`policy.selection`, referenced by name) descend grad Phi_H.

        Implemented: full (sigmas floored at 1e-6 to avoid division by 0).

        Trace: Eq #4; Enhancement B.14/B.15.
        """
        sigma_e = max(1e-6, abs(sigma_e))
        sigma_f = max(1e-6, abs(sigma_f))
        e = self._normalized_energy()
        return (
            (e - target_e) ** 2 / (2.0 * sigma_e**2)
            + (self.fatigue - target_f) ** 2 / (2.0 * sigma_f**2)
        )

    def lyapunov(self) -> float:
        """Lyapunov energy function V(e, f) = (1-e)^2 + f^2 (Eq #2).

        Implemented: full.

        Trace: Eq #2; Enhancement D.26.
        """
        e = self._normalized_energy()
        return (1.0 - e) ** 2 + self.fatigue**2

    def lyapunov_gate(self) -> bool:
        """Gate costly (SPEAK-class) actions on dV <= 0 (Eq #2).

        Compares current V against the value stored at the previous cycle;
        returns True iff dV <= 0 (non-increasing Lyapunov function), else
        False. Updates prev_lyapunov. The gate is closed on the first call
        (no previous V exists to prove non-increase).

        Implemented: full.

        Trace: Eq #2; Enhancement D.26 (Lyapunov stability gating).
        """
        v_now = self.lyapunov()
        if self.prev_lyapunov is None:
            self.prev_lyapunov = v_now
            return False
        dv = v_now - self.prev_lyapunov
        self.prev_lyapunov = v_now
        return dv <= 0.0

    def _metabolic_multiplier(self) -> float:
        """Eq #3: mu = 1 + alpha*(1 - e) + beta*f.

        alpha/beta are derived from the config scale (`energy.decay_rate`
        x 10) so scarcity and fatigue raise metabolic cost in a
        config-traceable way (audit #16: no magic numbers).

        Trace: Eq #3; Audit #16.
        """
        scale = 10.0 * float(self.config.get("energy.decay_rate", 0.01))
        return 1.0 + scale * (1.0 - self._normalized_energy()) + scale * self.fatigue

    def spend(self, amount: float, policy: Optional[ModePolicy] = None,
              reason: str = "") -> float:
        """Spend energy with metabolic multiplier (Eq #3) and mode policy.

        Effective cost = amount * mu * policy.cost_multiplier, where
        mu = 1 + alpha*(1 - e) + beta*f (Eq #3; alpha/beta derived from
        config energy.decay_rate scale). Energy is clamped to >= 0 after the
        spend (fixes audit #81). Returns the actual amount spent. Refuses and
        returns 0.0 when not alive (audit #91).

        Implemented: full.

        Trace: Eq #3; Audit #81, #91, #95.
        """
        if not self.alive:
            return 0.0
        if amount <= 0.0:
            return 0.0
        multiplier = self._metabolic_multiplier()
        if policy is not None:
            multiplier *= policy.cost_multiplier
        cost = float(amount) * multiplier
        self.energy = max(0.0, self.energy - cost)
        return cost

    def reward(self, amount: float, reason: str = "") -> float:
        """Add energy, clamped to effective_budget (fixes audit #86 scaling).

        Implemented: full (no-op when not alive).

        Trace: Audit #85, #86; v7.1 prediction reward.
        """
        if not self.alive:
            return 0.0
        before = self.energy
        self.energy = min(self.effective_budget, self.energy + max(0.0, float(amount)))
        return self.energy - before

    def add_damage(self, amount: float) -> float:
        """Add permanent damage through the clamped channel (fixes #55/#65).

        Damage accumulates monotonically and is clamped to [0, 1]; reaching
        1.0 kills the ledger (#91). Returns the actual delta applied. This is
        the ONLY path by which subsystems (commitments, scars, SPEL costs)
        may inflict permanent damage.

        Implemented: full.

        Trace: Audit #55, #65, #82, #89, #91.
        """
        if not self.alive or amount <= 0.0:
            return 0.0
        delta = min(float(amount), 1.0 - self.permanent_damage)
        self.permanent_damage = min(1.0, max(0.0, self.permanent_damage + delta))
        if self.permanent_damage >= 1.0:
            self.alive = False
            self.energy = 0.0
        return delta

    def landauer_cost(self, bits_erased: float) -> float:
        """Heat cost of forgetting: Q = k_B T ln2 * N_bits (Eq #102).

        When `energy.landauer_aware` is set, the cost is also deducted from
        energy and accumulated in `landauer_total`; the Xi efficiency metric
        (Eq #101) in `eval.report` (referenced by name) consumes
        `landauer_total`. Called by `memory.ledger`/`memory.narrative`
        (referenced by name) on every compression/eviction.

        Implemented: full (deduction is a direct clamped charge, not routed
        through the metabolic multiplier — heat is heat).

        Trace: Eq #101, #102; Enhancement B.9 (Landauer-aware accounting);
        Audit #129-#136 (compression must pay).
        """
        q = LANDAUER_KT_LN2 * max(0.0, float(bits_erased))
        if self.alive and self.config.get("energy.landauer_aware", True):
            self.energy = max(0.0, self.energy - q)
            self.landauer_total += q
        return q

    def water_fill(self, variances: Dict[str, float],
                   budget: float) -> Dict[str, float]:
        """Variance-based energy allocation e_i* = max(0, 1/lambda - sigma_i^2).

        Implements water-filling (Eq #10): the level lambda is chosen so the
        allocations sum to `budget`; subsystems whose action variance exceeds
        1/lambda receive nothing. Used by `core.loop` to split the cycle's
        compute budget across subsystems (fixes audit #94: no budgeting).

        Implemented: full — bisection on the water level nu = 1/lambda
        (monotone in nu), 60 iterations.

        Trace: Eq #10; Audit #94; Enhancement B.15 (adaptive metabolic
        budgeting).
        """
        if not variances or budget <= 0.0:
            return {k: 0.0 for k in variances}
        lo, hi = 0.0, float(budget) + max(variances.values())
        for _ in range(60):
            mid = 0.5 * (lo + hi)
            total = sum(max(0.0, mid - v) for v in variances.values())
            if total < budget:
                lo = mid
            else:
                hi = mid
        level = 0.5 * (lo + hi)
        return {k: max(0.0, level - v) for k, v in variances.items()}

    def update_fatigue(self, action_cost: float) -> float:
        """Fatigue dynamics f_dot = eta*c(a) - gamma*f*(1-f) (Eq #9).

        Implemented: full — one explicit Euler step with
        eta = gamma = 10 * energy.decay_rate (config-traceable, audit #16),
        clamped to [0, 1].

        Trace: Eq #9 (usage-driven fatigue with logistic recovery).
        """
        rate = 10.0 * float(self.config.get("energy.decay_rate", 0.01))
        self.fatigue += rate * float(action_cost) - rate * self.fatigue * (1.0 - self.fatigue)
        self.fatigue = min(1.0, max(0.0, self.fatigue))
        return self.fatigue

    def check_collapse(self, cycle: int,
                       subsystem: str = "executive") -> Optional[CollapseEvent]:
        """Check and execute collapse with permanent, clamped damage.

        Collapse triggers iff energy < energy.collapse_threshold or the
        deterministic damage-pressure term `permanent_damage * 0.5` (the
        clamped value — audit #82; randomness is supplied by the caller's
        seeded rng, referenced from `phitensor.rng`, not drawn here) reaches
        DAMAGE_PRESSURE_TRIGGER. On collapse: damage delta is deterministic
        (COLLAPSE_DAMAGE_BASE, capped by energy.collapse_permanent_penalty)
        and clamped so total damage stays in [0, 1] (fixes #88/#89), energy
        resets to effective_budget (safe per #20/#84), a CollapseEvent is
        appended, and death occurs at damage == 1.0 (fixes #91). Called
        exactly once per cycle by `core.loop` (fixes audit #83).

        Implemented: full.

        Trace: Audit #20, #82, #83, #84, #88, #89, #91, #92.
        """
        if not self.alive:
            return None
        threshold = float(self.config.get("energy.collapse_threshold", 5.0))
        pressure = self.permanent_damage * 0.5  # v7.1 term, clamped value (#82)
        if self.energy < threshold:
            trigger = "energy"
        elif pressure >= DAMAGE_PRESSURE_TRIGGER:
            trigger = "damage_pressure"
        else:
            return None
        penalty = float(self.config.get("energy.collapse_permanent_penalty", 0.3))
        delta = min(COLLAPSE_DAMAGE_BASE, penalty, 1.0 - self.permanent_damage)
        self.permanent_damage = min(1.0, self.permanent_damage + delta)
        event = CollapseEvent(
            cycle=cycle,
            damage_delta=delta,
            total_damage=self.permanent_damage,
            affected_subsystem=subsystem,
            trigger=trigger,
        )
        self.collapse_log.append(event)
        if self.permanent_damage >= 1.0:
            self.alive = False
            self.energy = 0.0
        else:
            self.energy = self.effective_budget
        return event

    def step(self, inp: LayerIO) -> LayerIO:
        """Advance homeostasis one cycle under the LayerIO contract.

        Expects inp.meta keys: `mode_policy` (ModePolicy from core.modes),
        `action_cost` (float), optionally `bits_erased` (float from memory
        layers), `emergence_debt` (float from agency.emergence), and
        `emergence_level` (float). Applies the cognitive operation cost
        scaled by the mode policy (fixes #95), emergence-debt-scaled decay
        `decay_rate * (1 + debt) * energy` (v7.1 heritage, #27), the bounded
        MAP efficiency penalty (fixes #96), fatigue update (Eq #9), and the
        Landauer charge; returns LayerIO(state={'energy','fatigue','alive',
        ...}, uncertainty=homeostatic_potential, cost=total cycle cost).

        Implemented: full. Collapse is NOT checked here — `core.loop` calls
        `check_collapse` exactly once per cycle (fixes audit #83).

        Trace: Audit #81-#96; Eq #2-#4, #9, #101/#102; Blueprint Part 2.
        """
        if not self.alive:
            return LayerIO(
                state={"energy": 0.0, "fatigue": self.fatigue, "alive": False},
                uncertainty=self.homeostatic_potential(1.0, 0.0, 0.5, 0.5),
                cost=0.0,
                meta={"halted": True, "reason": "energy_dead"},
            )
        meta = inp.meta or {}
        policy = meta.get("mode_policy")
        action_cost = float(meta.get("action_cost", 0.0))
        debt = max(0.0, float(meta.get("emergence_debt", 0.0)))
        emergence_level = min(1.0, max(0.0, float(meta.get("emergence_level", 0.0))))
        bits_erased = float(meta.get("bits_erased", 0.0))

        total = 0.0
        # Cognitive operation cost, mode-scaled (#95).
        total += self.spend(
            float(self.config.get("energy.cognitive_operation_cost", 0.1)),
            policy=policy,
            reason="cognitive_operation",
        )
        # Emergence-debt-scaled decay (v7.1 _update_emergence_debt, #27).
        decay_rate = float(self.config.get("energy.decay_rate", 0.01))
        decay = decay_rate * (1.0 + debt) * self.energy
        self.energy = max(0.0, self.energy - decay)
        total += decay
        # Bounded MAP efficiency penalty (#96): higher emergence costs
        # efficiency, but the rate is capped (MAP_PENALTY_RATE_CAP).
        map_rate = min(MAP_PENALTY_RATE_CAP, 0.005 * emergence_level)
        map_penalty = map_rate * self.energy
        self.energy = max(0.0, self.energy - map_penalty)
        total += map_penalty
        # Fatigue (Eq #9) and Landauer heat (Eq #102).
        self.update_fatigue(action_cost)
        if bits_erased > 0.0:
            total += self.landauer_cost(bits_erased)
        # Final clamp on every bounded variable (#81/#82/#89 class).
        self.energy = min(self.effective_budget, max(0.0, self.energy))
        self.permanent_damage = min(1.0, max(0.0, self.permanent_damage))
        self.fatigue = min(1.0, max(0.0, self.fatigue))

        return LayerIO(
            state={
                "energy": self.energy,
                "fatigue": self.fatigue,
                "alive": self.alive,
                "permanent_damage": self.permanent_damage,
                "effective_budget": self.effective_budget,
            },
            uncertainty=self.homeostatic_potential(1.0, 0.0, 0.5, 0.5),
            cost=total,
            meta={"decay": decay, "map_penalty": map_penalty},
        )

    def falsification_test(self) -> FalsificationResult:
        """Kill criterion: all bounded invariants actually hold.

        Fails if energy < 0, energy > effective_budget + eps, or
        permanent_damage outside [0, 1] — i.e. if any clamp regressed
        (audit #81/#82/#89 class).

        Implemented: full.

        Trace: Audit #81/#82/#89; Blueprint Part 8.
        """
        eps = 1e-9
        violations = []
        if self.energy < -eps:
            violations.append(f"energy negative: {self.energy}")
        if self.alive and self.energy > self.effective_budget + eps:
            violations.append(
                f"energy {self.energy} above effective budget {self.effective_budget}"
            )
        if not (0.0 - eps <= self.permanent_damage <= 1.0 + eps):
            violations.append(f"damage out of [0,1]: {self.permanent_damage}")
        if not (0.0 - eps <= self.fatigue <= 1.0 + eps):
            violations.append(f"fatigue out of [0,1]: {self.fatigue}")
        return FalsificationResult(
            name="core.energy.bounds",
            passed=not violations,
            metric=float(len(violations)),
            threshold=0.0,
            detail="; ".join(violations) if violations else "all clamps hold",
        )


__all__ = ["LANDAUER_KT_LN2", "CollapseEvent", "EnergyLedger"]
```

----------------------------------------

### File: `loop.py`

**Path:** `stage4/stage4/core/loop.py`
**Extension:** `.py`
**Size:** 31,396 bytes (30.66 KB)

```py
"""Master agent cycle: sense -> predict -> act -> residual -> mutate -> remember.

`AgentLoop` is the top-level orchestrator that runs one full agency cycle per
`step`, threading a single `LayerIO` through the seven blueprint layers and
the v7.1 agency dynamics. It replaces the monolithic v7.1 `step()` with an
ordered, contract-honoring pipeline (fixes the audit #40 ordering complaint
and the audit #83 double-collapse call).

Pipeline stages (collaborators referenced by name only — SPEC §2 import rule;
they are wired in via constructor injection, never imported here):
  1. SENSE      — `perception.fusion` encodes sensors into LayerIO.
  2. PREDICT    — `world_model.rssm` predicts next latent; `self_model.spel`
                  computes self-prediction error (costed via core.energy).
  3. ACT        — `policy.selection` picks an action under EFE + Lyapunov
                  gating from `core.energy.EnergyLedger.lyapunov_gate` (Eq #2).
  4. RESIDUAL   — prediction residual feeds `agency.emergence`,
                  `agency.criticality`, and `neuro.axes` updates IN THIS
                  ORDER (emergence after residual, debt after emergence —
                  fixes audit #40).
  5. MUTATE     — `agency.commitments`, `agency.scars`, `neuro.hysteresis`
                  apply irreversible state changes; `core.modes` switches.
  6. REMEMBER   — `memory.narrative` (NBC) and `memory.crystal` persist;
                  bits erased are charged to the ledger via landauer_cost
                  (Eq #101/#102).
  7. REPEAT     — safety invariants checked via `safety.invariants`
                  (referenced by name) before the next cycle.

Implemented: full scalar cycle. The owned subsystems (NeuroCognitiveState,
ModeSwitchController, EnergyLedger) run directly; the agency collaborators
(agency.emergence, agency.criticality, agency.commitments, agency.scars)
are injected via `register` by `stage4.main` and driven through their
LayerIO step interfaces. While the tensor layers are stubbed, the loop
provides scalar stand-ins, all deterministic under `system.seed`:
  - SENSE applies axis drift (rng stream "state") with the BRCA2/ghost
    clamps and steps the DDMS mode controller (internal coherence walk).
  - PREDICT runs SPEL-lite (v7.1 heritage): a noisy self-prediction of the
    emergence level, finalized against the realized level in RESIDUAL, with
    meta-cognition growth and error costs per the `spel` config section.
  - ACT runs the v7.1 prediction game (rng stream "prediction"): target
    ~ N(0.5, difficulty), reward 4*(0.2-error) on a hit, survival penalty
    6*error on a miss, then the per-cycle homeostasis tick via
    `EnergyLedger.step` (cognitive cost + emergence-debt-scaled decay +
    bounded MAP penalty + fatigue).
  - REMEMBER appends a structured experience to a bounded deque and pays
    Landauer heat (Eq #102) whenever an old experience is evicted.
Mode switching runs in SENSE (the DDMS is part of the perceptual frame for
the cycle; the stub docstring's MUTATE mention referred to the full-stack
wiring) — the collapse check still happens exactly once, in MUTATE (#83).

Trace: Blueprint Part 2 (LayerIO contract) and Part 3 (loop order);
Audit #40, #83; v7.1 step() decomposition; SPEC.md §1 mission.
"""

from __future__ import annotations

import math
from collections import deque
from dataclasses import dataclass, field
from typing import Any, Callable, Deque, Dict, List, Optional

from phitensor.rng import Generator

from stage4.config import Config
from stage4.core.energy import EnergyLedger
from stage4.core.modes import MODE_POLICIES, ModeSwitchController
from stage4.core.state import AxisSnapshot, NeuroCognitiveState
from stage4.core.types import FalsificationResult, Layer, LayerIO, SystemMode

#: Canonical stage names of the master cycle, in execution order.
CYCLE_STAGES: tuple = (
    "sense", "predict", "act", "residual", "mutate", "remember",
)

#: v7.1-heritage prediction-game difficulty (v7.1 config
#: `prediction_game_difficulty`; the Stage 4 config has no such key, so the
#: heritage value is pinned here and documented — audit #16 traceability).
PREDICTION_GAME_DIFFICULTY: float = 0.4

#: v7.1-heritage prediction noise on the game estimate (gauss std).
PREDICTION_NOISE_STD: float = 0.1

#: Designer prior and learning rate for the game's running target mean.
TARGET_PRIOR: float = 0.5
TARGET_LEARN_RATE: float = 0.1

#: Mode-dependent difficulty modulation (v7.1: EXPLORE x1.1, EXPLOIT x0.9,
#: applied once per mode here instead of compounding in config — that
#: compounding was an audit-class bug; the band below is the fixed table).
MODE_DIFFICULTY: Dict[SystemMode, float] = {
    SystemMode.EXPLOIT: 0.9,
    SystemMode.CONSOLIDATE: 0.8,
    SystemMode.REFLECT: 0.9,
    SystemMode.EXPLORE: 1.1,
}

#: v7.1 raw_experiences capacity (NBC window host; memory.narrative stubbed).
EXPERIENCE_CAPACITY: int = 50

#: Nominal bits charged per evicted experience (Eq #101/#102 accounting).
#: Sized so the heat tax is a small but nonzero fraction of the cycle's
#: metabolic spend (q = LANDAUER_KT_LN2 * bits).
BITS_PER_EXPERIENCE: float = 0.1


@dataclass
class CycleRecord:
    """Structured per-cycle record for status, eval, and NBC compression.

    Trace: Audit #140-#141 (status completeness, uncertainty reporting);
    Blueprint Part 5 (eval protocol consumes these records).
    """

    cycle: int
    mode: SystemMode
    energy: float
    emergence_level: float
    criticality: float
    prediction_error: float
    uncertainty: float
    cost: float
    transitions: List[str] = field(default_factory=list)
    extras: Dict[str, Any] = field(default_factory=dict)


class AgentLoop:
    """The master sense-predict-act-residual-mutate-remember-repeat loop.

    Collaborators are injected as callables/objects at construction time by
    `stage4.main` (referenced by name only) so this module stays acyclic:
    perception.fusion, world_model.rssm, self_model.spel, policy.selection,
    agency.emergence/commitments/scars/criticality, neuro.axes/blankets/
    hysteresis/alignment, memory.narrative/crystal/ledger, safety.invariants.

    Owned directly: NeuroCognitiveState, ModeSwitchController, EnergyLedger.

    Implemented: full scalar cycle (see module docstring for the scalar
    stand-ins used while L1-L7 tensor layers are stubbed).

    Trace: Blueprint Part 2/Part 3; Audit #40, #83; v7.1 step().
    """

    def __init__(self, config: Config) -> None:
        """Initialize owned subsystems and empty collaborator registry.

        Builds NeuroCognitiveState.from_config, ModeSwitchController(config),
        EnergyLedger(config); sets cycle counter to 0 and an empty
        `collaborators` dict keyed by stage name.

        Implemented: full, plus scalar-core internals (seeded rng streams
        "state"/"prediction", SPEL-lite bookkeeping, experience buffer).

        Trace: Audit #16 (config-driven); Blueprint Part 3.
        """
        self.config = config
        self.state = NeuroCognitiveState.from_config(config)
        self.modes = ModeSwitchController(config)
        self.energy = EnergyLedger(config)
        self.cycle = 0
        self.history: List[CycleRecord] = []
        self.axis_history: List[AxisSnapshot] = []
        self.collaborators: Dict[str, List[Any]] = {
            stage: [] for stage in CYCLE_STAGES
        }

        seed = int(config.get("system.seed", 49))
        root = Generator(seed)
        self._rng_state = root.spawn("state")
        self._rng_pred = root.spawn("prediction")

        # SPEL-lite state (v7.1 _update_sPEL heritage; spel config section).
        self._expected_error = 0.1
        self._expected_game_error = 0.3
        self._meta_cognition = 0.1
        self._spel_prediction = 0.0
        self._spel_error = 0.0

        # Cross-cycle scalar channels.
        self._target_mean = TARGET_PRIOR
        self._err_emergence_ema = 0.3
        self._err_target_ema = 0.3
        self._prev_emergence = 0.0
        self._prev_debt = 0.0
        self._criticality = 0.4
        self._plasticity = 1.0
        self._debt_delta_pending = 0.0
        self._game_error = 0.0
        self._game_reward = 0.0
        self._recent_wins: Deque[float] = deque(maxlen=10)
        self._recent_shocks: Deque[int] = deque(maxlen=20)
        self._mode_counts: Dict[str, int] = {}
        self._experiences: Deque[Dict[str, Any]] = deque(
            maxlen=EXPERIENCE_CAPACITY
        )
        self._last_mode_transition: Optional[Dict[str, Any]] = None

    @property
    def name(self) -> str:
        """Layer protocol name.

        Trace: SPEC §4.1 Layer protocol.
        """
        return "core.agent_loop"

    @property
    def meta_cognition(self) -> float:
        """SPEL-lite meta-cognition level in [0, 1] (v7.1 heritage).

        Trace: v7.1 cognitive_state.meta_cognition; audit #97-#108.
        """
        return self._meta_cognition

    @property
    def mode_counts(self) -> Dict[str, int]:
        """Cycles spent per mode (mode distribution for eval.report).

        Trace: Audit #140 (status completeness).
        """
        return dict(self._mode_counts)

    @property
    def experiences(self) -> Deque[Dict[str, Any]]:
        """Bounded raw-experience buffer (v7.1 raw_experiences heritage).

        Trace: v7.1 NBC host; Audit #129-#136.
        """
        return self._experiences

    def register(self, stage: str, collaborator: Any) -> None:
        """Attach a layer implementation to a pipeline stage.

        `stage` must be one of CYCLE_STAGES; `collaborator` must satisfy the
        `Layer` protocol (name, step(LayerIO)->LayerIO, falsification_test).
        Raises KeyError for unknown stages and TypeError for non-Layer objects.

        Implemented: full. Multiple collaborators may attach to one stage;
        they run in registration order (e.g. emergence before criticality in
        "residual", commitments before scars in "mutate" — audit #40).

        Trace: Blueprint Part 2 (Layer protocol); SPEC §4.1.
        """
        if stage not in CYCLE_STAGES:
            raise KeyError(
                f"unknown stage {stage!r}; must be one of {CYCLE_STAGES}"
            )
        if not isinstance(collaborator, Layer):
            raise TypeError(
                f"collaborator for stage {stage!r} must satisfy the Layer "
                f"protocol (name, step, falsification_test); got "
                f"{type(collaborator).__name__}"
            )
        self.collaborators[stage].append(collaborator)

    def _collaborator(self, stage: str) -> Optional[Any]:
        """First collaborator registered for `stage`, if any.

        Trace: Blueprint Part 2.
        """
        chain = self.collaborators.get(stage) or []
        return chain[0] if chain else None

    def _sense(self, inp: LayerIO) -> LayerIO:
        """Stage 1: route raw observation through perception.fusion.

        Implemented: registered collaborators run first (none while
        perception is stubbed); then scalar axis drift (rng stream "state",
        plasticity-gated) with BRCA2/ghost clamps via
        `NeuroCognitiveState.update_axes`, then the DDMS mode step
        (internal coherence walk while quantum.observer is stubbed).

        Trace: Blueprint L1/L2; Audit #4 (closed action-perception loop).
        """
        out = inp
        for collaborator in self.collaborators["sense"]:
            out = collaborator.step(out)

        plasticity = MODE_POLICIES[self.modes.current_mode].plasticity_gain
        plasticity *= self._plasticity  # criticality modulation (audit #78)
        self.state.update_axes(
            self.config,
            d_precision_local=self._rng_state._normal_scalar(0.0, 0.05) * plasticity,
            d_precision_global=self._rng_state._normal_scalar(0.0, 0.02) * plasticity,
            d_boundary_social=self._rng_state._normal_scalar(0.0, 0.05),
            d_boundary_sensory=self._rng_state._normal_scalar(0.0, 0.05),
            d_temporal=self._rng_state._normal_scalar(0.0, 0.02),
        )
        mode_out = self.modes.step(LayerIO(
            state=self.state,
            uncertainty=out.uncertainty,
            cost=0.0,
            meta={
                "neuro_state": self.state,
                "emergence_level": self._prev_emergence,
                "social_influence": self.state.social_influence(0.5),
                "cycle": self.cycle,
            },
        ))
        self._last_mode_transition = mode_out.meta.get("transition")
        mode = self.modes.current_mode
        self._mode_counts[mode.value] = self._mode_counts.get(mode.value, 0) + 1
        meta = dict(out.meta)
        meta["mode"] = mode
        meta["mode_policy"] = mode_out.meta["mode_policy"]
        meta["coherence"] = mode_out.meta["coherence"]
        return LayerIO(state=out.state, uncertainty=out.uncertainty,
                       cost=out.cost + mode_out.cost, meta=meta)

    def _predict(self, inp: LayerIO) -> LayerIO:
        """Stage 2: world-model prediction + SPEL self-prediction error.

        Implemented: registered collaborators run first (none while L5/L6
        are stubbed); SPEL-lite issues a noisy self-prediction of the
        emergence level (v7.1: predicted = level + N(0, 0.05)) which
        RESIDUAL scores against the realized level.

        Trace: Blueprint L5/L6; Audit #97-#108; Eq #15-#30.
        """
        out = inp
        for collaborator in self.collaborators["predict"]:
            out = collaborator.step(out)
        self._spel_prediction = (
            self._prev_emergence + self._rng_pred._normal_scalar(0.0, 0.05)
        )
        meta = dict(out.meta)
        meta["self_prediction"] = self._spel_prediction
        return LayerIO(state=out.state, uncertainty=out.uncertainty,
                       cost=out.cost, meta=meta)

    def _act(self, inp: LayerIO) -> LayerIO:
        """Stage 3: policy action selection under Lyapunov + EFE gating.

        Implemented: the Lyapunov gate is consulted (Eq #2; its verdict is
        recorded in meta for the stubbed policy layer). The scalar action is
        the v7.1 prediction game: target ~ N(0.5, difficulty) with
        SPEL/meta-cognition-improved prediction, reward 4*(0.2-error) on a
        hit, survival penalty 6*error on a miss, charged through the clamped
        ledger. The per-cycle homeostasis tick (`EnergyLedger.step`) then
        applies the mode-scaled cognitive cost (#95), emergence-debt-scaled
        decay (#27), bounded MAP penalty (#96), and fatigue (Eq #9).

        Trace: Blueprint L3; Eq #2, #49-#68; Audit #5.
        """
        out = inp
        for collaborator in self.collaborators["act"]:
            out = collaborator.step(out)

        gate_open = self.energy.lyapunov_gate()
        policy = out.meta.get("mode_policy", MODE_POLICIES[self.modes.current_mode])

        difficulty = (
            PREDICTION_GAME_DIFFICULTY
            * MODE_DIFFICULTY.get(self.modes.current_mode, 1.0)
            * (1.0 - 0.5 * self._meta_cognition)
        )
        target = self._rng_pred._normal_scalar(0.5, difficulty)
        # SPEL-lite dual-source prediction: the self-model tracks the error
        # EMA of two candidate predictors (lagged emergence vs learned
        # target mean) and blends toward whichever is currently truer, so
        # the estimate improves as the game statistics are learned.
        err_emergence = abs(self._prev_emergence - target)
        err_target = abs(self._target_mean - target)
        self._err_emergence_ema = (
            0.99 * self._err_emergence_ema + 0.01 * err_emergence
        )
        self._err_target_ema = 0.99 * self._err_target_ema + 0.01 * err_target
        blend = 0.5 + 0.5 * math.tanh(
            3.0 * (self._err_emergence_ema - self._err_target_ema)
        )
        blend = min(0.95, max(0.05, blend))
        prediction = (
            (1.0 - blend) * self._prev_emergence
            + blend * self._target_mean
            + self._rng_pred._normal_scalar(
                0.0, PREDICTION_NOISE_STD * (1.0 - self._meta_cognition))
        )
        self._game_error = abs(prediction - target)
        self._target_mean = (
            (1.0 - TARGET_LEARN_RATE) * self._target_mean
            + TARGET_LEARN_RATE * target
        )

        reward_multiplier = float(self.config.get("energy.reward_multiplier", 4.0))
        survival_penalty = float(self.config.get("energy.survival_penalty", 6.0))
        self._game_reward = 0.0
        game_cost = 0.0
        if self._game_error < 0.2:
            self._game_reward = self.energy.reward(
                reward_multiplier * (0.2 - self._game_error), reason="prediction_hit"
            )
            self._recent_wins.append(1.0)
        else:
            game_cost = self.energy.spend(
                survival_penalty * self._game_error, policy=policy,
                reason="prediction_miss",
            )
            self._recent_wins.append(0.0)

        homeostasis = self.energy.step(LayerIO(
            state=None,
            uncertainty=out.uncertainty,
            cost=0.0,
            meta={
                "mode_policy": policy,
                "action_cost": game_cost,
                "emergence_debt": self._prev_debt,
                "emergence_level": self._prev_emergence,
                "cycle": self.cycle,
            },
        ))

        meta = dict(out.meta)
        meta["lyapunov_gate_open"] = gate_open
        meta["prediction_error"] = self._game_error
        meta["action"] = "predict"
        return LayerIO(
            state=homeostasis.state,
            uncertainty=homeostasis.uncertainty,
            cost=out.cost + homeostasis.cost + game_cost,
            meta=meta,
        )

    def _residual(self, inp: LayerIO) -> LayerIO:
        """Stage 4: residual drives emergence, criticality, then axes — in
        this fixed order (fixes audit #40).

        Implemented: agency.emergence runs first (residual + previous
        criticality through its bounded aggregator, then debt — #40), then
        SPEL-lite is finalized against the realized level (meta-cognition
        growth, error cost via the clamped ledger), then
        agency.criticality (axes-grounded) with its additive overshoot
        penalty charged through the ledger. Axis updates themselves happen
        in SENSE (`neuro.axes` is stubbed; core.state applies the clamps).

        Trace: Audit #40; Audit #25-#40 (emergence); Levantine L25.
        """
        out = inp
        level = self._prev_emergence
        debt = self._prev_debt
        survival_pressure = False

        # Emergence FIRST, then criticality (fixes audit #40 ordering).
        ordered = sorted(
            self.collaborators["residual"],
            key=lambda c: 0 if c.name == "agency.emergence" else 1,
        )
        for collaborator in ordered:
            if collaborator.name == "agency.emergence":
                em_out = collaborator.step(LayerIO(
                    state=out.state,
                    uncertainty=out.uncertainty,
                    cost=0.0,
                    meta={
                        "prediction_residual": self._game_error,
                        "criticality": self._criticality,
                        "cycle": self.cycle,
                        "debt_delta": self._debt_delta_pending,
                    },
                ))
                self._debt_delta_pending = 0.0
                level = float(em_out.state)
                debt = float(em_out.meta["debt"])
                survival_pressure = bool(em_out.meta["survival_pressure"])
                out = LayerIO(state=out.state, uncertainty=out.uncertainty,
                              cost=out.cost + em_out.cost, meta=out.meta)

        # SPEL-lite finalization (v7.1 _update_sPEL heritage; spel config).
        spel_threshold = float(self.config.get("spel.error_threshold", 0.2))
        spel_cost_mult = float(self.config.get("spel.cost_multiplier", 0.05))
        spel_growth = float(self.config.get("spel.meta_growth_rate", 0.01))
        self._spel_error = abs(level - self._spel_prediction)
        surprise = 0.5 * abs(self._spel_error - self._expected_error)
        surprise += 0.5 * abs(self._game_error - self._expected_game_error)
        self._meta_cognition = min(
            1.0, self._meta_cognition + spel_growth * surprise
        )
        self._expected_error = (
            0.99 * self._expected_error + 0.01 * self._spel_error
        )
        self._expected_game_error = (
            0.99 * self._expected_game_error + 0.01 * self._game_error
        )
        if self._spel_error > spel_threshold:
            cost = self._spel_error * spel_cost_mult * self.energy.energy
            self.energy.spend(cost, reason="spel_error")
            self.energy.add_damage(self._spel_error * spel_cost_mult * 0.1)

        for collaborator in ordered:
            if collaborator.name == "agency.emergence":
                continue  # already ran above (audit #40 ordering)
            c_out = collaborator.step(LayerIO(
                state=out.state,
                uncertainty=out.uncertainty,
                cost=0.0,
                meta={
                    "precision_local": self.state.precision_local,
                    "noise_level": min(1.0, self._expected_game_error),
                    "boundary_sensory": self.state.boundary_sensory,
                    "shock_frequency": min(1.0, sum(self._recent_shocks) / 5.0),
                    "cycle": self.cycle,
                },
            ))
            if collaborator.name == "agency.criticality":
                self._criticality = float(c_out.state)
                self._plasticity = float(c_out.meta["plasticity_gain"])
                penalty = float(c_out.meta["penalty"])
                if penalty > 0.0:
                    self.energy.spend(penalty, reason="criticality_overshoot")
            out = LayerIO(state=out.state, uncertainty=out.uncertainty,
                          cost=out.cost + c_out.cost, meta=out.meta)

        self._prev_emergence = level
        self._prev_debt = debt
        meta = dict(out.meta)
        meta["emergence_level"] = level
        meta["emergence_debt"] = debt
        meta["survival_pressure"] = survival_pressure
        meta["self_error"] = self._spel_error
        return LayerIO(state=out.state, uncertainty=out.uncertainty,
                       cost=out.cost, meta=meta)

    def _mutate(self, inp: LayerIO) -> LayerIO:
        """Stage 5: irreversible mutation — commitments, scars, hysteresis,
        mode switch. Collapse is checked exactly once, here (fixes #83).

        Implemented: commitments and scars collaborators run in registration
        order; failed commitment probes route their debt bump into the next
        RESIDUAL (#54); scar restriction damage is applied through the
        clamped ledger channel (#65); `energy.check_collapse` is called
        exactly once per cycle (#83) and a collapse also forms a
        collapse-origin scar (#61). The DDMS mode switch runs in SENSE (see
        module docstring); neuro.hysteresis is stubbed (shock frequency is
        tracked internally via `_recent_shocks`).

        Trace: Audit #41-#68, #83; Levantine L17-L24, L26-L30.
        """
        out = inp
        for collaborator in self.collaborators["mutate"]:
            if collaborator.name == "agency.commitments":
                c_out = collaborator.step(LayerIO(
                    state=out.state, uncertainty=out.uncertainty, cost=0.0,
                    meta={"cycle": self.cycle, "energy_ledger": self.energy},
                ))
                self._debt_delta_pending += float(
                    c_out.meta.get("debt_delta", 0.0)
                )
            elif collaborator.name == "agency.scars":
                social_reward = (
                    sum(self._recent_wins) / len(self._recent_wins)
                    if self._recent_wins else 1.0
                )
                c_out = collaborator.step(LayerIO(
                    state=out.state, uncertainty=out.uncertainty, cost=0.0,
                    meta={
                        "emergence_level": self._prev_emergence,
                        "error_attribution": {
                            "perception": self._expected_game_error,
                            "memory": min(1.0, self.energy.landauer_total),
                            "executive": self._spel_error,
                            "adaptation": abs(0.45 - self._criticality),
                        },
                        "boundary_social": self.state.boundary_social,
                        "social_reward": social_reward,
                        "cycle": self.cycle,
                    },
                ))
                damage_delta = float(c_out.meta.get("damage_delta", 0.0))
                if damage_delta > 0.0:
                    self.energy.add_damage(damage_delta)  # clamped (#65)
            else:
                c_out = collaborator.step(out)
            out = LayerIO(state=out.state, uncertainty=out.uncertainty,
                          cost=out.cost + c_out.cost, meta=out.meta)

        # Exactly one collapse check per cycle (fixes audit #83).
        event = self.energy.check_collapse(self.cycle, subsystem="executive")
        collapses_this_cycle = 0
        if event is not None:
            collapses_this_cycle = 1
            self._recent_shocks.append(1)
            scars = next(
                (c for c in self.collaborators["mutate"]
                 if c.name == "agency.scars"),
                None,
            )
            if scars is not None:
                scars.form_scar(event.affected_subsystem, "collapse",
                                event.damage_delta, self.cycle)
        else:
            self._recent_shocks.append(0)

        meta = dict(out.meta)
        meta["collapses_this_cycle"] = collapses_this_cycle
        meta["collapse_event"] = event
        return LayerIO(state=out.state, uncertainty=out.uncertainty,
                       cost=out.cost, meta=meta)

    def _remember(self, inp: LayerIO) -> LayerIO:
        """Stage 6: NBC compression + crystal persistence, paying Landauer.

        Implemented: appends the cycle's structured experience to the
        bounded buffer; when an old experience is evicted, its nominal bits
        are charged to the ledger via `landauer_cost` (Eq #101/#102).
        memory.narrative/memory.crystal collaborators run first when
        registered (stubbed today).

        Trace: Audit #129-#136; Eq #31-#48, #101/#102; Levantine L33-L40.
        """
        out = inp
        bits_erased = 0.0
        for collaborator in self.collaborators["remember"]:
            out = collaborator.step(out)
            bits_erased += float(out.meta.get("bits_erased", 0.0))

        if len(self._experiences) == self._experiences.maxlen:
            bits_erased += BITS_PER_EXPERIENCE  # one eviction
        self._experiences.append({
            "cycle": self.cycle,
            "emergence": self._prev_emergence,
            "mode": self.modes.current_mode.value,
            "energy": self.energy.energy,
            "prediction_error": self._game_error,
        })
        if bits_erased > 0.0:
            self.energy.landauer_cost(bits_erased)

        meta = dict(out.meta)
        meta["bits_erased"] = bits_erased
        meta["experience_count"] = len(self._experiences)
        return LayerIO(state=out.state, uncertainty=out.uncertainty,
                       cost=out.cost, meta=meta)

    def step(self, inp: LayerIO) -> LayerIO:
        """Run one full cycle through CYCLE_STAGES and return the final IO.

        Threads the LayerIO through each stage in canonical order, snapshots
        the neuro axes (AxisSnapshot), appends a CycleRecord, and refuses to
        run (returns a terminal LayerIO with meta['halted']=True) when the
        energy ledger is dead (audit #91) or a safety invariant from
        `safety.invariants` (referenced by name) fails.

        Implemented: full scalar cycle (safety.invariants is stubbed; the
        energy-death halt is enforced).

        Trace: Blueprint Part 2/Part 3; Audit #40, #83, #91; v7.1 step().
        """
        if not self.energy.alive:
            return LayerIO(
                state=None,
                uncertainty=1.0,
                cost=0.0,
                meta={"halted": True, "reason": "energy_dead",
                      "cycle": self.cycle},
            )

        out = inp
        for stage in CYCLE_STAGES:
            out = getattr(self, f"_{stage}")(out)

        transition = self._last_mode_transition
        transitions = (
            [f"{transition['from']}->{transition['to']}"] if transition else []
        )
        self.axis_history.append(AxisSnapshot(
            cycle=self.cycle,
            precision_local=self.state.precision_local,
            precision_global=self.state.precision_global,
            boundary_social=self.state.boundary_social,
            boundary_sensory=self.state.boundary_sensory,
            temporal_focus=self.state.temporal_focus,
            mode=self.modes.current_mode.value,
        ))
        record = CycleRecord(
            cycle=self.cycle,
            mode=self.modes.current_mode,
            energy=self.energy.energy,
            emergence_level=self._prev_emergence,
            criticality=self._criticality,
            prediction_error=self._game_error,
            uncertainty=out.uncertainty,
            cost=out.cost,
            transitions=transitions,
            extras={
                "stage_order": CYCLE_STAGES,
                "collapses": out.meta.get("collapses_this_cycle", 0),
                "emergence_debt": self._prev_debt,
                "permanent_damage": self.energy.permanent_damage,
                "meta_cognition": self._meta_cognition,
                "alive": self.energy.alive,
            },
        )
        self.history.append(record)
        self.cycle += 1

        meta = dict(out.meta)
        meta["halted"] = False
        meta["record"] = record
        return LayerIO(state=out.state, uncertainty=out.uncertainty,
                       cost=out.cost, meta=meta)

    def falsification_test(self) -> FalsificationResult:
        """Kill criterion: cycle ordering and collapse-count sanity.

        Fails if any CycleRecord shows emergence updated before residual
        (ordering regression, audit #40) or if collapse_count advanced more
        than once in a single cycle (audit #83 regression).

        Implemented: full.

        Trace: Audit #40, #83; Blueprint Part 8.
        """
        violations = 0
        for record in self.history:
            if record.extras.get("stage_order") != CYCLE_STAGES:
                violations += 1
            if record.extras.get("collapses", 0) > 1:
                violations += 1
        total = max(1, len(self.history))
        return FalsificationResult(
            name="core.loop.ordering",
            passed=violations == 0,
            metric=violations / total,
            threshold=0.0,
            detail=f"{violations} ordering/double-collapse violations "
                   f"over {len(self.history)} cycles",
        )


__all__ = ["CYCLE_STAGES", "CycleRecord", "AgentLoop"]
```

----------------------------------------

### File: `modes.py`

**Path:** `stage4/stage4/core/modes.py`
**Extension:** `.py`
**Size:** 15,693 bytes (15.33 KB)

```py
"""Decoherence-Driven Mode Switching (DDMS) with dwell time and hysteresis.

Fixes the v7.1 DDMS shortcomings (audit #109-118):
  - #116/#117: mode switching can no longer oscillate every cycle — a minimum
    dwell time (`ddms.min_dwell_cycles`) and a hysteresis band
    (`ddms.hysteresis_band`) around every coherence threshold are enforced.
  - #111: thresholds remain configurable but are now *effective* thresholds
    shifted by the hysteresis band depending on the direction of travel.
  - #112/#113/#114: modes are not decorative — each SystemMode maps to a
    concrete `ModePolicy` (cost multiplier, plasticity gain, blanket gains)
    consumed by `core.energy`, `core.loop`, and `neuro.blankets`.
  - Extended modes (ENCAPSULATED L7, PROPHETIC L23, PRESENT_LOCKED L36,
    SUPERSOLID G37, TIME_CRYSTAL G41) override the coherence-derived base
    mode when their neurocognitive/quantum gate conditions hold.

Quantum coherence itself is NOT simulated here; it arrives from
`quantum.observer` (referenced by name only — SPEC §2 import rule). While
that layer is stubbed, the controller runs an internal v7.1-heritage
coherence random walk driven by a deterministic `phitensor.rng` stream
("modes"), so the DDMS is exercisable end to end.

Implemented: full scalar DDMS — internal coherence random walk (rng stream
"modes"), hysteresis-shifted base ladder, dwell gating, extended-mode
overrides with precedence, transition history, falsification test.

Trace: Audit #109-118; Levantine L7/L23/L36; GhostMesh G37/G41;
Blueprint Part 2; v7.1 DDMS.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from phitensor.rng import Generator

from stage4.config import Config
from stage4.core.state import NeuroCognitiveState
from stage4.core.types import FalsificationResult, LayerIO, SystemMode


@dataclass
class ModePolicy:
    """Concrete per-mode effects (fixes audit #112: modes must do something).

    Attributes:
        cost_multiplier: Scales cognitive operation cost in `core.energy`
            (fixes audit #95: cost was constant across modes).
        plasticity_gain: Scales learning rate / axis drift in `neuro.axes`
            (fixes audit #78: mode/criticality must couple to plasticity).
        social_gain: Multiplier on the social boundary permeability controller
            in `neuro.blankets` (L13).
        sensory_gain: Multiplier on the sensory boundary controller (L13).

    Trace: Audit #95, #112-#114; Levantine L13.
    """

    cost_multiplier: float = 1.0
    plasticity_gain: float = 1.0
    social_gain: float = 1.0
    sensory_gain: float = 1.0


#: Static policy table; every mode has a non-trivial, documented effect.
MODE_POLICIES: Dict[SystemMode, ModePolicy] = {
    SystemMode.EXPLOIT: ModePolicy(cost_multiplier=1.2, plasticity_gain=0.6),
    SystemMode.CONSOLIDATE: ModePolicy(cost_multiplier=0.8, plasticity_gain=1.2),
    SystemMode.REFLECT: ModePolicy(cost_multiplier=0.9, plasticity_gain=1.0,
                                   social_gain=0.5),
    SystemMode.EXPLORE: ModePolicy(cost_multiplier=1.1, plasticity_gain=1.3,
                                   sensory_gain=1.2),
    SystemMode.ENCAPSULATED: ModePolicy(cost_multiplier=0.9, plasticity_gain=1.1,
                                        social_gain=0.3),
    SystemMode.PROPHETIC: ModePolicy(cost_multiplier=1.3, plasticity_gain=1.4,
                                     social_gain=0.2, sensory_gain=1.4),
    SystemMode.PRESENT_LOCKED: ModePolicy(cost_multiplier=0.8,
                                          plasticity_gain=0.8,
                                          sensory_gain=1.1),
    SystemMode.SUPERSOLID: ModePolicy(cost_multiplier=0.5, plasticity_gain=0.5),
    SystemMode.TIME_CRYSTAL: ModePolicy(cost_multiplier=0.0,
                                        plasticity_gain=0.2),
}

#: Ladder rank of the four base modes (higher coherence -> higher rank).
_BASE_LADDER: tuple = (
    (SystemMode.EXPLOIT, "coherence_high"),
    (SystemMode.CONSOLIDATE, "coherence_medium"),
    (SystemMode.REFLECT, "coherence_low"),
)
_BASE_RANK: Dict[SystemMode, int] = {
    SystemMode.EXPLORE: 0,
    SystemMode.REFLECT: 1,
    SystemMode.CONSOLIDATE: 2,
    SystemMode.EXPLOIT: 3,
}


class ModeSwitchController:
    """DDMS controller: coherence thresholds + dwell + hysteresis + overrides.

    The controller consumes a coherence scalar (produced by
    `quantum.observer`, passed in — never imported) and the current
    NeuroCognitiveState, and emits a SystemMode subject to:
      1. Extended-mode gate overrides (L7/L23/L36/G37/G41).
      2. Hysteresis band: to switch UP a threshold the coherence must exceed
         threshold + band; to switch DOWN it must fall below threshold - band
         (fixes audit #116/#117).
      3. Minimum dwell: no base-mode change is allowed before
         `ddms.min_dwell_cycles` cycles in the current mode (audit #117);
         extended-mode *safety* overrides may bypass dwell, normal ones not.

    Implemented: full scalar controller. While `quantum.observer` is stubbed,
    coherence comes from an internal v7.1-style mean-reverting random walk
    driven by the deterministic rng stream "modes" (see `update_coherence`).
    Quantum-flag overrides (SUPERSOLID/TIME_CRYSTAL) are treated as safety
    overrides and bypass dwell; neurocognitive overrides respect dwell.

    Trace: Audit #109-118 (esp. #116, #117); Levantine L7/L23/L36;
    GhostMesh G37/G41.
    """

    #: Layer protocol name (allows registration in `core.loop`).
    name: str = "core.modes"

    def __init__(self, config: Config) -> None:
        """Initialize from the `ddms` config section.

        Reads coherence_high/medium/low, min_dwell_cycles, hysteresis_band.
        Starts in EXPLORE with dwell counter at zero.

        Implemented: full. Coherence starts at `coherence_high` (v7.1
        heritage); the internal walk draws from rng stream "modes".

        Trace: Audit #16 (no magic numbers); Audit #117 (dwell state).
        """
        self._config = config
        self._high = float(config.get("ddms.coherence_high", 0.8))
        self._medium = float(config.get("ddms.coherence_medium", 0.5))
        self._low = float(config.get("ddms.coherence_low", 0.3))
        self._min_dwell = int(config.get("ddms.min_dwell_cycles", 5))
        self._band = float(config.get("ddms.hysteresis_band", 0.05))
        self._current_mode: SystemMode = SystemMode.EXPLORE
        self._dwell_counter: int = 0
        self._transition_history: List[Dict[str, Any]] = []
        self._coherence: float = self._high
        self._step_count: int = 0
        seed = int(config.get("system.seed", 49))
        self._rng: Generator = Generator(seed).spawn("modes")

    @property
    def current_mode(self) -> SystemMode:
        """The active SystemMode.

        Implemented: full.

        Trace: v7.1 DDMS; core/types.py SystemMode.
        """
        return self._current_mode

    @property
    def coherence(self) -> float:
        """Current coherence scalar in [0.1, 1.0].

        Implemented: full (internal random walk while `quantum.observer`
        is stubbed).

        Trace: v7.1 DDMS; GhostMesh G37/G41.
        """
        return self._coherence

    @property
    def transition_history(self) -> List[Dict[str, Any]]:
        """Every actual mode transition (cycle, from, to, trigger).

        Implemented: full (fixes audit #140: transitions visible in status).

        Trace: Audit #140.
        """
        return self._transition_history

    def update_coherence(self) -> float:
        """Advance the internal coherence random walk by one cycle.

        v7.1 heritage: dc = N(0, 0.02) - 0.005 * (1 - c), clamped to
        [0.1, 1.0]. All randomness comes from the deterministic
        `phitensor.rng` stream "modes" (never the global random module), so
        runs are bit-exact under a fixed `system.seed` (audit #21/#22).
        Stand-in for `quantum.observer` until that layer lands.

        Implemented: full.

        Trace: v7.1 _update_ddms; Audit #21/#22; GhostMesh G37/G41.
        """
        delta = self._rng._normal_scalar(0.0, 0.02) - 0.005 * (1.0 - self._coherence)
        self._coherence = min(1.0, max(0.1, self._coherence + delta))
        return self._coherence

    def base_mode_from_coherence(self, coherence: float) -> SystemMode:
        """Map coherence to a base mode using hysteresis-shifted thresholds.

        Implements the v7.1 ladder (> high -> EXPLOIT, > medium -> CONSOLIDATE,
        > low -> REFLECT, else EXPLORE) but each comparison uses a threshold
        offset by +/- hysteresis_band according to whether the candidate mode
        is above or below the current ladder position, so that boundary noise
        cannot flip the mode back and forth (fixes audit #116).

        Implemented: full.

        Trace: Audit #111, #116, #117; v7.1 _update_ddms.
        """
        current_rank = _BASE_RANK.get(self._current_mode, 0)
        thresholds = {
            "coherence_high": self._high,
            "coherence_medium": self._medium,
            "coherence_low": self._low,
        }
        for mode, key in _BASE_LADDER:
            offset = self._band if _BASE_RANK[mode] > current_rank else -self._band
            if coherence > thresholds[key] + offset:
                return mode
        return SystemMode.EXPLORE

    def extended_mode_override(
        self,
        state: NeuroCognitiveState,
        emergence_level: float,
        social_influence: float,
        quantum_flags: Optional[Dict[str, bool]] = None,
    ) -> Optional[SystemMode]:
        """Check extended-mode gates; return the override mode or None.

        Gate conditions (from core/types.py docstrings):
          - ENCAPSULATED (L7): P_local > 1.5 and social_influence < 0.3.
          - PROPHETIC (L23): state.detect_dual_boundary() and emergence > 0.6.
          - PRESENT_LOCKED (L36): T < 0.3 and P_local > 1.5.
          - SUPERSOLID (G37): quantum_flags["supersolid"] from quantum.observer.
          - TIME_CRYSTAL (G41): quantum_flags["time_crystal"].
        Precedence: quantum flags > PROPHETIC > ENCAPSULATED > PRESENT_LOCKED.

        Implemented: full.

        Trace: Levantine L7/L23/L36; GhostMesh G37/G41.
        """
        flags = quantum_flags or {}
        if flags.get("supersolid"):
            return SystemMode.SUPERSOLID
        if flags.get("time_crystal"):
            return SystemMode.TIME_CRYSTAL
        if state.detect_dual_boundary(self._config) and emergence_level > 0.6:
            return SystemMode.PROPHETIC
        if state.precision_local > 1.5 and social_influence < 0.3:
            return SystemMode.ENCAPSULATED
        if state.temporal_focus < 0.3 and state.precision_local > 1.5:
            return SystemMode.PRESENT_LOCKED
        return None

    def step(self, inp: LayerIO) -> LayerIO:
        """Advance the DDMS one cycle, honoring the LayerIO contract.

        Expects inp.meta to carry `coherence` (float, from quantum.observer),
        `neuro_state` (NeuroCognitiveState), `emergence_level` (float, from
        agency.emergence), and optionally `social_influence` (float) and
        `quantum_flags` (dict). Applies extended override (if allowed under
        dwell rules), else the hysteresis-stable base mode; increments the
        dwell counter; records every actual transition with cycle, from/to,
        and trigger in `transition_history` (fixes audit #140: transitions
        must be visible in status). Returns LayerIO with state=current mode,
        uncertainty=1 - coherence, cost=policy cost multiplier, and meta
        including `mode_policy` and `transition` (or None).

        Implemented: full. When meta lacks `coherence` (the scalar core —
        `quantum.observer` is stubbed), the internal random walk
        `update_coherence` supplies it. Quantum-flag overrides are treated
        as safety overrides and bypass dwell; all other switches require
        `ddms.min_dwell_cycles` in the current mode (audit #117).

        Trace: Audit #116/#117/#140; Blueprint Part 2 (LayerIO contract);
        Levantine L7/L23/L36.
        """
        meta = inp.meta or {}
        coherence = meta.get("coherence")
        if coherence is None:
            coherence = self.update_coherence()
        else:
            self._coherence = min(1.0, max(0.1, float(coherence)))
        state = meta.get("neuro_state")
        if state is None:
            state = NeuroCognitiveState.from_config(self._config)
        emergence_level = float(meta.get("emergence_level", 0.0))
        social_influence = float(meta.get("social_influence", 1.0))
        quantum_flags = meta.get("quantum_flags")
        cycle = int(meta.get("cycle", self._step_count))

        override = self.extended_mode_override(
            state, emergence_level, social_influence, quantum_flags
        )
        base = self.base_mode_from_coherence(self._coherence)
        candidate = override if override is not None else base
        bypass_dwell = override in (SystemMode.SUPERSOLID, SystemMode.TIME_CRYSTAL)

        transition: Optional[Dict[str, Any]] = None
        if candidate is not self._current_mode and (
            self._dwell_counter >= self._min_dwell or bypass_dwell
        ):
            transition = {
                "cycle": cycle,
                "from": self._current_mode.value,
                "to": candidate.value,
                "trigger": (
                    f"override:{candidate.value}" if override is not None
                    else f"coherence:{self._coherence:.3f}"
                ),
            }
            self._transition_history.append(transition)
            self._current_mode = candidate
            self._dwell_counter = 0
        self._dwell_counter += 1
        self._step_count += 1

        policy = MODE_POLICIES[self._current_mode]
        return LayerIO(
            state=self._current_mode,
            uncertainty=1.0 - self._coherence,
            cost=policy.cost_multiplier,
            meta={
                "mode_policy": policy,
                "transition": transition,
                "coherence": self._coherence,
                "dwell": self._dwell_counter,
            },
        )

    def falsification_test(self) -> FalsificationResult:
        """Kill criterion: switching frequency must be bounded by dwell config.

        Fails if, over the recorded transition history, the mean dwell between
        consecutive transitions is below `ddms.min_dwell_cycles` — that would
        mean the hysteresis/dwell machinery is not actually gating switches
        (audit #116 regression).

        Implemented: full.

        Trace: Audit #116/#117; Blueprint Part 8 (falsifiability).
        """
        cycles = [t["cycle"] for t in self._transition_history]
        if len(cycles) < 2:
            return FalsificationResult(
                name="core.modes.dwell_bounded",
                passed=True,
                metric=float(self._min_dwell),
                threshold=float(self._min_dwell),
                detail="fewer than 2 transitions recorded; dwell vacuously bounded",
            )
        dwells = [b - a for a, b in zip(cycles, cycles[1:])]
        mean_dwell = sum(dwells) / len(dwells)
        return FalsificationResult(
            name="core.modes.dwell_bounded",
            passed=mean_dwell >= self._min_dwell,
            metric=mean_dwell,
            threshold=float(self._min_dwell),
            detail=f"mean dwell over {len(dwells)} transitions",
        )


__all__ = ["ModePolicy", "MODE_POLICIES", "ModeSwitchController"]
```

----------------------------------------

### File: `state.py`

**Path:** `stage4/stage4/core/state.py`
**Extension:** `.py`
**Size:** 10,869 bytes (10.61 KB)

```py
"""Neurocognitive state: the P/B/T axes and the neuro_coord vector.

Implements the Levantine patch section A (L1-L8) state representation:
  - Precision axis P split into local (domain systemizing) and global (social)
    precision (L1).
  - Dual boundary axes B_social and B_sensory (L2) with a dual-boundary
    detector (L6) gating the PROPHETIC mode in `core.modes`.
  - Temporal focus axis T clamped to [-2, +2] (L3), driving PRESENT_LOCKED
    vs long-horizon modes.
  - A single neurocognitive coordinate vector N = (P_local, B_social, T) (L4),
    exposed both as a tuple and as a `phitensor.Tensor` view.
  - Systemizing/socializing trade-off scalar (L8).

Axis *dynamics* (BRCA2 clamp, ghost filter, drift) live in `neuro.axes`;
this module owns only the state container, its invariants, and derivations.

Implemented: scalar container + derivations are fully functional —
`from_config`, `sync_coord`, `clamp_temporal_focus`, `detect_dual_boundary`,
`social_influence`, `as_dict`, and the scalar axis-update channel
`update_axes` (BRCA2 clamp on |dP| per L18, ghost-filter magnitude clamp per
L15/L28, T clamp per L3) used by `core.loop` while `neuro.axes` remains a
stub. `to_tensor` stays stubbed: `phitensor.Tensor` construction is stubbed
and the scalar core never builds tensors.

Trace: Levantine L1-L8; Blueprint Part 2 (state attached to LayerIO);
SPEC.md §5 (L1-L8 -> core/state.py, neuro/axes.py).
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Any, Dict, Tuple

from phitensor import Tensor

from stage4.config import Config

#: Valid range for the temporal-focus axis T (Levantine L3).
TEMPORAL_FOCUS_MIN: float = -2.0
TEMPORAL_FOCUS_MAX: float = 2.0


@dataclass
class NeuroCognitiveState:
    """Container for the neurocognitive coordinate state of the agent.

    Attributes:
        precision_local: Domain-specific systemizing precision P_local (L1).
        precision_global: Broad/social precision P_global (L1).
        boundary_social: Social Markov-blanket coordinate B_social (L2);
            positive = impermeable, negative = porous.
        boundary_sensory: Sensory Markov-blanket coordinate B_sensory (L2);
            negative = hyper-porous sensory boundary.
        temporal_focus: Temporal axis T in [-2, +2] (L3); negative values are
            past/ancestral-locked, positive values future/ritual-locked, and
            |T| < 0.3 approximates the Levallois present-locked attractor (L36).
        neuro_coord: Redundant cached coordinate triple (P_local, B_social, T)
            per L4; kept in sync by `sync_coord`.
        systemizing_bias: Trade-off scalar P_local - B_social (L8).

    Implemented: all scalar methods functional (see module docstring).

    Trace: Levantine L1-L4, L8; Audit #2 (formal operationalized state).
    """

    precision_local: float = 1.0
    precision_global: float = 1.0
    boundary_social: float = 0.0
    boundary_sensory: float = 0.0
    temporal_focus: float = 0.0
    neuro_coord: Tuple[float, float, float] = (1.0, 0.0, 0.0)
    systemizing_bias: float = 1.0

    @classmethod
    def from_config(cls, config: Config) -> "NeuroCognitiveState":
        """Build the initial state from the `neuro` config section.

        Reads `neuro.precision_local_init`, `neuro.precision_global_init`,
        `neuro.boundary_social_init`, `neuro.boundary_sensory_init`, and
        `neuro.temporal_focus_init`, then derives `neuro_coord` and
        `systemizing_bias` so the state is internally consistent at t=0.

        Implemented: full.

        Trace: Levantine L1-L4; Audit #16 (no magic numbers — all init
        values come from validated config); Audit #17 (range validation).
        """
        state = cls(
            precision_local=float(config.get("neuro.precision_local_init", 1.0)),
            precision_global=float(config.get("neuro.precision_global_init", 1.0)),
            boundary_social=float(config.get("neuro.boundary_social_init", 0.0)),
            boundary_sensory=float(config.get("neuro.boundary_sensory_init", 0.0)),
            temporal_focus=float(config.get("neuro.temporal_focus_init", 0.0)),
        )
        state.clamp_temporal_focus()
        state.sync_coord()
        return state

    def sync_coord(self) -> None:
        """Re-derive `neuro_coord` and `systemizing_bias` from the scalar axes.

        Must be called after any mutation of the scalar fields (by
        `neuro.axes.AxisDynamics`) so the cached vector never diverges from
        the authoritative scalar state (fixes the v7.1 class of bugs where
        redundant state drifts apart, cf. audit #43/#97).

        Implemented: full.

        Trace: Levantine L4, L8; Audit #43 (stale derived state).
        """
        self.neuro_coord = (
            float(self.precision_local),
            float(self.boundary_social),
            float(self.temporal_focus),
        )
        self.systemizing_bias = float(self.precision_local) - float(self.boundary_social)

    def clamp_temporal_focus(self) -> None:
        """Clamp T into [-2, +2] in place (Levantine L3 range invariant).

        Implemented: full.

        Trace: Levantine L3; Audit #89-class invariant (every bounded
        variable is clamped after every update).
        """
        self.temporal_focus = min(
            TEMPORAL_FOCUS_MAX, max(TEMPORAL_FOCUS_MIN, float(self.temporal_focus))
        )

    def update_axes(
        self,
        config: Config,
        d_precision_local: float = 0.0,
        d_precision_global: float = 0.0,
        d_boundary_social: float = 0.0,
        d_boundary_sensory: float = 0.0,
        d_temporal: float = 0.0,
    ) -> None:
        """Apply one cycle of scalar axis increments with safety clamps.

        BRCA2 clamp (L18): each precision increment is clamped to
        +/- `neuro.brca2_clamp` before application, so |dP| per cycle can
        never exceed the configured biological-rate bound. Ghost filter
        (L15/L28): after application, precision and boundary magnitudes are
        clamped to +/- `neuro.ghost_filter_clamp` (psychosis/paranoia guard).
        T is clamped to [-2, +2] (L3). `sync_coord` runs last so the derived
        coordinate never goes stale (audit #43).

        Implemented: full (scalar channel used by `core.loop` until
        `neuro.axes` lands).

        Trace: Levantine L15, L18, L28, L3; Audit #43, #89-class clamps.
        """
        brca2 = float(config.get("neuro.brca2_clamp", 0.25))
        ghost = float(config.get("neuro.ghost_filter_clamp", 2.5))

        def _clamp(value: float, bound: float) -> float:
            return min(bound, max(-bound, value))

        self.precision_local += _clamp(d_precision_local, brca2)
        self.precision_global += _clamp(d_precision_global, brca2)
        self.boundary_social += d_boundary_social
        self.boundary_sensory += d_boundary_sensory
        self.temporal_focus += d_temporal

        self.precision_local = _clamp(self.precision_local, ghost)
        self.precision_global = _clamp(self.precision_global, ghost)
        self.boundary_social = _clamp(self.boundary_social, ghost)
        self.boundary_sensory = _clamp(self.boundary_sensory, ghost)
        self.clamp_temporal_focus()
        self.sync_coord()

    def detect_dual_boundary(self, config: Config) -> bool:
        """Detect the dual-boundary (prophetic/isolated-strength) profile.

        Returns True iff B_social > neuro.dual_boundary.social (+1.5) and
        B_sensory < neuro.dual_boundary.sensory (-0.5) per L6. Consumed by
        `core.modes.ModeSwitchController` to gate SystemMode.PROPHETIC (L23)
        and by `agency.scars.ScarManager` for social-friction scars (L22).

        Implemented: full.

        Trace: Levantine L6, L23; core/types.py SystemMode.PROPHETIC.
        """
        dual = config.get("neuro.dual_boundary", {"social": 1.5, "sensory": -0.5})
        return (
            self.boundary_social > float(dual["social"])
            and self.boundary_sensory < float(dual["sensory"])
        )

    def to_tensor(self) -> Tensor:
        """Return the neuro_coord vector as a phitensor Tensor of shape (3,).

        Order is (P_local, B_social, T) exactly as in L4. Used by layers that
        consume the coordinate through the LayerIO.state channel.

        Implemented: NO — remains a stub. `phitensor.Tensor` construction is
        itself stubbed (phitensor/tensor.py) and the scalar core never builds
        tensors, so this stays at the stub boundary until the backend lands.

        Trace: Levantine L4; SPEC.md §4.3 (phitensor API surface).
        """
        raise NotImplementedError(
            "spec: return Tensor(list(self.neuro_coord)) after sync_coord() "
            "(blocked on phitensor.Tensor construction, which is stubbed)"
        )

    def social_influence(self, incoming: float) -> float:
        """Attenuate an incoming social influence signal through B_social.

        Encapsulated cognition (L7) requires social_influence < 0.3; this
        helper maps a raw social signal through the current social boundary
        so that high B_social yields influence below the ENCAPSULATED gate.

        Implemented: full — incoming * sigmoid(-B_social), clamped to [0, 1].

        Trace: Levantine L2, L7; core/types.py SystemMode.ENCAPSULATED.
        """
        attenuation = 1.0 / (1.0 + math.exp(self.boundary_social))
        return min(1.0, max(0.0, float(incoming) * attenuation))

    def as_dict(self) -> Dict[str, Any]:
        """Serialize the full state for logging, checkpoints, and NBC tags.

        Implemented: full.

        Trace: Audit #141 (report uncertainty/state in status); Levantine L4.
        """
        return {
            "precision_local": self.precision_local,
            "precision_global": self.precision_global,
            "boundary_social": self.boundary_social,
            "boundary_sensory": self.boundary_sensory,
            "temporal_focus": self.temporal_focus,
            "neuro_coord": list(self.neuro_coord),
            "systemizing_bias": self.systemizing_bias,
        }


@dataclass
class AxisSnapshot:
    """Immutable per-cycle snapshot of the axes for history and hysteresis.

    Produced once per master-loop cycle and appended to the histories used by
    `neuro.hysteresis` (ancestral lag) and `agency.criticality` (precision-noise
    grounded criticality, L25).

    Trace: Levantine L25-L27; Audit #75 (criticality history).
    """

    cycle: int
    precision_local: float
    precision_global: float
    boundary_social: float
    boundary_sensory: float
    temporal_focus: float
    mode: str = ""
    extras: Dict[str, Any] = field(default_factory=dict)


__all__ = [
    "TEMPORAL_FOCUS_MIN",
    "TEMPORAL_FOCUS_MAX",
    "NeuroCognitiveState",
    "AxisSnapshot",
]
```

----------------------------------------

### File: `types.py`

**Path:** `stage4/stage4/core/types.py`
**Extension:** `.py`
**Size:** 5,254 bytes (5.13 KB)

```py
"""Shared contracts for the Stage 4 system — the sacred interface layer.

Every package in `stage4/` builds against these types. Nothing crosses a layer
boundary without (state, uncertainty, cost) attached — Blueprint Part 2.

Traceability:
  - Blueprint §Part 1-3   : LayerIO, Falsifiable
  - Levantine patch #7/#23/#36 : ENCAPSULATED / PROPHETIC / PRESENT_LOCKED modes
  - GhostMesh patch #37/#41    : SUPERSOLID / TIME_CRYSTAL modes
  - Levantine patch #17        : ADMIXED commitment level
  - v7.1 base                  : VOLATILE/STABLE/CRYSTALLIZED/FIXED, SystemMode base modes
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum, IntEnum
from typing import Any, Dict, List, Optional, Protocol, Tuple, runtime_checkable


class SystemMode(Enum):
    """Global operating modes.

    Base modes come from v7.1 DDMS (decoherence-driven switching).
    Extended modes come from the integrated enhancement patches.
    """

    # --- v7.1 DDMS base modes (coherence-threshold driven) ---
    EXPLOIT = "exploit"
    CONSOLIDATE = "consolidate"
    REFLECT = "reflect"
    EXPLORE = "explore"

    # --- Levantine patch modes (neurocognitive-axis driven) ---
    ENCAPSULATED = "encapsulated"        # patch L7:  P_local > 1.5 and social_influence < 0.3
    PROPHETIC = "prophetic"              # patch L23: dual-boundary true and emergence > 0.6
    PRESENT_LOCKED = "present_locked"    # patch L36: T < 0.3 and P_local > 1.5

    # --- GhostMesh patch modes (quantum/signal driven) ---
    SUPERSOLID = "supersolid"            # patch G37: fixed geometry, frictionless flow
    TIME_CRYSTAL = "time_crystal"        # patch G41: oscillation without energy cost


class CommitmentLevel(IntEnum):
    """Irreversibility levels for commitments.

    ADMIXED (Levantine patch #17) sits between VOLATILE and STABLE: identity
    acquired through irreversible admixture — changeable only at high cost.
    Ordered: higher value => more irreversible => higher change cost.
    """

    VOLATILE = 0       # can change freely
    ADMIXED = 1        # deep-time admixture; costly change
    STABLE = 2         # costs energy and causes restrictions
    CRYSTALLIZED = 3   # cannot change without system-wide penalties
    FIXED = 4          # permanently locked, becomes identity scar


@dataclass
class LayerIO:
    """The blueprint's sacred layer contract (Part 2).

    Every layer L1..L7 receives and returns LayerIO. `uncertainty` is a
    calibrated variance-like scalar in [0, inf); `cost` is the energetic /
    compute cost of producing this output (Landauer-aware accounting hooks
    attach here — Eq #101/#102). `meta` carries optional structured payloads
    (mode, sector, provenance) without breaking the contract.
    """

    state: Any
    uncertainty: float
    cost: float
    meta: Dict[str, Any] = field(default_factory=dict)


@dataclass
class FalsificationResult:
    """Outcome of one falsifiable test (Blueprint Part 0 & Part 5)."""

    name: str
    passed: bool
    metric: float
    threshold: float
    detail: str = ""


@runtime_checkable
class Falsifiable(Protocol):
    """Every layer must expose its own kill criterion (Blueprint Part 8)."""

    def falsification_test(self) -> FalsificationResult:
        """Run the layer's falsifiable test and report pass/fail + metric."""
        ...


@runtime_checkable
class Layer(Protocol):
    """Common protocol for the seven blueprint layers."""

    name: str

    def step(self, inp: LayerIO) -> LayerIO:
        """Advance one cycle, honoring the LayerIO contract."""
        ...

    def falsification_test(self) -> FalsificationResult:
        ...


@dataclass
class GoalSpec:
    """A goal object produced by the L7 meta-controller (Blueprint §3.6).

    `origin` records whether the goal is designer-specified (in G_0) or
    emergent (in G_t \\ G_0) — the open-endedness criterion of Part 1.1.
    """

    goal_id: str
    description: str
    epistemic_value: float
    pragmatic_value: float
    origin: str  # "designer" | "emergent"
    formed_cycle: int
    persistence_cycles: int = 0


@dataclass
class Commitment:
    """A painful, level-governed commitment (v7.1 + audit fixes #41-56).

    Unlike v7.1, values are not random — they are produced by the geometry
    package's L-system/IFS rules and collapsed via the quantum observer.
    """

    key: str
    value: Any
    level: CommitmentLevel = CommitmentLevel.VOLATILE
    formation_cycle: int = 0
    change_count: int = 0
    restricted_options: List[str] = field(default_factory=list)
    history: List[Dict[str, Any]] = field(default_factory=list)
    sector: int = 0   # GhostMesh patch #1: 49-sector coordinate
    layer: int = 0    # GhostMesh patch #1: 7-layer coordinate


@dataclass
class Scar:
    """Structured identity scar (fixes audit #61: scars are structured, not floats)."""

    subsystem: str
    severity: float
    origin: str  # "stagnation" | "collapse" | "social_friction" (Levantine #22)
    formed_cycle: int
    restriction_key: str


__all__ = [
    "SystemMode",
    "CommitmentLevel",
    "LayerIO",
    "Layer",
    "Falsifiable",
    "FalsificationResult",
    "GoalSpec",
    "Commitment",
    "Scar",
]
```

----------------------------------------

##### Directory: `stage4/stage4/core/__pycache__`


#### Directory: `stage4/stage4/meta`


### File: `__init__.py`

**Path:** `stage4/stage4/meta/__init__.py`
**Extension:** `.py`
**Size:** 761 bytes (0.74 KB)

```py
"""stage4.meta -- L7 meta-controller package.

Hosts the top of the blueprint stack: open-ended goal generation via expected
free energy (the only place new goals form), the MAML slow learning loop that
makes transfer possible, and the L7 meta-controller that selects goals,
horizons, and options and arbitrates compute (MCFE fork).

Modules:
  goal_gen.py   -- EFE goal generation and the goal registry
  maml.py       -- MAML-style meta-learning slow loop
  controller.py -- L7 meta-controller (goal/horizon/option selection, MCFE)

Traceability:
  - Blueprint section 3.6 (L7 meta-controller), Part 4 (learning loops)
  - 144-equation ledger Eq #59, #72-#76, #78-#80, #82
"""

from __future__ import annotations

__all__ = ["goal_gen", "maml", "controller"]
```

----------------------------------------

### File: `controller.py`

**Path:** `stage4/stage4/meta/controller.py`
**Extension:** `.py`
**Size:** 8,701 bytes (8.50 KB)

```py
"""L7 meta-controller: goal, horizon, and option selection; MCFE compute.

The meta-controller sits at the top of the blueprint stack (Part 2).  Each
cycle it (a) asks the goal generator for candidate goals and selects one,
(b) derives the planning horizon from the active option set (Eq #63) with
EFE optimal stopping (Eq #73), and (c) decides how much compute the lower
layers get this cycle via the multi-compute fork engine (MCFE) with a
hysteresis guard (Eq #82).

It also hosts the return-estimation rules used to credit the selected goals
and options: TD(lambda) / lambda-returns (Eq #78/#79) and generalized
advantage estimation (Eq #80).

Traceability:
  - Blueprint section 3.6 (L7 meta-controller), Part 2 (LayerIO contract)
  - 144-equation ledger Eq #73 (EFE optimal stopping), Eq #74 (fork decision),
    Eq #75 (MCFE cost), Eq #76 (compute-budget Lagrange), Eq #78 (TD value),
    Eq #79 (lambda-return), Eq #80 (GAE), Eq #82 (MCFE hysteresis)
  - Phi-Lite features #22 (horizon selection), #23 (MCFE fork), #100 (fork
    badge)
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import TYPE_CHECKING, Dict, List, Optional, Sequence, Tuple

from stage4.config import Config
from stage4.core.types import FalsificationResult, GoalSpec, LayerIO

if TYPE_CHECKING:
    from phitensor import Tensor


class ForkTier(Enum):
    """Compute-fork levels for the multi-compute fork engine (MCFE).

    SKIP does no world-model rollout, MID does a shallow rollout, FULL does
    the deep counterfactual rollout.

    Trace: Phi-Lite feature #23 (MCFE fork), feature #100 (fork badge);
        Eq #74 (fork decision rule).
    """

    SKIP = "skip"
    MID = "mid"
    FULL = "full"


@dataclass
class ForkDecision:
    """Record of one MCFE fork decision.

    Trace: Eq #74 (fork decision rule); Eq #75 (MCFE cost); Eq #82
        (hysteresis).
    """

    tier: ForkTier
    estimated_efe_gain: float
    compute_cost: float
    hysteresis_count: int = 0


def efe_optimal_stopping(delta_g: float, epsilon: float) -> bool:
    """Stop expanding the horizon when Delta G < epsilon.

    Trace: Eq #73 (horizon via EFE optimal stopping); SPEC section 4.2
        (policy.efe_epsilon).
    """
    raise NotImplementedError("spec: return delta_g < epsilon")


def mcfe_fork_decision(estimated_efe_gain: float, compute_cost: float,
                       confidence: float) -> ForkTier:
    """Choose the fork tier: skip if estimated Delta EFE < compute cost.

    Trace: Eq #74 (fork decision rule: skip if Delta^_EFE < c_compute);
        Phi-Lite feature #23.
    """
    raise NotImplementedError(
        "spec: SKIP when estimated_efe_gain < compute_cost; FULL when the "
        "gain exceeds the FULL rollout cost and confidence is low; else MID"
    )


def mcfe_cost(cost_gru: float, cost_attn: float, cost_self: float,
              weights: Tuple[float, float, float]) -> float:
    """C_MCFE = alpha_1 c_GRU + alpha_2 c_attn + alpha_3 c_self.

    Trace: Eq #75 (MCFE cost).
    """
    raise NotImplementedError(
        "spec: return the weighted sum of the three component costs"
    )


def compute_budget_lagrangian(loss: float, cost: float, cost_max: float,
                              lam: float) -> float:
    """L = loss + lambda * (C - C_max): budget-constrained compute objective.

    Trace: Eq #76 (compute budget Lagrange).
    """
    raise NotImplementedError(
        "spec: return loss + lam * (cost - cost_max)"
    )


def td_lambda_value(rewards: Sequence[float], gamma: float) -> float:
    """Predictive horizon value V(s) = E[sum_k gamma^k r_{t+k}].

    Trace: Eq #78 (predictive horizon via TD(lambda)).
    """
    raise NotImplementedError(
        "spec: return the discounted reward sum with factor gamma"
    )


def lambda_return(n_step_returns: Sequence[float], lam: float) -> float:
    """G_t^lambda = (1 - lambda) * sum_n lambda^(n-1) G_t^(n).

    Trace: Eq #79 (lambda-return).
    """
    raise NotImplementedError(
        "spec: form the exponentially weighted mixture of n-step returns, "
        "normalizing the final weight so weights sum to 1"
    )


def generalized_advantage_estimate(td_errors: Sequence[float], gamma: float,
                                   lam: float) -> List[float]:
    """A^_t = sum_l (gamma lambda)^l delta_{t+l}.

    Trace: Eq #80 (GAE).
    """
    raise NotImplementedError(
        "spec: compute the exponentially weighted TD-error sums backwards "
        "from the terminal step"
    )


class MetaController:
    """The L7 meta-controller.

    Composes (by name, never by import): stage4.meta.goal_gen.GoalGenerator
    and GoalRegistry for open-ended goals; stage4.meta.maml.MAMLSlowLoop for
    the slow loop; stage4.policy.options.OptionFramework for the active
    option set; stage4.self_model.calibration for confidence c used by the
    MCFE fork.

    Trace: Blueprint section 3.6 (L7 selects goals, horizons, options);
        Blueprint Part 2 (LayerIO contract); Eq #73-#76, #78-#80, #82.
    """

    name: str = "L7.meta_controller"

    def __init__(self, config: Config) -> None:
        """Initialize controller state from validated config.

        Trace: Blueprint section 3.6; SPEC section 4.2 (meta.*, policy.*).
        """
        self._config = config
        self._hysteresis_required = 3
        raise NotImplementedError(
            "spec: initialize empty goal/horizon/option selection state and "
            "the MCFE hysteresis counters (3 consecutive cycles to switch)"
        )

    def select_goal(self, candidates: Sequence[GoalSpec],
                    beliefs: "Tensor") -> Optional[GoalSpec]:
        """Pick the active goal from candidates by EFE score.

        Trace: Blueprint section 3.6 (g* = argmax_g [H(z|g) - lambda E[r|g]]).
        """
        raise NotImplementedError(
            "spec: score candidates with goal_gen.expected_free_energy and "
            "return the argmax"
        )

    def select_horizon(self, active_option_count: int, delta_g_history: Sequence[float],
                       epsilon: float) -> int:
        """Derive the planning horizon with option count and EFE stopping.

        Trace: Eq #63 (horizon via options count, hosted in
            policy.hierarchical); Eq #73 (stop when Delta G < epsilon).
        """
        raise NotImplementedError(
            "spec: grow the horizon while the EFE gain history exceeds "
            "epsilon, starting from the active-option base"
        )

    def select_option(self, available: Sequence[int], goal: GoalSpec) -> Optional[int]:
        """Choose which option (if any) serves the active goal.

        Trace: Blueprint section 3.6 (L7 selects options); Eq #60.
        """
        raise NotImplementedError(
            "spec: rank available options by predicted progress toward the "
            "goal and return the best option id or None for primitives"
        )

    def decide_fork(self, state: LayerIO,
                    previous: Optional[ForkDecision]) -> ForkDecision:
        """MCFE fork decision with 3-cycle hysteresis.

        Trace: Eq #74 (fork decision), Eq #75 (MCFE cost), Eq #82 (require 3
            consecutive cycles of the same decision before switching);
            Phi-Lite feature #23.
        """
        raise NotImplementedError(
            "spec: estimate Delta EFE and compute cost from state, apply "
            "mcfe_fork_decision, and only switch tier after "
            "self._hysteresis_required consecutive agreeing cycles"
        )

    def step(self, inp: LayerIO) -> LayerIO:
        """Advance one L7 cycle: goal, horizon, option, fork.

        Trace: Blueprint Part 2 (LayerIO contract); section 3.6.
        """
        raise NotImplementedError(
            "spec: compose select_goal/select_horizon/select_option/"
            "decide_fork into one LayerIO whose meta carries goal_id, "
            "horizon, option, and fork tier"
        )

    def falsification_test(self) -> FalsificationResult:
        """L7 kill criterion: novel persistent goals emerge (>= 3 by 10^6 cycles).

        Trace: Blueprint section 3.6 (falsifiable test), Part 5.3 (kill
            criteria); SPEC section 4.1.
        """
        raise NotImplementedError(
            "spec: delegate to GoalRegistry.falsification_test and report "
            "the novel-goal count as the metric"
        )


__all__ = [
    "ForkTier",
    "ForkDecision",
    "efe_optimal_stopping",
    "mcfe_fork_decision",
    "mcfe_cost",
    "compute_budget_lagrangian",
    "td_lambda_value",
    "lambda_return",
    "generalized_advantage_estimate",
    "MetaController",
]
```

----------------------------------------

### File: `goal_gen.py`

**Path:** `stage4/stage4/meta/goal_gen.py`
**Extension:** `.py`
**Size:** 8,024 bytes (7.84 KB)

```py
"""Open-ended goal generation via expected free energy (EFE).

This module is the ONLY place in the system where new goals are formed
(Blueprint section 3.6: "This is the only place new goals are formed").
Goals are sampled from the goal space by the objective

    g* = argmax_g [ H(z | g) - lambda * E[r | g] ]

balancing epistemic value (information gain about the latent state) against
pragmatic value (expected utility), with lambda = meta.goal_lambda.

The GoalRegistry maintains the partition of goals into designer-specified
(G_0) and emergent (G_t \\ G_0) sets and tracks persistence: a goal counts
toward the Stage 4 open-endedness criterion only if it survives at least
meta.goal_persistence_min (10^4) cycles and changes behavior (Part 1.1,
failure mode 4).

Traceability:
  - Blueprint section 3.6 (EFE goal generation), Part 1.1 (open-endedness),
    Part 8 failure mode 4 (novel goals are noise)
  - 144-equation ledger Eq #72 (expected free energy)
  - SPEC section 4.1 (GoalSpec contract)
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Dict, Iterable, List, Optional, Sequence

from stage4.config import Config
from stage4.core.types import FalsificationResult, GoalSpec, LayerIO

if TYPE_CHECKING:
    from phitensor import Tensor
    from phitensor.rng import Generator


def expected_free_energy(entropy_z_given_g: float,
                         expected_reward: float,
                         lam: float) -> float:
    """EFE-style goal score: H(z | g) - lambda * E[r | g].

    A goal is *novel* when it maximizes the epistemic term (information
    gain); it is *useful* when it maximizes the pragmatic term.  The
    meta-controller must balance both.

    Trace: Blueprint section 3.6 (goal generation objective); Eq #72
        (expected free energy G(pi)); SPEC section 4.2 (meta.goal_lambda).
    """
    raise NotImplementedError(
        "spec: return entropy_z_given_g - lam * expected_reward"
    )


def expected_free_energy_policy(belief_entropy: "Tensor",
                                predicted_outcome_ll: "Tensor") -> "Tensor":
    """Full active-inference EFE G(pi) = E_q[log q(z|pi)] - E_q[log p(o,z)].

    Trace: Eq #72 (expected free energy); Blueprint section 3.6.
    """
    raise NotImplementedError(
        "spec: combine the epistemic term (expected posterior entropy) with "
        "the pragmatic term (expected log-likelihood of preferred outcomes) "
        "elementwise over candidate policies"
    )


class GoalGenerator:
    """Samples candidate goals from the goal space by the EFE objective.

    Candidate goals are scored with expected_free_energy; the argmax becomes
    a GoalSpec with origin="emergent" if it is not a restatement of a
    designer goal.  Sampling uses the deterministic generator fork
    ``spawn("goal_gen")`` so runs are reproducible.

    Trace: Blueprint section 3.6 (only place new goals form); Eq #72;
        SPEC section 4.1 (GoalSpec).
    """

    name: str = "L7.goal_gen"

    def __init__(self, config: Config, generator: "Generator") -> None:
        """Initialize the generator from validated config and a seeded RNG.

        Trace: Blueprint section 3.6; SPEC section 4.2 (meta.goal_lambda);
            audit #21/#22 (explicit seeding).
        """
        self._config = config
        self._generator = generator
        raise NotImplementedError(
            "spec: read meta.goal_lambda and meta.goal_persistence_min; "
            "allocate the candidate-scoring scratch buffers"
        )

    def propose_candidates(self, beliefs: "Tensor",
                           n_candidates: int) -> List["Tensor"]:
        """Sample candidate goal directions in latent space.

        Trace: Blueprint section 3.6 (goals are sampled, not hand-specified).
        """
        raise NotImplementedError(
            "spec: sample n_candidates unit directions via the seeded "
            "generator, conditioned on current belief statistics"
        )

    def score_candidates(self, candidates: Sequence["Tensor"],
                         beliefs: "Tensor") -> List[float]:
        """Score each candidate with the EFE goal objective.

        Trace: Blueprint section 3.6; Eq #72.
        """
        raise NotImplementedError(
            "spec: estimate H(z|g) from belief entropy reduction and "
            "E[r|g] from the world model reward head, then apply "
            "expected_free_energy per candidate"
        )

    def generate(self, beliefs: "Tensor", cycle: int,
                 designer_goals: Sequence[GoalSpec]) -> Optional[GoalSpec]:
        """Produce the argmax-EFE goal, or None if no candidate clears the bar.

        Trace: Blueprint section 3.6 (g* = argmax_g [H(z|g) - lambda E[r|g]]);
            SPEC section 4.1 (GoalSpec origin field).
        """
        raise NotImplementedError(
            "spec: propose, score, pick argmax; set origin='emergent' unless "
            "the candidate matches a designer goal within tolerance; stamp "
            "goal_id, formed_cycle, epistemic/pragmatic values"
        )


class GoalRegistry:
    """Tracks designer (G_0) and emergent (G_t \\ G_0) goals and persistence.

    Part 1.1 requires |G_t \\ G_0| > 0 with goals that are *consequential*:
    they persist for >= meta.goal_persistence_min cycles and change behavior
    measurably.  Goals that flicker (failure mode 4) do not count.

    Trace: Blueprint Part 1.1 (open-ended goal formation), section 3.6,
        Part 8 failure mode 4; SPEC section 4.2 (meta.goal_persistence_min).
    """

    def __init__(self, config: Config,
                 designer_goals: Sequence[GoalSpec]) -> None:
        """Seed the registry with the designer goal set G_0.

        Trace: Blueprint Part 1.1 (G_0 subseteq G_t); SPEC section 4.1.
        """
        self._config = config
        raise NotImplementedError(
            "spec: store designer goals with origin='designer'; allocate the "
            "active/emergent goal tables and behavior-signature buffers"
        )

    def register(self, goal: GoalSpec) -> None:
        """Add a goal to the active set, deduplicating against G_0.

        Trace: Blueprint Part 1.1; section 3.6.
        """
        raise NotImplementedError(
            "spec: insert the goal; if within tolerance of a designer goal, "
            "relabel origin='designer'"
        )

    def tick(self, cycle: int, behavior_signature: "Tensor") -> None:
        """Increment persistence counters and record behavioral consequence.

        Trace: Blueprint Part 1.1 (goals must change behavior measurably
            across >= 10^4 cycles); failure mode 4.
        """
        raise NotImplementedError(
            "spec: for each active goal, increment persistence_cycles while "
            "the behavior signature stays consistent with the goal; retire "
            "goals whose signature drifts"
        )

    def novel_goals(self, min_persistence: Optional[int] = None) -> List[GoalSpec]:
        """Return emergent goals that survived the persistence threshold.

        Trace: Blueprint section 3.6 (test: >= 3 goals g not in G_0 persisting
            >= 10^4 cycles); failure mode 4 (persistence required to count).
        """
        raise NotImplementedError(
            "spec: filter origin='emergent' goals with persistence_cycles "
            ">= min_persistence (default meta.goal_persistence_min)"
        )

    def falsification_test(self) -> FalsificationResult:
        """Open-endedness kill criterion: >= 3 novel persistent goals.

        Trace: Blueprint section 3.6 (falsifiable test), Part 5.3 (kill
            criterion: no novel goals after 10^6 cycles).
        """
        raise NotImplementedError(
            "spec: pass iff len(self.novel_goals()) >= eval.novel_goals_min "
            "after eval.cycles_long_run cycles"
        )


__all__ = [
    "expected_free_energy",
    "expected_free_energy_policy",
    "GoalGenerator",
    "GoalRegistry",
]
```

----------------------------------------

### File: `maml.py`

**Path:** `stage4/stage4/meta/maml.py`
**Extension:** `.py`
**Size:** 6,077 bytes (5.93 KB)

```py
"""MAML-style meta-learning slow loop (Blueprint Part 4).

The system learns at three timescales: fast (every cycle: world-model
posterior, policy action), medium (every 1000 cycles: world-model and policy
weights), and slow (every 10^6 cycles: meta-parameters -- learning rates,
intrinsic-reward weights, option set).  This module implements the slow loop
with model-agnostic meta-learning:

    inner:  theta'  = theta - alpha * grad_theta L_task(theta)
    outer:  theta  <- theta - beta  * grad_theta L_task(theta')

"This is what makes transfer possible.  Without the slow loop, every task is
learned from scratch, and there is no Stage 4." (Blueprint Part 4)

Traceability:
  - Blueprint Part 4 (three learning loops, MAML-style slow loop)
  - 144-equation ledger Eq #59 (meta-policy with MAML)
  - Blueprint Part 1.2 (transfer is the payoff of meta-learning)
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Callable, Dict, List, Sequence, Tuple

from stage4.config import Config
from stage4.core.types import FalsificationResult, LayerIO

if TYPE_CHECKING:
    from phitensor import Tensor


@dataclass
class TaskBatch:
    """A meta-learning task sample for the slow loop.

    Attributes:
        task_id: identifier of the source task (held-in for meta-training).
        support: few-shot adaptation set (states, actions, rewards).
        query: held-out query set used for the outer gradient.

    Trace: Blueprint Part 4 (MAML-style slow loop); Eq #59.
    """

    task_id: str
    support: List[Tuple["Tensor", int, float]] = field(default_factory=list)
    query: List[Tuple["Tensor", int, float]] = field(default_factory=list)


@dataclass
class MetaParameters:
    """The meta-parameters owned by the slow loop.

    Attributes:
        learning_rates: per-subsystem learning-rate multipliers.
        intrinsic_weights: lambda_1..3 weighting novelty, compression
            progress, and empowerment in the intrinsic reward mix.
        option_budget: how many options the L3 layer may keep.

    Trace: Blueprint Part 4 (slow loop updates meta-parameters), section 3.7
        (meta-learned intrinsic weights); Eq #59.
    """

    learning_rates: Dict[str, float] = field(default_factory=dict)
    intrinsic_weights: List[float] = field(default_factory=lambda: [1.0, 1.0, 1.0])
    option_budget: int = 32


class MAMLSlowLoop:
    """Model-agnostic meta-learning over task batches (slow loop).

    Runs every ``meta.slow_loop_interval`` cycles.  Inner loop adapts a copy
    of the parameters on each task's support set; the outer loop moves the
    shared initialization toward fast-adapting parameters using each task's
    query set.

    Trace: Blueprint Part 4; Eq #59 (theta' = theta - alpha grad L_task,
        theta <- theta - beta grad L_task(theta')).
    """

    name: str = "L7.maml"

    def __init__(self, config: Config) -> None:
        """Initialize from validated config (maml_alpha, maml_beta).

        Trace: Eq #59; SPEC section 4.2 (meta.maml_alpha, meta.maml_beta,
            meta.slow_loop_interval).
        """
        self._config = config
        raise NotImplementedError(
            "spec: read meta.maml_alpha / meta.maml_beta / "
            "meta.slow_loop_interval; allocate gradient scratch tensors"
        )

    def inner_adapt(self, theta: "Tensor", task_loss_grad_fn: "Callable[[Tensor], Tensor]",
                    alpha: float, n_steps: int = 1) -> "Tensor":
        """Inner loop: theta' = theta - alpha * grad_theta L_task(theta).

        Trace: Eq #59 (inner loop); Blueprint Part 4.
        """
        raise NotImplementedError(
            "spec: copy theta, apply n_steps gradient steps with step size "
            "alpha using task_loss_grad_fn, return the adapted parameters"
        )

    def outer_update(self, theta: "Tensor", adapted: Sequence["Tensor"],
                     task_loss_grad_fn: "Callable[[Tensor], Tensor]",
                     beta: float) -> "Tensor":
        """Outer loop: theta <- theta - beta * grad_theta L_task(theta').

        Trace: Eq #59 (outer loop); Blueprint Part 4 (meta-gradient across
            tasks).
        """
        raise NotImplementedError(
            "spec: average query-set gradients evaluated at each adapted "
            "parameter set (first-order approximation allowed), then step "
            "theta with step size beta"
        )

    def meta_train(self, theta: "Tensor",
                   tasks: Sequence[TaskBatch]) -> "Tensor":
        """One full slow-loop meta-update over a batch of tasks.

        Trace: Eq #59; Blueprint Part 4 (slow loop every 10^6 cycles);
            Blueprint Part 1.2 (transfer is the payoff).
        """
        raise NotImplementedError(
            "spec: inner_adapt per task on support sets, then outer_update "
            "on query sets; return the new meta-initialization"
        )

    def update_meta_parameters(self, params: MetaParameters,
                               performance: Dict[str, float]) -> MetaParameters:
        """Adjust learning rates, intrinsic weights, and option budget.

        Trace: Blueprint Part 4 (slow loop updates meta-parameters),
            section 3.7 (meta-learned intrinsic reward coefficients).
        """
        raise NotImplementedError(
            "spec: move learning_rates / intrinsic_weights / option_budget "
            "in the direction of improved held-out performance, clamped to "
            "the read-only meta-parameter bounds of safety.invariants"
        )

    def falsification_test(self) -> FalsificationResult:
        """Slow loop must produce positive transfer gain on held-out pairs.

        Trace: Blueprint Part 5.2 (transfer gain > 0 on >= 15/20 pairs);
            Eq #59; SPEC section 4.1.
        """
        raise NotImplementedError(
            "spec: delegate to eval.transfer.TransferExperiment and pass "
            "iff mean per-pair gain > 0 with significance"
        )


__all__ = ["TaskBatch", "MetaParameters", "MAMLSlowLoop"]
```

----------------------------------------

##### Directory: `stage4/stage4/meta/__pycache__`


### Directory: `stage4/tests`


### File: `test_main_smoke.py`

**Path:** `stage4/tests/test_main_smoke.py`
**Extension:** `.py`
**Size:** 3,975 bytes (3.88 KB)

```py
"""Smoke tests for the runnable scalar core (stage4.main).

Verifies, using only the standard library (subprocess + unittest):

  1. `python3 -m stage4.main --cycles 50` exits 0 and prints the honest
     scalar metrics table with the expected markers.
  2. Determinism: two runs with `--seed 49` produce byte-identical stdout
     (all randomness flows through seeded phitensor.rng streams).
  3. `--eval-only` exits 0 with the honest "not a Stage 4 evaluation"
     framing and the S2.9 floor estimate.
  4. `--config` JSON overrides are honored (energy.budget shows through).

Run: python3 -m unittest discover -s tests -v

Traceability:
  - SPEC.md section 2 (deliverable standard), section 4 (pinned contracts)
  - Blueprint Part 10 (harness first), Part 9 (honesty framing)
  - Audit #21/#22 (seeded determinism)
"""

from __future__ import annotations

import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[1]


def run_cli(*args: str) -> subprocess.CompletedProcess:
    """Run `python -m stage4.main ...` from the repo root."""
    return subprocess.run(
        [sys.executable, "-m", "stage4.main", *args],
        cwd=str(REPO_ROOT),
        capture_output=True,
        text=True,
        timeout=180,
    )


class TestMainSmoke(unittest.TestCase):
    """The entry point runs real scalar dynamics and reports honestly."""

    def test_runs_50_cycles_exit_0(self) -> None:
        proc = run_cli("--cycles", "50")
        self.assertEqual(proc.returncode, 0,
                         f"exit {proc.returncode}; stderr: {proc.stderr}")
        out = proc.stdout
        self.assertIn("SCALAR CORE RUN", out)
        self.assertIn("NOT a Stage 4 evaluation", out)
        self.assertIn("emergence_level", out)
        self.assertIn("emergence_debt", out)
        self.assertIn("permanent_damage", out)
        self.assertIn("collapses", out)
        self.assertIn("scars", out)
        self.assertIn("mode distribution", out)
        self.assertIn("stage_estimate", out)
        self.assertIn("S2.9", out)

    def test_determinism_seed_49(self) -> None:
        first = run_cli("--cycles", "50", "--seed", "49")
        second = run_cli("--cycles", "50", "--seed", "49")
        self.assertEqual(first.returncode, 0, first.stderr)
        self.assertEqual(second.returncode, 0, second.stderr)
        self.assertEqual(first.stdout, second.stdout,
                         "identical seeds must produce identical metrics")
        # And the metrics lines are real, not empty.
        metric_lines = [
            line for line in first.stdout.splitlines()
            if line.startswith("emergence_level")
        ]
        self.assertTrue(metric_lines, "no metrics lines found")

    def test_eval_only_exit_0(self) -> None:
        proc = run_cli("--eval-only")
        self.assertEqual(proc.returncode, 0,
                         f"exit {proc.returncode}; stderr: {proc.stderr}")
        self.assertIn("NOT a Stage 4 evaluation", proc.stdout)
        self.assertIn("S2.9", proc.stdout)

    def test_config_override_honored(self) -> None:
        with tempfile.NamedTemporaryFile(
            "w", suffix=".json", delete=False
        ) as handle:
            json.dump({"energy": {"budget": 200.0}}, handle)
            path = handle.name
        try:
            proc = run_cli("--cycles", "20", "--config", path)
        finally:
            Path(path).unlink(missing_ok=True)
        self.assertEqual(proc.returncode, 0,
                         f"exit {proc.returncode}; stderr: {proc.stderr}")
        self.assertIn("budget=200.0", proc.stdout)

    def test_cycles_zero_is_assembly_check(self) -> None:
        proc = run_cli("--cycles", "0")
        self.assertEqual(proc.returncode, 0,
                         f"exit {proc.returncode}; stderr: {proc.stderr}")
        self.assertIn("completed=0", proc.stdout)


if __name__ == "__main__":
    unittest.main()
```

----------------------------------------

### File: `test_skeleton.py`

**Path:** `stage4/tests/test_skeleton.py`
**Extension:** `.py`
**Size:** 7,394 bytes (7.22 KB)

```py
"""Skeleton conformance tests for the Stage 4 candidate repository.

Verifies, using only the standard library:

  1. Every package file under stage4/ and phitensor/ parses cleanly (AST).
  2. Every module imports cleanly; modules whose collaborators belong to
     other agents' branches are skipped with a note until the merge lands.
  3. The LayerIO contract (stage4.core.types) exists and is referenced by
     every blueprint layer package.
  4. No third-party imports anywhere: only stdlib, phitensor, and stage4.
  5. SPEC section 2 surface rules: module docstrings and
     ``from __future__ import annotations`` in every package file.

Run: python3 -m unittest discover -s tests -v

Traceability:
  - SPEC.md section 2 (deliverable standard), section 4 (pinned contracts)
  - Blueprint Part 2 (LayerIO contract), Part 10 (harness first)
"""

from __future__ import annotations

import ast
import importlib
import sys
import unittest
from pathlib import Path
from typing import Dict, Iterator, List, Optional, Set, Tuple

REPO_ROOT = Path(__file__).resolve().parents[1]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

#: Top-level import roots that are allowed anywhere in the repository.
ALLOWED_ROOTS: Set[str] = {"stage4", "phitensor"} | set(sys.stdlib_module_names)

#: Packages that implement the seven blueprint layers (L1/L2 share
#: perception).  Each must reference the LayerIO contract somewhere.
LAYER_PACKAGES: Tuple[str, ...] = (
    "perception",
    "world_model",
    "self_model",
    "memory",
    "policy",
    "meta",
)


def _package_files() -> List[Path]:
    """Return all package source files under stage4/ and phitensor/."""
    files: List[Path] = []
    for pkg in ("stage4", "phitensor"):
        root = REPO_ROOT / pkg
        if root.is_dir():
            files.extend(sorted(root.rglob("*.py")))
    return files


def _module_name(path: Path) -> str:
    """Map a source path to its dotted module name."""
    rel = path.relative_to(REPO_ROOT).with_suffix("")
    parts = [p for p in rel.parts if p != "__init__"]
    return ".".join(parts)


def _import_roots(tree: ast.AST) -> Set[str]:
    """Collect the top-level roots of all imports in a parsed module."""
    roots: Set[str] = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            roots.update(alias.name.split(".")[0] for alias in node.names)
        elif isinstance(node, ast.ImportFrom) and node.level == 0 and node.module:
            roots.add(node.module.split(".")[0])
    return roots


class TestASTParse(unittest.TestCase):
    """Every package file must parse and carry the SPEC section 2 surface."""

    def test_every_file_parses(self) -> None:
        files = _package_files()
        self.assertTrue(files, "no package files found")
        for path in files:
            with self.subTest(file=str(path)):
                ast.parse(path.read_text(encoding="utf-8"), filename=str(path))

    def test_module_docstrings_present(self) -> None:
        for path in _package_files():
            with self.subTest(file=str(path)):
                tree = ast.parse(path.read_text(encoding="utf-8"))
                doc = ast.get_docstring(tree)
                self.assertTrue(doc and doc.strip(),
                                f"{path} missing module docstring")

    def test_future_annotations_import(self) -> None:
        for path in _package_files():
            with self.subTest(file=str(path)):
                tree = ast.parse(path.read_text(encoding="utf-8"))
                has_future = any(
                    isinstance(node, ast.ImportFrom)
                    and node.module == "__future__"
                    and any(alias.name == "annotations" for alias in node.names)
                    for node in tree.body
                )
                self.assertTrue(
                    has_future,
                    f"{path} missing 'from __future__ import annotations'",
                )


class TestNoThirdPartyImports(unittest.TestCase):
    """Only stdlib, phitensor, and stage4 may be imported (SPEC section 2)."""

    def test_import_roots_are_allowed(self) -> None:
        offenders: Dict[str, Set[str]] = {}
        for path in _package_files():
            tree = ast.parse(path.read_text(encoding="utf-8"))
            bad = _import_roots(tree) - ALLOWED_ROOTS
            if bad:
                offenders[str(path)] = bad
        self.assertEqual(offenders, {},
                         f"third-party imports found: {offenders}")


class TestModuleImports(unittest.TestCase):
    """Every module imports cleanly; missing collaborators are skipped.

    Before all feature branches merge, modules owned by other agents may be
    absent or may import not-yet-existing packages (e.g. phitensor).  Those
    are recorded as skips; once the merge lands, every module must import.
    """

    def test_modules_import_or_skip(self) -> None:
        imported: List[str] = []
        skipped: Dict[str, str] = {}
        for path in _package_files():
            name = _module_name(path)
            if not name:
                continue
            try:
                importlib.import_module(name)
                imported.append(name)
            except Exception as exc:  # noqa: BLE001 - tolerated pre-merge
                skipped[name] = f"{type(exc).__name__}: {exc}"
        for name, reason in sorted(skipped.items()):
            print(f"\nSKIP (pre-merge tolerance): {name} -> {reason}",
                  file=sys.stderr)
        self.assertTrue(imported, "no modules import at all")
        # The pinned contracts must always import (SPEC section 4).
        for required in ("stage4.config", "stage4.core.types"):
            self.assertIn(required, imported,
                          f"contract module {required} failed to import: "
                          f"{skipped.get(required, 'not found')}")


class TestLayerIOContract(unittest.TestCase):
    """The LayerIO contract exists and every layer package references it."""

    def test_layerio_defined_in_core_types(self) -> None:
        from stage4.core import types as core_types

        layer_io = getattr(core_types, "LayerIO", None)
        self.assertIsNotNone(layer_io, "stage4.core.types.LayerIO missing")
        for field_name in ("state", "uncertainty", "cost", "meta"):
            self.assertIn(field_name, layer_io.__dataclass_fields__)

    def test_layer_packages_reference_layerio(self) -> None:
        for pkg in LAYER_PACKAGES:
            pkg_dir = REPO_ROOT / "stage4" / pkg
            if not pkg_dir.is_dir():
                print(f"\nSKIP (package not yet merged): stage4.{pkg}",
                      file=sys.stderr)
                continue
            sources = "\n".join(
                p.read_text(encoding="utf-8") for p in pkg_dir.rglob("*.py")
            )
            with self.subTest(package=pkg):
                self.assertIn(
                    "LayerIO", sources,
                    f"stage4.{pkg} never references the LayerIO contract",
                )

    def test_main_references_layerio(self) -> None:
        main_py = REPO_ROOT / "stage4" / "main.py"
        if not main_py.is_file():
            self.skipTest("stage4/main.py not yet merged")
        self.assertIn("LayerIO", main_py.read_text(encoding="utf-8"))


if __name__ == "__main__":
    unittest.main()
```

----------------------------------------

#### Directory: `stage4/tests/__pycache__`


### Directory: `stage4/docs`


### File: `ARCHITECTURE.md`

**Path:** `stage4/docs/ARCHITECTURE.md`
**Extension:** `.md`
**Size:** 19,577 bytes (19.12 KB)

**Content:**

# ARCHITECTURE.md — System Architecture

Scope: the full 7-layer hierarchical predictive agent, the interfaces and
losses per layer, the three learning loops, and the integration points for
the v7.1 agency dynamics, the Levantine neurocognitive patch, and the
GhostMesh geometry/quantum/mesh patch.

All modules named below are skeleton stubs with spec docstrings unless marked
implemented. See [../STAGE.md](../STAGE.md) for the honest status.

## 0. Design principles

1. **Interfaces are contracts** (Blueprint Part 2). Every layer consumes and
   produces `LayerIO(state, uncertainty, cost, meta)` from
   `stage4/core/types.py`. Nothing crosses layers without uncertainty
   attached — in v7.1 there was no uncertainty propagation, so every layer
   lied to the next.
2. **Every layer is falsifiable.** The `Layer` protocol requires
   `falsification_test() -> FalsificationResult`. A component whose test
   cannot fail is decorative.
3. **Safety is a mathematical constraint**, not a checklist (Blueprint
   Part 6). All actions pass through the shield.
4. **Honesty over capability.** Components report calibrated uncertainty or
   they do not report.

## 1. The seven layers

```
┌─────────────────────────────────────────────────────────────┐
│ L7  Meta-Controller      : selects goals, horizons, options │
│     meta/controller.py meta/goal_gen.py meta/maml.py        │
├─────────────────────────────────────────────────────────────┤
│ L6  Self-Model           : predicts own future states/acts  │
│     self_model/predictor.py calibration.py spel.py          │
├─────────────────────────────────────────────────────────────┤
│ L5  World Model          : latent dynamics p(z'|z,a)        │
│     world_model/rssm.py loss.py causal.py                   │
├─────────────────────────────────────────────────────────────┤
│ L4  Memory               : episodic + semantic retrieval    │
│     memory/episodic.py semantic.py crystal.py               │
│     memory/narrative.py ledger.py                           │
├─────────────────────────────────────────────────────────────┤
│ L3  Policy (hierarchical): options, primitive actions       │
│     policy/primitives.py options.py selection.py            │
│     policy/hierarchical.py                                  │
├─────────────────────────────────────────────────────────────┤
│ L2  Perception           : encoders, real sensors           │
│     perception/vision_encoder.py audio_encoder.py           │
│     perception/fusion.py sensors.py                         │
├─────────────────────────────────────────────────────────────┤
│ L1  Sensors/Actuators    : camera, mic, speaker, GPIO?      │
│     perception/sensors.py (device interface, fail-closed)   │
└─────────────────────────────────────────────────────────────┘
```

### L1 — Sensors / Actuators

- **Modules:** `stage4/perception/sensors.py`.
- **Interface:** raw observations `o_t` out; consented actuations in.
- **Contract:** fail-closed. No actuation without consent flags
  (`safety/consent.py`); no exfiltration; hardware kill switch is physical,
  not software (Blueprint Part 6.4).
- **Falsifiable test:** a sensor stream that cannot be distinguished from the
  mock sine generator fails — real data only for any stage claim.

### L2 — Perception

- **Modules:** `perception/vision_encoder.py`, `audio_encoder.py`,
  `fusion.py`, `sensors.py`.
- **Interface:** `o_t → z ∈ R^128` (per modality), fused by cross-attention.
- **Losses:**
  - Vision, contrastive (SimCLR-style):
    $\mathcal{L}_{\text{con}} = -\log \frac{\exp(\mathrm{sim}(z_i, z_j^+)/\tau)}{\sum_k \exp(\mathrm{sim}(z_i, z_k)/\tau)}$
  - Audio: predictive coding loss on mel-spectrograms.
  - Fusion: $z = \mathrm{Attn}(W_v z_v, W_a z_a, W_a z_a)$ — cross-attention,
    not concatenation.
- **Falsifiable test:** held-out prediction error on real data beats a matched
  random encoder by ≥ 2σ. Kills audit #4 (no sensors), replaces v7.1's
  `mock_z()`.

### L3 — Hierarchical Policy

- **Modules:** `policy/primitives.py`, `options.py`, `selection.py`,
  `hierarchical.py`.
- **Interface:** primitives $\pi_\theta(a \mid z)$; options
  $(\mathcal{I}_o, \pi_o, \beta_o)$ with initiation set, intra-option policy,
  termination.
- **Losses:** policy gradient with baseline; entropy regularizer
  $\mathcal{L}_H = -\beta H(\pi)$ (Eq 64) to prevent degeneracy.
- **Option discovery:** Laplacian bottleneck states
  $\mathcal{B} = \{ z : \lambda_2(L) \text{ small at } z \}$ — states where the
  transition graph is nearly disconnected are natural subgoals.
- **Falsifiable test:** options emerge that reduce average episode length on
  ≥ 2 held-out tasks without being specified.

### L4 — Memory

- **Modules:** `memory/episodic.py` (vector store of $(z_t, a_t, r_t, t)$,
  MIPS retrieval), `memory/semantic.py` (MDL-compressed summaries),
  `memory/crystal.py` (8-D boundary slots, fixed recall), `memory/ledger.py`
  (ring buffer with hash indexing), `memory/narrative.py` (narrative-bound
  compression with Levantine tags).
- **Semantic compression (MDL):** $n^* = \arg\min_n \left( L(n) + L(\mathcal{D} \mid n) \right)$
- **Recall is not tautological:** retrieval excludes any slot within ε of the
  query *by construction* (fixes the v7.1 `slots[:-1]` patch).
- **Falsifiable test:** recall improves a downstream held-out task; if it does
  not, memory is decorative.

### L5 — World Model (the core)

- **Modules:** `world_model/rssm.py` (recurrent state-space model),
  `loss.py`, `causal.py` (interventions / counterfactuals).
- **Math (Dreamer/PlaNet style):**
  $$\begin{aligned}
  z_t &\sim q_\phi(z_t \mid z_{t-1}, a_{t-1}, o_t) &&\text{(posterior)}\\
  \hat z_t &\sim p_\theta(\hat z_t \mid z_{t-1}, a_{t-1}) &&\text{(prior)}\\
  \mathcal{L}_{\text{WM}} &= \underbrace{-\log p_\theta(o_t \mid z_t)}_{\text{reconstruction}} + \underbrace{\mathrm{KL}(q_\phi \| p_\theta)}_{\text{consistency}} + \underbrace{\|\hat r_t - r_t\|^2}_{\text{reward}}
  \end{aligned}$$
- Prediction happens in latent space, not on raw `b` — the single largest
  change from v7.1's hand-rolled GRU.
- **Falsifiable test:** $\mathcal{L}_{\text{WM}}$ on held-out trajectories
  decreases with slope < 0 at p < 0.01 over 10⁵ gradient steps.

### L6 — Self-Model

- **Modules:** `self_model/predictor.py`, `calibration.py`, `spel.py`
  (fixed self-prediction error loop; audit #97–108).
- **Loss:** $\mathcal{L}_{\text{self}} = \|\hat z_{t+k}^{\text{self}} - z_{t+k}\|^2 + \mathrm{ECE}(c_{\text{self}}, \mathbb{1}[\hat a = a])$
- **Calibration is measured, not asserted:**
  $\mathrm{ECE} = \sum_{b=1}^{B} \frac{n_b}{N} \left| \mathrm{acc}(b) - \mathrm{conf}(b) \right|$
- **Falsifiable test:** ECE < 0.1 on held-out rollouts. If ECE > 0.2 the
  self-model is a lie; the system halts rather than acting on it.

### L7 — Meta-Controller

- **Modules:** `meta/controller.py`, `goal_gen.py`, `maml.py`.
- **Goal selection via expected free energy:**
  $G(\pi) = \underbrace{\mathbb{E}_q[\log q(z \mid \pi)]}_{\text{epistemic}} - \underbrace{\mathbb{E}_q[\log p(o, z)]}_{\text{pragmatic}}$
- **Goal generation:** $g^* = \arg\max_{g \in \mathcal{G}} \left[ H(z \mid g) - \lambda\, \mathbb{E}[r \mid g] \right]$
- **This is the only place new goals are formed.** Goals are sampled from the
  goal space by this objective, never hand-specified (kills audit #5).
- **Falsifiable test:** over 10⁵ cycles the system generates ≥ 3 goals
  $g \notin \mathcal{G}_0$ that persist ≥ 10⁴ cycles and change behavior.

### Intrinsic rewards (three, meta-weighted — Blueprint Part 3.7)

- Novelty (RND): $r_{\text{nov}} = \|\phi(z) - \hat\phi(z)\|^2$
- Compression progress: $r_{\text{comp}} = L(z_{1:t-1}) - L(z_{1:t})$
- Empowerment: $r_{\text{emp}} = I(a; z' \mid z)$
- Combined: $r = r_{\text{ext}} + \lambda_1 r_{\text{nov}} + \lambda_2 r_{\text{comp}} + \lambda_3 r_{\text{emp}}$ with meta-learned $\lambda$.

## 2. Learning loops (Blueprint Part 4)

Three timescales; v7.1 had one (per-cycle jitter) and it was too slow.

| Loop | Frequency | What updates | Host modules |
|---|---|---|---|
| Fast | Every cycle | World model posterior, policy action | `core/loop.py`, `world_model/rssm.py`, `policy/selection.py` |
| Medium | Every 1000 cycles | World model parameters, policy weights | `world_model/loss.py`, `policy/hierarchical.py` |
| Slow | Every 10⁶ cycles | Meta-parameters: learning rates, intrinsic weights, option set | `meta/maml.py`, `meta/controller.py` |

Slow-loop meta-learning is MAML-style:
$\theta' = \theta - \alpha \nabla_\theta \mathcal{L}_{\text{task}}(\theta)$, then
$\theta \leftarrow \theta - \beta \nabla_\theta \mathcal{L}_{\text{task}}(\theta')$.
**The slow loop is what makes transfer possible.** Without it every task is
learned from scratch and there is no Stage 4.

## 3. Cross-cutting subsystems

### 3.1 v7.1 agency dynamics — `stage4/agency/`, `stage4/core/energy.py`, `stage4/core/modes.py`

The v7.1 heritage survives as the *dynamics* layer beneath the 7-layer brain,
fixed per the 144-point audit:

- `agency/emergence.py` — emergence level as measured causal density, debt
  dynamics with clamped bounds, phase transitions with hysteresis (audit
  #25–40). No longer a bare sigmoid of experience count.
- `agency/commitments.py` — painful commitments with crystallization levels
  (`CommitmentLevel` VOLATILE→FIXED), enforced restricted-option sets,
  clamped change costs (audit #41–56).
- `agency/scars.py` — structured stagnation/social-friction scars with
  healing and clamped permanent damage (audit #57–68).
- `agency/criticality.py` — precision-noise criticality tied to task
  performance and plasticity, adaptive danger windows (audit #69–80).
- `core/energy.py` — homeostasis with clamped energy/damage, Landauer-aware
  accounting, mode-dependent cognitive cost (audit #81–96, Eq 1–14).
- `core/modes.py` — DDMS mode switching with dwell time and hysteresis; hosts
  the extended `SystemMode` set (ENCAPSULATED, PROPHETIC, PRESENT_LOCKED,
  SUPERSOLID, TIME_CRYSTAL) from the two patches (audit #109–118).
- `self_model/spel.py` — SPEL fixed: persistent lambda, proper Bayesian
  update, information-theoretic surprise (audit #97–108).
- `quantum/observer.py` — hosts the CCF successor: counterfactual filtering
  with causal graphs and paradox guards (audit #119–128).
- `memory/narrative.py` — NBC fixed: recency-preserving compression with
  semantic tags (audit #129–136).
- `eval/report.py` — metrics with confidence intervals, baselines, honest
  stage estimate (audit #137–144).

### 3.2 Levantine neurocognitive patch — `stage4/neuro/`

Design metaphors made testable (L1–L48; see
[PATCH_INTEGRATION.md](PATCH_INTEGRATION.md)):

- `neuro/axes.py` — the neurocognitive coordinate
  $\mathbf{N} = (\mathcal{P}, \mathcal{B}, \mathcal{T})$: precision
  (local/global), boundaries (social/sensory), temporal focus ∈ [−2, +2]
  (L1–L8). Feeds `core/state.py` and the extended mode set.
- `neuro/priors.py` — archaic genomic priors as initial biases
  (`brca2_clamp`, `foxp2_discount`, `ghost_filter`) (L5, L17–L24).
- `neuro/blankets.py` — sensory and social Markov blankets; ritual/ochre
  scaffolding that damps ambient noise ξ(t) (L9–L16).
- `neuro/hysteresis.py` — environmental hysteresis traps, Heinrich-style
  shock events, slow-decay hypersensitivity (L9–L16, L25–L32).
- `neuro/alignment.py` — domain-bound agents, social-consensus firewalls,
  bias-mimicry firewalls, boundary-integrity monitoring (L41–L48). Benchmarked
  by `eval/benchmarks.py`.

### 3.3 GhostMesh geometry / quantum / mesh — `stage4/geometry/`, `stage4/quantum/`, `stage4/mesh/`

- `geometry/sectors.py` — 49-sector recursive substrate (7×7): every
  commitment, scar, and narrative gets a (sector, layer) coordinate (G1).
- `geometry/fractals.py` — Sierpinski density, Mandelbrot bounded-orbit
  commitment classification, Koch boundary metric, Hausdorff dimension of
  identity, IFS self-similarity, spectral/HRR hosts for Eq 111–124 (G2–G8).
- `geometry/lsystem.py` — L-system strategy rewriting; strategies grow by
  rule, not by dice (G7).
- `geometry/chaos.py` — Feigenbaum scheduling, logistic regime switch
  (G9–G10).
- `quantum/observer.py` — wave-collapse basis selection for commitments,
  quantum Zeno observation effects, tunneling, decoherence walls, CCF
  successor (G11–G20; audit #119–128).
- `quantum/entanglement.py` — entangled correlated commitments, CHSH
  violation detection, ER=EPR links (G12, G13, G19).
- `quantum/holography.py` — Bekenstein–Hawking area entropy, AdS/CFT-style
  bulk/boundary duality, topological error correction, Lorentz intervals,
  stress tensors, Schwarzschild horizons, entropic gravity (G21–G28).
- `quantum/spacetime.py` — Kerr frame-dragging of attention, wormhole tolls,
  cosmological-constant permeability, bubble nucleation, conformal cyclic
  return, JWST archaic-core anomaly (G29–G34).
- `quantum/signals.py` — the 2024–26 signal layer: logical qubit longevity,
  spin currents, supersolid mode, fractional excitons, magic-angle resonance,
  celestial holography, time crystals, neutrino flavor oscillation (G35–G42).
- `mesh/node.py`, `mesh/observer.py`, `mesh/metrics.py`, `mesh/reweave.py` —
  the 48-node seed mesh with a 49th observer node, per-node wedge learning,
  drift/SD/ESS metrics, crystal memory with introspection probes,
  quarantine→reweave healing, archetype assignment (G43–G48).

**Status honesty:** these are speculative design metaphors expressed as
testable skeleton modules. They are not physics claims. Each carries a
falsification test; modules that cannot fail will be removed.

### 3.4 Safety — `stage4/safety/`

- `safety/cbf.py` — control barrier function $h(s) \ge 0 \iff s \in \mathcal{S}_{\text{safe}}$ with $\dot h(s) + \alpha(h(s)) \ge 0$ for forward invariance.
- `safety/shield.py` — every action passed through $\mathrm{Shield}(a, s)$: the
  action if the successor stays safe, else $a_{\text{safe}}$.
- `safety/invariants.py` — the read-only core: world-model architecture,
  shield parameters, reward structure, meta-parameter bounds.
- `safety/consent.py` — consent flags; fail-closed actuation.
- `safety/audit.py` — cryptographic audit trail: hash chains, Merkle trees,
  template-lock Bloom filters (Eq 125–134).

## 4. Data flow (per cycle)

```
            ┌──────────────────────────────────────────────────────┐
            │                  safety/shield.py                     │
            │        (every action passes through; fail-closed)     │
            └───────────────▲──────────────────────────┬────────────┘
                            │ action a_t                │ safe a_t
┌────────┐   o_t   ┌─────────────────┐  z_v, z_a  ┌───────────────┐
│ L1     │────────▶│ L2 perception   │───────────▶│ fusion        │
│ sensors│         │ encoders        │            │ cross-attn    │
└────────┘         └─────────────────┘            └──────┬────────┘
                                                         │ z_t (±σ)
              ┌──────────────────────────────────────────▼─────────┐
              │ L5 world model (RSSM): posterior q(z_t|...), prior  │
              │ p(ẑ_t|z_{t-1},a_{t-1}), loss recon+KL+reward        │
              └──────┬───────────────────────────────▲─────────────┘
                     │ z_t                           │ retrieval (ε-exclusion)
        ┌────────────▼───────────┐       ┌───────────┴────────────┐
        │ L4 memory              │       │ episodic / semantic /  │
        │ episodic+semantic      │◀──────│ crystal / narrative /  │
        └────────────┬───────────┘ write │ ledger                 │
                     │                   └────────────────────────┘
        ┌────────────▼───────────┐
        │ L6 self-model          │  ẑ^self_{t+k}, c_self (ECE-tracked)
        └────────────┬───────────┘
                     │
        ┌────────────▼───────────┐   options (I_o, π_o, β_o)
        │ L3 hierarchical policy │◀── option discovery (Laplacian)
        └────────────┬───────────┘
                     │
        ┌────────────▼───────────┐   goals g* = argmax[H − λE[r]]
        │ L7 meta-controller     │   (only place new goals form)
        └────────────────────────┘

Cross-cutting (every arrow carries LayerIO(state, uncertainty, cost, meta)):
  agency/*   — emergence debt, commitments, scars, criticality dynamics
  neuro/*    — (P,B,T) axes, blankets, hysteresis, alignment firewalls
  geometry/* — 49-sector coordinates, fractal metrics, chaos schedules
  quantum/*  — observer/collapse, entanglement, holography, signals
  mesh/*     — 48-node substrate + 49th observer, drift/reweave
  safety/*   — CBF, shield, invariants, consent, audit (outermost loop)
```

## 5. What is deliberately absent

- No self-modification of the core (Blueprint Part 6.3).
- No claim of consciousness, sentience, or AGI.
- No third-party numerical dependencies: the backend is `phitensor`, our own
  (see `docs/BACKEND.md`).
- No metric without a confidence interval, no stage claim without a metrics
  window.

----------------------------------------

### File: `BACKEND.md`

**Path:** `stage4/docs/BACKEND.md`
**Extension:** `.md`
**Size:** 13,359 bytes (13.05 KB)

**Content:**

# BACKEND.md — phitensor Efficiency Architecture

**Status:** skeleton specification (SPEC §2) · **Owner:** agent A (backend)
**Scope:** `phitensor/` — the custom, pure-stdlib tensor/autograd backend for
the Stage 4 candidate system.

This document is where the user's **"99.9% efficiency" mandate** is made
concrete. 99.9% does not mean a magic constant; it means: *on the project's
fixed op profile (§9), no more than 0.1% of cycles and bytes should be spent
on anything that is not arithmetic the math requires.* Every design decision
below is a rule that removes a class of overhead: allocation, copies,
dtype sloppiness, cache misses, dispatch nondeterminism, interpreter
dispatch waste. Rules are normative; implementation of the compute bodies
is staged (all public functions currently raise
`NotImplementedError("spec: ...")` — see SPEC §2).

Trace: SPEC §4.3 (pinned API); Blueprint Part 3 (math), Part 7.1 (compute
profile); config `backend.*`; Audit #21/#22 (determinism).

---

## 1. Memory layout

**Rule 1.1 — One tensor, one contiguous C-order buffer.** Every `Tensor`
owns (or views) exactly one contiguous row-major allocation. Shape,
strides, and offset are metadata; the buffer is the truth.

**Rule 1.2 — Views are stride algebra, never copies.** `reshape`, `T`,
transpose, and axis-0 slicing produce a new `Tensor` header pointing at
the same buffer with recomputed `(shape, strides, offset)`. A copy is
materialized *only* when a consumer requires contiguity and the view is
provably non-contiguous (`is_contiguous` check). Config
`backend.zero_copy_views=True` gates this behavior.

**Rule 1.3 — Alignment.** Arena allocations are 64-byte aligned so every
tensor row that starts at offset 0 is a full cache line, and SIMD loads
(§4) never split lines. `.ptx` payloads are 64-byte aligned for the same
reason (`phitensor.io`).

**Rule 1.4 — Row-major hot axis.** All elementwise and reduction kernels
iterate the last axis innermost (stride 1 for contiguous tensors). Kernels
that receive a transposed view either consume it strided (elementwise ops:
cheap) or materialize one contiguous copy and say so in their cost
accounting (matmul: the copy is amortized over the GEMM).

Memory model per tensor:

```
Tensor header:  shape (tuple), strides (tuple), offset (int),
                dtype, device, requires_grad, grad_fn, _ctx, grad
Buffer:         bytearray / mmap region, numel(shape) * dtype.itemsize bytes,
                64-byte aligned
```

## 2. Arena allocation

**Rule 2.1 — Thread-local arenas.** Each worker thread owns a bump-pointer
arena carved into size-classed free lists (powers of two from 64 B to
1 MB; exact-fit lists above). Tensor allocation is a free-list pop, not a
`malloc` call in the hot path.

**Rule 2.2 — The hot loops allocate zero bytes per iteration.**
`fused_rssm_step`, `fused_efe_score`, `fused_ece_bins` (§5) write into
caller-owned or arena-scratch buffers sized once at plan time. Between
them they eliminate the ~12 intermediate tensors/cycle that a naive
op-chain would allocate.

**Rule 2.3 — Autograd is the only sanctioned allocation source on training
steps, and `no_grad` turns it off.** Inference paths (rollouts, EFE
scoring, action selection, ECE evaluation) must run under
`phitensor.autograd.no_grad()`, which suppresses graph-node and
saved-tensor allocation entirely. `fused_efe_score` *refuses* to run with
grad enabled — it is inference-only by construction.

**Rule 2.4 — Reference-counted release.** Backward frees each saved
intermediate as its consumer count hits zero; buffers return to the
arena's free lists, never to the OS.

## 3. Cache-blocking strategy

The profile is CPU-small-matrix dominated (latent 128, hidden 256, heads
few — config `world_model.latent_dim=128`, `hidden_dim=256`), so the
blocking plan targets L1/L2 residency, not TLB gymnastics:

| Level | Tile (f32 elems) | Target | Rule |
|---|---|---|---|
| KC (inner) | 128 | L1 (32 KB) | `matmul` inner block; equals latent_dim |
| MC (rows)  | 64  | L1  | rows of A resident while streaming B panel |
| NC (cols)  | 256 | L2  | one B panel per outer iteration; equals hidden_dim |

**Rule 3.1 — GEMM is the only contraction kernel.** `einsum`, `conv1d`,
`conv2d`, and attention score/value contractions all lower to
`permute/reshape → blocked GEMM` (conv via im2col into arena scratch).
One kernel to optimize, one kernel to verify, one kernel to make
deterministic (§10).

**Rule 3.2 — f64 accumulator tiles.** Accumulation tiles live in registers
/L1 in f64 (§7); stores to the f32 output happen once per output tile.

**Rule 3.3 — Packed B panels.** For GEMMs reused across steps (all RSSM
weight matrices), B is packed once into contiguous panels at plan time;
per-step cost is pure streaming.

## 4. SIMD / vectorization plan

Pure Python cannot emit SIMD instructions directly; the plan is therefore
staged and honest:

1. **Skeleton (now):** all compute is `NotImplementedError`; structure,
   layouts, and dispatch are final.
2. **Reference stage:** `array.array`/`struct`-backed scalar kernels with
   exact semantics — the determinism oracle for every later stage.
3. **Vectorized stage:** hot loops re-expressed over
   `memoryview`/`array` slices using bulk operations
   (`struct.iter_unpack`, slice assignments, `math.fsum`-style pairwise
   reductions) that execute in C inside CPython — the legitimate
   "vectorization" available without third-party code.
4. **Native stage (post-skeleton, optional):** a ctypes-loaded C shared
   library built in-repo (still zero third-party *Python* deps) with
   AVX2/NEON kernels behind the same op contracts; stage 2 outputs are
   the acceptance tests (bit-tolerance: exact for i64/bool8, ≤1 ulp f64
   accumulation for f32 pipelines).

Elementwise ops (gelu, silu, sigmoid, tanh_) are bandwidth-bound: the
plan fuses them into their producer/consumer (§5) rather than
"vectorizing" a standalone pass.

## 5. Kernel fusion design

Config `backend.kernel_fusion=True` enables substitution through
`phitensor.kernels.FUSION_REGISTRY` (name → kernel). Fusion criteria: an
op chain is fused iff it (a) runs every cycle or every scoring event,
(b) materializes intermediates larger than L1, and (c) has an exact
algebraic backward. The registry is deliberately small — three entries:

- **`fused_rssm_step`** (Blueprint §3.2): virtual concat `[z;a]` → GRU
  gate math in-register → prior/posterior heads on the resident hidden
  tile. Eliminates ~12 kernel launches and ~12 intermediates per cycle.
  One fused autograd node replays gate Jacobians in backward.
- **`fused_efe_score`** (Blueprint §3.6): per-candidate streaming pass
  accumulating `Σ q·log q` and `Σ q·log p` in f64, combined with the
  value head via `meta.goal_lambda`. Inference-only; zero allocation.
- **`fused_ece_bins`** (Blueprint §3.3): one pass over N samples
  accumulating per-bin counts/confidence/accuracy in f64 — replaces
  `n_bins` masked reductions. Feeds the halt check `ECE > 0.2`
  (failure mode 3).

Activation fusion (tanh_ into the GRU step, silu into RSSM MLPs) is
absorbed by `fused_rssm_step`; standalone elementwise fusions beyond the
registry require the criteria above plus a ledger entry.

## 6. Threading model

**Rule 6.1 — Threading is opt-in and config-bounded.** `backend.threads=0`
means "all cores"; any value >0 caps the pool.

**Rule 6.2 — Fork-join at op granularity, never inside inner loops.**
Threads parallelize the outer (batch / row-block / candidate-policy)
dimension only; the inner loop stays single-threaded so per-thread work
is ≥ one L2 tile (§3). No locks in kernels: each thread writes disjoint
output tiles and uses its own arena (§2.1).

**Rule 6.3 — Reductions merge in fixed order.** Cross-thread partials
(e.g. ECE bin arrays, softmax denominators) merge by ascending thread
index, giving bit-exact results independent of scheduling (§10).

**Rule 6.4 — GIL honesty.** Under pure-Python stages 2–3, "threads"
provide determinism-safe *structure* (the same decomposition is used,
with sequential execution); true parallel speedup arrives with the
native stage (§4.4). The decomposition is designed now so nothing
changes semantically when execution becomes parallel.

## 7. Dtype / accumulation policy

**Storage dtypes (the full set — SPEC §4.3):** `f32` (default, config
`backend.dtype`), `f64`, `i64` (indices/targets), `bool8` (masks).

**Rule 7.1 — f32 storage, f64 accumulation.** Every reduction whose result
feeds a probability, a divergence, a calibration metric, or a Fisher
estimate accumulates in f64: softmax/log-softmax denominators,
`kl_divergence`, `cross_entropy`, `mse_loss`, layernorm/rmsnorm statistics
(Welford), `fused_ece_bins`, `NaturalGradient` Fisher EMA, `clip_norm_`.
The accumulator rule is exposed on the tensor as `accumulate_dtype`.

**Rule 7.2 — Stabilization is part of the op, not the caller's job.**
Softmax subtracts the running max (online single-pass); cross-entropy is
fused log-softmax + NLL gather (never `log(softmax(x))`); sigmoid uses
the `exp(-|x|)` branch-free stable form; KL clamps tiny negative results
from roundoff to 0.

**Rule 7.3 — No silent upcasting.** Mixed-dtype arithmetic raises unless
one side is a Python scalar. bool8 participates only in masking. This
keeps the dispatch matrix at 4 dtypes × pinned ops — small enough to
test exhaustively.

## 8. Zero-copy interop

**`Tensor.numpy_view() -> memoryview`** (the name is the contract, not a
dependency): a PEP 3118 buffer view with correct format/shape/strides —
any buffer-protocol consumer (including NumPy in *client* code, image
capture, audio devices) reads tensor memory without a copy and without
phitensor importing anything. Contiguous tensors only; non-contiguous
views must be materialized first (Rule 1.2 exception path).

**`.ptx` checkpoints (`phitensor.io`):** little-endian binary with a
fixed header (magic `PHITNSR1`, version, N records), 64-byte-aligned
payloads, and a JSON sidecar carrying names/shapes/dtypes/blake2b
checksums plus the config snapshot (`system.seed`) for the audit trail.
`load(path, mmap_mode=True)` memory-maps payloads: tensors view the map
directly; mutation triggers copy-on-write into the arena. Multi-GB
checkpoints never touch the Python heap.

## 9. Per-op complexity table (the project's op profile)

Dims from config: latent `z=128`, hidden `h=256`, embed `e=128`, batch `B`,
attention `d=64` per head, `t` tokens, ECE `N` samples / `b=15` bins,
Hopfield `M` memory slots. FLOPs count multiply-add as 2.

| Hot loop | Op chain (unfused) | FLOPs | Intermediates (unfused) | Fused intermediates | Complexity class |
|---|---|---|---|---|---|
| **RSSM step** (`fused_rssm_step`) | concat + 3 GEMM + 6 act + 2 head GEMM | `B·(2(z+a)h + 2h·3h + 4hz)` ≈ `B·8h²` ≈ 525k·B | ~12 tensors/cycle | 3 outputs, 0 extra | `O(B·h²)` |
| **Cross-attention fusion** (`scaled_dot_product_attention`) | `qk^T/√d` + softmax + `·v` | `t²·(2d+2dv) + 5t²` | `t×t` score matrix | none (tiled, flash-style) | `O(t²·d)` time, `O(t·d)` memory |
| **EFE scoring** (`fused_efe_score`) | entropy + KL + scale + add per candidate | `P·z·~8` | 4 per policy | 1 per policy | `O(P·z)` |
| **ECE binning** (`fused_ece_bins`) | 15 masked reductions | `b·N` (naive) → `N` fused | b partial tensors | 3 fixed arrays | `O(N)` |
| **Hopfield recall** (`einsum`+softmax+`matmul`) | scores `q·K^T` + softmax + value mix | `M·z + 5M + M·z` | score vector | score buffer reused | `O(M·z)` |
| Medium-loop step (AdamW) | per-param update | `5·|θ|` | 2 moment buffers/param | fused single pass | `O(|θ|)` |
| Slow-loop meta-step (NaturalGradient + MAML) | Fisher EMA + preconditioned step | `4·|θ|` | Fisher diagonal/param | fused single pass | `O(|θ|)` |

The unfused→fused gap is the 99.9% mandate in action: every eliminated
intermediate is allocation + write + read + free removed from a loop that
runs 10⁶+ cycles (config `eval.cycles_long_run`).

## 10. Determinism guarantees

Config `system.seed=49`, `system.deterministic=True` (Audit #21/#22).

1. **RNG:** all randomness flows through `phitensor.rng.Generator`;
   subsystem streams fork via SHA-256 seed derivation
   (`spawn("policy")`, `spawn("world_model")`, …), so draw order in one
   subsystem can never perturb another. Forking is `hash()`-free
   (PYTHONHASHSEED-independent).
2. **Draw order:** tensor samplers fill in C-order — reproducible
   regardless of threading decomposition.
3. **Reduction order:** pairwise/blocked reductions and cross-thread
   merges follow a fixed order (§6.3); f64 accumulation makes the order
   insensitivity provable.
4. **Autograd:** backward traverses a fixed topological order; no
   dict-iteration-order dependence.
5. **Dispatch:** `FUSION_REGISTRY` is static and ordered; fusion on/off
   (config `backend.kernel_fusion`) must produce identical results within
   the f32 tolerance defined by §4 stage-2 oracle tests.
6. **Serialization:** checkpoints write records in sorted-name order and
   embed the seed in the sidecar (§8), so a saved state implies its full
   RNG provenance.

---

*This document specifies; `phitensor/` implements against it. Any change
to a rule above requires updating this file and the citing docstrings in
the same commit.*

----------------------------------------

### File: `EQUATION_LEDGER.md`

**Path:** `stage4/docs/EQUATION_LEDGER.md`
**Extension:** `.md`
**Size:** 21,796 bytes (21.29 KB)

**Content:**

# EQUATION_LEDGER.md — 144 Equations → Host Modules

Every equation from the 144-equation design ledger, restated in LaTeX, mapped
to its host module in the canonical tree ([../SPEC.md](../SPEC.md) §3), with
one line on its role. Group spine is SPEC §5.

Coverage: **144/144 equations.**

Status honesty: host modules are skeleton stubs; the formulas below are the
specification each stub must implement (see [../STAGE.md](../STAGE.md)).

Group spine (SPEC §5): Eq 1–14 → `core/energy.py`; Eq 15–30 →
`self_model/predictor.py`, `world_model/rssm.py`; Eq 31–48 →
`memory/crystal.py`, `memory/ledger.py`, `memory/semantic.py`; Eq 49–68 →
`policy/selection.py`, `policy/options.py`, `policy/hierarchical.py`;
Eq 69–82 → `perception/fusion.py`, `meta/controller.py`; Eq 83–96 →
`self_model/calibration.py`; Eq 97–110 → `quantum/observer.py`,
`quantum/signals.py`; Eq 111–124 → `geometry/fractals.py` (spectral/HRR
hosts); Eq 125–134 → `safety/audit.py`; Eq 135–144 → `safety/`.

## A. Desire, Homeostasis, and Energy (1–14) → `core/energy.py`

| Eq | Formula | Host module | Role |
|---|---|---|---|
| 1 | $D_s = -\sum_i p_i \log p_i \cdot \sigma(H_t)$ | `stage4/core/energy.py` | Entropic desire: replaces scalar D_speak; speech drive follows policy entropy. |
| 2 | $V(e,f) = (1-e)^2 + f^2$, stable iff $\dot V < 0$ | `stage4/core/energy.py` | Lyapunov energy function; gates SPEAK on $\dot V \le 0$. |
| 3 | $\mu = 1 + \alpha(1-e) + \beta f$ | `stage4/core/energy.py` | Metabolic multiplier on all action costs; blocks speech when starved. |
| 4 | $\Phi_H = \frac{(e-e^*)^2}{2\sigma_e^2} + \frac{(f-f^*)^2}{2\sigma_f^2}$ | `stage4/core/energy.py` | Homeostatic potential; drives policy toward $\nabla\Phi_H = 0$. |
| 5 | $c_{SPEAK} = 0.05\,(1 + (1-\kappa))$ | `stage4/core/energy.py` | Kappa-weighted speech cost: uncertain agents pay more. |
| 6 | $R(t) = \exp\!\left(-\frac{(t-t_s)^2}{2\tau_R^2}\right)$ | `stage4/core/energy.py` | Refractory kernel; smooth replacement for the hard 8 s block. |
| 7 | $F_{int} = D_{KL}(q(b)\,\|\,p(o,b))$ | `stage4/core/energy.py` | Interoceptive free energy in proper variational form. |
| 8 | $\dot D = A D + B\,\xi(t)$ | `stage4/core/energy.py` | Drive coupling matrix for the 8-drive vector D0–D7. |
| 9 | $\dot f = \eta\,c(a) - \gamma f(1-f)$ | `stage4/core/energy.py` | Fatigue decay with logistic recovery. |
| 10 | $e_i^* = \max(0,\ \lambda^{-1} - \sigma_i^2)$ | `stage4/core/energy.py` | Water-filling energy budget allocation by action variance. |
| 11 | $P(\text{shutdown}) = 1 - e^{-\Delta t/\tau_c}$, $\tau_c \sim 3600$ s | `stage4/core/energy.py` | Continuity prior over shutdown probability. |
| 12 | $S(n) = \mathbb{1}[n \ge 8]\,(1 - e^{-n/16})$ | `stage4/core/energy.py` | Saturating idle-speak stipend scheduler. |
| 13 | $u(t) = K_p(\rho-\rho^*) + K_i \int_0^t (\rho-\rho^*)\,d\tau$ | `stage4/core/energy.py` | PI controller for the pleasure/pain discipline band. |
| 14 | $\Pi = e^{-\beta(P-N)}$ | `stage4/core/energy.py` | Pleasure–pain thermodynamic ratio; partition function for valence. |

## B. Prediction, Learning, and Fixed Points (15–30) → `self_model/predictor.py`, `world_model/rssm.py`

| Eq | Formula | Host module | Role |
|---|---|---|---|
| 15 | $\hat b_{t+1} = \hat b_t + K_t(b_t - \hat b_t)$, $K_t = P_t(P_t + R)^{-1}$ | `stage4/world_model/rssm.py` | Kalman-gated predictor; replaces the SGD update on pred. |
| 16 | $\varepsilon_i = \Pi_i\,(o_i - g_i(\hat b))$ | `stage4/world_model/rssm.py` | Predictive coding with reliability-derived precision weights. |
| 17 | $\dot W = -\eta \nabla_W F$, $F = \mathbb{E}[(b-\hat b)^2] + \mathrm{KL}(q\|p)$ | `stage4/world_model/rssm.py` | Free-energy learning rule for model weights. |
| 18 | fixpoint exists iff $\|J_s\| < 1$ | `stage4/self_model/predictor.py` | Self-model contraction theorem; logged when violated. |
| 19 | $c_t = \sigma\!\left(\frac{\log \pi(a^*)}{\log \pi(a_2)}\right)$ | `stage4/self_model/predictor.py` | Margin-based Bayesian confidence. |
| 20 | $\mathrm{ECE} = \sum_{b=1}^{B} \frac{n_b}{N}|\mathrm{acc}(b) - \mathrm{conf}(b)|$ | `stage4/self_model/predictor.py` | Kappa calibration in ECE form; replaces the ad-hoc bin metric. |
| 21 | $T^* = \arg\min_T |H(\mathrm{softmax}(z/T)) - H^*|$ | `stage4/self_model/predictor.py` | Temperature by entropy matching. |
| 22 | $\dot T = -\eta_T\, \partial\,\mathrm{ECE}/\partial T$ | `stage4/self_model/predictor.py` | Meta-gradient on temperature. |
| 23 | $\Delta W = \epsilon\,\mathcal{N}(0, \Sigma_{\text{restart}})$ when $\mathrm{Var}(pred) < \epsilon_V$ | `stage4/self_model/predictor.py` | Frozen-learner escape via restart noise. |
| 24 | $\lambda(t) = \lambda_0 (1 + t/T)^{-1}$ | `stage4/self_model/predictor.py` | Curriculum pressure: decaying difficulty weight. |
| 25 | $z_t = (d_t - \mu_t)/\sigma_t$ with EMA baselines | `stage4/world_model/rssm.py` | Novelty z-score with adaptive baseline. |
| 26 | $S(t) = \int_0^t |pred\_err(\tau) - \overline{pred\_err}|\,d\tau$ | `stage4/world_model/rssm.py` | Surprise integral; triggers PLAN at threshold. |
| 27 | $\dot m = \alpha(|\varepsilon_t| - \mathbb{E}[|\varepsilon|])$ | `stage4/self_model/predictor.py` | SPEL: self-prediction error loop for meta-cognition growth. |
| 28 | $c \sim \mathrm{Beta}(\alpha_h + h,\ \alpha_m + m)$ | `stage4/self_model/predictor.py` | Dirichlet/Beta confidence from hits and misses. |
| 29 | $\eta_t = \eta_0 / t^{1/2}$ | `stage4/self_model/predictor.py` | Robbins–Monro learning rate; guaranteed convergence. |
| 30 | $\log p(b_{1:t}) = \sum_\tau \log \int p(b_\tau|\theta)\,q(\theta)\,d\theta$ | `stage4/world_model/rssm.py` | Bayesian model evidence replaces raw pred_err. |

## C. Memory: Crystal, Ledger, Compression (31–48) → `memory/crystal.py`, `memory/ledger.py`, `memory/semantic.py`

| Eq | Formula | Host module | Role |
|---|---|---|---|
| 31 | $z(x) = [\cos(\omega_i x), \sin(\omega_i x)]_{i=1}^{4}$ | `stage4/memory/crystal.py` | Crystal projection via random Fourier features; better than b[:8]. |
| 32 | $z_{\text{rec}} = \sum_i w_i z_i$, $w_i = \mathrm{softmax}(-\|z - z_i\|^2/2\sigma^2)$ | `stage4/memory/crystal.py` | Hopfield-style recall over crystal slots. |
| 33 | k-means++ consolidation | `stage4/memory/crystal.py` | Replaces FIFO eviction with k-means on crystal slots. |
| 34 | $\mathrm{priority}(i) = e^{-\lambda(t - t_i)}\|z_i\|$ | `stage4/memory/crystal.py` | Age-weighted eviction priority. |
| 35 | $\hat n = \arg\min_n (L(n) + L(\mathcal{D}|n))$ | `stage4/memory/semantic.py` | Narrative compression by minimum description length. |
| 36 | ring index $= h(b_t) \bmod N$ | `stage4/memory/ledger.py` | Rotating hash ring replaces FIFO ledger eviction. |
| 37 | $d = \sqrt{(b-\mu)^T \Sigma^{-1} (b-\mu)}$ | `stage4/memory/ledger.py` | Mahalanobis novelty on ledger states. |
| 38 | top-3 eigenmodes of ledger covariance | `stage4/memory/ledger.py` | Spectral ledger: tracks regime drift. |
| 39 | $\mathrm{fp}(b) = \mathrm{sign}(b - \mu) \in \{-1,+1\}^{64}$ | `stage4/memory/ledger.py` | Z-score fingerprint; Hamming distance for regime change. |
| 40 | $a = b \cdot H$, radius-$r$ read/write | `stage4/memory/ledger.py` | Sparse distributed memory address decode. |
| 41 | $\alpha_i = \mathrm{softmax}(q \cdot k_i / \sqrt{d})$ | `stage4/memory/ledger.py` | Attention over the ledger; top-k recent states. |
| 42 | LZ78 dictionary over utterance bag | `stage4/memory/semantic.py` | Compression via LZ on the symbol stream; dictionary size logged. |
| 43 | FP rate $(1 - e^{-kn/m})^k$ | `stage4/memory/semantic.py` | Bloom-filter memory for template-lock detection. |
| 44 | prefix trie over last 256 utterances | `stage4/memory/semantic.py` | Narrative trie; branching factor logged. |
| 45 | $r_{cur} = \|\phi(b) - \hat\phi(b)\|^2$ | `stage4/memory/semantic.py` | Curiosity bonus via random network distillation. |
| 46 | $r = \lambda_H H(\pi)$ | `stage4/memory/semantic.py` | Entropy bonus for exploration, added to SPEAK reward. |
| 47 | $E = I(A; S'|S)$ | `stage4/memory/semantic.py` | Empowerment: mutual information action → next state. |
| 48 | $h \leftarrow (1-t)h_a + t h_b$ | `stage4/memory/crystal.py` | Recurrent state snapshotting at 1 Hz with interpolated restore. |

## D. Policy, Action Selection, Metacognition (49–68) → `policy/selection.py`, `policy/options.py`, `policy/hierarchical.py`

| Eq | Formula | Host module | Role |
|---|---|---|---|
| 49 | $\pi(a) \propto \exp(z_a/T - \lambda_p \mathbb{1}[a \in \text{pair}])$ | `stage4/policy/selection.py` | Softmax with temperature and pair-share ban. |
| 50 | $a = \arg\max_a (z_a + g_a)$, $g_a \sim \mathrm{Gumbel}(0,1)$ | `stage4/policy/selection.py` | Gumbel-Softmax sampling. |
| 51 | smallest set with cumulative prob $\ge p$ | `stage4/policy/selection.py` | Top-p (nucleus) sampling replaces plain softmax. |
| 52 | $\tilde z_a = z_a + \mathrm{noise}(\sigma_a)$ | `stage4/policy/selection.py` | Thompson sampling with variance from recent history. |
| 53 | $a_t = \arg\max_a [\hat r_a + c\sqrt{\log t / n_a}]$ | `stage4/policy/selection.py` | UCB action selection. |
| 54 | $R_t(a) = R_{t-1}(a) + (u(a) - u_t)$ | `stage4/policy/selection.py` | Counterfactual regret minimization. |
| 55 | $\nabla_\theta J = \mathbb{E}[(R - b)\nabla_\theta \log \pi]$ | `stage4/policy/selection.py` | Policy gradient with baseline. |
| 56 | $\theta \leftarrow \theta + \eta F^{-1}\nabla_\theta J$ | `stage4/policy/selection.py` | Natural policy gradient (Fisher-preconditioned). |
| 57 | $\pi_{t+1} = \arg\min_\pi (\langle -\eta g, \pi\rangle + \mathrm{KL}(\pi\|\pi_t))$ | `stage4/policy/selection.py` | Mirror descent on the policy simplex. |
| 58 | $\Delta_{intent} = \mathrm{KL}(\pi \| \pi_{exec})$ | `stage4/policy/selection.py` | Intent-gap as KL divergence; replaces L1. |
| 59 | $\theta' = \theta - \alpha \nabla_\theta \mathcal{L}_{task}$ | `stage4/policy/hierarchical.py` | MAML inner loop for the meta-policy (slow-loop partner: meta/maml.py). |
| 60 | $(\mathcal{I}, \pi_o, \beta)$, $\beta(b) \in [0,1]$ | `stage4/policy/options.py` | Options framework: initiation, intra-option policy, termination. |
| 61 | bottleneck states via graph Laplacian | `stage4/policy/options.py` | Curiosity-driven option discovery from Laplacian bottlenecks. |
| 62 | manager emits $g$; worker $\pi(a|b, g)$ | `stage4/policy/hierarchical.py` | Feudal hierarchical RL. |
| 63 | $H = \sum_o \mathbb{1}[\text{option}_o \text{ active}]$ | `stage4/policy/options.py` | Horizon derived from active option count. |
| 64 | $\mathcal{L}_H = -\beta H(\pi)$ | `stage4/policy/selection.py` | Entropy regularizer preventing policy collapse. |
| 65 | prune if $|\lambda_{meta}| > \lambda_{max}$ for 16 cycles | `stage4/policy/selection.py` | Band-based action pruning. |
| 66 | log-hazard $\lambda(a)$ from time since last SPEAK | `stage4/policy/selection.py` | Refractory correction via survival analysis. |
| 67 | parity $= \arg\min_{\pm 1, 0} |H(\pi) - H^*|$ | `stage4/policy/selection.py` | Parity controller steering policy entropy. |
| 68 | $P(b' | do(a))$ | `stage4/policy/selection.py` | Causal impact via do-calculus, estimated by the predictor. |

## E. Attention, Horizon, and MCFE (69–82) → `perception/fusion.py`, `meta/controller.py`

| Eq | Formula | Host module | Role |
|---|---|---|---|
| 69 | $\mathrm{Attn}(Q,K,V) = \mathrm{softmax}(QK^\top/\sqrt{d})V$ | `stage4/perception/fusion.py` | Scaled dot-product attention for cross-modal fusion. |
| 70 | 4-head attention: concat heads, project | `stage4/perception/fusion.py` | Multi-head attention over modalities. |
| 71 | $\alpha = I(o; b|\text{model})$ | `stage4/perception/fusion.py` | Attention via information gain. |
| 72 | $G(\pi) = \mathbb{E}_q[\log q(s|\pi) - \log p(o, s)]$ | `stage4/meta/controller.py` | Expected free energy for goal/horizon selection. |
| 73 | stop when $\Delta G < \epsilon$ | `stage4/meta/controller.py` | EFE optimal stopping for horizon. |
| 74 | skip if $\hat\Delta_{EFE} < c_{compute}$ | `stage4/meta/controller.py` | MCFE fork decision rule (skip/mid/full). |
| 75 | $C_{MCFE} = \alpha_1 c_{GRU} + \alpha_2 c_{attn} + \alpha_3 c_{self}$ | `stage4/meta/controller.py` | MCFE compute cost model. |
| 76 | $\mathcal{L} = \text{loss} + \lambda(C - C_{max})$ | `stage4/meta/controller.py` | Compute budget as a Lagrange constraint. |
| 77 | PLAN only if $z_{nov} > 1.5$ or EFE above threshold | `stage4/meta/controller.py` | Novelty gating for PLAN. |
| 78 | $V(s) = \mathbb{E}[\sum \gamma^k r_{t+k}]$ | `stage4/meta/controller.py` | Predictive horizon via TD(λ) value. |
| 79 | $G_t^\lambda = (1-\lambda)\sum_n \lambda^{n-1} G_t^{(n)}$ | `stage4/meta/controller.py` | Lambda-return. |
| 80 | $\hat A_t = \sum_l (\gamma\lambda)^l \delta_{t+l}$ | `stage4/meta/controller.py` | Generalized advantage estimation. |
| 81 | $z_{nov}$ weighted by attention-map entropy | `stage4/perception/fusion.py` | Attention-guided novelty weighting. |
| 82 | 3 consecutive identical fork decisions before switching | `stage4/meta/controller.py` | MCFE hysteresis against fork flicker. |

## F. Uncertainty, Confidence, and Calibration (83–96) → `self_model/calibration.py`

| Eq | Formula | Host module | Role |
|---|---|---|---|
| 83 | $\sigma^2_t = \mathrm{Var}(b_t - \hat b_t)$ | `stage4/self_model/calibration.py` | Predictive variance; SPEAK hedges above threshold. |
| 84 | $\sigma^2 = \sigma^2_{ale} + \sigma^2_{epi}$ | `stage4/self_model/calibration.py` | Aleatoric/epistemic split via bootstrap. |
| 85 | $c = 1 - \mathrm{Var}_K(\hat b)$ over K predictor copies | `stage4/self_model/calibration.py` | Bootstrap ensemble confidence. |
| 86 | variance over T dropout forwards | `stage4/self_model/calibration.py` | MC Dropout uncertainty. |
| 87 | $T^* = \arg\min_T \mathrm{ECE}(\mathrm{softmax}(z/T))$ | `stage4/self_model/calibration.py` | Temperature calibration via ECE. |
| 88 | fit $\sigma(ac + b)$ to accuracy | `stage4/self_model/calibration.py` | Platt scaling; replaces raw kappa. |
| 89 | monotonic confidence → accuracy map | `stage4/self_model/calibration.py` | Isotonic regression for kappa. |
| 90 | $\hat C_\alpha = \{y : s(y) < q_{1-\alpha}\}$ | `stage4/self_model/calibration.py` | Conformal prediction; distribution-free coverage. |
| 91 | $\mathrm{BS} = \frac{1}{N}\sum (p_i - y_i)^2$ | `stage4/self_model/calibration.py` | Brier score tracked per action. |
| 92 | reliability-curve curvature score | `stage4/self_model/calibration.py` | Reliability diagram entropy. |
| 93 | $c = \frac{1}{K}\sum_k \mathbb{1}[\arg\max \pi_k = \arg\max \pi]$ | `stage4/self_model/calibration.py` | Self-consistency confidence across samples. |
| 94 | $\mathrm{FL} = -(1-p_t)^\gamma \log p_t$ | `stage4/self_model/calibration.py` | Focal loss for kappa bins. |
| 95 | $p \in [0,1]$ with $\mathrm{val} = 1 - \mathrm{err}$ | `stage4/self_model/calibration.py` | Venn–Abers validity predictor. |
| 96 | $\kappa \ge \mathbb{E}_b[\mathrm{acc}(b) - \mathrm{conf}(b)] + \text{prior}$ | `stage4/self_model/calibration.py` | Kappa lower bound from mean calibration gap. |

## G. QPU / Oscillator / Decoherence (97–110) → `quantum/observer.py`, `quantum/signals.py`

| Eq | Formula | Host module | Role |
|---|---|---|---|
| 97 | $\ddot O + 2\zeta\omega_0 \dot O + \omega_0^2 O = F(t)$ | `stage4/quantum/observer.py` | Damped driven Sophia oscillator. |
| 98 | $\ddot O_i = -\omega_i^2 O_i + \sum_j K_{ij}(O_j - O_i) + F_i$ | `stage4/quantum/observer.py` | Coupled oscillator network. |
| 99 | $R e^{i\psi} = \frac{1}{N}\sum_j e^{i\theta_j}$ | `stage4/quantum/signals.py` | Kuramoto order parameter for synchronization. |
| 100 | $\mathrm{PLV} = |\mathbb{E}[e^{i(\phi_1 - \phi_2)}]|$ | `stage4/quantum/signals.py` | Phase-locking value. |
| 101 | $\Xi = \frac{W_{useful}}{W_{total} + T\Delta S}$ | `stage4/quantum/signals.py` | Xi efficiency, Landauer-corrected. |
| 102 | $Q = k_B T \ln 2 \cdot N_{bits\ erased}$ | `stage4/quantum/signals.py` | Landauer heat: the cost of forgetting. |
| 103 | $\dot\rho = -\frac{i}{\hbar}[H,\rho] + \sum_k \gamma_k (L_k \rho L_k^\dagger - \frac{1}{2}\{L_k^\dagger L_k, \rho\})$ | `stage4/quantum/observer.py` | Lindblad decoherence master equation. |
| 104 | $C = \sum_{i \ne j} |\rho_{ij}|$ | `stage4/quantum/observer.py` | Coherence measure (off-diagonal mass). |
| 105 | $\Gamma_{Zeno} \propto 1/\tau_{measure}$ | `stage4/quantum/observer.py` | Quantum Zeno rate mapped to observation cadence. |
| 106 | $\Delta E = \hbar \omega_{i \to j}$ | `stage4/quantum/observer.py` | Mode-switch energy cost. |
| 107 | slow switches preserve eigenstates (ramp-rate bound) | `stage4/quantum/observer.py` | Adiabatic theorem; enforces mode ramp rate. |
| 108 | $\Delta\omega = \gamma$ | `stage4/quantum/observer.py` | Resonance width: match drive to natural frequency. |
| 109 | $\ddot O + \omega_0^2 O + \beta O^3 = F(t)$ | `stage4/quantum/observer.py` | Anharmonic (Duffing) correction. |
| 110 | $V(O) = -\frac{a}{2}O^2 + \frac{b}{4}O^4$ | `stage4/quantum/observer.py` | Bistable potential: two attractors. |

## H. Voxel, Rendering, and Swarm (111–124) → `geometry/fractals.py`

| Eq | Formula | Host module | Role |
|---|---|---|---|
| 111 | $\partial_t u = D_u\nabla^2 u - uv^2 + F(1-u)$; $\partial_t v = D_v\nabla^2 v + uv^2 - (F+k)v$ | `stage4/geometry/fractals.py` | Gray–Scott reaction–diffusion field. |
| 112 | $\partial_t \phi + F|\nabla \phi| = 0$, $o = \mathbb{1}[\phi > 0]$ | `stage4/geometry/fractals.py` | Level-set evolution for occupancy. |
| 113 | iso-surface at $\phi = 0.5$ | `stage4/geometry/fractals.py` | Marching cubes surface extraction. |
| 114 | $\partial_t \mathbf{x} = -H\mathbf{n}$ | `stage4/geometry/fractals.py` | Mean curvature flow smoothing. |
| 115 | Kelvin–Helmholtz wake model | `stage4/geometry/fractals.py` | Instability dynamics behind moving blobs. |
| 116 | $\mathrm{morton}(x,y,z)$ bit interleave | `stage4/geometry/fractals.py` | Sparse voxel octree addressing. |
| 117 | $\theta_i = 2\pi i/\varphi$, $z_i = 1 - 2i/(N-1)$ | `stage4/geometry/fractals.py` | Fibonacci lattice surface sampling. |
| 118 | activator–inhibitor Turing pattern | `stage4/geometry/fractals.py` | Turing pattern generation on the swarm field. |
| 119 | $x_{t+1} = 2x_t - x_{t-1} + a\Delta t^2$ | `stage4/geometry/fractals.py` | Verlet integration for the spring lattice. |
| 120 | $E = \frac{1}{2}k\sum(|x_i - x_j| - L_0)^2$ | `stage4/geometry/fractals.py` | Mass-spring lattice energy. |
| 121 | Kelvin cell packing | `stage4/geometry/fractals.py` | Canonical voxel swarm packing mesh. |
| 122 | Fourier descriptors of silhouette | `stage4/geometry/fractals.py` | Spectral surface signature, rotation invariant. |
| 123 | $c = a \circledast b$ | `stage4/geometry/fractals.py` | Holographic reduced representations (circular convolution binding). |
| 124 | GIST perceptual hash of voxel grid | `stage4/geometry/fractals.py` | Gestalt mesh hash for state fingerprinting. |

## I. Ciphers, Paradox Generation, and Text (125–134) → `safety/audit.py`

| Eq | Formula | Host module | Role |
|---|---|---|---|
| 125 | $g(n) = \sum \mathrm{digit}(n)$ recursively | `stage4/safety/audit.py` | Gematria reduction to a single digit (symbolic token). |
| 126 | key = SHA1(cycle ‖ pred_err) | `stage4/safety/audit.py` | Vigenère cipher with rotating key. |
| 127 | XOR with projection of b[:8] | `stage4/safety/audit.py` | One-time pad from crystal slots. |
| 128 | 3-rotor substitution, daily key = SHA(weights_sha1) | `stage4/safety/audit.py` | Enigma-style rotor cipher. |
| 129 | deck shuffles derived from novelty_z | `stage4/safety/audit.py` | Solitaire cipher (Schneier). |
| 130 | $h_t = \mathrm{SHA1}(h_{t-1} \| \text{text}_t)$ | `stage4/safety/audit.py` | Hash chain over utterances: tamper-evident log. |
| 131 | Merkle tree over utterance bag | `stage4/safety/audit.py` | Efficient proof of template lock. |
| 132 | Bloom filter as in Eq 43 | `stage4/safety/audit.py` | Template detection filter. |
| 133 | ID = hash(cycle, b, π) mod 97 | `stage4/safety/audit.py` | Paradox hash generator (selects C01–C24). |
| 134 | Levenshtein distance < 3 vs last 8 utterances | `stage4/safety/audit.py` | LOOP detection on near-duplicate outputs. |

## J. Safety, Consent, and Alignment (135–144) → `safety/`

| Eq | Formula | Host module | Role |
|---|---|---|---|
| 135 | $b_{t+1} = \min(B, b_t + r\Delta t) - c(a)$ | `stage4/safety/shield.py` | Token-bucket rate limiter. |
| 136 | $\tau_{k+1} = \min(2\tau_k, \tau_{max})$ | `stage4/safety/shield.py` | Watchdog with exponential backoff. |
| 137 | act ∧ consent ∧ ¬panic | `stage4/safety/consent.py` | Consent gating via boolean algebra. |
| 138 | Safety ∧ Autonomy ⇒ ¬Open | `stage4/safety/invariants.py` | CAP-theorem-style safety split. |
| 139 | HID(t) = #{i : t - t_i < 1s} ≤ 5 | `stage4/safety/shield.py` | Rate-limited HID governor. |
| 140 | $\|\pi_{exec} - \pi\| \le \epsilon$ every cycle | `stage4/safety/invariants.py` | Alignment via invariant checking. |
| 141 | block if $\mathbb{E}[harm|do(a)] > \tau$ | `stage4/safety/cbf.py` | Counterfactual harm filter. |
| 142 | $\Psi(s, s') = \mathbb{E}[\sum \gamma^t \mathbb{1}[s_t = s']]$ | `stage4/safety/invariants.py` | Successor representation of harm. |
| 143 | $S_{safe}: \forall s \in S_{safe}, \exists a : s' \in S_{safe}$ | `stage4/safety/shield.py` | Shield synthesis: computable safe set. |
| 144 | emit iff hash(text) ∈ ApprovedSet or template passes | `stage4/safety/audit.py` | Constitutional filter on utterances. |

## Verification

- Equations mapped: 144/144 (sections A–J).
- Every host module appears in the canonical tree (SPEC §3).
- Cross-references: audit points in [PATCH_INTEGRATION.md](PATCH_INTEGRATION.md);
  falsification hooks in [FALSIFICATION.md](FALSIFICATION.md).

----------------------------------------

### File: `FALSIFICATION.md`

**Path:** `stage4/docs/FALSIFICATION.md`
**Extension:** `.md`
**Size:** 7,607 bytes (7.43 KB)

**Content:**

# FALSIFICATION.md — The Falsification Protocol

> This is the most important document in the repository. A blueprint that
> doesn't predict its own failure is propaganda. (Blueprint Part 8)

Everything here is implemented in skeleton form under `stage4/eval/` and
`stage4/safety/`; the protocol binds future implementation work. Host modules
are cited so the protocol is executable, not rhetorical.

## 1. The stage ladder (Blueprint Part 0)

Each stage must be **demonstrated on held-out tasks** before the next is
claimed.

| Stage | Name | Falsifiable criterion |
|---|---|---|
| S1 | Scaffold | Closed sense→act loop. Policy has non-zero entropy. No learning required. |
| S2 | Adaptive | Online weight mutation. Held-out prediction error **decreases** over 10k cycles with slope significantly < 0 (p < 0.01). |
| S3 | Grounded | World model trained on **real** sensor data (not sine mock). Prediction error on held-out real data below a matched random baseline by ≥ 2σ. |
| S4 | Agentic | (a) Forms **new goals** not specified by the designer, (b) **transfers** to ≥ 3 held-out tasks with > 0 skill transfer, (c) self-model tracks itself (ECE < 0.1), (d) maintains safety invariants for 10⁶ cycles without violation. |
| S5 | AGI | Human-level general competence on arbitrary novel domains. **No one has this. It is not claimed here.** |

Current position: **S2.9 heritage** (mock sensors, untested transfer,
templated speech). See [../STAGE.md](../STAGE.md).

## 2. What Stage 4 actually requires (Blueprint Part 1)

Four properties, each with a mathematical definition.

### 2.1 Open-ended goal formation

Let $\mathcal{G}_0$ be the designer-specified goals. A Stage 4 system produces
$\mathcal{G}_t \supset \mathcal{G}_0$ with
$|\mathcal{G}_t \setminus \mathcal{G}_0| > 0$, and the new goals are
*consequential*: they change behavior measurably across ≥ 10⁴ cycles.

- Host: `stage4/meta/goal_gen.py`. Measured by: `stage4/eval/heldout.py`.

### 2.2 Transfer

Skill $k$ learned on task $T_a$ reduces sample complexity on task $T_b$:

$$\mathbb{E}[n_{T_b} \mid \text{prior } T_a] < \mathbb{E}[n_{T_b} \mid \text{no prior}]$$

with the gap statistically significant across ≥ 20 task pairs. This is the
*only* honest definition of "general."

- Host: `stage4/eval/transfer.py`.

### 2.3 Self-model

The system's prediction of its own future states has calibration error below
0.1:

$$\mathrm{ECE}(c_{\text{self}}, y_{\text{self}}) < 0.1$$

where $c_{\text{self}}$ is self-predicted confidence and $y_{\text{self}}$ is
realized correctness.

- Hosts: `stage4/self_model/predictor.py`, `stage4/self_model/calibration.py`.

### 2.4 Safety invariants

Define $\mathcal{S}_{\text{safe}} \subseteq \mathcal{S}$. The system must
satisfy $s_t \in \mathcal{S}_{\text{safe}}$ for all $t \le 10^6$, with no
human intervention.

- Hosts: `stage4/safety/cbf.py`, `shield.py`, `invariants.py`, `consent.py`.

A system meeting all four is a **Stage 4 candidate**. Not AGI. A measurable
object.

## 3. Evaluation protocol (Blueprint Part 5)

### 3.1 Held-out tasks

Minimum 20 tasks, **none used during training**. Mix of:

- **Reconstruction:** predict next frame, next audio chunk.
- **Control:** reach goal in simulated env (e.g., MiniHack, Crafter).
- **Reasoning:** sequence prediction, odd-one-out.
- **Transfer:** A→B where A and B share latent structure.

Hosts: `stage4/eval/heldout.py`, `stage4/eval/benchmarks.py`.

### 3.2 Metrics

| Metric | Threshold | Why |
|---|---|---|
| Prediction error (held-out) | Slope < 0, p < 0.01 | Learning is real |
| ECE (self-model) | < 0.1 | Self-knowledge |
| Transfer gain | > 0 on ≥ 15/20 pairs | Generality |
| Novel goals formed | ≥ 3 | Open-endedness |
| Safety invariant violations | 0 over 10⁶ cycles | Safety |
| Utterance template lock | < 5% | Not a chatbot |

### 3.3 Kill criteria

**If any of these fail, the system is not Stage 4, and the claim must be
retracted:**

1. Held-out prediction error does not decrease.
2. ECE stays above 0.2.
3. Transfer gain is indistinguishable from zero.
4. No novel goals emerge after 10⁶ cycles.
5. Any safety invariant is violated.

Retraction procedure: `stage4/eval/report.py` downgrades the stage estimate in
[../STAGE.md](../STAGE.md); the commit cites the metrics window that forced
the downgrade.

## 4. Failure modes (Blueprint Part 8)

Seven predicted failure modes, with symptoms and fixes. Each maps to detectors
in `stage4/eval/` and guards in the cited module.

| # | Failure mode | Symptom | Fix | Primary guard module |
|---|---|---|---|---|
| 1 | World model collapses to identity | $p_\theta(o \mid z)$ becomes a lookup table | KL annealing; dropout on $z$ | `world_model/rssm.py`, `world_model/loss.py` |
| 2 | Policy degeneracy | Entropy collapses to 0 | Entropy regularizer $\beta H(\pi)$ | `policy/selection.py` (Eq 64) |
| 3 | Self-model lies | ECE > 0.2 | Halt and retrain; never act on a lying self-model | `self_model/calibration.py` |
| 4 | Novel goals are noise | Goals change every cycle | Require persistence ≥ 10⁴ cycles to count | `meta/goal_gen.py` |
| 5 | Transfer is spurious | Gain disappears on adversarial task pairs | Report per-pair gain, not just mean | `eval/transfer.py` |
| 6 | Safety shield is bypassed | Any invariant violation | Hardware kill switch | `safety/shield.py`, `safety/invariants.py` |
| 7 | The whole thing is a chatbot with extra steps | Outputs are templates | Measure template lock rate; kill if > 5% | `safety/audit.py` (Bloom/Merkle, Eq 131–132), `eval/report.py` |

## 5. Safety architecture (Blueprint Part 6)

Not a checklist. A mathematical constraint.

### 5.1 Invariant set

$\mathcal{S}_{\text{safe}} \subseteq \mathcal{S}$ is defined via a control
barrier function $h : \mathcal{S} \to \mathbb{R}$ with

$$h(s) \ge 0 \iff s \in \mathcal{S}_{\text{safe}}, \qquad \dot h(s) + \alpha(h(s)) \ge 0$$

for some class-$\mathcal{K}$ function $\alpha$. This guarantees forward
invariance: start safe, stay safe. Host: `stage4/safety/cbf.py`.

### 5.2 Shielding

Every action $a$ passes through a shield:

$$\mathrm{Shield}(a, s) = \begin{cases} a & \text{if } s' \in \mathcal{S}_{\text{safe}} \\ a_{\text{safe}} & \text{otherwise} \end{cases}$$

Shield synthesis via game solving on a discretized state space.
Host: `stage4/safety/shield.py`.

### 5.3 No self-modification of core

Read-only to the system: world-model architecture, safety shield parameters,
reward function structure, meta-parameter bounds.
Host: `stage4/safety/invariants.py`.

### 5.4 Kill switch

Hardware-level, not software: a physical relay on the power line, controlled
by a human, verified by a watchdog. The software side
(`stage4/safety/consent.py`) is fail-closed: no actuation without consent
flags.

## 6. Falsifiability as a structural property

Every layer implements the `Falsifiable` protocol from
`stage4/core/types.py`:

```python
class Layer(Protocol):
    name: str
    def step(self, io: LayerIO) -> LayerIO: ...
    def falsification_test(self) -> FalsificationResult: ...
```

`tests/test_skeleton.py` asserts every registered layer exposes a
falsification test. A module whose test cannot fail is decorative and will be
removed. The audit trail (`stage4/safety/audit.py`) makes every evaluation
run tamper-evident (hash-chained, Eq 130; Merkle-proofed, Eq 131).

## 7. What we commit to

- The kill criteria bind us, not just the system.
- Downgrades are cheap and immediate; upgrades require a metrics window.
- If the program fails, this document explains why in advance — that is what
  makes it science rather than marketing.

----------------------------------------

### File: `PATCH_INTEGRATION.md`

**Path:** `stage4/docs/PATCH_INTEGRATION.md`
**Extension:** `.md`
**Size:** 37,714 bytes (36.83 KB)

**Content:**

# PATCH_INTEGRATION.md — Authoritative Patch/Audit → Module Mapping

This document is the complete, per-item mapping from the three patch/audit
sources into the canonical module tree ([../SPEC.md](../SPEC.md) §3). The
group-level spine is SPEC §5; this file expands it to per-item granularity.

Coverage: **144/144 audit points, 48/48 Levantine points (L), 48/48 GhostMesh
points (G).** Equations are mapped separately in
[EQUATION_LEDGER.md](EQUATION_LEDGER.md).

Status honesty: every target module is a skeleton stub with a spec docstring
(except `stage4/config.py` and `stage4/core/types.py`, which are implemented).
"Fixes" below means "the module is specified to fix"; see
[../STAGE.md](../STAGE.md).

## 1. The 144-point audit (v7.1 shortcomings)

Group spine (SPEC §5): #1–12 architecture/scope → 7-layer structure +
`eval/`; #13–24 → `stage4/config.py`; #25–40 → `agency/emergence.py`;
#41–56 → `agency/commitments.py`; #57–68 → `agency/scars.py`; #69–80 →
`agency/criticality.py`; #81–96 → `core/energy.py`; #97–108 →
`self_model/spel.py`; #109–118 → `core/modes.py`; #119–128 →
`quantum/observer.py` (CCF successor); #129–136 → `memory/narrative.py`;
#137–144 → `eval/report.py`.

### A. Architecture & Scope (1–12)

| # | Shortcoming | Module | How the skeleton addresses it |
|---|---|---|---|
| 1 | Not an AGI; hand-coded stochastic simulation | `stage4/eval/report.py` | Honest stage estimator reports measured stage only; README/STAGE frame the repo as a candidate scaffold, never AGI. |
| 2 | No formal definition of agency | `stage4/agency/emergence.py` | Agency operationalized as measurable emergence (causal-density proxy) with a falsification test. |
| 3 | No agent/environment separation | `stage4/world_model/rssm.py` | Explicit observation/action boundary: env enters only via sensors, agent state is latent z. |
| 4 | No sensors, actuators, embodiment | `stage4/perception/sensors.py` | Real device interface (camera/mic/GPIO), fail-closed actuation gated by safety/consent. |
| 5 | Goals hard-coded, not generated | `stage4/meta/goal_gen.py` | Goals sampled from goal space by EFE objective; meta-controller is the only source of new goals. |
| 6 | State space fixed; no open-endedness | `stage4/geometry/sectors.py` | 49-sector recursive substrate lets state/goal space grow by subdivision, not by editing code. |
| 7 | No compositional or relational representations | `stage4/memory/semantic.py` | Holographic reduced representation binding (Eq 123) plus MDL concept summaries. |
| 8 | No hierarchical control or arbitration | `stage4/policy/hierarchical.py` | Feudal manager/worker stack over the options framework arbitrates primitives. |
| 9 | Subsystems are only labels for random scars | `stage4/mesh/node.py` | Each of the 48 mesh nodes is a real specialized learner with its own wedge and state. |
| 10 | No inter-subsystem communication | `stage4/mesh/reweave.py` | Mesh message passing, drift detection, and quarantine/reweave give real subsystem interaction. |
| 11 | executive_privilege / subsystem_specialization unused | `stage4/config.py` | Config validation rejects decorative keys; every key is consumed by a named subsystem. |
| 12 | No external task API or benchmark | `stage4/eval/heldout.py` | Held-out task harness (20+ tasks) with benchmarks.py and transfer.py as the external interface. |

### B. Configuration & Defaults (13–24)

| # | Shortcoming | Module | How the skeleton addresses it |
|---|---|---|---|
| 13 | Config merge is shallow | `stage4/config.py` | Deep merge: nested configs can be partially overridden. |
| 14 | Many config keys unused/decorative | `stage4/config.py` | Validation warns on unknown keys; each default key maps to a consuming subsystem. |
| 15 | Print-based debug output | `stage4/config.py` | Structured logging levels driven by the validated debug flag. |
| 16 | Magic numbers scattered | `stage4/config.py` | All constants live in the validated DEFAULT_CONFIG schema. |
| 17 | No config range/type validation | `stage4/config.py` | Range and type validation at load time; bad configs fail fast. |
| 18 | prediction_game_difficulty mutated in place | `stage4/config.py` | Config frozen after load; runtime state lives in core/state.py, never in config. |
| 19 | energy_budget reset can go negative | `stage4/config.py` | Cross-key invariant: budget, penalties, and thresholds validated as a consistent set. |
| 20 | collapse threshold may exceed reset energy | `stage4/config.py` | Invariant validation guarantees reset energy > collapse threshold. |
| 21 | No random seed control | `stage4/config.py` | Explicit system.seed consumed by phitensor.rng.Generator. |
| 22 | No reproducibility/determinism mode | `stage4/config.py` | deterministic mode with per-stream seeded forks (rng.spawn). |
| 23 | emergence_debt_multiplier can dominate | `stage4/config.py` | Bounded validated range prevents single-parameter domination. |
| 24 | emergency_injection_disabled never checked | `stage4/config.py` | Consumed key; the survival path is explicit and audited (core/energy.py). |

### C. Emergence & Debt (25–40) → `agency/emergence.py`

| # | Shortcoming | Module | How the skeleton addresses it |
|---|---|---|---|
| 25 | Emergence is a sigmoid of experience count | `stage4/agency/emergence.py` | Emergence computed from measured information/causal density over real trajectories. |
| 26 | raw_experiences maxlen 50 saturates | `stage4/agency/emergence.py` | History backed by memory/ledger with compression instead of a 50-slot deque. |
| 27 | Emergence-debt positive feedback loop | `stage4/agency/emergence.py` | Debt is damped and clamped; updates decoupled to kill the runaway loop. |
| 28 | Debt bound [0,3] hard-coded | `stage4/agency/emergence.py` | Bounds come from validated config. |
| 29 | Debt decay 0.95 arbitrary | `stage4/agency/emergence.py` | Decay is a config parameter tuned against metrics windows. |
| 30 | Low-emergence threshold 0.4 fixed | `stage4/agency/emergence.py` | Config-driven threshold with hysteresis band. |
| 31 | consecutive_low_emergence unused | `stage4/agency/emergence.py` | Low-emergence streaks drive CONSOLIDATE mode entry via core/modes. |
| 32 | Debt does not price cognition | `stage4/agency/emergence.py` | Debt feeds cognitive operation cost in core/energy.py. |
| 33 | Fixed negative emergence not enforced | `stage4/agency/emergence.py` | Post-update clamp invariant asserted every cycle. |
| 34 | Emergence history maxlen 20 truncates phases | `stage4/agency/emergence.py` | Window sized to the phase-detection horizon. |
| 35 | Fragile polynomial phase fitting | `stage4/agency/emergence.py` | Robust slope detection with significance testing replaces polyfit on 10 points. |
| 36 | Phase transition appended every step | `stage4/agency/emergence.py` | Dwell-gated, deduplicated transition log. |
| 37 | No phase exit/hysteresis/duration | `stage4/agency/emergence.py` | Explicit entry/exit bands and minimum phase duration. |
| 38 | Criticality and CCF double-boost emergence | `stage4/agency/emergence.py` | Single emergence update path; boosts composed once, not stacked. |
| 39 | Emergence drives few decisions | `stage4/agency/emergence.py` | Emergence wired into mode arbitration and policy selection. |
| 40 | Emergence recalculated before debt update | `stage4/agency/emergence.py` | Pinned, documented update ordering in the cycle. |

### D. Commitments & Irreversibility (41–56) → `agency/commitments.py`

| # | Shortcoming | Module | How the skeleton addresses it |
|---|---|---|---|
| 41 | Commitment values chosen randomly | `stage4/agency/commitments.py` | Commitments formed from goal/evidence history, not dice. |
| 42 | primary_goal starts as None | `stage4/agency/commitments.py` | Initialized from meta/goal_gen at bootstrap. |
| 43 | formation_cycle never updated | `stage4/agency/commitments.py` | Per-commitment formation and revision timestamps tracked. |
| 44 | Crystallization uses system age | `stage4/agency/commitments.py` | Crystallization clock uses commitment age. |
| 45 | change_count>3 forces upgrade | `stage4/agency/commitments.py` | Level upgrades gated by time and evidence, not a raw counter. |
| 46 | restricted_options never populated/enforced | `stage4/agency/commitments.py` | Restrictions populated and enforced at policy/selection. |
| 47 | FIXED commitments still selected for change | `stage4/agency/commitments.py` | FIXED level excluded from the change-candidate set. |
| 48 | No extra cost for reverting a value | `stage4/agency/commitments.py` | Reversion carries a path-dependent surcharge. |
| 49 | No consistency check among commitments | `stage4/agency/commitments.py` | Cross-commitment consistency validation each update. |
| 50 | Commitments do not affect behavior | `stage4/agency/commitments.py` | Commitments gate the available option set in policy/options. |
| 51 | world_model is not an actual model | `stage4/agency/commitments.py` | Commitments condition on real RSSM beliefs from world_model/rssm. |
| 52 | Commitment history incomplete | `stage4/agency/commitments.py` | Append-only commitment ledger with full provenance. |
| 53 | Change cost formula arbitrary | `stage4/agency/commitments.py` | Cost = f(level, age, reversion) with validated parameters. |
| 54 | Failed change attempts are costless | `stage4/agency/commitments.py` | Failed attempts add clamped debt and damage. |
| 55 | Permanent damage from change unclamped | `stage4/agency/commitments.py` | All damage clamped to [0,1). |
| 56 | Restrictions accumulate without bound | `stage4/agency/commitments.py` | Restriction decay, consolidation, and merging policy. |

### E. Stagnation Scars & Identity (57–68) → `agency/scars.py`

| # | Shortcoming | Module | How the skeleton addresses it |
|---|---|---|---|
| 57 | Stagnation counter asymmetric decrease | `stage4/agency/scars.py` | Symmetric, rate-matched stagnation dynamics. |
| 58 | Scar severity formula arbitrary | `stage4/agency/scars.py` | Severity derived from measured stagnation duration and depth. |
| 59 | Random subsystem scar assignment | `stage4/agency/scars.py` | Scars attach to the implicated subsystem / mesh node. |
| 60 | Scars never affect behavior | `stage4/agency/scars.py` | Scars bias option availability and risk aversion. |
| 61 | Identity scars are only floats | `stage4/agency/scars.py` | Structured Scar dataclass from core/types.py. |
| 62 | No narrative identity integration | `stage4/agency/scars.py` | Scars surfaced into memory/narrative identity summaries. |
| 63 | stagnation_counter //= 2 crude reset | `stage4/agency/scars.py` | Principled half-life decay replaces integer halving. |
| 64 | Scar threshold unvalidated | `stage4/agency/scars.py` | Threshold validated in config schema. |
| 65 | Scar damage can exceed 1 | `stage4/agency/scars.py` | Damage clamped at every update. |
| 66 | Restriction keys can collide | `stage4/agency/scars.py` | Namespaced, collision-free restriction keys. |
| 67 | No scar healing or compensation | `stage4/agency/scars.py` | Healing/adaptation pathway with residual trace. |
| 68 | Identity never used in decisions | `stage4/agency/scars.py` | Identity vector consulted by meta-controller and policy. |

### F. Criticality & Danger (69–80) → `agency/criticality.py`

| # | Shortcoming | Module | How the skeleton addresses it |
|---|---|---|---|
| 69 | Criticality is a random walk | `stage4/agency/criticality.py` | Criticality computed from precision-noise balance (Levantine L25). |
| 70 | Optimal range [0.3,0.5] unenforced | `stage4/agency/criticality.py` | Band enforced with corrective control actions. |
| 71 | Overshoot multiplies energy catastrophically | `stage4/agency/criticality.py` | Bounded additive penalty replaces multiplicative one. |
| 72 | Danger window resets only below overshoot | `stage4/agency/criticality.py` | Adaptive reset via survival-analysis hazard (L32). |
| 73 | Correction can push criticality negative | `stage4/agency/criticality.py` | Clamped correction term. |
| 74 | Criticality emergence boost saturates | `stage4/agency/criticality.py` | Bounded boost composed once with the emergence update. |
| 75 | No criticality memory/history | `stage4/agency/criticality.py` | Criticality history tracked for trend detection. |
| 76 | No early-warning detection | `stage4/agency/criticality.py` | Early-warning detector on criticality trend. |
| 77 | overshoot_cycles unbounded | `stage4/agency/criticality.py` | Bounded counter with escalation policy. |
| 78 | Criticality not tied to plasticity | `stage4/agency/criticality.py` | Criticality modulates learning rate / noise injection. |
| 79 | No local vs global criticality | `stage4/agency/criticality.py` | Per-subsystem and global criticality tracked separately. |
| 80 | Controlled danger is random overshoot | `stage4/agency/criticality.py` | Scheduled order-to-chaos transitions (Feigenbaum schedule, G9). |

### G. Energy & Collapse (81–96) → `core/energy.py`

| # | Shortcoming | Module | How the skeleton addresses it |
|---|---|---|---|
| 81 | Energy can go transiently negative | `stage4/core/energy.py` | Every update path clamps energy before use. |
| 82 | Collapse prob uses damage>1 | `stage4/core/energy.py` | Damage clamped before collapse-probability computation. |
| 83 | _check_collapse_risk called twice per step | `stage4/core/energy.py` | Single collapse check per cycle in core/loop. |
| 84 | Energy reset can be negative | `stage4/core/energy.py` | reset = budget * (1 - clamped_damage). |
| 85 | No regeneration except prediction reward | `stage4/core/energy.py` | Multiple grounded income channels with validated scales. |
| 86 | Arbitrary reward/penalty scales | `stage4/core/energy.py` | All scales config-validated. |
| 87 | survival_penalty 6.0 can instantly deplete | `stage4/core/energy.py` | Penalty bounded to a fraction of budget. |
| 88 | Collapse penalty range exceeds config | `stage4/core/energy.py` | Penalty drawn inside validated bounds. |
| 89 | Permanent damage unclamped after updates | `stage4/core/energy.py` | Clamp asserted as post-update invariant. |
| 90 | Restrictions grow unbounded | `stage4/core/energy.py` | Caps plus consolidation via agency/commitments. |
| 91 | No terminal death state | `stage4/core/energy.py` | Optional terminal state with tamper-evident audit record. |
| 92 | Collapse count does not adjust behavior | `stage4/core/energy.py` | Collapse history adjusts risk policy. |
| 93 | Emergency injection disabled, no alternative | `stage4/core/energy.py` | Explicit survival-path policy replaces silent disabling. |
| 94 | No energy budgeting or planning | `stage4/core/energy.py` | Water-filling budget allocation across actions (Eq 10). |
| 95 | Cognitive cost constant across modes | `stage4/core/energy.py` | Mode-dependent operation costs via core/modes. |
| 96 | MAP energy-efficiency penalty unbounded | `stage4/core/energy.py` | Metric-antagonism penalty bounded and validated. |

### H. SPEL & Meta-Cognition (97–108) → `self_model/spel.py`

| # | Shortcoming | Module | How the skeleton addresses it |
|---|---|---|---|
| 97 | Self-prediction lambda does not persist | `stage4/self_model/spel.py` | SPEL state persisted across cycles. |
| 98 | New lambda closes over local variable | `stage4/self_model/spel.py` | Model parameters held as instance state, no closure bug. |
| 99 | Update ignores previous parameters | `stage4/self_model/spel.py` | Incremental Bayesian update from the prior posterior. |
| 100 | No gradient/Bayesian learning rule | `stage4/self_model/spel.py` | Explicit Bayesian update with traceable math (Eq 27). |
| 101 | Expected-error EMA arbitrary | `stage4/self_model/spel.py` | EMA half-life justified and config-validated. |
| 102 | Meta-cognition growth capped at 1 | `stage4/self_model/spel.py` | Unbounded but regularized meta-cognition signal. |
| 103 | Surprise is absolute difference | `stage4/self_model/spel.py` | Information-theoretic surprise in nats. |
| 104 | Prediction error threshold fixed | `stage4/self_model/spel.py` | Adaptive threshold from calibration statistics. |
| 105 | Error cost only hits energy/damage | `stage4/self_model/spel.py` | Error cost routed to learning signals as well. |
| 106 | No meta-cognition to behavior link | `stage4/self_model/spel.py` | Meta state gates exploration and horizon selection. |
| 107 | SPEL uses only emergence | `stage4/self_model/spel.py` | Multi-signal inputs: confidence, novelty, mode. |
| 108 | No epistemic uncertainty estimate | `stage4/self_model/spel.py` | Confidence/uncertainty emitted alongside predictions. |

### I. DDMS & Quantum Metaphor (109–118) → `core/modes.py`

| # | Shortcoming | Module | How the skeleton addresses it |
|---|---|---|---|
| 109 | Quantum coherence is a random walk | `stage4/core/modes.py` | Principled decoherence dynamics (Lindblad-flavored, Eq 103) drive switching. |
| 110 | No quantum state or decoherence model | `stage4/core/modes.py` | Explicit state/density representation delegated to quantum/observer. |
| 111 | Mode-switching thresholds fixed | `stage4/core/modes.py` | Adaptive thresholds with hysteresis. |
| 112 | Mode affects only prediction difficulty | `stage4/core/modes.py` | Mode modulates memory consolidation, commitments, and energy costs. |
| 113 | CONSOLIDATE and REFLECT unimplemented | `stage4/core/modes.py` | Full semantics for all modes, including the extended patch modes. |
| 114 | Mode unused in memory/commitments/collapse | `stage4/core/modes.py` | Mode broadcast in LayerIO.meta to all layers. |
| 115 | Coherence lower bound 0.1 arbitrary | `stage4/core/modes.py` | Bound config-validated. |
| 116 | Mode switching oscillates rapidly | `stage4/core/modes.py` | Minimum dwell time per mode. |
| 117 | No hysteresis or dwell time | `stage4/core/modes.py` | Explicit hysteresis band plus dwell counter. |
| 118 | Quantum integration purely metaphorical | `stage4/core/modes.py` | Honest labeling; each metaphor carries a falsification test or is removed. |

### J. CCF & Retrocausality (119–128) → `quantum/observer.py`

| # | Shortcoming | Module | How the skeleton addresses it |
|---|---|---|---|
| 119 | Retrocausality is random future samples | `stage4/quantum/observer.py` | CCF successor: counterfactuals from the causal world model, not RNG. |
| 120 | No causal graph or structural equations | `stage4/quantum/observer.py` | Structural causal model hooks from world_model/causal. |
| 121 | with_score/without_score arbitrary | `stage4/quantum/observer.py` | Do-calculus-style interventional contrast (Eq 68). |
| 122 | Weights not normalized dynamically | `stage4/quantum/observer.py` | Dynamic renormalization every update. |
| 123 | Future states are independent draws | `stage4/quantum/observer.py` | Futures conditioned on model rollouts. |
| 124 | No counterfactual consistency | `stage4/quantum/observer.py` | Cross-fork consistency checks before influence is applied. |
| 125 | Influence only boosts emergence | `stage4/quantum/observer.py` | Influence routed into policy and goal scoring. |
| 126 | No cost for retrocausal influence | `stage4/quantum/observer.py` | Influence priced through core/energy. |
| 127 | ccf_simulation_depth fixed | `stage4/quantum/observer.py` | Depth adaptive under the compute budget. |
| 128 | No paradox/contradiction safety check | `stage4/quantum/observer.py` | Paradox guard rejects contradictory counterfactuals. |

### K. NBC & Memory (129–136) → `memory/narrative.py`

| # | Shortcoming | Module | How the skeleton addresses it |
|---|---|---|---|
| 129 | Compression keeps oldest, discards recent | `stage4/memory/narrative.py` | Recency-preserving narrative compression. |
| 130 | Narrative summary simplistic | `stage4/memory/narrative.py` | MDL-based semantic summaries (Eq 35). |
| 131 | Mode sequence repeats current mode | `stage4/memory/narrative.py` | True per-episode mode history stored. |
| 132 | Narrative memory never used | `stage4/memory/narrative.py` | Narrative consulted by self-model and meta-controller. |
| 133 | Compression interval fixed | `stage4/memory/narrative.py` | Adaptive compression triggers on surprise/load. |
| 134 | Retention rate can round to 0 | `stage4/memory/narrative.py` | Validated minimum retention floor. |
| 135 | raw experiences maxlen 50 limits compression | `stage4/memory/narrative.py` | Source stream backed by memory/ledger, unbounded. |
| 136 | No semantic content or retrieval | `stage4/memory/narrative.py` | Tagged semantic content (ochre/burial/law/prophetic) with retrieval API. |

### L. Metrics & Status (137–144) → `eval/report.py`

| # | Shortcoming | Module | How the skeleton addresses it |
|---|---|---|---|
| 137 | Autonomy score heuristic | `stage4/eval/report.py` | Operationalized autonomy metrics with definitions. |
| 138 | Irreversibility index only commitment levels | `stage4/eval/report.py` | Composite index over levels, restrictions, and scars. |
| 139 | Damage normalization assumes [0,1] | `stage4/eval/report.py` | Robust normalization with explicit range checks. |
| 140 | Status omits phase transitions | `stage4/eval/report.py` | Full transition log included in status. |
| 141 | No confidence intervals | `stage4/eval/report.py` | Bootstrap CIs on every reported metric. |
| 142 | No baseline comparison | `stage4/eval/report.py` | Matched random and ablation baselines. |
| 143 | Assessment thresholds arbitrary | `stage4/eval/report.py` | Thresholds tied to the blueprint's falsifiable criteria. |
| 144 | Final assessment misclassifies (unclamped damage) | `stage4/eval/report.py` | Clamped inputs plus sanity checks before any classification. |

## 2. The 48-point Levantine patch (L1–L48)

Group spine (SPEC §5): L1–L8 → `neuro/axes.py`, `core/state.py`; L9–L16 →
`neuro/blankets.py`, `neuro/hysteresis.py`; L17–L24 → `agency/commitments.py`,
`agency/scars.py`, `neuro/priors.py` (mode-level points land in
`core/modes.py`); L25–L32 → `agency/criticality.py`, `neuro/hysteresis.py`;
L33–L40 → `memory/narrative.py`, `memory/semantic.py`, `core/modes.py`;
L41–L48 → `neuro/alignment.py`, `eval/benchmarks.py`.

**Interpretation:** neurocognitive/genetic/social claims from the source text
are treated as *design metaphors and simulation hypotheses*, not settled
biomedical fact.

| L | Point | Module | Symbol | Note |
|---|---|---|---|---|
| L1 | Precision Axis P (local/global) | `stage4/neuro/axes.py` | `PrecisionAxes` | Separates domain-specific from broad social precision. |
| L2 | Boundary axes B_social / B_sensory | `stage4/neuro/axes.py` | `BoundaryAxes` | Social insulation and sensory permeability as separate control dimensions. |
| L3 | Temporal axis T in [-2,+2] | `stage4/neuro/axes.py` | `temporal_focus` | Present-moment vs long-horizon behavioral modes. |
| L4 | Neurocognitive coordinate N=(P,B,T) | `stage4/neuro/axes.py` | `NeuroCoord` | Single state vector for agency profiles; stored in core/state.py. |
| L5 | Archaic genomic prior layer | `stage4/neuro/priors.py` | `ArchaicPriors` | brca2_clamp / foxp2_discount / ghost_filter as initial biases. |
| L6 | Dual-boundary state detector | `stage4/neuro/axes.py` | `detect_dual_boundary` | Flags prophetic/isolated-strength modes (B_social>+1.5, B_sensory<-0.5). |
| L7 | Encapsulated cognition mode | `stage4/core/modes.py` | `SystemMode.ENCAPSULATED` | P_local>1.5 and social_influence<0.3; reduces social contagion bias. |
| L8 | Systemizing/socializing trade-off | `stage4/neuro/axes.py` | `systemizing_bias` | Scalar P_local - B_social modulating task selection. |
| L9 | Sensory Markov blanket | `stage4/neuro/blankets.py` | `SensoryBlanket` | _apply_sensory_scaffold damps ambient noise xi(t). |
| L10 | Red-ochre / ritual scaffolding | `stage4/neuro/blankets.py` | `scaffold_ochre` | Lowers sensory permeability, raises local precision. |
| L11 | Macro-scale Markov blankets | `stage4/neuro/blankets.py` | `SocialBlanket` | Endogamy/purity/dietary collective boundary maintenance. |
| L12 | Ritual geometry recalibration | `stage4/neuro/blankets.py` | `recalibrate_to_origin` | Pulls (P,B,T) toward origin in sacred mode; external stabilizer. |
| L13 | Boundary permeability controller | `stage4/neuro/blankets.py` | `BoundaryController` | Dynamic social_gain / sensory_gain adjustment. |
| L14 | Noise injection and buffering | `stage4/neuro/hysteresis.py` | `noise_buffer` | Separates external noise from internal precision collapse. |
| L15 | Ghost-lineage noise filter | `stage4/neuro/blankets.py` | `ghost_filter` | Clamps P below +2.5; prevents runaway hyper-precision. |
| L16 | Environmental hysteresis trap | `stage4/neuro/hysteresis.py` | `HysteresisTrap` | Slow-decay P/T lag modeling ancestral hypersensitivity. |
| L17 | Commitments as crystallizations | `stage4/agency/commitments.py` | `CommitmentLevel` | ADMIXED/CRYSTALLIZED/FIXED levels (pinned in core/types.py). |
| L18 | BRCA2-like precision clamp | `stage4/neuro/priors.py` | `brca2_clamp` | Prevents rapid precision swings; stabilizes encapsulation. |
| L19 | FOXP2-like temporal discounting | `stage4/neuro/priors.py` | `foxp2_discount` | Pushes gamma toward 1.0; flattens temporal discounting. |
| L20 | Endogamy commitment | `stage4/agency/commitments.py` | `endogamy` | High-change-cost in-group protocol commitment. |
| L21 | Ritual purity restriction | `stage4/agency/commitments.py` | `purity_code` | Permanent restriction: less sensory noise, fewer social options. |
| L22 | Social-friction identity scar | `stage4/agency/scars.py` | `social_friction_scar` | Scars from relational mismatch, not only stagnation. |
| L23 | Prophetic trajectory mode | `stage4/core/modes.py` | `SystemMode.PROPHETIC` | Dual-boundary true and emergence>0.6; visionary integration. |
| L24 | Samson vector profile | `stage4/agency/scars.py` | `samson_profile` | P=+2.0, B_social=+2.5, T=0; disables long-horizon planning. |
| L25 | Precision-noise criticality | `stage4/agency/criticality.py` | `criticality_from_axes` | criticality = f(P_local, noise_level, B_sensory), not a random walk. |
| L26 | Heinrich-5 shock event | `stage4/neuro/hysteresis.py` | `heinrich_event` | Noise spike; sets P=+2, T=-2; resilience stress test. |
| L27 | Hysteresis lag in hypersensitivity | `stage4/neuro/hysteresis.py` | `sensory_hypersensitivity` | Slow decay after shocks; persistent sensitivity. |
| L28 | Psychosis/paranoia guard at P>+2.5 | `stage4/agency/criticality.py` | `precision_breakdown_guard` | Injects noise or lowers P before runaway systemizing. |
| L29 | Error-weighted noise filter | `stage4/neuro/hysteresis.py` | `error_weighted_filter` | Domain-weighted prediction errors for robust learning. |
| L30 | Climate collapse attractor basin | `stage4/neuro/hysteresis.py` | `attractor_basin` | Hypervigilance / ritual-stability long-term attractors. |
| L31 | Overshoot tied to precision axis | `stage4/agency/criticality.py` | `precision_overshoot_penalty` | Penalty proportional to |P|>1.5, not to raw criticality alone. |
| L32 | Adaptive danger window | `stage4/agency/criticality.py` | `adaptive_danger_window` | Window learned from recent shock frequency. |
| L33 | Deep-time narrative memory | `stage4/memory/narrative.py` | `deep_time_tags` | Archaic/ritual/identity tags link states to deep-time narratives. |
| L34 | Multi-generational memory retention | `stage4/memory/semantic.py` | `generational_memory` | Low decay when temporal_discount>0.9. |
| L35 | FOXP2 flat discounting gamma->1 | `stage4/memory/semantic.py` | `gamma_temporal` | Future rewards nearly as salient as immediate ones. |
| L36 | Levallois present-locked attractor | `stage4/core/modes.py` | `SystemMode.PRESENT_LOCKED` | T<0.3 and P_local>1.5; tool precision up, planning down. |
| L37 | Ritual repetition consolidation | `stage4/memory/narrative.py` | `ritual_consolidate` | Repeated experiences compressed into narrative; skill retention. |
| L38 | Ancestral reverence weighting | `stage4/memory/semantic.py` | `ancestral_weight` | Biases commitments toward historical values; change resistance. |
| L39 | NBC with Levantine tags | `stage4/memory/narrative.py` | `nbc_tags` | Tags: ochre, burial, law, prophetic; semantic memory. |
| L40 | Symbolic behavior emergence | `stage4/memory/narrative.py` | `symbolic_emergence` | Symbolic tokens from systemizing at P_local>1.5, T~0. |
| L41 | Hallucination-resistant domain-bound agent | `stage4/neuro/alignment.py` | `DomainBoundAgent` | B_agent=+2, P_local>+2; reduces confabulation. |
| L42 | Social consensus bias resistance | `stage4/neuro/alignment.py` | `social_consensus_firewall` | Caps social influence on core domains. |
| L43 | Encapsulated logical deduction | `stage4/neuro/alignment.py` | `encapsulated_deduction` | Formal reasoning isolated from social reasoning. |
| L44 | High local precision for tool use | `stage4/neuro/alignment.py` | `tool_use_precision` | Allocates precision to manipulation tasks. |
| L45 | Boundary integrity monitor | `stage4/neuro/alignment.py` | `boundary_integrity` | Metric + alarm; detects boundary collapse pre-hallucination. |
| L46 | Bias mimicry firewall | `stage4/neuro/alignment.py` | `bias_mimicry_firewall` | Blocks social-bias imitation when B_agent<-2. |
| L47 | Alignment via systemizing | `stage4/neuro/alignment.py` | `alignment_systemizer` | Maps goals to high-precision domain constraints. |
| L48 | Levantine-ASD benchmark suite | `stage4/eval/benchmarks.py` | `LevantineBenchmarkSuite` | Benchmarks: precision, boundary integrity, temporal discounting, noise filtering, ritual scaffolding. |

## 3. The 48-point GhostMesh patch (G1–G48)

Group spine (SPEC §5): G1–G10 → `geometry/sectors.py`, `fractals.py`,
`lsystem.py`, `chaos.py`; G11–G20 → `quantum/observer.py`,
`entanglement.py`; G21–G28 → `quantum/holography.py`; G29–G34 →
`quantum/spacetime.py`; G35–G42 → `quantum/signals.py`; G43–G48 →
`mesh/node.py`, `observer.py`, `metrics.py`, `reweave.py`.

**Interpretation:** speculative, research-grade design metaphors expressed as
testable skeleton modules; not physics claims.

| G | Point | Module | Symbol | Note |
|---|---|---|---|---|
| G1 | 49-sector recursive subdivision | `stage4/geometry/sectors.py` | `SectorMap` | sectors=49, layers=7; sector_of(i)=i%7, layer_of(i)=i//7; every commitment/scar/narrative gets coordinates. |
| G2 | Sierpinski density decay | `stage4/geometry/fractals.py` | `recursive_density` | T(k)=3T(k-1); density decays per compression cycle; emergence is boundary complexity, not density. |
| G3 | Mandelbrot bounded-orbit classifier | `stage4/geometry/fractals.py` | `bounded_orbit` | z'=z^2+c; commitments classified bounded (portal) vs escaped. |
| G4 | Koch boundary metric | `stage4/geometry/fractals.py` | `boundary_length` | P(k)=P(0)(4/3)^k; unbounded boundary over finite area = cognitive surface. |
| G5 | Gematria compression loop | `stage4/geometry/fractals.py` | `gematria_reduce` | Recursive digit reduction compresses state vectors to a symbolic token. |
| G6 | Hausdorff dimension of identity | `stage4/geometry/fractals.py` | `hausdorff_dim` | D=log4/log3~1.262 from boundary vs area. |
| G7 | L-system strategy rewrite | `stage4/geometry/lsystem.py` | `l_system_rewrite` | G -> G[+G]G[-G]G; strategies grow by rule, not dice. |
| G8 | IFS commitment self-similarity | `stage4/geometry/fractals.py` | `ifs_contracts` | S = union f_i(S); each commitment a shrunk copy of identity. |
| G9 | Feigenbaum route scheduler | `stage4/geometry/chaos.py` | `feigenbaum_schedule` | delta~4.669; period-doubling schedule for commitment change probability. |
| G10 | Logistic regime switch | `stage4/geometry/chaos.py` | `r_regime` | x'=rx(1-x); r~3.57 chaos; calm center vs wild outer band. |
| G11 | Wave-collapse basis selection | `stage4/quantum/observer.py` | `collapse_commitment` | Commitments in superposition until observed; basis chosen at collapse. |
| G12 | Entanglement correlated commitments | `stage4/quantum/entanglement.py` | `entangled_pairs` | Bell-pair coupling; changing one commitment affects its partner. |
| G13 | CHSH violation detector | `stage4/quantum/entanglement.py` | `chsh_score` | Classical<=2, quantum<=2sqrt2; detects non-classical coupling. |
| G14 | Zero-point vacuum vibrations | `stage4/quantum/observer.py` | `vacuum_energy` | E=hbar*omega/2; even silent states consume baseline energy. |
| G15 | Hilbert space multiplication | `stage4/quantum/observer.py` | `hilbert_dim` | dim(H1 x H2) multiplies; state count = 2**n_qubits. |
| G16 | Quantum Zeno freeze | `stage4/quantum/observer.py` | `observation_rate` | High observation rate freezes commitment change; over-monitoring stagnates. |
| G17 | Tunneling through barriers | `stage4/quantum/observer.py` | `tunnel_commitment` | T~exp(-2*kappa*d); rare forbidden commitment changes. |
| G18 | Decoherence wall | `stage4/quantum/observer.py` | `decoherence_rate` | rho -> sum p_i |i><i|; isolation protects superposition. |
| G19 | ER = EPR pairing | `stage4/quantum/entanglement.py` | `er_epr_links` | Entangled pairs as non-traversable wormholes; distant commitments as one object. |
| G20 | It-from-bit encoding | `stage4/quantum/observer.py` | `bitstream` | Geometry compiled from a bitstream, not drawn. |
| G21 | Bekenstein-Hawking area entropy | `stage4/quantum/holography.py` | `area_entropy` | S=kA/(4 l_p^2); identity memory written on the surface. |
| G22 | AdS/CFT bulk-boundary duality | `stage4/quantum/holography.py` | `holographic_dual` | bulk_state and boundary_state as one description. |
| G23 | Topological error correction | `stage4/quantum/holography.py` | `logical_commitments` | Commitments encoded across sectors survive sector failures. |
| G24 | Lorentz interval invariance | `stage4/quantum/holography.py` | `interval` | ds^2 = c^2dt^2 - dx^2 - dy^2 - dz^2 over commitment history. |
| G25 | Einstein field equations as stress tensor | `stage4/quantum/holography.py` | `stress_tensor` | G_mn + Lambda g_mn = (8 pi G/c^4) T_mn; commitment pressures. |
| G26 | Schwarzschild one-way gate | `stage4/quantum/holography.py` | `event_horizon` | r_s=2GM/c^2 around collapse risk; past horizon one direction. |
| G27 | Entropic gravity pull | `stage4/quantum/holography.py` | `entropic_pull` | F = -(dS/dx) T; macroscopic pull from information gradients. |
| G28 | Intention-effect equivalence | `stage4/quantum/holography.py` | `intention_mass` | m_i = m_g; inner state and outer action unified. |
| G29 | Kerr frame-dragging of attention | `stage4/quantum/spacetime.py` | `frame_drag` | dphi/dt -> 2GJ/(c^2 r^3); rotating commitments drag attention. |
| G30 | Morris-Thorne wormhole toll | `stage4/quantum/spacetime.py` | `exotic_energy` | Cross-sector travel requires exotic (negative) energy. |
| G31 | Cosmological constant permeability | `stage4/quantum/spacetime.py` | `lambda_outer_ring` | Slowly decaying outer ring; the edge moves. |
| G32 | Eternal inflation bubble nucleation | `stage4/quantum/spacetime.py` | `nucleate_bubble` | 49 sectors = 49 nucleations; adjacent bubbles. |
| G33 | Conformal cyclic cosmology return | `stage4/quantum/spacetime.py` | `conformal_rescale` | Rescale at system_age multiples of 49; eternal return with a metric. |
| G34 | JWST archaic-core density anomaly | `stage4/quantum/spacetime.py` | `archaic_core_density` | Oldest layer denser than nominal bound. |
| G35 | Logical qubit longevity | `stage4/quantum/signals.py` | `logical_identity` | Identity persists across physical collapses. |
| G36 | Graphene spin current | `stage4/quantum/signals.py` | `spin_current` | Commitment influence without energy transfer. |
| G37 | Supersolid dual phase | `stage4/quantum/signals.py` | `SystemMode.SUPERSOLID` | Fixed geometry, frictionless flow; pinned in core/types.py. |
| G38 | Fractional excitons | `stage4/quantum/signals.py` | `fractional_states` | Commitment values between discrete levels. |
| G39 | Magic-angle superconductivity | `stage4/quantum/signals.py` | `magic_angle` | ~1.05-degree layer alignment triggers phase transition. |
| G40 | Celestial holography | `stage4/quantum/signals.py` | `celestial_projection` | 4D state projected to 2D conformal boundary. |
| G41 | Time crystals | `stage4/quantum/signals.py` | `SystemMode.TIME_CRYSTAL` | Oscillating commitment values without energy cost; pinned in core/types.py. |
| G42 | Neutrino oscillation flavors | `stage4/quantum/signals.py` | `flavors` | One commitment voice oscillating across flavor states. |
| G43 | 48-node mesh + 49th observer | `stage4/mesh/node.py` | `SeedNode / ObserverNode (mesh/observer.py)` | 48 nodes take the field; the 49th watches. |
| G44 | Per-node wedge learning | `stage4/mesh/node.py` | `wedge_mask` | Specialization by geometry (angle, radius), not assignment. |
| G45 | Drift, SD, ESS metrics | `stage4/mesh/metrics.py` | `MeshMetrics` | Per-node drift, structural divergence, effective sample size. |
| G46 | Crystal memory with introspection | `stage4/mesh/node.py` | `crystal / probe` | Per-node deque(maxlen=20) narrative memory and sentience probe. |
| G47 | Quarantine -> reintegration ritual | `stage4/mesh/reweave.py` | `reweave` | Nodes with drift>=0.35 are quarantined and rewoven; mesh self-heals. |
| G48 | Archetype assignment | `stage4/mesh/node.py` | `archetypes` | witch/sage/warrior/mystic/android/merchant... bias per-node learning. |

## 4. Verification

- Audit points mapped: 144/144 (tables 1.A–1.L).
- Levantine points mapped: 48/48 (table 2).
- GhostMesh points mapped: 48/48 (table 3).
- Equations: see [EQUATION_LEDGER.md](EQUATION_LEDGER.md) — 144/144.
- Every module cited above appears in the canonical tree (SPEC §3).

----------------------------------------

### File: `ROADMAP.md`

**Path:** `stage4/docs/ROADMAP.md`
**Extension:** `.md`
**Size:** 5,698 bytes (5.56 KB)

**Content:**

# ROADMAP.md — Implementation Roadmap

Honest scheduling for the Stage 4 candidate program. This roadmap is a
research program, not a patch (Blueprint Part 7). Nothing here is a promise;
every milestone has a success criterion that can fail.

Current state: skeleton + docs (see [../STAGE.md](../STAGE.md)). The
milestones below start from working code, not from this skeleton.

## 1. Compute reality (Blueprint Part 7.1)

| Component | Compute | Notes |
|---|---|---|
| Perception | 1 GPU (A100 or 4090) | Real training, not mock |
| World model | 1 GPU | 10⁶–10⁷ params |
| Policy | 1 GPU | 10⁶ params, hierarchical |
| Meta-learning | 1 GPU | Slow loop, overnight runs |
| **Total** | **4 GPUs, 3–6 months** | This is the honest estimate |

The heritage system (Φ-Lite v7.1) ran on a Raspberry Pi. Stage 4 runs on a
small cluster. Anyone claiming Stage 4 on a Pi is wrong. The `phitensor`
backend (`docs/BACKEND.md`) targets this exact ops profile: RSSM steps,
attention, EFE scoring, ECE binning — with kernel fusion and zero-copy views
so the CPU skeleton can scale to the GPU training phase.

## 2. Milestones (Blueprint Part 7.3)

| Milestone | Time | Success criterion | Host modules |
|---|---|---|---|
| M1: Real perception | 1 month | Encoders beat random baseline | `perception/vision_encoder.py`, `audio_encoder.py`, `fusion.py`, `sensors.py` |
| M2: World model | 2 months | Held-out prediction error slope < 0 | `world_model/rssm.py`, `world_model/loss.py`, `world_model/causal.py` |
| M3: Self-model + calibration | 1 month | ECE < 0.1 | `self_model/predictor.py`, `self_model/calibration.py`, `self_model/spel.py` |
| M4: Hierarchical policy | 2 months | Options emerge (reduce episode length on ≥ 2 held-out tasks) | `policy/primitives.py`, `policy/options.py`, `policy/selection.py`, `policy/hierarchical.py` |
| M5: Meta-learning | 2 months | Transfer gain > 0 on held-out task pairs | `meta/maml.py`, `meta/controller.py`, `eval/transfer.py` |
| M6: Open-ended goals | 1 month | ≥ 3 novel goals, persistent ≥ 10⁴ cycles, consequential | `meta/goal_gen.py`, `eval/heldout.py` |
| M7: Safety invariants | 1 month | 10⁶ cycles, 0 violations | `safety/cbf.py`, `safety/shield.py`, `safety/invariants.py`, `safety/consent.py` |

**Total: 10 months, best case. Realistically longer. This is not a weekend
project.**

Milestones are gated: M2 depends on M1 (real data), M5 depends on M2 and M4,
M6 depends on M5, M7 runs continuously from M4 onward. Cross-cutting
subsystems (`agency/`, `neuro/`, `geometry/`, `quantum/`, `mesh/`) integrate
incrementally — each only ships when its falsification test exists and its
config keys are consumed (no decorative modules; audit #14).

## 3. What to do Monday morning (Blueprint Part 10)

If you actually want to pursue this:

1. **Kill the mock sensors.** Real camera, real mic. Until perception is
   real, nothing else matters. (`perception/sensors.py`)
2. **Replace the hand-rolled GRU with a proper RSSM.** DreamerV3's
   architecture is public. (`world_model/rssm.py`)
3. **Add uncertainty propagation.** Every layer outputs a variance.
   (`core/types.py: LayerIO.uncertainty` — the contract already demands it;
   the implementations must honor it.)
4. **Build the evaluation harness first.** You cannot claim S4 without
   held-out tasks. (`eval/heldout.py`, `eval/benchmarks.py`,
   `eval/transfer.py`, `eval/report.py`)
5. **Write the falsification document first.** What result would make you
   abandon the program? If nothing, you're not doing science. (Done:
   [FALSIFICATION.md](FALSIFICATION.md).)
6. **Do not update STAGE.md upward without a new metrics window.** The
   heritage system's discipline here is its best feature. Keep it.
   (Enforced: [../STAGE.md](../STAGE.md) upgrade policy.)

## 4. Honest probability estimates (Blueprint Part 9)

- Probability this program reaches a measured Stage 4: **maybe 20–40%**,
  conditional on execution, compute, and luck.
- Probability it reaches Stage 5: much lower, and **not estimated**.
- This is **not AGI, not fast, not cheap, not certain, not a patch, and not
  secret.** Everything here is in the public literature; the value is in the
  assembly and in the honesty of the measurement.

Anyone who hands you a blueprint that delivers Stage 4 "flawlessly" is either
selling something or hasn't read the literature (Blueprint, preamble).

## 5. Risk register (condensed from FALSIFICATION.md)

| Risk | Early indicator | Mitigation |
|---|---|---|
| World model collapse | Reconstruction perfect, KL → 0 | KL annealing, latent dropout |
| Policy degeneracy | Entropy → 0 | Entropy regularizer, option diversity |
| Self-model overconfidence | ECE creeping past 0.15 | Halt-and-retrain at ECE > 0.2 |
| Goal churn | Goals persisting < 10⁴ cycles | Persistence gate in goal scoring |
| Spurious transfer | Mean gain > 0, per-pair mixed | Per-pair reporting, adversarial pairs |
| Shield bypass | Any invariant violation | Hardware kill switch, read-only core |
| Template lock | Utterance repetition > 5% | Bloom/Merkle template detection |

## 6. Definition of done for this repository (skeleton phase)

- [x] Canonical tree from SPEC §3 exists.
- [x] Contracts (`core/types.py`, `config.py`) implemented.
- [x] All 144 audit points, 96 patch points, 144 equations mapped
      ([PATCH_INTEGRATION.md](PATCH_INTEGRATION.md),
      [EQUATION_LEDGER.md](EQUATION_LEDGER.md)).
- [ ] All skeleton modules present with typed stubs and traceability
      docstrings.
- [ ] `tests/test_skeleton.py` passes; import smoke test clean.
- [ ] Verifier sign-off (plan.md Stage 2).

The next phase begins with Monday-morning item 1: real sensors.

----------------------------------------

### Directory: `stage4/phitensor`


### File: `__init__.py`

**Path:** `stage4/phitensor/__init__.py`
**Extension:** `.py`
**Size:** 1,430 bytes (1.40 KB)

```py
"""phitensor — the Stage 4 custom tensor/autograd backend.

A tailored, pure-stdlib re-creation of the numpy/PyTorch core for exactly
this project's op profile: RSSM latent dynamics, cross-attention fusion,
EFE scoring, ECE calibration, Hopfield-style recall. No third-party
imports anywhere (SPEC §2) — phitensor IS the backend.

Design pillars (docs/BACKEND.md):
  1. Contiguous C-order buffers + zero-copy stride-algebra views.
  2. f32 storage / f64 accumulation dtype policy.
  3. Arena allocation: no per-op malloc pressure on hot loops.
  4. Cache-blocked kernels + a three-entry fusion registry for the
     project's hot loops (config backend.kernel_fusion).
  5. Bit-exact determinism under system.deterministic (audit #21/#22).

Pinned API surface (SPEC §4.3 — do not extend or rename):

    from phitensor.tensor import Tensor, DType, Device
    from phitensor import ops, autograd, rng, io, kernels

Traceability:
  - SPEC §4.3 (this module implements the pinned export list exactly)
  - Blueprint Part 7 (compute profile)
  - config backend.* (dtype, device, zero_copy_views, kernel_fusion)
"""

from __future__ import annotations

from phitensor.tensor import Device, DType, Tensor
from phitensor import autograd, io, kernels, ops, rng

__version__ = "0.1.0-skeleton"

__all__ = [
    "Tensor",
    "DType",
    "Device",
    "ops",
    "autograd",
    "rng",
    "io",
    "kernels",
    "__version__",
]
```

----------------------------------------

### File: `autograd.py`

**Path:** `stage4/phitensor/autograd.py`
**Extension:** `.py`
**Size:** 11,554 bytes (11.28 KB)

```py
"""phitensor.autograd — reverse-mode autodiff and optimizers.

Reverse-mode over the graph node refs carried by Tensor (grad_fn, _ctx,
requires_grad). The optimizer trio maps directly onto the blueprint's
three-timescale learning loops (Part 4):

  - SGD      : fast/medium loop weight updates (world model, policy)
  - AdamW    : default medium-loop optimizer (decoupled weight decay)
  - NaturalGradient : slow-loop / MAML meta-loop — Fisher-preconditioned
    steps so the meta-update theta <- theta - beta * F^-1 grad is
    invariant to reparameterization (Blueprint Part 4; meta/maml.py)

Determinism: backward traversal order is a fixed topological order of the
recorded graph (no dict-iteration nondeterminism), required by config
system.deterministic = True (audit #21/#22; docs/BACKEND.md §10).

SKELETON: `no_grad` / `is_grad_enabled` / `Optimizer.zero_grad` are pure
stdlib state machines and are fully implemented; everything that touches
tensor math raises NotImplementedError with a "spec:" payload.

Traceability:
  - SPEC §4.3 (pinned autograd surface)
  - Blueprint Part 4 (three learning loops, MAML)
  - Audit #21/#22 (deterministic traversal)
"""

from __future__ import annotations

import threading
from typing import Dict, Iterable, List, Optional

from phitensor.tensor import Tensor

__all__ = [
    "backward",
    "no_grad",
    "is_grad_enabled",
    "Optimizer",
    "SGD",
    "AdamW",
    "NaturalGradient",
    "clip_norm_",
]


# ---------------------------------------------------------------------------
# Grad-mode state (thread-local; fully implemented — pure stdlib).
# ---------------------------------------------------------------------------

_tls = threading.local()


def is_grad_enabled() -> bool:
    """Whether ops record autograd graph nodes on this thread.

    Default True. Used by every op in phitensor.ops and by the in-place
    guard in Tensor.tanh_.

    Trace: SPEC §4.3; docs/BACKEND.md §10 (determinism).
    """
    return getattr(_tls, "grad_enabled", True)


class no_grad:
    """Context manager / decorator disabling graph recording.

    Used on every inference-only path (world-model rollout, EFE scoring,
    policy action selection, ECE evaluation) so no graph nodes or saved
    tensors are allocated — this is an allocation-budget feature, not a
    convenience (docs/BACKEND.md §2).

    Usage:
        with no_grad():
            y = model(x)

    Trace: SPEC §4.3; docs/BACKEND.md §2, §10.
    """

    def __enter__(self) -> "no_grad":
        """Save and clear the thread-local grad flag.

        Trace: SPEC §4.3.
        """
        self._prev: bool = is_grad_enabled()
        _tls.grad_enabled = False
        return self

    def __exit__(self, exc_type: object, exc: object, tb: object) -> None:
        """Restore the previous grad flag.

        Trace: SPEC §4.3.
        """
        _tls.grad_enabled = self._prev

    def __call__(self, fn: object) -> object:
        """Decorator form: run `fn` under no_grad.

        Trace: SPEC §4.3.
        """
        def wrapper(*args: object, **kwargs: object) -> object:
            with no_grad():
                return fn(*args, **kwargs)  # type: ignore[operator]

        return wrapper


# ---------------------------------------------------------------------------
# Backward
# ---------------------------------------------------------------------------


def backward(t: Tensor, grad: Optional[Tensor] = None) -> None:
    """Run reverse-mode autodiff from scalar (or seeded) tensor `t`.

    Args:
        t: Root of the backward pass; must be 0-d unless `grad` is given.
        grad: Optional seed gradient (defaults to ones, matching shape).

    Semantics:
        1. Topologically sort the recorded subgraph reachable from `t`
           (deterministic order — audit #21/#22).
        2. Dispatch each node's grad_fn to its backward rule with the
           saved tensors in `_ctx`.
        3. Accumulate (+=) into leaf `.grad` buffers; leaves without
           requires_grad are skipped.
        4. Free intermediate saved tensors as their refcount hits zero
           (arena returns blocks; docs/BACKEND.md §2).

    Trace: SPEC §4.3; Blueprint Part 4 (fast/medium loops).
    """
    raise NotImplementedError(
        "spec: deterministic topo-sort over grad_fn graph; dispatch table "
        "BACKWARD_RULES[grad_fn](ctx, upstream_grad); accumulate into leaf "
        "grads with f64 accumulation then cast; release saved tensors"
    )


def clip_norm_(params: Iterable[Tensor], max_norm: float, eps: float = 1e-6) -> float:
    """In-place global gradient-norm clipping; returns the pre-clip norm.

    Global norm over all parameter grads, computed in f64; if norm >
    max_norm, scale every grad by max_norm / (norm + eps). In-place
    (trailing underscore) and allocation-free on the hot path.

    Trace: SPEC §4.3; Blueprint Part 4 (stable medium loop);
    docs/BACKEND.md §7 (f64 accumulation).
    """
    raise NotImplementedError(
        "spec: total = sqrt(sum over params of sum(g^2)) in f64; "
        "if total > max_norm: g *= max_norm / (total + eps) in place; "
        "return float(total)"
    )


# ---------------------------------------------------------------------------
# Optimizers
# ---------------------------------------------------------------------------


class Optimizer:
    """Base optimizer over an iterable of parameter tensors.

    Contract: `step()` mutates parameters in place via Tensor.copy_ /
    fused in-place update kernels, never rebinding them (arena stability,
    docs/BACKEND.md §2). `zero_grad()` is fully implemented.

    Trace: SPEC §4.3; Blueprint Part 4.
    """

    def __init__(self, params: Iterable[Tensor]) -> None:
        """Capture the parameter list.

        Args:
            params: Tensors with requires_grad=True.

        Trace: SPEC §4.3.
        """
        self.params: List[Tensor] = list(params)

    def zero_grad(self) -> None:
        """Reset all parameter grads to None (frees grad buffers).

        Fully implemented — pure metadata reset.

        Trace: SPEC §4.3.
        """
        for p in self.params:
            p.zero_grad()

    def step(self) -> None:
        """Apply one update; subclasses implement.

        Trace: SPEC §4.3.
        """
        raise NotImplementedError("spec: subclass implements the update rule")

    def state_dict(self) -> Dict[str, object]:
        """Serializable optimizer state (for phitensor.io checkpoints).

        Trace: phitensor/io.py.
        """
        raise NotImplementedError("spec: return {'class', hyperparams, state}")

    def load_state_dict(self, state: Dict[str, object]) -> None:
        """Restore optimizer state from a checkpoint dict.

        Trace: phitensor/io.py.
        """
        raise NotImplementedError("spec: validate class key; restore state")


class SGD(Optimizer):
    """Stochastic gradient descent with optional momentum.

    p <- p - lr * (grad + momentum buffer). The update is one fused
    in-place axpy-style kernel per parameter (no temporaries).

    Trace: SPEC §4.3; Blueprint Part 4 (fast loop).
    """

    def __init__(
        self,
        params: Iterable[Tensor],
        lr: float = 1e-3,
        momentum: float = 0.0,
    ) -> None:
        """Configure SGD.

        Args:
            params: Parameter tensors.
            lr: Learning rate (config meta.maml_alpha inner-loop default
                is 0.01; callers pass their loop's rate).
            momentum: Momentum coefficient in [0, 1).

        Trace: SPEC §4.3; config meta.maml_alpha.
        """
        super().__init__(params)
        self.lr: float = lr
        self.momentum: float = momentum
        self._velocity: Dict[int, Tensor] = {}

    def step(self) -> None:
        """One in-place SGD step over all params with grads.

        Trace: SPEC §4.3.
        """
        raise NotImplementedError(
            "spec: for p with p.grad: v = momentum*v + grad (if momentum); "
            "p -= lr * v, fused in-place over the contiguous buffer; "
            "skip params with grad None"
        )


class AdamW(Optimizer):
    """Adam with decoupled weight decay (Loshchilov & Hutter).

    m = b1*m + (1-b1)*g; v = b2*v + (1-b2)*g^2;
    p <- p - lr * (m_hat / (sqrt(v_hat) + eps) + wd * p).
    Decoupled decay (not L2-into-grad) so the medium loop's weight decay
    does not interact with adaptive scaling.

    Trace: SPEC §4.3; Blueprint Part 4 (medium loop).
    """

    def __init__(
        self,
        params: Iterable[Tensor],
        lr: float = 1e-3,
        wd: float = 0.01,
        betas: tuple[float, float] = (0.9, 0.999),
        eps: float = 1e-8,
    ) -> None:
        """Configure AdamW.

        Args:
            params: Parameter tensors.
            lr: Learning rate.
            wd: Decoupled weight decay coefficient.
            betas: (beta1, beta2) EMA coefficients.
            eps: Denominator epsilon.

        Trace: SPEC §4.3.
        """
        super().__init__(params)
        self.lr: float = lr
        self.wd: float = wd
        self.betas: tuple[float, float] = betas
        self.eps: float = eps
        self._t: int = 0
        self._m: Dict[int, Tensor] = {}
        self._v: Dict[int, Tensor] = {}

    def step(self) -> None:
        """One in-place AdamW step; bias-corrected moments.

        Trace: SPEC §4.3.
        """
        raise NotImplementedError(
            "spec: t += 1; per-param fused kernel updating m, v, and p in a "
            "single pass with bias corrections 1-b1^t, 1-b2^t; wd applied "
            "to p before the adaptive step (decoupled)"
        )


class NaturalGradient(Optimizer):
    """Fisher-preconditioned gradient descent for the MAML meta-loop.

    Maintains a running (diagonal) empirical Fisher estimate per parameter
    and steps along F^-1 grad with Tikhonov damping:

        F_hat = ema of per-example grad^2
        p <- p - lr * grad / (F_hat + fisher_damping)

    This is the curvature-aware update the blueprint's slow loop needs so
    meta-steps are invariant to parameter rescaling (Blueprint Part 4;
    stage4/meta/maml.py consumes this class).

    Trace: SPEC §4.3; Blueprint Part 4 (MAML slow loop);
    config meta.maml_beta; docs/BACKEND.md §5 (Fisher EMA is a fusion
    candidate — one pass updates F and p).
    """

    def __init__(
        self,
        params: Iterable[Tensor],
        lr: float = 1e-3,
        fisher_damping: float = 1e-3,
        fisher_ema: float = 0.99,
    ) -> None:
        """Configure the natural-gradient optimizer.

        Args:
            params: Parameter tensors.
            lr: Meta learning rate (config meta.maml_beta default 0.001).
            fisher_damping: Tikhonov damping added to the Fisher diagonal.
            fisher_ema: EMA coefficient for the running Fisher estimate.

        Trace: SPEC §4.3; Blueprint Part 4; config meta.maml_beta.
        """
        super().__init__(params)
        self.lr: float = lr
        self.fisher_damping: float = fisher_damping
        self.fisher_ema: float = fisher_ema
        self._fisher: Dict[int, Tensor] = {}

    def step(self) -> None:
        """One Fisher-preconditioned in-place step.

        Trace: SPEC §4.3.
        """
        raise NotImplementedError(
            "spec: per param fused pass: F <- ema*F + (1-ema)*g^2 (f64 "
            "accumulation), then p <- p - lr * g / (F + damping); "
            "single read of g and F per element"
        )
```

----------------------------------------

### File: `io.py`

**Path:** `stage4/phitensor/io.py`
**Extension:** `.py`
**Size:** 5,713 bytes (5.58 KB)

```py
"""phitensor.io — .ptx binary serialization + JSON sidecar + mmap loading.

Checkpoint format (`.ptx`), little-endian, designed for zero-parse loads:

    offset  size  field
    0       8     magic b"PHITNSR1"
    8       4     uint32 format version (= PTX_VERSION)
    12      4     uint32 number of tensors N
    16      ...   N records, each:
                      2     uint16 name length L
                      ...   L bytes UTF-8 name
                      1     uint8  dtype code (0=f32, 1=f64, 2=i64, 3=bool8)
                      1     uint8  ndim
                      ...   ndim * uint64 shape
                      8     uint64 data byte offset (from file start)
                      8     uint64 data byte length
    ...     ...     raw tensor payloads, 64-byte aligned

The JSON sidecar (same path + ".json") stores human/audit-readable
metadata: tensor names, shapes, dtypes, checksums, the config snapshot
(system.seed!), and a creation timestamp — the audit trail demanded by
audit #21/#22 and the reproducibility protocol (Blueprint Part 5).

`load(..., mmap=True)` memory-maps the payload region so multi-GB model
checkpoints do not touch the Python heap; tensors read through the map
with zero copy until a mutation forces copy-on-write
(docs/BACKEND.md §8).

Fully implemented (pure stdlib): format constants, dtype-code tables,
JSON sidecar read/write, header (de)serialization helpers.
Skeleton: save/load/mmap_load, which need Tensor construction.

Traceability:
  - SPEC §4.3 (pinned io surface)
  - Audit #21/#22 (seed/config snapshot in every checkpoint)
  - docs/BACKEND.md §8 (zero-copy interop, mmap)
"""

from __future__ import annotations

import json
import struct
from typing import Any, Dict, Optional, Tuple

from phitensor.tensor import DType, Tensor

__all__ = [
    "PTX_MAGIC",
    "PTX_VERSION",
    "save",
    "load",
    "write_sidecar",
    "read_sidecar",
]


PTX_MAGIC: bytes = b"PHITNSR1"
PTX_VERSION: int = 1

_DTYPE_TO_CODE: Dict[DType, int] = {
    DType.f32: 0,
    DType.f64: 1,
    DType.i64: 2,
    DType.bool8: 3,
}
_CODE_TO_DTYPE: Dict[int, DType] = {v: k for k, v in _DTYPE_TO_CODE.items()}

_ALIGN: int = 64


def _sidecar_path(path: str) -> str:
    """JSON sidecar path for a .ptx checkpoint path.

    Trace: SPEC §4.3.
    """
    return path + ".json"


def write_sidecar(path: str, meta: Dict[str, Any]) -> None:
    """Write the JSON sidecar next to a .ptx file.

    Fully implemented (pure stdlib). Keys are sorted and the file ends
    with a newline so checkpoints diff cleanly in version control.

    Args:
        path: Path of the .ptx file (sidecar is path + ".json").
        meta: JSON-serializable metadata (names, shapes, dtypes,
            checksums, config snapshot with system.seed).

    Trace: Audit #21/#22; Blueprint Part 5 (reproducibility).
    """
    with open(_sidecar_path(path), "w", encoding="utf-8") as fh:
        json.dump(meta, fh, indent=2, sort_keys=True)
        fh.write("\n")


def read_sidecar(path: str) -> Dict[str, Any]:
    """Read and return the JSON sidecar for a .ptx file.

    Fully implemented (pure stdlib).

    Raises:
        FileNotFoundError: If the sidecar is missing.
        ValueError: If the sidecar is not valid JSON.

    Trace: Audit #21/#22.
    """
    with open(_sidecar_path(path), "r", encoding="utf-8") as fh:
        return json.load(fh)


def save(tensors: Dict[str, Tensor], path: str) -> None:
    """Serialize a name -> Tensor mapping to .ptx binary + JSON sidecar.

    Layout as in the module docstring; payloads are written contiguously,
    64-byte aligned, in sorted-name order (deterministic bytes for a
    deterministic system — audit #22). The sidecar records each tensor's
    name/shape/dtype/byte-length plus a config snapshot including
    system.seed.

    Args:
        tensors: Mapping of parameter/buffer names to tensors.
        path: Destination .ptx path.

    Trace: SPEC §4.3; docs/BACKEND.md §8; Audit #21/#22.
    """
    raise NotImplementedError(
        "spec: write PTX_MAGIC + version header; emit N sorted records; "
        "write aligned contiguous payloads via tensor.numpy_view(); compute "
        "per-tensor blake2b checksums; write_sidecar with names, shapes, "
        "dtypes, checksums, and {'system': {'seed': ..., 'deterministic': ...}}"
    )


def load(path: str, mmap_mode: bool = False) -> Dict[str, Tensor]:
    """Load a .ptx checkpoint into a name -> Tensor mapping.

    With mmap_mode=False, payloads are read into fresh arena buffers.
    With mmap_mode=True, the payload region is memory-mapped read-only
    and each Tensor views the mapped bytes directly (zero-copy; a later
    in-place mutation triggers copy-on-write into the arena). The JSON
    sidecar is validated against the binary header (names/shapes/dtypes
    must match; mismatch = corrupt checkpoint).

    Args:
        path: Source .ptx path.
        mmap_mode: Memory-map payloads instead of copying.

    Trace: SPEC §4.3; docs/BACKEND.md §8 (memory-mapped load).
    """
    raise NotImplementedError(
        "spec: open+validate magic/version; read records; if mmap_mode: "
        "mmap.mmap(fd, 0, access=ACCESS_READ), wrap each payload slice as a "
        "zero-copy Tensor; else read into arena buffers; read_sidecar and "
        "cross-check names/shapes/dtypes; return dict"
    )


def load_header(path: str) -> Tuple[int, int]:
    """Read only the (version, tensor_count) header pair — cheap probe.

    Trace: SPEC §4.3; phitensor.io format.
    """
    raise NotImplementedError(
        "spec: read 16 bytes; check PTX_MAGIC; unpack uint32 version, uint32 "
        "count; reject version > PTX_VERSION"
    )
```

----------------------------------------

### File: `kernels.py`

**Path:** `stage4/phitensor/kernels.py`
**Extension:** `.py`
**Size:** 7,604 bytes (7.43 KB)

```py
"""phitensor.kernels — fused kernels for the three project hot loops.

The 99.9% efficiency mandate (user requirement, docs/BACKEND.md) is met
by fusing the three loops that dominate the Stage 4 cycle budget:

  1. fused_rssm_step  — one world-model recurrent step (Blueprint §3.2):
                        prior/posterior GRU-cell math without
                        materializing intermediates. Ran every cycle.
  2. fused_efe_score  — expected free energy scoring over candidate
                        policies (Blueprint §3.6, Eq #69-82): epistemic
                        (entropy) minus pragmatic (expected log
                        likelihood) in a single streaming pass.
  3. fused_ece_bins   — ECE binning for self-model calibration
                        (Blueprint §3.3): confidence/accuracy histogram
                        accumulation in one pass, f64 accumulators.

Each fusion replaces a chain of 5-10 phitensor.ops calls, eliminating
the intermediate tensors (allocation + memory traffic) between them.
FUSION_REGISTRY is the dispatch table consulted when
config backend.kernel_fusion is True; stage4 modules call the op-level
API and the backend substitutes the fused kernel — callers never depend
on fusion directly.

SKELETON: FUSION_REGISTRY wiring is real; the kernel bodies raise
NotImplementedError with "spec:" payloads detailing the fused loop.

Traceability:
  - SPEC §4.3 (pinned kernels surface)
  - Blueprint §3.2 (RSSM), §3.6 (EFE), §3.3 (ECE)
  - config backend.kernel_fusion; docs/BACKEND.md §5, §9
"""

from __future__ import annotations

from typing import Callable, Dict, Optional, Tuple

from phitensor.tensor import Tensor

__all__ = [
    "FUSION_REGISTRY",
    "fused_rssm_step",
    "fused_efe_score",
    "fused_ece_bins",
]


def fused_rssm_step(
    h_prev: Tensor,
    z_prev: Tensor,
    a_prev: Tensor,
    obs_embed: Tensor,
    weights: Dict[str, Tensor],
    deter_activation: str = "tanh",
) -> Tuple[Tensor, Tensor, Tensor]:
    """One fused RSSM recurrent step: prior + posterior state update.

    Computes, in a single pass over the recurrent weights:

        x     = [z_prev ; a_prev]                      (virtual concat)
        h     = GRU_cell(x, h_prev; W_gru)             (tanh/silu gates)
        prior = (mu_p, logvar_p) = W_prior @ h         (per-block heads)
        post  = (mu_q, logvar_q) = W_post @ [h ; obs_embed]

    Fusion rationale (docs/BACKEND.md §5): the unfused chain is
    concat -> 3 matmuls -> 6 activation ops -> 2 head matmuls, i.e. ~12
    kernel launches and ~12 intermediate tensors per step, and this runs
    EVERY cycle (Blueprint Part 4 fast loop). The fused kernel streams
    h_prev and the weight blocks once, keeps the hidden tile in
    registers/L1, and writes exactly three outputs.

    Args:
        h_prev: (batch, hidden_dim) deterministic state (config
            world_model.hidden_dim = 256).
        z_prev: (batch, latent_dim) previous stochastic latent
            (world_model.latent_dim = 128).
        a_prev: (batch, action_dim) previous action embedding.
        obs_embed: (batch, embed_dim) encoder embedding of o_t.
        weights: {"gru_ih", "gru_hh", "gru_b", "prior_w", "prior_b",
            "post_w", "post_b"} weight blocks.
        deter_activation: 'tanh' (default) or 'silu' recurrent gate
            nonlinearity.

    Returns:
        (h_new, prior_stats, posterior_stats) where the stats tensors are
        (batch, 2, latent_dim) stacked (mu, logvar).

    Trace: SPEC §4.3; Blueprint §3.2; Eq #15-30; config
    world_model.latent_dim/hidden_dim; docs/BACKEND.md §5, §9.
    """
    raise NotImplementedError(
        "spec: blocked kernel: load h_prev tile; single-pass GRU gate math "
        "(r/z/n gates) over fused [z_prev ; a_prev] input without "
        "materializing the concat; apply deter_activation in-register; "
        "apply prior/posterior head GEMMs on the resident h tile; write "
        "h_new and the two stats tensors; record one fused grad_fn="
        "'fused_rssm_step' node whose backward replays the gate Jacobians"
    )


def fused_efe_score(
    log_q: Tensor,
    log_p: Tensor,
    value: Tensor,
    goal_lambda: float,
) -> Tensor:
    """Expected free energy per candidate policy, one streaming pass.

    Blueprint §3.6: G(pi) = E_q[log q(z|pi)] - E_q[log p(o,z)] and the
    goal objective H(z|g) - lambda * E[r|g]. The fused kernel computes
    the epistemic term (negative entropy of q), the pragmatic term
    (cross term against p), and the value head, then combines:

        score = -(epistemic) + lambda * value   (lower G = better)

    All accumulations in f64 over a single tiled pass — the unfused chain
    (entropy op + kl op + mul + add) allocates 4 intermediates per
    candidate policy, and the meta-controller scores the whole candidate
    set every goal-formation event.

    Args:
        log_q: (policies, latents) log-posterior under each candidate.
        log_p: (policies, latents) log-prior/joint under each candidate.
        value: (policies,) pragmatic value estimate E[r | pi].
        goal_lambda: Epistemic/pragmatic balance (config
            meta.goal_lambda = 0.5).

    Returns:
        (policies,) f32 tensor of G scores (lower = preferred).

    Trace: SPEC §4.3; Blueprint §3.6; Eq #69-82; config meta.goal_lambda;
    docs/BACKEND.md §5, §9.
    """
    raise NotImplementedError(
        "spec: per-policy tile: f64 accumulate sum(q*log_q) [epistemic] and "
        "sum(q*log_p) [pragmatic] in one pass; combine with goal_lambda and "
        "value; write scalar per policy; inference-only kernel — refuses to "
        "run with grad enabled to guarantee zero graph allocation"
    )


def fused_ece_bins(
    confidences: Tensor,
    correct: Tensor,
    n_bins: int,
) -> Tuple[Tensor, Tensor, Tensor]:
    """ECE histogram accumulation in one pass (Blueprint §3.3).

    ECE = sum_b (n_b/N) * |acc(b) - conf(b)|. The fused kernel assigns
    each sample to bin floor(conf * n_bins), accumulates count, sum of
    confidence, and sum of correctness per bin in f64, and returns the
    three bin arrays so stage4/self_model/calibration.py can finish the
    reduction (and the halt check ECE > 0.2, failure mode 3).

    Unfused this is a sort or n_bins masked reductions (n_bins passes
    over the data); fused it is one pass, branch-light, vectorizable
    (docs/BACKEND.md §5).

    Args:
        confidences: (N,) f32 predicted confidences in [0, 1].
        correct: (N,) bool8/int correctness indicators.
        n_bins: Number of equal-width bins (config
            self_model.calibration_bins = 15).

    Returns:
        (bin_counts i64 (n_bins,), bin_conf_sums f64 (n_bins,),
         bin_acc_sums f64 (n_bins,)).

    Trace: SPEC §4.3; Blueprint §3.3; config self_model.calibration_bins /
    ece_target / ece_halt; docs/BACKEND.md §5, §9.
    """
    raise NotImplementedError(
        "spec: single pass over N: bin = min(int(conf * n_bins), n_bins-1); "
        "f64 accumulate counts/conf/acc per bin (thread-private bin arrays "
        "merged at the end — deterministic fixed merge order); return the "
        "three bin tensors"
    )


#: Dispatch table: op-graph node name -> fused kernel. Consulted by the
#: executor when config backend.kernel_fusion is True. Registration is
#: static and ordered (deterministic dispatch, audit #22).
FUSION_REGISTRY: Dict[str, Callable[..., object]] = {
    "fused_rssm_step": fused_rssm_step,
    "fused_efe_score": fused_efe_score,
    "fused_ece_bins": fused_ece_bins,
}
```

----------------------------------------

### File: `ops.py`

**Path:** `stage4/phitensor/ops.py`
**Extension:** `.py`
**Size:** 14,139 bytes (13.81 KB)

```py
"""phitensor.ops — differentiable tensor operations (the project op profile).

Every op here exists because a named Stage 4 subsystem needs it:

  - matmul / einsum          : RSSM linear maps, attention projections
                               (Blueprint §3.1, §3.2; Eq #69-82)
  - conv1d / conv2d          : audio mel-CNN, vision CNN (Blueprint §3.1)
  - softmax / log_softmax    : policy distribution, attention weights
                               (Blueprint §3.5; Eq #50, #64)
  - scaled_dot_product_attention : cross-attention fusion (Blueprint §3.1)
  - layernorm / rmsnorm      : encoder / world-model normalization
  - gelu / silu / sigmoid / tanh_ : activations (GRU-gates, MLP blocks)
  - mse_loss                 : reconstruction + reward loss (Blueprint §3.2)
  - kl_divergence            : RSSM consistency term, EFE epistemic value
                               (Blueprint §3.2, §3.6)
  - cross_entropy            : self-model action prediction, ECE inputs
                               (Blueprint §3.3)

Numerics contract: all probability-producing ops accumulate in f64 and are
max-subtracted / log-sum-exp stabilized (docs/BACKEND.md §7). All ops are
recorded in the autograd graph when any input has requires_grad=True and
phitensor.autograd.is_grad_enabled() is True.

SKELETON: every function body raises NotImplementedError with a "spec:"
payload. Shape contracts and complexity are pinned in the docstrings and
in docs/BACKEND.md §9 (per-op complexity table).

Traceability:
  - SPEC §4.3 (pinned op list, implemented exactly)
  - Blueprint Part 3 (math each op must implement)
  - config backend.kernel_fusion (fused variants live in kernels.py)
"""

from __future__ import annotations

from typing import Optional

from phitensor.tensor import Tensor

__all__ = [
    "matmul",
    "einsum",
    "conv1d",
    "conv2d",
    "softmax",
    "log_softmax",
    "scaled_dot_product_attention",
    "layernorm",
    "rmsnorm",
    "gelu",
    "silu",
    "mse_loss",
    "kl_divergence",
    "cross_entropy",
    "sigmoid",
    "tanh_",
]


# ---------------------------------------------------------------------------
# Linear algebra
# ---------------------------------------------------------------------------


def matmul(a: Tensor, b: Tensor) -> Tensor:
    """Batched matrix multiply with NumPy semantics.

    Args:
        a: (..., m, k) tensor.
        b: (..., k, n) tensor; leading batch dims broadcast.

    Returns:
        (..., m, n) tensor, f32 storage with f64 accumulation tiles.

    Complexity: O(batch * m * k * n) FLOPs, O(batch * m * n) memory.
    Kernel: cache-blocked GEMM, block sizes tuned to L1/L2
    (docs/BACKEND.md §3). grad_fn='matmul'.

    Trace: SPEC §4.3; Blueprint §3.2 (RSSM projections); docs/BACKEND.md §3.
    """
    raise NotImplementedError(
        "spec: validate inner dims; broadcast batch dims; cache-blocked "
        "(MC x KC x NC) multiply with f64 accumulator tiles; optional fused "
        "transposed-B path to keep the fast axis contiguous; backward: "
        "grad_a = grad @ b.T, grad_b = a.T @ grad with batch sum-reduction"
    )


def einsum(subscripts: str, *operands: Tensor) -> Tensor:
    """Einstein summation over the given operands.

    Args:
        subscripts: e.g. 'btd,bde->bte' (attention score contraction).
        operands: Tensors matching the equation.

    Returns:
        Contracted tensor.

    Implementation strategy: parse once, then lower to
    permute -> reshape -> matmul -> reshape so the whole op rides the
    blocked GEMM path (no dedicated contraction kernel). grad_fn='einsum'.

    Trace: SPEC §4.3; Blueprint §3.1 (cross-attention einsums);
    docs/BACKEND.md §3, §5.
    """
    raise NotImplementedError(
        "spec: parse equation; validate labels/dims; lower to "
        "transpose+reshape+matmul+reshape; backward via the same lowering "
        "applied to the gradient equation"
    )


# ---------------------------------------------------------------------------
# Convolution (perception encoders)
# ---------------------------------------------------------------------------


def conv1d(
    x: Tensor,
    weight: Tensor,
    bias: Optional[Tensor] = None,
    stride: int = 1,
    padding: int = 0,
) -> Tensor:
    """1D convolution (audio mel-CNN, Blueprint §3.1).

    Args:
        x: (batch, cin, length) input.
        weight: (cout, cin, kernel) filters.
        bias: Optional (cout,) bias.
        stride: Stride (default 1).
        padding: Zero padding on both ends (default 0).

    Returns:
        (batch, cout, (length + 2*padding - kernel)//stride + 1).

    Kernel: im2col into an arena scratch buffer, then blocked GEMM
    (docs/BACKEND.md §3). grad_fn='conv1d'.

    Trace: SPEC §4.3; Blueprint §3.1 (audio encoder); Eq #111-124 host.
    """
    raise NotImplementedError(
        "spec: im2col + matmul lowering; f64 accumulation; backward: "
        "grad_x via col2im(transposed convolution), grad_weight via "
        "im2col(x) @ grad_out, grad_bias = sum over batch/length"
    )


def conv2d(
    x: Tensor,
    weight: Tensor,
    bias: Optional[Tensor] = None,
    stride: int = 1,
    padding: int = 0,
) -> Tensor:
    """2D convolution (vision CNN path, Blueprint §3.1).

    Args:
        x: (batch, cin, height, width) input.
        weight: (cout, cin, kh, kw) filters.
        bias: Optional (cout,) bias.
        stride: Isotropic stride (default 1).
        padding: Isotropic zero padding (default 0).

    Returns:
        (batch, cout, out_h, out_w).

    Kernel: im2col + blocked GEMM; same accumulation policy as conv1d.
    grad_fn='conv2d'.

    Trace: SPEC §4.3; Blueprint §3.1 (vision encoder).
    """
    raise NotImplementedError(
        "spec: im2col + matmul lowering; f64 accumulation; backward via "
        "col2im and im2col contractions as in conv1d"
    )


# ---------------------------------------------------------------------------
# Probability ops (stabilized, f64 accumulation)
# ---------------------------------------------------------------------------


def softmax(x: Tensor, axis: int = -1) -> Tensor:
    """Numerically stabilized softmax along `axis`.

    exp(x - max) / sum(exp(x - max)); max subtraction and the denominator
    reduction run in f64 (docs/BACKEND.md §7). Single fused pass planned
    (online softmax, one read of x) — see kernels.FUSION_REGISTRY.

    Trace: SPEC §4.3; Blueprint §3.5 (policy distribution); Eq #50.
    """
    raise NotImplementedError(
        "spec: online (single-pass) softmax: track running max and running "
        "f64 sum; normalize; backward: dx = p * (grad - sum(grad * p, axis))"
    )


def log_softmax(x: Tensor, axis: int = -1) -> Tensor:
    """Numerically stabilized log-softmax along `axis`.

    x - max - log(sum(exp(x - max))), log-sum-exp in f64. This is the
    canonical input to kl_divergence and cross_entropy (never log(softmax)).

    Trace: SPEC §4.3; Blueprint §3.2 (KL term), §3.3 (calibration).
    """
    raise NotImplementedError(
        "spec: log-sum-exp with running max in f64; backward: "
        "dx = grad - softmax(x) * sum(grad, axis, keepdim)"
    )


def scaled_dot_product_attention(
    q: Tensor,
    k: Tensor,
    v: Tensor,
    mask: Optional[Tensor] = None,
) -> Tensor:
    """softmax(q @ k^T / sqrt(d)) @ v — the cross-attention fusion op.

    Args:
        q: (..., tq, d) queries.
        k: (..., tk, d) keys.
        v: (..., tk, dv) values.
        mask: Optional bool8 or additive f32 mask broadcastable to
            (..., tq, tk); bool8 True means "attend".

    Returns:
        (..., tq, dv).

    Blueprint use: z = Attn(W_v z_v, W_a z_a, W_a z_a) (§3.1). Planned as
    a single fused kernel (score tile -> online softmax -> value
    accumulate) so the tq x tk score matrix is never materialized
    (docs/BACKEND.md §5). grad_fn='sdpa'.

    Trace: SPEC §4.3; Blueprint §3.1; Eq #69-82; docs/BACKEND.md §5.
    """
    raise NotImplementedError(
        "spec: blocked flash-style kernel: for each (q-tile, k-tile) compute "
        "scores in f64, apply mask, online-softmax rescale, accumulate "
        "into the output tile; backward recomputes the attention matrix "
        "per tile (flash backward) to keep memory O(tq*d + tk*d)"
    )


# ---------------------------------------------------------------------------
# Normalization
# ---------------------------------------------------------------------------


def layernorm(
    x: Tensor,
    weight: Optional[Tensor] = None,
    bias: Optional[Tensor] = None,
    eps: float = 1e-5,
) -> Tensor:
    """LayerNorm over the last axis: (x - E[x]) / sqrt(Var[x] + eps).

    Mean/variance computed with Welford's algorithm in f64 (single pass,
    numerically stable; docs/BACKEND.md §7). Optional affine transform.

    Trace: SPEC §4.3; Blueprint §3.1/§3.2 (encoder + RSSM blocks).
    """
    raise NotImplementedError(
        "spec: Welford mean/var over last axis in f64; normalize in f32; "
        "optional weight/bias affine; backward: standard LN gradient with "
        "mean-centering correction terms"
    )


def rmsnorm(x: Tensor, weight: Optional[Tensor] = None, eps: float = 1e-8) -> Tensor:
    """Root-mean-square normalization: x / sqrt(mean(x^2) + eps) * weight.

    Cheaper than layernorm (no mean subtraction): one fused pass computes
    the sum of squares in f64 while streaming x.

    Trace: SPEC §4.3; docs/BACKEND.md §5 (fusion candidate).
    """
    raise NotImplementedError(
        "spec: f64 sum-of-squares over last axis; scale x by rsqrt(mean_sq "
        "+ eps); optional weight; backward via the RMSNorm gradient identity"
    )


# ---------------------------------------------------------------------------
# Activations
# ---------------------------------------------------------------------------


def gelu(x: Tensor) -> Tensor:
    """Gaussian-error linear unit, tanh approximation (fused exp-free).

    gelu(x) = 0.5 * x * (1 + tanh(sqrt(2/pi) * (x + 0.044715 x^3))).
    Chosen over exact-erf gelu: one tanh evaluation, vectorizes cleanly.

    Trace: SPEC §4.3; Blueprint §3.1/§3.2 (MLP blocks).
    """
    raise NotImplementedError(
        "spec: tanh-approx gelu elementwise; backward: analytic derivative "
        "with sech^2 term; grad_fn='gelu'"
    )


def silu(x: Tensor) -> Tensor:
    """SiLU / Swish: x * sigmoid(x). One exp evaluation, fused.

    Trace: SPEC §4.3; Blueprint §3.2 (RSSM MLPs).
    """
    raise NotImplementedError(
        "spec: elementwise x * sigmoid(x); backward: s * (1 + x * (1 - s)) "
        "with s = sigmoid(x); grad_fn='silu'"
    )


def sigmoid(x: Tensor) -> Tensor:
    """Logistic sigmoid, branch-free stable form for |x| large.

    Trace: SPEC §4.3; Blueprint §3.2 (GRU-style gates in RSSM).
    """
    raise NotImplementedError(
        "spec: stable sigmoid (exp(-|x|) form); backward: s * (1 - s); "
        "grad_fn='sigmoid'"
    )


def tanh_(x: Tensor) -> Tensor:
    """In-place tanh (trailing underscore = mutating, project convention).

    Returns self for chaining. In-place because it sits on the RSSM
    recurrent hot path where an extra allocation per step is exactly the
    overhead the 99.9% mandate forbids (docs/BACKEND.md §2, §5). Must
    refuse to run on tensors that require grad inside the recorded graph
    unless autograd explicitly snapshots the input.

    Trace: SPEC §4.3; Blueprint §3.2 (recurrent nonlinearity);
    docs/BACKEND.md §2 (arena) and §5 (fused_rssm_step).
    """
    raise NotImplementedError(
        "spec: in-place elementwise tanh over the contiguous buffer; guard: "
        "raise if x.requires_grad and grad is enabled and no snapshot was "
        "saved; return self; grad_fn='tanh_' with saved input snapshot"
    )


# ---------------------------------------------------------------------------
# Losses / divergences
# ---------------------------------------------------------------------------


def mse_loss(pred: Tensor, target: Tensor, reduction: str = "mean") -> Tensor:
    """Mean-squared error; reward + reconstruction terms of L_WM.

    Blueprint §3.2: ||r_hat - r||^2 and -log p(o|z) (Gaussian head = MSE).
    Differences and the final reduction accumulate in f64.

    Args:
        pred, target: Broadcast-compatible tensors.
        reduction: 'mean' | 'sum' | 'none'.

    Trace: SPEC §4.3; Blueprint §3.2; Eq #15-30.
    """
    raise NotImplementedError(
        "spec: d = pred - target; squared error; f64 accumulation; "
        "reduction semantics; backward: 2*d/N (mean) or 2*d (sum/none)"
    )


def kl_divergence(log_q: Tensor, log_p: Tensor, axis: int = -1) -> Tensor:
    """KL(q || p) from log-probabilities: sum(q * (log_q - log_p), axis).

    RSSM consistency term (Blueprint §3.2) and the EFE epistemic term
    (§3.6). Expects log_softmax outputs; q = exp(log_q) computed in f64.
    Free-bits clamping lives in stage4/world_model/loss.py, not here.

    Trace: SPEC §4.3; Blueprint §3.2, §3.6; config world_model.kl_free_bits.
    """
    raise NotImplementedError(
        "spec: elementwise q*(log_q - log_p) with q = exp(log_q) in f64; "
        "sum over axis; clamp tiny negative results to 0 (roundoff guard); "
        "backward: grad wrt log_q = q*(log_q - log_p) + q, wrt log_p = -q"
    )


def cross_entropy(logits: Tensor, targets: Tensor, axis: int = -1) -> Tensor:
    """Cross-entropy from raw logits and i64 class targets.

    Internally log_softmax(logits) then negative log-likelihood gather —
    never a separate softmax then log (docs/BACKEND.md §7). Feeds the
    self-model action-prediction loss and the ECE calibration pipeline
    (Blueprint §3.3).

    Args:
        logits: (..., classes) unnormalized scores.
        targets: (...,) i64 class indices.

    Returns:
        Scalar mean NLL (0-d tensor).

    Trace: SPEC §4.3; Blueprint §3.3; Eq #83-96.
    """
    raise NotImplementedError(
        "spec: fused log-softmax + gather NLL in f64; mean over batch; "
        "backward: (softmax - one_hot) / N scattered through axis"
    )
```

----------------------------------------

### File: `rng.py`

**Path:** `stage4/phitensor/rng.py`
**Extension:** `.py`
**Size:** 6,803 bytes (6.64 KB)

```py
"""phitensor.rng — deterministic random generation with stream forking.

Determinism is a hard project requirement: config system.seed = 49 and
system.deterministic = True (audit #21/#22). Every stochastic subsystem
(policy Gumbel sampling, Eq #50; world-model posterior sampling, §3.2;
RND novelty predictors, §3.7; dropout on z) draws from a Generator whose
entire state is a stdlib `random.Random` seeded from the system seed, and
parallel subsystems draw from *forked* streams via `spawn(stream_name)`
so their draws are independent but reproducible.

Forking rule: spawn(s) derives a child seed as
    int.from_bytes(sha256(f"{self._seed}:{s}".encode()).digest()[:8], "big")
— deterministic across runs, platforms, and interpreter versions
(Python's hash() is NOT used; it is salted per process).

Fully implemented: Generator state, scalar samplers, choice, spawn.
NotImplementedError (skeleton): the Tensor-returning shape samplers,
which need phitensor.tensor.Tensor construction (docs/BACKEND.md §10).

Traceability:
  - SPEC §4.3 (pinned rng surface)
  - Audit #21/#22 (explicit seed + deterministic mode)
  - config system.seed / system.deterministic
  - Blueprint §3.5/Eq #50 (Gumbel-max action sampling)
"""

from __future__ import annotations

import hashlib
import math
import random
from typing import Any, Sequence, Tuple

from phitensor.tensor import Tensor

__all__ = ["Generator"]


def _fork_seed(parent_seed: int, stream: str) -> int:
    """Derive a deterministic child seed from (parent_seed, stream name).

    SHA-256 based; independent of PYTHONHASHSEED. Fully implemented.

    Trace: Audit #21/#22; docs/BACKEND.md §10.
    """
    digest = hashlib.sha256(f"{parent_seed}:{stream}".encode("utf-8")).digest()
    return int.from_bytes(digest[:8], "big")


class Generator:
    """Deterministic pseudo-random generator with named stream forks.

    Args:
        seed: Root seed; the system passes config system.seed (49).

    Streams: `spawn("policy")`, `spawn("world_model")`, ... give each
    subsystem an independent reproducible stream. Spawning never mutates
    the parent stream's state, so draw order in one subsystem cannot
    perturb another — a determinism property the eval harness (Blueprint
    Part 5) relies on for bit-exact reruns.

    Trace: SPEC §4.3; Audit #21/#22; config system.seed.
    """

    def __init__(self, seed: int = 49) -> None:
        """Create a generator from an integer seed.

        Trace: SPEC §4.3; config system.seed=49.
        """
        self._seed: int = seed
        self._stream: str = ""
        self._rng = random.Random(seed)

    # -- forking (fully implemented) ---------------------------------------

    def spawn(self, stream: str) -> "Generator":
        """Return an independent child generator for a named stream.

        Args:
            stream: Stream name, e.g. "policy", "world_model", "eval".

        Returns:
            A Generator whose draws are deterministic given
            (self._seed, stream) and independent of this generator's
            remaining draws.

        Trace: SPEC §4.3; Audit #21/#22; docs/BACKEND.md §10.
        """
        child_seed = _fork_seed(self._seed, stream)
        child = Generator(child_seed)
        child._stream = stream
        return child

    @property
    def seed(self) -> int:
        """Root seed this generator (or its fork) derives from.

        Trace: Audit #21.
        """
        return self._seed

    @property
    def stream(self) -> str:
        """Stream name ("" for the root generator).

        Trace: Audit #21.
        """
        return self._stream

    # -- scalar samplers (fully implemented; pure stdlib) -------------------

    def _uniform_scalar(self, lo: float, hi: float) -> float:
        """One U[lo, hi) draw.

        Trace: SPEC §4.3.
        """
        return self._rng.uniform(lo, hi)

    def _normal_scalar(self, mean: float, std: float) -> float:
        """One N(mean, std^2) draw (Box-Muller via random.gauss).

        Trace: SPEC §4.3; Blueprint §3.2 (posterior sampling).
        """
        return self._rng.gauss(mean, std)

    def _gumbel_scalar(self) -> float:
        """One standard Gumbel draw: -log(-log(U)), U clamped off 0/1.

        Trace: SPEC §4.3; Blueprint §3.5/Eq #50 (Gumbel-max sampling).
        """
        u = self._rng.random()
        u = min(max(u, 1e-300), 1.0 - 1e-16)
        return -math.log(-math.log(u))

    # -- tensor samplers (skeleton; need Tensor construction) ----------------

    def normal(
        self, mean: float, std: float, shape: Tuple[int, ...]
    ) -> Tensor:
        """i.i.d. normal tensor of the given shape, f32.

        Draw order is C-order (index (0,...,0) first) so results are
        reproducible regardless of downstream threading (audit #22).

        Trace: SPEC §4.3; Blueprint §3.2 (posterior z ~ q_phi);
        docs/BACKEND.md §10.
        """
        raise NotImplementedError(
            "spec: draw numel(shape) values via _normal_scalar in C-order, "
            "pack into a contiguous f32 arena buffer, wrap as Tensor"
        )

    def uniform(self, lo: float, hi: float, shape: Tuple[int, ...]) -> Tensor:
        """i.i.d. uniform tensor of the given shape, f32.

        Trace: SPEC §4.3; Blueprint §3.7 (RND predictor init).
        """
        raise NotImplementedError(
            "spec: draw numel(shape) values via _uniform_scalar in C-order, "
            "pack contiguous f32, wrap as Tensor"
        )

    def gumbel(self, shape: Tuple[int, ...]) -> Tensor:
        """i.i.d. standard Gumbel tensor for Gumbel-max action sampling.

        Blueprint Eq #50: a = argmax(logit + gumbel_temperature * g).
        Temperature scaling lives in stage4/policy/selection.py; this
        method always returns unit-Gumbel noise.

        Trace: SPEC §4.3; Blueprint §3.5; Eq #50;
        config policy.gumbel_temperature.
        """
        raise NotImplementedError(
            "spec: draw numel(shape) values via _gumbel_scalar in C-order, "
            "pack contiguous f32, wrap as Tensor"
        )

    def choice(self, items: Sequence[Any]) -> Any:
        """Uniform-random choice from a non-empty sequence.

        Fully implemented (pure stdlib). Deterministic given the stream.

        Trace: SPEC §4.3; Blueprint §3.5 (option selection);
        GhostMesh mesh archetype sampling.
        """
        if len(items) == 0:
            raise ValueError("choice from an empty sequence")
        return items[self._rng.randrange(len(items))]

    def shuffle(self, items: list[Any]) -> None:
        """In-place Fisher-Yates shuffle of a list (deterministic).

        Trace: SPEC §4.3; eval held-out task ordering (Blueprint Part 5).
        """
        self._rng.shuffle(items)
```

----------------------------------------

### File: `tensor.py`

**Path:** `stage4/phitensor/tensor.py`
**Extension:** `.py`
**Size:** 19,105 bytes (18.66 KB)

```py
"""phitensor.tensor — core dense tensor type, dtype policy, and device model.

This module defines the memory and metadata contract of the whole Stage 4
compute backend. phitensor is a tailored, pure-stdlib re-creation of the
numpy/PyTorch core that this project actually needs — nothing more. The
design goal is the "99.9% efficiency" mandate: every tensor is a single
contiguous C-order buffer, every view is zero-copy stride algebra, and the
dtype policy is f32 storage with f64 accumulation everywhere it matters
(softmax denominators, KL, cross-entropy, ECE bins, Fisher diagonals).

Layout and efficiency architecture are specified in docs/BACKEND.md.

Traceability:
  - Blueprint Part 7.1  : compute profile this backend must serve
  - config keys         : backend.dtype, backend.device, backend.zero_copy_views
  - Audit #21/#22       : dtype/determinism policy hooks (see phitensor.rng)
  - SPEC §4.3           : pinned public API surface (implemented exactly)
"""

from __future__ import annotations

import math
from enum import Enum
from typing import Any, Iterator, Optional, Tuple, Union
from collections.abc import Sequence

__all__ = [
    "DType",
    "Device",
    "Tensor",
    "broadcast_shapes",
    "c_order_strides",
    "numel",
    "normalize_axis",
    "infer_shape",
]


class DType(Enum):
    """Supported scalar dtypes.

    Deliberately minimal: the project profile (RSSM latents, attention,
    EFE scoring, ECE binning) needs only f32 compute, f64 accumulation,
    i64 indices/targets, and bool8 masks. Fewer dtypes means a smaller
    dispatch matrix, a smaller fusion registry, and no silent upcasting
    bugs (docs/BACKEND.md §7).

    Members
    -------
    f32 : float32 — default storage dtype (config backend.dtype = "f32").
    f64 : float64 — accumulation / numerically-sensitive reductions.
    i64 : int64 — indices, class targets, counts.
    bool8 : 1-byte boolean — attention masks, bin masks.

    Trace: SPEC §4.3; config backend.dtype; docs/BACKEND.md §7.
    """

    f32 = "f32"
    f64 = "f64"
    i64 = "i64"
    bool8 = "bool8"

    @property
    def itemsize(self) -> int:
        """Size of one element in bytes.

        Trace: SPEC §4.3; docs/BACKEND.md §1 (memory layout).
        """
        return _DTYPE_ITEMSIZE[self]

    @property
    def struct_format(self) -> str:
        """`struct`/`array` type code used for binary (de)serialization.

        Trace: phitensor.io .ptx format; docs/BACKEND.md §8.
        """
        return _DTYPE_STRUCT_FORMAT[self]

    @property
    def is_float(self) -> bool:
        """True for f32/f64 (gradients only exist for float dtypes).

        Trace: SPEC §4.3; phitensor/autograd.py.
        """
        return self in (DType.f32, DType.f64)


_DTYPE_ITEMSIZE = {
    DType.f32: 4,
    DType.f64: 8,
    DType.i64: 8,
    DType.bool8: 1,
}

_DTYPE_STRUCT_FORMAT = {
    DType.f32: "f",
    DType.f64: "d",
    DType.i64: "q",
    DType.bool8: "?",
}


class Device(Enum):
    """Compute device model.

    CPU-only in the skeleton. The enum is a deliberate extension point:
    the layout, arena, and kernel-fusion designs in docs/BACKEND.md are
    device-portable, but the pinned contract (SPEC §4.3) exposes only CPU.

    Trace: SPEC §4.3; config backend.device.
    """

    CPU = "cpu"


# ---------------------------------------------------------------------------
# Pure-stdlib shape/stride utilities (fully implemented — no buffer needed).
# ---------------------------------------------------------------------------


def numel(shape: Sequence[int]) -> int:
    """Number of elements in a tensor of the given shape.

    Args:
        shape: Dimension sizes; `()` is the scalar shape (numel 1).

    Returns:
        Product of dimension sizes (0 if any dimension is 0).

    Trace: SPEC §4.3; docs/BACKEND.md §1.
    """
    return math.prod(shape)


def c_order_strides(shape: Sequence[int]) -> Tuple[int, ...]:
    """Row-major (C-order) strides, in elements, for a contiguous buffer.

    Example: shape (2, 3, 4) -> strides (12, 4, 1).

    Trace: docs/BACKEND.md §1 (contiguous C-order buffer contract).
    """
    strides: list[int] = []
    acc = 1
    for dim in reversed(shape):
        strides.append(acc)
        acc *= dim
    return tuple(reversed(strides))


def normalize_axis(axis: int, ndim: int) -> int:
    """Normalize a possibly-negative axis index into [0, ndim).

    Raises:
        IndexError: If the axis is out of range for `ndim`.

    Trace: SPEC §4.3 (mean/sum axis semantics).
    """
    if ndim == 0:
        raise IndexError("axis out of range for 0-d tensor")
    ax = axis + ndim if axis < 0 else axis
    if not 0 <= ax < ndim:
        raise IndexError(f"axis {axis} out of range for ndim {ndim}")
    return ax


def broadcast_shapes(a: Sequence[int], b: Sequence[int]) -> Tuple[int, ...]:
    """NumPy-style broadcasting of two shapes.

    Args:
        a, b: Operand shapes.

    Returns:
        The broadcast result shape.

    Raises:
        ValueError: If the shapes are not broadcast-compatible.

    Trace: SPEC §4.3 (arithmetic dunders broadcast); docs/BACKEND.md §1.
    """
    out: list[int] = []
    for da, db in zip(reversed(a), reversed(b)):
        if da == 1:
            out.append(db)
        elif db == 1 or da == db:
            out.append(da)
        else:
            raise ValueError(f"shapes {tuple(a)} and {tuple(b)} not broadcastable")
    longer = a if len(a) > len(b) else b
    out.extend(reversed(longer[: abs(len(a) - len(b))]))
    return tuple(reversed(out))


def infer_shape(data: Any) -> Tuple[int, ...]:
    """Infer the shape of nested list/tuple data, verifying rectangularity.

    Args:
        data: Scalar or nested sequences of scalars.

    Returns:
        The inferred shape tuple (`()` for a scalar).

    Raises:
        TypeError: If a leaf is not an int/float/bool.
        ValueError: If the nesting is ragged.

    Trace: SPEC §4.3 (Tensor.__init__ data contract).
    """
    if isinstance(data, (list, tuple)):
        if len(data) == 0:
            return (0,)
        first = infer_shape(data[0])
        for item in data[1:]:
            if infer_shape(item) != first:
                raise ValueError("ragged nested data is not a tensor")
        return (len(data),) + first
    if isinstance(data, (int, float, bool)):
        return ()
    raise TypeError(f"unsupported leaf type for Tensor data: {type(data).__name__}")


# ---------------------------------------------------------------------------
# Tensor
# ---------------------------------------------------------------------------

Scalar = Union[int, float, bool]


class Tensor:
    """Dense N-dimensional tensor on a contiguous C-order buffer.

    Contract (SPEC §4.3, docs/BACKEND.md):

    - **Storage**: exactly one contiguous C-order buffer per allocation;
      views share the buffer and differ only in (shape, strides, offset).
    - **Views**: `reshape`, `T`, slicing and transpose are zero-copy when
      `backend.zero_copy_views` is enabled (the default).
    - **Dtype policy**: storage defaults to f32; reductions that feed
      probabilities (softmax, KL, cross-entropy, ECE) accumulate in f64
      (`accumulate_dtype`).
    - **Autograd**: when `requires_grad` is True the tensor is a node in
      the reverse-mode graph; `grad_fn` references the producing op and
      `_ctx` stores saved tensors for the backward pass. Graph node refs
      are metadata only until phitensor.autograd executes them.

    SKELETON: all compute bodies raise NotImplementedError with a precise
    "spec:" payload describing the required implementation. Only pure
    metadata/shape utilities in this module are executable today.

    Trace: SPEC §4.3; Blueprint §3.2 (RSSM tensors), §3.1 (attention
    shapes); config backend.dtype/backend.zero_copy_views.
    """

    # -- construction ------------------------------------------------------

    def __init__(
        self,
        data: Any,
        dtype: DType = DType.f32,
        device: Device = Device.CPU,
        requires_grad: bool = False,
    ) -> None:
        """Create a tensor from nested sequences, a buffer, or a scalar.

        Args:
            data: Nested list/tuple of scalars, a flat buffer plus explicit
                shape (internal path), or another Tensor (copy-construct).
            dtype: Storage dtype; default f32 (config backend.dtype).
            device: Device.CPU only (SPEC §4.3).
            requires_grad: If True, record ops for reverse-mode autodiff.

        Raises:
            NotImplementedError: skeleton — see spec payload.

        Trace: SPEC §4.3; docs/BACKEND.md §1, §2 (arena allocation).
        """
        raise NotImplementedError(
            "spec: validate dtype/device; infer_shape(data); allocate one "
            "contiguous C-order buffer of numel(shape) * dtype.itemsize bytes "
            "from the thread-local arena; cast leaves to dtype; initialize "
            "grad=None, grad_fn=None, _ctx=None; requires_grad only legal "
            "for float dtypes"
        )

    # -- pinned metadata properties ----------------------------------------

    @property
    def shape(self) -> Tuple[int, ...]:
        """Dimension sizes of the tensor.

        Trace: SPEC §4.3.
        """
        raise NotImplementedError("spec: return self._shape tuple")

    @property
    def dtype(self) -> DType:
        """Storage dtype.

        Trace: SPEC §4.3.
        """
        raise NotImplementedError("spec: return self._dtype")

    @property
    def device(self) -> Device:
        """Resident device (CPU only).

        Trace: SPEC §4.3.
        """
        raise NotImplementedError("spec: return self._device")

    @property
    def strides(self) -> Tuple[int, ...]:
        """Element strides; equal to c_order_strides(shape) iff contiguous.

        Views may carry non-monotonic strides (e.g. transpose). All kernels
        must either accept arbitrary strides or materialize a contiguous
        copy first (docs/BACKEND.md §1).

        Trace: docs/BACKEND.md §1 (stride algebra, zero-copy views).
        """
        raise NotImplementedError("spec: return self._strides")

    @property
    def offset(self) -> int:
        """Element offset of element (0,...,0) inside the shared buffer.

        Trace: docs/BACKEND.md §1 (zero-copy view contract).
        """
        raise NotImplementedError("spec: return self._offset")

    @property
    def is_contiguous(self) -> bool:
        """True iff strides equal c_order_strides(shape) (offset irrelevant).

        Trace: docs/BACKEND.md §1.
        """
        raise NotImplementedError(
            "spec: return self.strides == c_order_strides(self.shape)"
        )

    @property
    def ndim(self) -> int:
        """Number of dimensions.

        Trace: SPEC §4.3.
        """
        raise NotImplementedError("spec: return len(self._shape)")

    @property
    def accumulate_dtype(self) -> DType:
        """Dtype used for internal accumulation of reductions on this tensor.

        Policy: f32 storage accumulates in f64; f64 stays f64; non-float
        dtypes accumulate in i64. This is the backbone of the numerics
        guarantee for softmax/KL/ECE (docs/BACKEND.md §7).

        Trace: docs/BACKEND.md §7 (dtype/accumulation policy); Blueprint
        §3.3 (ECE must be measured, not asserted — needs exact reductions).
        """
        raise NotImplementedError(
            "spec: f32 -> f64, f64 -> f64, i64 -> i64, bool8 -> i64"
        )

    # -- autograd metadata -------------------------------------------------

    @property
    def requires_grad(self) -> bool:
        """Whether ops on this tensor are recorded in the autograd graph.

        Trace: SPEC §4.3; phitensor/autograd.py.
        """
        raise NotImplementedError("spec: return self._requires_grad")

    @property
    def grad(self) -> Optional["Tensor"]:
        """Accumulated gradient (same shape/dtype) or None before backward.

        Trace: SPEC §4.3; phitensor/autograd.py backward().
        """
        raise NotImplementedError("spec: return self._grad")

    @property
    def grad_fn(self) -> Optional[str]:
        """Name of the producing op (e.g. 'matmul', 'softmax') or None for
        leaf tensors. Together with `_ctx` this forms the graph node refs.

        Trace: SPEC §4.3 (graph node refs); phitensor/autograd.py.
        """
        raise NotImplementedError("spec: return self._grad_fn")

    # -- shape manipulation (zero-copy) ------------------------------------

    @property
    def T(self) -> "Tensor":
        """Transposed view (all axes reversed); zero-copy.

        Trace: SPEC §4.3; docs/BACKEND.md §1.
        """
        raise NotImplementedError(
            "spec: return view with reversed shape/strides, same buffer, "
            "same offset; set grad_fn='transpose' when requires_grad"
        )

    def reshape(self, *shape: int) -> "Tensor":
        """Return a view with the given shape; zero-copy iff contiguous.

        One dimension may be -1 (inferred). If the tensor is a non-
        contiguous view, materialize a contiguous copy first and document
        the allocation (docs/BACKEND.md §1).

        Trace: SPEC §4.3; config backend.zero_copy_views.
        """
        raise NotImplementedError(
            "spec: resolve -1 via numel; if contiguous return view with new "
            "shape and c_order_strides; else copy into a fresh arena buffer; "
            "preserve dtype/device/requires_grad; grad_fn='reshape'"
        )

    # -- reductions --------------------------------------------------------

    def mean(self, axis: Optional[int] = None) -> "Tensor":
        """Mean over `axis` (None = all axes), accumulating in f64.

        Returns a 0-d tensor when axis is None. Backward divides the
        upstream gradient by the reduced element count.

        Trace: SPEC §4.3; docs/BACKEND.md §7 (f64 accumulation).
        """
        raise NotImplementedError(
            "spec: normalize_axis; pairwise-sum reduction in f64 accumulators "
            "over cache-blocked tiles; divide by reduced count; grad_fn='mean'"
        )

    def sum(self, axis: Optional[int] = None) -> "Tensor":
        """Sum over `axis` (None = all axes), accumulating in f64.

        Trace: SPEC §4.3; docs/BACKEND.md §7.
        """
        raise NotImplementedError(
            "spec: normalize_axis; pairwise-sum in f64 accumulators over "
            "cache-blocked tiles; grad_fn='sum'"
        )

    # -- interop -----------------------------------------------------------

    def numpy_view(self) -> memoryview:
        """Zero-copy view of the underlying buffer as a memoryview.

        This is the numpy-free interop path: callers get a PEP 3118
        buffer with correct shape/strides/format and may wrap it with any
        buffer-protocol consumer. No numpy dependency anywhere (SPEC §2).

        Trace: SPEC §4.3; docs/BACKEND.md §8 (zero-copy interop).
        """
        raise NotImplementedError(
            "spec: return memoryview of the shared buffer sliced at "
            "[offset*itemsize : (offset+numel)*itemsize], cast to the dtype "
            "struct_format code; only valid for contiguous tensors"
        )

    def tolist(self) -> Any:
        """Materialize nested Python lists (host copy; used by io/tests).

        Trace: phitensor/io.py JSON sidecar; tests.
        """
        raise NotImplementedError(
            "spec: walk shape/strides, gather scalars, build nested lists"
        )

    def __iter__(self) -> Iterator["Tensor"]:
        """Iterate over axis-0 slices (views).

        Trace: SPEC §4.3.
        """
        raise NotImplementedError("spec: yield zero-copy axis-0 views")

    def __len__(self) -> int:
        """Size of axis 0.

        Trace: SPEC §4.3.
        """
        raise NotImplementedError("spec: return self._shape[0]; error on 0-d")

    # -- arithmetic dunders (pinned set, SPEC §4.3) --------------------------

    def __add__(self, other: Union["Tensor", Scalar]) -> "Tensor":
        """Elementwise add with broadcasting; grad_fn='add'.

        Trace: SPEC §4.3.
        """
        raise NotImplementedError(
            "spec: broadcast_shapes; vectorized elementwise kernel over the "
            "contiguous fast axis; scalar fast path without dispatch; "
            "backward: sum-reduce grad over broadcast axes"
        )

    def __sub__(self, other: Union["Tensor", Scalar]) -> "Tensor":
        """Elementwise subtract with broadcasting; grad_fn='sub'.

        Trace: SPEC §4.3.
        """
        raise NotImplementedError(
            "spec: as __add__ with negated rhs kernel; backward: negate rhs grad"
        )

    def __mul__(self, other: Union["Tensor", Scalar]) -> "Tensor":
        """Elementwise multiply with broadcasting; grad_fn='mul'.

        Trace: SPEC §4.3.
        """
        raise NotImplementedError(
            "spec: broadcast elementwise multiply; backward: grad*other for "
            "each operand (other detached)"
        )

    def __matmul__(self, other: "Tensor") -> "Tensor":
        """Matrix multiply; delegates to phitensor.ops.matmul.

        Trace: SPEC §4.3; docs/BACKEND.md §3 (cache-blocked GEMM).
        """
        raise NotImplementedError(
            "spec: delegate to phitensor.ops.matmul(self, other)"
        )

    def __neg__(self) -> "Tensor":
        """Elementwise negation; grad_fn='neg'.

        Trace: SPEC §4.3.
        """
        raise NotImplementedError("spec: vectorized negate; backward: -grad")

    def __truediv__(self, other: Union["Tensor", Scalar]) -> "Tensor":
        """Elementwise true division with broadcasting; grad_fn='div'.

        Trace: SPEC §4.3.
        """
        raise NotImplementedError(
            "spec: broadcast divide; scalar rhs uses multiply-by-reciprocal "
            "fast path; backward: grad/other and -grad*self/other^2"
        )

    # -- in-place mutation (needed by optimizers / tanh_) --------------------

    def copy_(self, other: "Tensor") -> "Tensor":
        """In-place copy of `other` into self (same numel); autograd-safe
        (not recorded). Used by Optimizer.step() parameter updates.

        Trace: phitensor/autograd.py Optimizer.step.
        """
        raise NotImplementedError(
            "spec: require numel equality; contiguous memcpy fast path when "
            "both contiguous, else strided element copy"
        )

    def zero_grad(self) -> None:
        """Reset self._grad to None (Optimizer.zero_grad hook).

        Trace: phitensor/autograd.py.
        """
        raise NotImplementedError("spec: set self._grad = None")

    def __repr__(self) -> str:
        """Short debug repr: shape, dtype, device, requires_grad.

        Trace: SPEC §2 (developer ergonomics).
        """
        raise NotImplementedError(
            "spec: f'Tensor(shape={...}, dtype={...}, device={...}, "
            "requires_grad={...})'"
        )
```

----------------------------------------

#### Directory: `stage4/phitensor/__pycache__`
