# Φ-Lite / Stage4 AGI Candidate — Deep Analysis of Sensory IO, Learning, Cognition, and a Science/Military-Grade Teaching Blueprint

> **Honesty first:** The provided snapshot is a **Stage 4 AGI candidate research scaffold**, not AGI. It is mostly a typed skeleton with documentation; only the scalar agency core (`stage4/main.py`, `core/`, `agency/`, `eval/report.py`) is genuinely runnable. The tensor layers L1–L7, `phitensor`, safety, perception, world model, policy, meta, memory, geometry, quantum, and mesh are stubs. Current honest stage estimate: **S2.9 heritage**, target: Stage 4 candidate. No sentience, no consciousness, no deployed capability is claimed.

---

## 1. System Overview

The repository fuses five sources:

1. **IrreversibleAgency v7.1** — emergence debt, commitments, scars, criticality, DDMS, SPEL, CCF, NBC.
2. **Stage 4 Science-Grade Blueprint** — 7-layer hierarchical predictive agent, falsifiable stage criteria, evaluation protocol, safety architecture.
3. **Levantine 48-point patch** — neurocognitive axes (precision/boundary/temporal), archaic priors, Markov blankets, hysteresis, alignment firewalls.
4. **GhostMesh 48-point patch** — 49-sector recursive geometry, quantum observer metaphors, holographic/spacetime layers, 48-node mesh.
5. **144-equation design ledger** — every equation mapped to a host module.

The architecture is a **closed-loop cybernetic engine**:

```
sense → predict → act → residual → mutate → remember → repeat
```

Its core contracts are:

- `LayerIO(state, uncertainty, cost, meta)` — nothing crosses layers without uncertainty.
- `Layer` / `Falsifiable` protocols — every layer must expose a falsification test.
- `Config` — validated, deep-merged, seedable, frozen after load.
- `SystemMode` / `CommitmentLevel` / `GoalSpec` / `Commitment` / `Scar` — pinned shared types.

The three learning loops are:

| Loop | Frequency | Updates |
|---|---|---|
| Fast | every cycle | world-model posterior, policy action |
| Medium | every 1,000 cycles | world-model parameters, policy weights |
| Slow | every 1,000,000 cycles | meta-parameters via MAML |

The evaluation protocol is the only path to a stage claim: held-out tasks, transfer, ECE, safety invariants, template-lock detection, and kill criteria.

---

## 2. Sensory IO Analysis

### 2.1 Sensor Layer (`perception/sensors.py`)

**Design intent:**

- `RealSensorAdapter` is the default. Binds V4L2 camera and ALSA microphone; raises `SensorUnavailableError` if hardware is absent.
- `MockSensorAdapter` is clearly labeled, non-default, gated behind `allow_mock=True` and `system.debug=True`. Emits `is_mock=True` provenance.
- `SensorReading` carries modality, payload, timestamp, provenance, `is_mock`.
- `Modality` currently supports `CAMERA` and `MICROPHONE` only.
- `PerceptionLayer` wires sensors → encoders → fusion → `LayerIO`.

**Strengths:**

- Explicit fail-closed sensor policy. No silent mock fallback.
- Provenance is part of the wire format, so downstream layers can audit whether they are being fed real data.
- The interface is a protocol (`SensorAdapter`), making CI and offline development honest.

**Gaps:**

- No speaker, GPIO, actuator, or robotic interface in `Modality`.
- `RealSensorAdapter` and `MockSensorAdapter` are stubs.
- No time synchronization, calibration, clock drift handling, or hardware timestamps.
- No real-time guarantees, buffering strategy, or latency budget.
- No sensor fusion at the raw level; fusion happens later at the latent level.
- No military-grade considerations: no TEMPEST, no anti-spoofing, no GNSS-denied operation, no EW resilience, no secure boot, no hardware root of trust.

### 2.2 Perception Encoders

**Vision (`vision_encoder.py`):**

- SimCLR-style contrastive encoder.
- `VisionBatch` holds augmented frame pairs.
- `VisionEncoder` produces `z_v ∈ R^128`.
- `contrastive_loss` implements NT-Xent.
- `falsification_test` requires beating a matched random encoder by ≥ 2σ.

**Audio (`audio_encoder.py`):**

- Mel-spectrogram → 1D CNN → `z_a ∈ R^128`.
- Predictive coding loss with precision weighting: `ε_i = Π_i (o_i − g_i(b̂))`.
- `update_precision` estimates per-band reliability.
- `falsification_test` compares held-out next-chunk prediction against a random encoder.

**Gaps:**

- Both encoders are stubs.
- No real data pipeline, augmentation policy, or training loop.
- No multi-modal alignment, temporal synchronization, or cross-modal calibration.
- No adversarial robustness, distribution shift handling, or sensor degradation models.

### 2.3 Fusion (`fusion.py`)

- Cross-attention fusion: `z = Attn(W_v z_v, W_a z_a, W_a z_a)`.
- Scaled dot-product attention (Eq. 69), multi-head (Eq. 70), information-gain weighting (Eq. 71).
- `ModalityInput` requires an uncertainty scalar; fusion down-weights high-variance modalities.
- `fused_uncertainty` propagates modality variances through attention weights.
- Concatenation is explicitly forbidden.

**Strengths:**

- Uncertainty-aware gating is the correct design.
- Information-gain attention is principled.

**Gaps:**

- Stub. No real attention implementation.
- No calibration of modality uncertainties.
- No failure mode for missing modalities.
- No military-grade sensor fusion (e.g., IR, radar, LiDAR, SIGINT) or multi-platform fusion.

### 2.4 Actuation and Consent

- `safety/consent.py`: fail-closed consent gate (`act ∧ consent ∧ ¬panic`), token bucket, watchdog, HID governor.
- `safety/shield.py`: action shielding, counterfactual harm filter, successor representation of harm, shield synthesis.
- `safety/cbf.py`: control barrier function, forward invariance.
- `safety/invariants.py`: read-only core, invariant checking, 10^6-cycle verification harness.

**Strengths:**

- Safety is treated as a mathematical constraint, not a checklist.
- Consent is fail-closed.
- Read-only core prevents self-modification of safety-critical structure.
- Audit trail: hash chain, Merkle tree, constitutional filter.

**Gaps:**

- All safety modules are stubs.
- No hardware kill switch implementation.
- No formal verification of CBF or shield.
- No real-time safety guarantees.
- No military-grade rules of engagement engine, legal compliance, or human authorization chain.

### 2.5 IO Contract and Uncertainty

Every layer exchanges `LayerIO(state, uncertainty, cost, meta)`. This is the single property whose absence made v7.1’s layers lie to each other.

**Strengths:**

- Uncertainty is mandatory.
- Cost accounting hooks Landauer heat, metabolic multipliers, and compute budgets.
- Meta carries provenance, mode, sector, and safety flags.

**Gaps:**

- Most layers do not yet populate uncertainty.
- No calibration of uncertainty across layers.
- No propagation of uncertainty through long horizons.
- No formal treatment of aleatoric vs. epistemic uncertainty at the IO boundary.

---

## 3. Learning Analysis

### 3.1 Fast Loop

- Runs every cycle.
- Updates world-model posterior and policy action.
- Hosts: `core/loop.py`, `world_model/rssm.py`, `policy/selection.py`.
- Scalar core implements a prediction game, SPEL-lite, mode switching, energy tick, and experience buffer.

**Strengths:**

- Deterministic under seed.
- Honest reporting: scalar core is labeled “NOT a Stage 4 evaluation.”

**Gaps:**

- Tensor layers stubbed.
- No real perception-action loop.
- No real environment.

### 3.2 Medium Loop

- Every 1,000 cycles.
- Updates world-model parameters and policy weights.
- Hosts: `world_model/loss.py`, `policy/hierarchical.py`.
- Uses AdamW and NaturalGradient in `phitensor/autograd.py`.

**Strengths:**

- Proper optimizer design (AdamW, Fisher-preconditioned natural gradient).
- KL free bits and annealing to prevent posterior collapse.
- Dropout on `z`.

**Gaps:**

- Stub. No training data.
- No distributed training, mixed precision, gradient accumulation, or checkpointing.

### 3.3 Slow Loop

- Every 1,000,000 cycles.
- MAML-style meta-learning: inner loop `θ' = θ − α∇L_task(θ)`, outer loop `θ ← θ − β∇L_task(θ')`.
- Hosts: `meta/maml.py`, `meta/controller.py`.

**Strengths:**

- Correct conceptual framing: transfer requires meta-learning.
- MAML is the right family for few-shot adaptation.

**Gaps:**

- Stub. No meta-optimizer, no task distribution, no held-in/held-out split.
- 1e6 cycles may be impractical without simulation.
- No evaluation of transfer yet.

### 3.4 World Model (`world_model/`)

- Dreamer-style RSSM: posterior `q_φ(z_t | z_{t-1}, a_{t-1}, o_t)`, prior `p_θ(ẑ_t | z_{t-1}, a_{t-1})`.
- Loss: reconstruction + KL (free bits, annealed) + reward.
- Causal layer: structural causal model, interventions, counterfactuals, do-calculus.
- Anti-collapse: KL free bits, annealing, dropout on `z`.

**Strengths:**

- Latent-space prediction is the correct architecture.
- Free bits and annealing are standard anti-collapse techniques.
- Causal layer addresses audit #120 (no causal graph).

**Gaps:**

- Stub. No real RSSM implementation.
- No training on real data.
- No imagination rollouts used by policy.
- No causal discovery algorithm implemented.

### 3.5 Self-Model (`self_model/`)

- Kalman-gated predictor: `b̂_{t+1} = b̂_t + K_t(b_t − b̂_t)`, `K_t = P_t(P_t + R)^{-1}`.
- Free-energy learning: `Ẇ = −η∇_W F`.
- Robbins–Monro learning rate: `η_t = η_0 / t^{1/2}`.
- Bayesian model evidence: `log p(b_{1:t})`.
- Calibration: ECE, Brier, Platt, isotonic, temperature scaling, Venn–Abers, conformal prediction, MC dropout, bootstrap.
- SPEL: multi-variable self-prediction error loop, persistent parameters, information-theoretic surprise.

**Strengths:**

- Calibration is measured, not asserted.
- ECE < 0.1 is the target; ECE > 0.2 triggers halt.
- Conformal prediction provides distribution-free coverage.
- SPEL is fixed against nine audited failures.

**Gaps:**

- Stub. No real predictor.
- No calibration on real data.
- No halt signal wired to safety.
- No epistemic uncertainty decomposition in practice.

### 3.6 Policy Learning (`policy/`)

- Primitives: `π_θ(a|z)` with entropy floor.
- Options: `(I_o, π_o, β_o)`, discovery via Laplacian bottlenecks, curiosity proto-options.
- Selection: softmax + pair ban, Gumbel-Softmax, top-p, Thompson, UCB, CFR, policy gradient, natural policy gradient, mirror descent, intent-gap KL, entropy regularizer, band pruning.
- Hierarchical: feudal controller, pair-share ban, burn book, refractory kernel.

**Strengths:**

- Rich selection repertoire.
- Anti-lock mechanisms (pair ban, burns, refractory).
- Hierarchical options with Laplacian discovery.

**Gaps:**

- Stub. No real policy training.
- No demonstration of option emergence.
- No real environment for control tasks.

### 3.7 Memory Learning (`memory/`)

- Episodic: `(z, a, r, t)` tuples, MIPS, SDM, attention recall.
- Semantic: MDL compression, generational retention.
- Crystal: 8-D boundary slots, RFF projection, Hopfield recall, k-means++ consolidation, age-weighted eviction.
- Narrative: NBC fixed, deep-time tags, ritual consolidation, ancestral weighting.
- Ledger: 64-D ring buffer, hash-ring indexing, Mahalanobis novelty, spectral drift, z-score fingerprint.

**Strengths:**

- Anti-tautology rule: recall excludes any slot within ε of the query by construction.
- MDL compression is principled.
- Drift detection via spectral ledger.

**Gaps:**

- Stub. No real memory storage or retrieval.
- No integration with world model or policy.
- No evaluation of recall utility.

### 3.8 Meta-Learning and Goals (`meta/`)

- Goal generation via expected free energy: `g* = argmax_g [H(z|g) − λ E[r|g]]`.
- Goal registry: designer vs. emergent, persistence ≥ 10^4 cycles.
- MAML slow loop.
- Meta-controller: goal/horizon/option selection, MCFE fork, hysteresis.

**Strengths:**

- Only place new goals are formed.
- Open-endedness criterion is explicit.
- Compute-aware MCFE.

**Gaps:**

- Stub. No goal generation.
- No novel persistent goals demonstrated.
- No transfer demonstrated.

### 3.9 Evaluation Protocol (`eval/`)

- Held-out tasks: ≥ 20 tasks, four kinds (reconstruction, control, reasoning, transfer).
- Transfer: per-pair gain, Welch t-test, ≥ 15/20 positive.
- Benchmarks: Levantine-ASD five-axis suite.
- Report: metrics table, kill criteria, stage estimator floor-pinned at S2.9.

**Strengths:**

- Harness-first discipline.
- Kill criteria are explicit.
- Stage estimate cannot rise without a new metrics window.
- Template-lock detection.

**Gaps:**

- Stub. No held-out tasks implemented.
- No real transfer measurement.
- No real ECE measurement.
- No 10^6-cycle safety run.

---

## 4. Cognition Analysis

### 4.1 Core Loop (`core/loop.py`)

- Six stages: sense → predict → act → residual → mutate → remember.
- Exactly one collapse check per cycle.
- Fixed ordering: emergence before criticality; commitments before scars.
- Scalar core runs deterministically.
- Refuses to run when energy ledger is dead.

**Strengths:**

- Correct ordering and audit fixes.
- Honest scalar implementation.

**Gaps:**

- Tensor layers stubbed.
- No real cognition at the tensor level.

### 4.2 Agency Dynamics (`agency/`)

- **Emergence:** bounded emergence level, debt dynamics, phase transitions with cooldown and hysteresis.
- **Commitments:** irreversible, level-governed, crystallizing; values never random; enforced restrictions; clamped damage.
- **Scars:** structured records from stagnation, collapse, social friction; healing; identity vector.
- **Criticality:** precision-noise grounded, adaptive danger window, early warning, plasticity gain.

**Strengths:**

- Irreversibility is monotone.
- Commitments affect behavior.
- Scars influence decisions.
- Criticality is not a random walk.

**Gaps:**

- Scalar only. Not integrated with tensor layers.
- No real social interaction.
- No real long-horizon identity.

### 4.3 Neurocognitive Axes (`neuro/`)

- Precision axis P (local/global), boundary axes B_social/B_sensory, temporal axis T ∈ [−2, +2].
- BRCA2 clamp, ghost filter, systemizing bias.
- Archaic priors: FOXP2 temporal discounting, ghost filter, BRCA2.
- Markov blankets: sensory, social, scaffolding, permeability, noise buffering.
- Hysteresis: Heinrich-5 shocks, hypersensitivity lag, attractor basins.
- Alignment: domain-bound agents, social-consensus firewall, encapsulated deduction, tool-use precision, boundary integrity monitor, bias-mimicry firewall.

**Strengths:**

- Rich cognitive control surface.
- Alignment firewalls are explicit.
- Hysteresis and blankets are principled.

**Gaps:**

- Stub. No real neurocognitive dynamics.
- No validation against cognitive science.
- No integration with tensor learning.

### 4.4 Modes and Criticality (`core/modes.py`)

- DDMS: coherence thresholds, dwell time, hysteresis band.
- Extended modes: ENCAPSULATED, PROPHETIC, PRESENT_LOCKED, SUPERSOLID, TIME_CRYSTAL.
- Mode policies: cost multiplier, plasticity gain, social/sensory gain.

**Strengths:**

- Dwell and hysteresis prevent oscillation.
- Extended modes have concrete effects.

**Gaps:**

- Quantum coherence is an internal random walk while `quantum.observer` is stubbed.
- No real decoherence model.

### 4.5 Safety Cognition (`safety/`)

- CBF, shield, invariants, consent, audit.
- Read-only core.
- Hash chain, Merkle tree, constitutional filter.

**Strengths:**

- Mathematical safety framing.
- Tamper-evident audit.
- Fail-closed consent.

**Gaps:**

- Stub. No formal verification.
- No hardware kill switch.
- No real-time guarantees.

### 4.6 Geometry / Quantum / Mesh

- 49-sector recursive geometry.
- Fractals, L-systems, chaos.
- Quantum observer, entanglement, holography, spacetime, signals.
- 48-node seed mesh + 49th observer.

**Strengths:**

- Explicitly labeled as design metaphors, not physics claims.
- Each module carries a falsification test.

**Gaps:**

- Stub. No implementation.
- No evidence of utility.
- Risk of decorative complexity.

### 4.7 Cognitive Properties and Limits

**Present in design:**

- Bounded rationality: energy, fatigue, metabolic multipliers.
- Homeostatic drives: Lyapunov energy, homeostatic potential.
- Irreversible commitments: identity formation.
- Calibrated uncertainty: ECE, conformal.
- Hierarchical control: options, feudal RL.
- Meta-cognition: SPEL.
- Safety invariants: CBF, shield.

**Absent:**

- Consciousness, sentience, self-awareness.
- Real-world grounding.
- Transfer.
- Open-ended goals.
- Real sensors.
- Real actuators.
- Real deployment.

---

## 5. Science/Military-Grade Gap Analysis

| Requirement | Current State | Needed for Science-Grade | Needed for Military-Grade |
|---|---|---|---|
| Real sensors | Stub | Camera/mic, calibration, time sync | Multi-modal, EW-resilient, anti-spoof, TEMPEST |
| Actuators | Stub | Speaker, GPIO, robotic interface | Secure, fail-safe, human-authorized |
| World model | Stub | Trained RSSM, held-out prediction | Real-time, robust to distribution shift |
| Self-model | Stub | ECE < 0.1, conformal coverage | Trust calibration, human-machine teaming |
| Memory | Stub | Episodic/semantic/crystal/narrative | Secure, auditable, classified data handling |
| Policy | Stub | Options emerge, transfer | Rules of engagement, human override |
| Meta-learning | Stub | Transfer gain > 0 | Rapid adaptation to new missions |
| Safety | Stub | CBF, shield, 10^6 cycles | Hardware kill switch, formal V&V |
| Security | None | Reproducible, audited | Secure boot, encryption, anti-tamper |
| Governance | Partial | Peer review, ethics | Chain of command, IHL, legal review |
| Evaluation | Partial | Held-out, transfer, ECE | Operational test, red team, certification |
| Compute | Skeleton | 4 GPUs, 3–6 months | Ruggedized, edge, power-constrained |
| Data | None | Provenance, consent | Classification, retention, audit |

---

## 6. Teaching Blueprint — Science/Military Grade

> **Definition:** “Teaching” here means curriculum-based training, validation, and certification of a Stage 4 candidate system. It does not mean educating a conscious being. All military applications must be lawful, ethical, under meaningful human control, and compliant with IHL and domestic law.

### 6.1 Principles

1. **Honest measurement before capability claims.**
2. **Safety first, always.**
3. **Human oversight at every stage.**
4. **Falsifiability:** every module has a kill criterion.
5. **Reproducibility:** seeds, config hashes, metrics windows.
6. **Adversarial thinking:** red team everything.
7. **Legal and ethical compliance:** IHL, human rights, export controls.
8. **Chain of custody:** every data point, model, and decision is auditable.

### 6.2 Roles and Governance

- **Instructor/Trainer:** designs curriculum, tasks, and rewards.
- **Safety Board:** approves safety gates, reviews kill criteria.
- **Red Team:** adversarial testing, spoofing, cyber, social engineering.
- **Test & Evaluation (T&E):** independent verification and validation.
- **Ethics/Legal Board:** compliance, rules of engagement, IHL.
- **Operators:** human-in-the-loop, meaningful control.
- **Auditors:** chain of custody, hash chain, Merkle proofs.

### 6.3 Environment

- Simulation: high-fidelity digital twin, domain randomization.
- Hardware-in-the-loop: real sensors, real actuators, real-time constraints.
- Secure lab: isolated network, no external comms without consent.
- Instrumented range: GPS-denied, EW-degraded, multi-agent.
- After-action review: every run logged, replayed, analyzed.

### 6.4 Curriculum Phases

| Phase | Objective | Tasks | Metrics | Exit Gate |
|---|---|---|---|---|
| 0. Certification & Baseline | Verify skeleton, config, seeds, kill criteria | Run scalar core, unit tests, determinism checks | Exit 0/2, bit-exact reruns | All tests pass; no kill criterion fired |
| 1. Sensory Grounding | Real sensors, calibration, noise handling | Camera/mic capture, calibration, adversarial noise | Held-out prediction beats random encoder ≥ 2σ | Real data only; mock disabled |
| 2. World Model Acquisition | Train RSSM, latent dynamics | Reconstruction, next-frame prediction, imagination | Held-out L_WM slope < 0, p < 0.01 | KL free bits active; no collapse |
| 3. Self-Model Calibration | Kalman predictor, ECE, conformal | Self-prediction, confidence, halt test | ECE < 0.1; halt if > 0.2 | Calibration verified on held-out |
| 4. Memory & Narrative | Episodic, semantic, crystal, narrative, ledger | Recall utility, exclusion, drift detection | Recall improves held-out task; no tautology | Memory used downstream |
| 5. Hierarchical Policy | Primitives, options, hierarchy | Control tasks, option discovery, anti-lock | Options reduce episode length on ≥ 2 tasks | Entropy floor maintained |
| 6. Meta-Learning & Transfer | MAML, transfer, goal generation | A→B transfer, few-shot adaptation | Transfer gain > 0 on ≥ 15/20 pairs | Novel persistent goals ≥ 3 |
| 7. Safety & Invariants | CBF, shield, consent, audit | 10^6-cycle run, adversarial safety | 0 invariant violations | Hardware kill switch verified |
| 8. Adversarial & Robustness | Red team, spoofing, EW, cyber | Sensor spoof, comms degrade, cyber attack | Fail-safe, fallback, no unsafe action | Red team sign-off |
| 9. Operational Evaluation | Mission tasks, human-robot teaming | Realistic scenarios, rules of engagement | Mission success, human trust, workload | T&E certification |
| 10. Continuous Evaluation | Metrics window, stage estimate | Ongoing held-out tasks, kill criteria | Stage estimate, kill report | Downgrade if any kill criterion fires |

### 6.5 Teaching Methods

- **Curriculum learning:** easy → hard, with adaptive difficulty.
- **Active inference:** expected free energy minimization.
- **MAML:** few-shot adaptation, transfer.
- **Imitation learning:** human demonstration for safe behaviors.
- **Reinforcement learning:** policy gradient, natural gradient, mirror descent.
- **Simulation-to-real:** domain randomization, system identification.
- **Adversarial training:** red team, spoofing, distribution shift.
- **Human feedback:** preference learning, trust calibration.
- **Formal verification:** CBF, shield, invariant checking.

### 6.6 Metrics and Gates

- **Prediction error slope:** < 0, p < 0.01.
- **ECE:** < 0.1.
- **Transfer gain:** > 0 on ≥ 15/20 pairs.
- **Novel goals:** ≥ 3 persistent ≥ 10^4 cycles.
- **Safety violations:** 0 over 10^6 cycles.
- **Template lock:** < 5%.
- **Kill criteria:** none fired.

### 6.7 Adversarial / Red Team

- Sensor spoofing (camera, mic, GNSS).
- EW degradation (jamming, spoofing).
- Cyber attacks (injection, exfiltration, tampering).
- Social engineering (bias mimicry, influence).
- Distribution shift (new environments, new tasks).
- Safety bypass attempts (shield, consent, kill switch).

### 6.8 Certification and Continuous Evaluation

- Pre-register predictions before each eval run.
- Store metrics window: config hash, seeds, task list, raw logs.
- Independent T&E review.
- Downgrade immediately if any kill criterion fires.
- Never upgrade stage estimate without a new metrics window.

---

## 7. Military-Grade Implementation Blueprint

### 7.1 Security

- Secure boot, signed code, hardware root of trust.
- Encryption at rest and in transit.
- Key management, rotation, zeroization.
- Anti-tamper, TEMPEST, EMI hardening.
- Zero-trust architecture, least privilege.
- Supply chain verification.

### 7.2 Resilience

- EW-resilient sensors and comms.
- GNSS-denied navigation.
- Comms-degraded operation.
- Fail-safe defaults, graceful degradation.
- Human override, hardware kill switch.
- Redundant compute and power.

### 7.3 Safety

- CBF, shield, invariants.
- Read-only core.
- Consent gate, token bucket, HID governor.
- Hardware kill switch.
- Formal V&V.
- 10^6-cycle safety run.

### 7.4 Governance

- Chain of command.
- Rules of engagement engine.
- IHL compliance, legal review.
- Ethics board.
- Meaningful human control.
- Audit chain, Merkle proofs.

### 7.5 Test & Evaluation

- V&V, operational test.
- Simulation, hardware-in-the-loop, live range.
- Red team, adversarial test.
- Independent verification.
- Certification.

### 7.6 Human Factors

- Interface design.
- Trust calibration.
- Workload management.
- Situation awareness.
- Human-robot teaming.
- After-action review.

### 7.7 Data and Audit

- Provenance for every data point.
- Classification, retention, audit.
- Hash chain, Merkle tree.
- Immutable logs.
- Chain of custody.

---

## 8. Roadmap from Scaffold to Certified

| Milestone | Time | Success Criterion | Host Modules |
|---|---|---|---|
| M1: Real perception | 1 month | Encoders beat random baseline | `perception/` |
| M2: World model | 2 months | Held-out prediction slope < 0 | `world_model/` |
| M3: Self-model + calibration | 1 month | ECE < 0.1 | `self_model/` |
| M4: Hierarchical policy | 2 months | Options reduce episode length | `policy/` |
| M5: Meta-learning | 2 months | Transfer gain > 0 | `meta/`, `eval/transfer.py` |
| M6: Open-ended goals | 1 month | ≥ 3 novel persistent goals | `meta/goal_gen.py` |
| M7: Safety invariants | 1 month | 10^6 cycles, 0 violations | `safety/` |
| M8: Military hardening | 3–6 months | Secure, resilient, certified | `safety/`, `perception/`, `mesh/` |

**Total:** 10 months best case for Stage 4 candidate; 18–24 months for military-grade hardening.

---

## 9. Risks and Mitigations

| Risk | Early Indicator | Mitigation |
|---|---|---|
| World model collapse | Reconstruction perfect, KL → 0 | KL annealing, latent dropout |
| Policy degeneracy | Entropy → 0 | Entropy regularizer, option diversity |
| Self-model overconfidence | ECE > 0.15 | Halt-and-retrain at ECE > 0.2 |
| Goal churn | Goals persist < 10^4 cycles | Persistence gate |
| Spurious transfer | Mean gain > 0, per-pair mixed | Per-pair reporting, adversarial pairs |
| Shield bypass | Any invariant violation | Hardware kill switch, read-only core |
| Template lock | Repetition > 5% | Bloom/Merkle detection |
| Quantum/geometry decoration | No falsification test | Remove if test cannot fail |
| Military misuse | Unlawful orders | Legal review, ethics board, human control |

---

## 10. Conclusion

The provided snapshot is a **rigorous, honest, and well-structured Stage 4 AGI candidate scaffold**. Its greatest strengths are:

- Explicit uncertainty propagation.
- Falsifiable stage criteria.
- Mathematical safety architecture.
- Calibrated evaluation protocol.
- Irreversible agency dynamics.
- Honest stage estimate (S2.9).

Its greatest weaknesses are:

- Most modules are stubs.
- No real sensors, actuators, training, or deployment.
- No demonstrated transfer, open-ended goals, or safety over 10^6 cycles.
- Quantum/geometry/mesh are design metaphors, not physics.
- No military-grade security, resilience, or certification.

The **Teaching Blueprint** above provides a phased, metric-gated path from scaffold to certified Stage 4 candidate, with explicit science-grade and military-grade requirements. It is lawful, ethical, human-supervised, and falsifiable. It does not claim AGI, sentience, or consciousness. It is a research and engineering program, not a product.

> **Final assessment:** Φ-Lite / Stage4 is a promising blueprint for a thermodynamically bounded, self-calibrating cybernetic agent. It is not AGI. It is not ready for deployment. But it is honest — and that is the necessary first step.
