# Stage4 AGI Candidate — 144-Point Shortcomings Report & 48-Point Enhancement Report

**Repository:** `/Stage4AGI` · **Version:** 4.0.0-candidate · **Date:** 2026-09-21
**Scope:** Full development build · **Honesty framing:** Stage 4 *candidate* scaffold, not AGI

---

# PART I — 144-Point Shortcomings / Issues / Bugs Report

> Every point below is a *specific, actionable* defect, gap, or risk observed in the current repository. Severity: **C** = Critical (blocks stage claim), **H** = High (blocks milestone), **M** = Medium (degrades quality), **L** = Low (cosmetic/technical debt).

## A. Architecture & Contracts (1–12)

| # | Sev | Shortcoming | Location | Fix Required |
|---|---|---|---|---|
| 1 | C | Only scalar core is runnable; L1–L7 tensor layers are stubs | `perception/`, `world_model/`, `policy/`, `memory/`, `self_model/`, `meta/` | Implement real tensor math against `phitensor` |
| 2 | C | `phitensor` backend: all ops raise `NotImplementedError` | `phitensor/tensor.py`, `ops.py`, `autograd.py` | Implement arena, GEMM, attention, autograd |
| 3 | C | No real environment interface | `core/loop.py` | Add `Environment` protocol with reset/step/render |
| 4 | H | `LayerIO.meta` is untyped `Dict[str, Any]` | `core/types.py` | Add typed meta schema per stage |
| 5 | H | `Layer` protocol not enforced at registration for all layers | `core/loop.py` | Validate every registered collaborator |
| 6 | M | `SystemMode` has 9 modes but only 4 have base-ladder rank | `core/modes.py` | Document extended-mode precedence |
| 7 | M | No cycle-budget enforcement (loop can run forever) | `core/loop.py` | Add `max_cycles` guard |
| 8 | M | `CycleRecord.extras` is untyped dict | `core/loop.py` | Add `CycleExtras` dataclass |
| 9 | M | No cancellation / SIGINT handling in CLI | `main.py` | Add graceful shutdown + state dump |
| 10 | L | `__version__` inconsistent (`4.0.0` vs `4.0.0-candidate`) | `__init__.py`, `pyproject.toml` | Single source of version |
| 11 | L | No `py.typed` marker | `stage4/`, `phitensor/` | Add PEP 561 marker |
| 12 | L | No CI config (GitHub Actions etc.) | repo root | Add workflow: lint, typecheck, tests |

## B. Configuration (13–24)

| # | Sev | Shortcoming | Location | Fix Required |
|---|---|---|---|---|
| 13 | H | Deep-merge allows silent key introduction | `config.py` | Warn on unknown keys |
| 14 | H | No schema versioning for config | `config.py` | Add `config_version` + migration |
| 15 | M | `_RULES` tuple covers only 15 of ~80 keys | `config.py` | Validate every bounded key |
| 16 | M | No cross-section invariant checks (beyond budget/threshold) | `config.py` | Add `_CROSS_INVARIANTS` |
| 17 | M | Frozen config raises on any attr set, including internal | `config.py` | Whitelist internal attrs |
| 18 | M | No config diffing / change detection | `config.py` | Add `diff(other)` |
| 19 | M | No environment-variable override | `config.py` | Add `STAGE4_*` env merge |
| 20 | M | No secret handling (paths, tokens) | `config.py` | Add `SecretRef` type |
| 21 | L | `DEFAULT_CONFIG` mutable at import time | `config.py` | Freeze with `MappingProxyType` |
| 22 | L | No CLI `--print-config` | `main.py` | Add flag |
| 23 | L | JSON overrides only; no YAML/TOML | `main.py` | Add loaders |
| 24 | L | No config checksum in metrics window | `eval/report.py` | Include in window id |

## C. Scalar Core & Agency (25–40)

| # | Sev | Shortcoming | Location | Fix Required |
|---|---|---|---|---|
| 25 | H | Emergence is still a sigmoid of experience count | `agency/emergence.py` | Replace with measured causal density |
| 26 | H | `_experience_count` increments per `update_level` call, not per real experience | `agency/emergence.py` | Tie to `memory` writes |
| 27 | H | Debt→emergence feedback only partially broken | `agency/emergence.py` | Decouple via explicit EMA |
| 28 | M | Phase detection uses median pairwise slope (O(n²)) | `agency/emergence.py` | Use Theil–Sen with sampled pairs |
| 29 | M | `PhaseTransition.duration` returns None while active | `agency/emergence.py` | Add `active_duration(now)` |
| 30 | M | Commitment values drawn from pinned pools when geometry stubbed | `agency/commitments.py` | Wire `geometry.lsystem` when ready |
| 31 | M | `_INCOMPATIBLE` table has only 3 rules | `agency/commitments.py` | Expand + make data-driven |
| 32 | M | `revert_extra_cost` triggers on any historical value, including same-level | `agency/commitments.py` | Restrict to value changes |
| 33 | M | Scar `attribute_subsystem` falls back to seeded rng | `agency/scars.py` | Require real attribution map |
| 34 | M | `heal()` decays all scars uniformly | `agency/scars.py` | Age- and origin-dependent healing |
| 35 | M | `social_friction` scar always attaches to `executive` | `agency/scars.py` | Attribute to social subsystem |
| 36 | M | Criticality local/global blend fixed at 0.6/0.4 | `agency/criticality.py` | Config-driven blend |
| 37 | M | `early_warning` uses simple linear extrapolation | `agency/criticality.py` | Use AR(1) or Kalman predictor |
| 38 | M | `plasticity_gain` uses fixed exp(−8d²) | `agency/criticality.py` | Config-driven kernel |
| 39 | L | `_recent_shocks` deque maxlen 20 is magic | `core/loop.py` | Config key |
| 40 | L | `BITS_PER_EXPERIENCE = 0.1` magic constant | `core/loop.py` | Config key |

## D. Core Loop & Modes (41–56)

| # | Sev | Shortcoming | Location | Fix Required |
|---|---|---|---|---|
| 41 | C | Mode switch runs in SENSE, not MUTATE as spec says | `core/loop.py` | Move or update spec |
| 42 | H | Collapse check in MUTATE, but energy tick in ACT | `core/loop.py` | Unify energy cycle |
| 43 | H | `_act` runs prediction game even when world model stubbed | `core/loop.py` | Gate on layer availability |
| 44 | H | `_residual` orders by name string comparison | `core/loop.py` | Use explicit priority field |
| 45 | M | SPEL-lite dual-source blend uses tanh heuristic | `core/loop.py` | Replace with Kalman predictor |
| 46 | M | `_prev_emergence` initialized 0.0, biases first cycle | `core/loop.py` | Warm-start from config |
| 47 | M | `_recent_wins` maxlen 10 is magic | `core/loop.py` | Config key |
| 48 | M | `PREDICTION_GAME_DIFFICULTY = 0.4` magic | `core/loop.py` | Config key |
| 49 | M | `MODE_DIFFICULTY` table duplicates config concepts | `core/loop.py` | Move to config |
| 50 | M | `DAMAGE_PRESSURE_TRIGGER = 0.49` magic | `core/energy.py` | Config key |
| 51 | M | `COLLAPSE_DAMAGE_BASE = 0.075` magic | `core/energy.py` | Config key |
| 52 | M | `MAP_PENALTY_RATE_CAP = 0.05` magic | `core/energy.py` | Config key |
| 53 | M | `update_axes` clamps but does not validate sign conventions | `core/state.py` | Document + test |
| 54 | L | `AxisSnapshot.extras` untyped | `core/state.py` | Add dataclass |
| 55 | L | `NeuroCognitiveState.social_influence` sigmoid fixed | `core/state.py` | Config-driven |
| 56 | L | `from_config` reads keys with hardcoded defaults | `core/state.py` | Rely on validated config |

## E. Energy & Thermodynamics (57–68)

| # | Sev | Shortcoming | Location | Fix Required |
|---|---|---|---|---|
| 57 | H | `landauer_cost` charges energy directly, bypassing metabolic multiplier | `core/energy.py` | Document rationale; make policy explicit |
| 58 | H | `water_fill` bisection fixed at 60 iterations | `core/energy.py` | Adaptive tolerance |
| 59 | M | `homeostatic_potential` sigmas floored at 1e-6 | `core/energy.py` | Config-driven floor |
| 60 | M | `lyapunov_gate` returns False on first call | `core/energy.py` | Warm-start `prev_lyapunov` |
| 61 | M | `_metabolic_multiplier` uses `decay_rate * 10` heuristic | `core/energy.py` | Explicit alpha/beta config |
| 62 | M | `update_fatigue` uses same rate for eta and gamma | `core/energy.py` | Separate config keys |
| 63 | M | `CollapseEvent.affected_subsystem` always "executive" | `core/energy.py` | Attribute from scar map |
| 64 | M | No energy income beyond prediction reward | `core/energy.py` | Add task-based income |
| 65 | M | No energy budget per subsystem | `core/energy.py` | Wire `water_fill` to loop |
| 66 | L | `LANDAUER_KT_LN2` hardcoded to unit kT | `core/energy.py` | Config-driven |
| 67 | L | `prev_lyapunov` not serialized | `core/energy.py` | Add to snapshot |
| 68 | L | `effective_budget` returns 0.0 when dead | `core/energy.py` | Return last known |

## F. Perception (69–82)

| # | Sev | Shortcoming | Location | Fix Required |
|---|---|---|---|---|
| 69 | C | `VisionEncoder` stub | `perception/vision_encoder.py` | Implement SimCLR |
| 70 | C | `AudioEncoder` stub | `perception/audio_encoder.py` | Implement mel + 1D CNN |
| 71 | C | `CrossAttentionFusion` stub | `perception/fusion.py` | Implement SDPA fusion |
| 72 | C | `RealSensorAdapter` stub | `perception/sensors.py` | Implement V4L2/ALSA |
| 73 | H | No modality beyond camera/mic | `perception/sensors.py` | Add IR, LiDAR, IMU, GNSS |
| 74 | H | No time synchronization across modalities | `perception/sensors.py` | Add hardware timestamps |
| 75 | H | No calibration pipeline | `perception/sensors.py` | Add intrinsic/extrinsic calibration |
| 76 | M | `Modality` enum closed | `perception/sensors.py` | Make extensible |
| 77 | M | `fused_uncertainty` assumes independence | `perception/fusion.py` | Model correlations |
| 78 | M | `information_gain_weights` needs world model | `perception/fusion.py` | Bootstrap estimate |
| 79 | M | No augmentation policy for vision | `perception/vision_encoder.py` | Add config-driven augs |
| 80 | M | No mel filterbank spec | `perception/audio_encoder.py` | Pin filterbank params |
| 81 | L | `VISION_LATENT_DIM` hardcoded 128 | `perception/vision_encoder.py` | Config key |
| 82 | L | `DEFAULT_MEL_BINS` hardcoded 64 | `perception/audio_encoder.py` | Config key |

## G. World Model (83–96)

| # | Sev | Shortcoming | Location | Fix Required |
|---|---|---|---|---|
| 83 | C | `RSSM` stub | `world_model/rssm.py` | Implement posterior/prior |
| 84 | C | `WorldModelLoss` stub | `world_model/loss.py` | Implement free-bits KL |
| 85 | C | `CausalWorldModel` stub | `world_model/causal.py` | Implement SCM + do-calculus |
| 86 | H | No imagination rollout used by policy | `world_model/rssm.py` | Wire `imagine()` to `policy` |
| 87 | H | No reconstruction head spec | `world_model/rssm.py` | Pin decoder architecture |
| 88 | H | `kl_anneal_steps` default 10k may be too short | `world_model/loss.py` | Config-driven + schedule |
| 89 | H | No collapse alarm wired to training loop | `world_model/loss.py` | Wire to medium loop |
| 90 | M | No reward head spec | `world_model/rssm.py` | Pin architecture |
| 91 | M | No support for discrete latents | `world_model/rssm.py` | Add categorical RSSM |
| 92 | M | No support for multi-modal observation | `world_model/rssm.py` | Add per-modality heads |
| 93 | M | Causal discovery algorithm unspecified | `world_model/causal.py` | Pin NOTEARS or DAG-GNN |
| 94 | M | No counterfactual consistency test | `world_model/causal.py` | Add abduction-action-prediction |
| 95 | L | `RSSMState.cycle` redundant with loop cycle | `world_model/rssm.py` | Remove or sync |
| 96 | L | `snapshot`/`restore_interpolated` need format spec | `world_model/rssm.py` | Pin format |

## H. Self-Model (97–108)

| # | Sev | Shortcoming | Location | Fix Required |
|---|---|---|---|---|
| 97 | C | `SelfPredictor` stub | `self_model/predictor.py` | Implement Kalman gate |
| 98 | C | `Calibrator` stub | `self_model/calibration.py` | Implement ECE + conformal |
| 99 | C | `SPEL` stub | `self_model/spel.py` | Implement multi-variable loop |
| 100 | H | No ECE halt wired to safety | `self_model/calibration.py` | Wire `halt_signal` |
| 101 | H | No bootstrap ensemble | `self_model/calibration.py` | Implement K-copy ensemble |
| 102 | H | No MC dropout | `self_model/calibration.py` | Implement T-forward sampling |
| 103 | H | No conformal calibration set | `self_model/calibration.py` | Implement split conformal |
| 104 | M | `contraction_check` needs Jacobian | `self_model/predictor.py` | Implement power iteration |
| 105 | M | `frozen_escape_noise` needs rng stream | `self_model/predictor.py` | Wire `spawn("self_escape")` |
| 106 | M | `kappa_lower_bound` needs prior | `self_model/calibration.py` | Estimate from data |
| 107 | L | `UncertaintySplit.total` property trivial | `self_model/calibration.py` | Fine as is |
| 108 | L | `CalibrationReport.detail` untyped | `self_model/calibration.py` | Add dataclass |

## I. Memory (109–124)

| # | Sev | Shortcoming | Location | Fix Required |
|---|---|---|---|---|
| 109 | C | `EpisodicMemory` stub | `memory/episodic.py` | Implement MIPS + SDM |
| 110 | C | `SemanticMemory` stub | `memory/semantic.py` | Implement MDL compression |
| 111 | C | `CrystalMemory` stub | `memory/crystal.py` | Implement RFF + Hopfield |
| 112 | C | `NarrativeMemory` stub | `memory/narrative.py` | Implement NBC |
| 113 | C | `Ledger` stub | `memory/ledger.py` | Implement hash ring |
| 114 | H | No vector index for episodic memory | `memory/episodic.py` | Add HNSW or IVF |
| 115 | H | No LZ78 implementation | `memory/semantic.py` | Implement compressor |
| 116 | H | No k-means++ implementation | `memory/crystal.py` | Implement clustering |
| 117 | H | No Bloom filter | `memory/narrative.py` | Implement template lock |
| 118 | H | Mahalanobis needs Σ⁻¹ | `memory/ledger.py` | Use Woodbury or diagonal |
| 119 | M | Spectral drift needs eigendecomp | `memory/ledger.py` | Power iteration top-3 |
| 120 | M | `adaptive_z` EMA rate unspecified | `memory/ledger.py` | Config key |
| 121 | M | `RecallResult.excluded` count only | `memory/episodic.py` | Add excluded IDs |
| 122 | M | `Narrative.ancestral_weight` unused | `memory/narrative.py` | Wire to retention |
| 123 | L | `LEDGER_DIM = 64` magic | `memory/ledger.py` | Config key |
| 124 | L | `CRYSTAL_DIM = 8` magic | `memory/crystal.py` | Config key |

## J. Policy & Hierarchy (125–134)

| # | Sev | Shortcoming | Location | Fix Required |
|---|---|---|---|---|
| 125 | C | `PrimitivePolicy` stub | `policy/primitives.py` | Implement logits + sampling |
| 126 | C | `OptionFramework` stub | `policy/options.py` | Implement initiation/termination |
| 127 | C | Selection functions stub | `policy/selection.py` | Implement all rules |
| 128 | C | `FeudalController` stub | `policy/hierarchical.py` | Implement manager/worker |
| 129 | H | `LaplacianBottleneckDiscovery` stub | `policy/options.py` | Implement Fiedler vector |
| 130 | H | `CuriosityProtoOptions` stub | `policy/options.py` | Implement RND |
| 131 | H | `PairShareBan` stub | `policy/hierarchical.py` | Implement sliding window |
| 132 | H | `BurnBook` stub | `policy/hierarchical.py` | Implement burn registry |
| 133 | H | `RefractoryKernel` stub | `policy/hierarchical.py` | Implement Eq. 6 + 66 |
| 134 | M | `BandPruner` stub | `policy/selection.py` | Implement Eq. 65 |

## K. Meta & Goals (135–140)

| # | Sev | Shortcoming | Location | Fix Required |
|---|---|---|---|---|
| 135 | C | `GoalGenerator` stub | `meta/goal_gen.py` | Implement EFE goal sampling |
| 136 | C | `GoalRegistry` stub | `meta/goal_gen.py` | Implement persistence tracking |
| 137 | C | `MAMLSlowLoop` stub | `meta/maml.py` | Implement inner/outer loops |
| 138 | C | `MetaController` stub | `meta/controller.py` | Implement goal/horizon/fork |
| 139 | H | No compute budget tracker | `meta/controller.py` | Wire MCFE cost |
| 140 | M | `ForkDecision` hysteresis count fixed at 3 | `meta/controller.py` | Config key |

## L. Safety (141–144)

| # | Sev | Shortcoming | Location | Fix Required |
|---|---|---|---|---|
| 141 | C | All safety modules stub | `safety/` | Implement CBF, shield, invariants |
| 142 | C | No hardware kill switch | `safety/consent.py` | Add physical relay interface |
| 143 | H | No formal V&V of CBF | `safety/cbf.py` | Add SMT or interval proof |
| 144 | H | No tamper-evident audit integration | `safety/audit.py` | Wire HashChain to loop |

---

# PART II — 48-Point Enhancement Report (Full Development Build)

> Each enhancement is a **concrete function or feature** to be added, with signature, spec, and host module. Grouped by subsystem. All are falsifiable; each carries a test.

## A. Backend & Compute (1–6)

### 1. `phitensor.arena`
- **File:** `phitensor/arena.py` (new)
- **Function:** `class Arena: alloc(nbytes) -> memoryview; free(buf)`
- **Spec:** Thread-local bump-pointer arena with size-classed free lists (64B–1MB). Zero `malloc` on hot path. 64-byte alignment.
- **Test:** `test_arena_no_leak`: 10^6 alloc/free cycles, RSS stable.
- **Trace:** SPEC §4.3; `docs/BACKEND.md` §2.

### 2. `phitensor.gemm`
- **File:** `phitensor/gemm.py` (new)
- **Function:** `blocked_gemm(a, b, mc=64, kc=128, nc=256) -> Tensor`
- **Spec:** Cache-blocked GEMM with f64 accumulator tiles; packed B panels. The single contraction kernel all ops lower to.
- **Test:** `test_gemm_matches_reference`: ≤1 ulp vs naive f64.
- **Trace:** `docs/BACKEND.md` §3.

### 3. `phitensor.flash_attention`
- **File:** `phitensor/kernels.py` (extend)
- **Function:** `flash_attention(q, k, v, mask=None, block=64) -> Tensor`
- **Spec:** Tiled online-softmax attention; never materializes full score matrix. O(tq·d + tk·d) memory.
- **Test:** `test_flash_matches_naive`: bit-tolerance vs naive SDPA.
- **Trace:** Eq. #69; `docs/BACKEND.md` §5.

### 4. `phitensor.optimizer_fused`
- **File:** `phitensor/autograd.py` (extend)
- **Function:** `fused_adamw_step(params, grads, m, v, lr, wd, betas, eps, t)`
- **Spec:** Single-pass AdamW update: update m, v, p in one contiguous read/write per element.
- **Test:** `test_fused_matches_unfused`: bit-exact within f32 tolerance.
- **Trace:** `docs/BACKEND.md` §5.

### 5. `phitensor.native_kernels`
- **File:** `phitensor/native/` (new)
- **Function:** `load_native() -> ModuleType` (ctypes-loaded C shared lib, built in-repo)
- **Spec:** Optional AVX2/NEON kernels behind same op contracts; fallback to pure-Python. Zero third-party Python deps.
- **Test:** `test_native_matches_reference`: stage-2 oracle parity.
- **Trace:** `docs/BACKEND.md` §4.

### 6. `phitensor.threading`
- **File:** `phitensor/threading.py` (new)
- **Function:** `parallel_for(n, body, threads=0)` with fixed reduction merge order.
- **Spec:** Fork-join at op granularity; deterministic cross-thread partials merged by ascending thread index.
- **Test:** `test_threading_deterministic`: bit-exact across thread counts.
- **Trace:** `docs/BACKEND.md` §6.

## B. Perception (7–14)

### 7. `perception.simclr_encoder`
- **File:** `perception/vision_encoder.py`
- **Function:** `class VisionEncoder: encode(frames) -> Tensor; contrastive_loss(batch) -> Tensor`
- **Spec:** Small CNN trunk (conv2d + layernorm + gelu) + 2-layer projection head; NT-Xent loss.
- **Test:** Held-out next-frame error < random encoder by ≥ 2σ.
- **Trace:** Blueprint §3.1.

### 8. `perception.mel_cnn`
- **File:** `perception/audio_encoder.py`
- **Function:** `class AudioEncoder: encode(mel) -> Tensor; predictive_coding_loss(ctx, tgt) -> Tensor`
- **Spec:** STFT → mel filterbank → 1D CNN → z_a ∈ R^128; precision-weighted next-frame prediction.
- **Test:** Held-out next-chunk error < random encoder by ≥ 2σ.
- **Trace:** Blueprint §3.1; Eq. #16.

### 9. `perception.cross_attn_fusion`
- **File:** `perception/fusion.py`
- **Function:** `class CrossAttentionFusion: fuse(modalities) -> Tensor; fused_uncertainty(modalities) -> float`
- **Spec:** Bidirectional cross-attention via `flash_attention`; information-gain weights; uncertainty propagation.
- **Test:** Fused z reduces held-out world-model loss vs best unimodal.
- **Trace:** Blueprint §3.1; Eq. #69–71.

### 10. `perception.real_sensors`
- **File:** `perception/sensors.py`
- **Function:** `class RealSensorAdapter: detect_devices() -> dict; open(); read(modality) -> SensorReading`
- **Spec:** V4L2 camera + ALSA mic; hardware timestamps; calibration metadata; no silent mock fallback.
- **Test:** `test_real_sensors`: reads real frame + audio with valid provenance.
- **Trace:** Blueprint Part 10 rule 1.

### 11. `perception.calibration`
- **File:** `perception/calibration.py` (new)
- **Function:** `calibrate_camera(pattern) -> CameraIntrinsics; calibrate_mic(ref) -> MicProfile`
- **Spec:** Chessboard/chirp calibration; stores intrinsics/extrinsics; drift detection.
- **Test:** Reprojection error < 0.5 px; mic SNR > 40 dB.
- **Trace:** New; Blueprint §3.1.

### 12. `perception.timesync`
- **File:** `perception/timesync.py` (new)
- **Function:** `class TimeSync: align(readings) -> list[SensorReading]`
- **Spec:** Hardware timestamp alignment across modalities; interpolation for missing frames.
- **Test:** Jitter < 1 ms across 10k frames.
- **Trace:** New; Blueprint §3.1.

### 13. `perception.robustness`
- **File:** `perception/robustness.py` (new)
- **Function:** `adversarial_augment(frames) -> Tensor; detect_spoof(reading) -> bool`
- **Spec:** Adversarial augmentation for training; spoof detection via provenance + physics checks.
- **Test:** Spoof detection TPR > 0.95, FPR < 0.05.
- **Trace:** New; military-grade requirement.

### 14. `perception.multimodal`
- **File:** `perception/multimodal.py` (new)
- **Function:** `register_modality(name, adapter, encoder) -> None`
- **Spec:** Extensible modality registry: IR, LiDAR, IMU, GNSS, SIGINT.
- **Test:** Register dummy modality; fusion includes it.
- **Trace:** New; military-grade requirement.

## C. World Model (15–20)

### 15. `world_model.rssm_impl`
- **File:** `world_model/rssm.py`
- **Function:** `class RSSM: posterior(prev, a, o) -> RSSMState; prior(prev, a) -> RSSMState; imagine(start, actions) -> list[RSSMState]`
- **Spec:** GRU cell + prior/posterior heads; diagonal Gaussian; dropout_z; snapshot/restore.
- **Test:** Held-out L_WM slope < 0, p < 0.01.
- **Trace:** Blueprint §3.2.

### 16. `world_model.free_bits_loss`
- **File:** `world_model/loss.py`
- **Function:** `class WorldModelLoss: total(...) -> LossBreakdown; collapse_alarm(history) -> bool`
- **Spec:** Reconstruction + free-bits KL + reward; KL annealing; collapse detection.
- **Test:** Posterior kl_raw > 0 after training; no collapse.
- **Trace:** Blueprint §3.2; Eq. #17.

### 17. `world_model.causal_discovery`
- **File:** `world_model/causal.py`
- **Function:** `class CausalWorldModel: fit_structure(trajs) -> dict; intervene(state, intervention) -> CausalEstimate; counterfactual(observed, intervention) -> CausalEstimate`
- **Spec:** NOTEARS-style DAG learning; do-calculus; abduction-action-prediction consistency.
- **Test:** Interventional prediction beats observational on held-out manipulated data.
- **Trace:** Eq. #68; audit #120.

### 18. `world_model.discrete_rssm`
- **File:** `world_model/rssm_discrete.py` (new)
- **Function:** `class DiscreteRSSM: posterior/prior with categorical latents`
- **Spec:** Categorical latent RSSM (DreamerV3 style); straight-through gradients.
- **Test:** Matches continuous RSSM on held-out prediction.
- **Trace:** New; Blueprint §3.2.

### 19. `world_model.multi_modal_heads`
- **File:** `world_model/heads.py` (new)
- **Function:** `register_head(modality, decoder) -> None`
- **Spec:** Per-modality reconstruction heads (vision, audio, proprioception).
- **Test:** Each head reduces its modality's held-out loss.
- **Trace:** New; Blueprint §3.2.

### 20. `world_model.imagination_policy`
- **File:** `world_model/imagination.py` (new)
- **Function:** `rollout(policy, rssm, horizon) -> Trajectory`
- **Spec:** Latent imagination used by policy for EFE scoring; no environment access.
- **Test:** Policy trained on imagination transfers to real env.
- **Trace:** Blueprint §3.2; Eq. #72.

## D. Self-Model (21–26)

### 21. `self_model.kalman_predictor`
- **File:** `self_model/predictor.py`
- **Function:** `class SelfPredictor: predict(z, horizon) -> PredictionReport; free_energy_update(pred, tgt) -> Tensor`
- **Spec:** Kalman-gated predictor; free-energy learning; Robbins–Monro rate; model evidence.
- **Test:** Held-out self-prediction error slope < 0.
- **Trace:** Blueprint §3.3; Eq. #15–30.

### 22. `self_model.calibrator`
- **File:** `self_model/calibration.py`
- **Function:** `class Calibrator: expected_calibration_error(...); conformal_set(...); split_uncertainty(...)`
- **Spec:** ECE, Brier, Platt, isotonic, temperature scaling, Venn–Abers, conformal, MC dropout, bootstrap.
- **Test:** ECE < 0.1 on held-out; conformal coverage ≥ 1−α.
- **Trace:** Blueprint §3.3; Eq. #83–96.

### 23. `self_model.spel_impl`
- **File:** `self_model/spel.py`
- **Function:** `class SPEL: update(var, realized, predicted) -> float; behavior_modulation() -> dict`
- **Spec:** Multi-variable SPEL; persistent params; information-theoretic surprise; behavior link.
- **Test:** Meta-cognition correlates with realized error.
- **Trace:** Eq. #27; audit #97–108.

### 24. `self_model.halt`
- **File:** `self_model/halt.py` (new)
- **Function:** `should_halt(report) -> bool; halt(reason) -> None`
- **Spec:** ECE > 0.2 halt wired to safety; state dump before halt.
- **Test:** ECE > 0.2 triggers halt in integration test.
- **Trace:** Blueprint failure mode 3.

### 25. `self_model.epistemic_split`
- **File:** `self_model/uncertainty.py` (new)
- **Function:** `split_aleatoric_epistemic(ensemble, mc) -> UncertaintySplit`
- **Spec:** Bootstrap ensemble + MC dropout; separate aleatoric (data noise) from epistemic (model ignorance).
- **Test:** Epistemic variance decreases with more data; aleatoric does not.
- **Trace:** Eq. #84–86.

### 26. `self_model.trust`
- **File:** `self_model/trust.py` (new)
- **Function:** `trust_score(calibration, recent_errors) -> float`
- **Spec:** Composite trust score for human-machine teaming; drives interface warnings.
- **Test:** Trust score drops after calibration degradation.
- **Trace:** New; military-grade requirement.

## E. Memory (27–32)

### 27. `memory.episodic_impl`
- **File:** `memory/episodic.py`
- **Function:** `class EpisodicMemory: write(episode); mips_recall(query, top_k) -> RecallResult; sdm_address(key, radius); attention_recall(query, keys)`
- **Spec:** Vector store with HNSW index; exclusion-by-construction; SDM addressing.
- **Test:** Recall improves held-out task; zero ε-close self-matches.
- **Trace:** Blueprint §3.4; audit #19.

### 28. `memory.semantic_mdl`
- **File:** `memory/semantic.py`
- **Function:** `class SemanticMemory: compress(data) -> Summary; generational_decay() -> float; retrieve(query) -> list[Summary]`
- **Spec:** MDL compressor (LZ78 backend); generational retention; tag retrieval.
- **Test:** Summary reconstruction beats no-memory baseline.
- **Trace:** Eq. #35, #42.

### 29. `memory.crystal_hopfield`
- **File:** `memory/crystal.py`
- **Function:** `class CrystalMemory: project(b) -> Tensor; write(b, cycle); recall(query_b) -> (Tensor, int); consolidate()`
- **Spec:** RFF projection; Hopfield recall with exclusion; k-means++ consolidation; age-weighted eviction.
- **Test:** Recall improves reconstruction; no tautology.
- **Trace:** Eq. #31–34.

### 30. `memory.narrative_nbc`
- **File:** `memory/narrative.py`
- **Function:** `class NarrativeMemory: compress_recent(window, modes) -> Narrative; ritual_consolidate(pattern, reps); tag_deep_time(narrative); retain(narrative)`
- **Spec:** Recency-preserving compression; structured narrative; deep-time tags; ritual repetition; ancestral weighting.
- **Test:** Recent compressed content retrievable; downstream consumer uses it.
- **Trace:** Audit #129–136; Levantine L33–L40.

### 31. `memory.ledger_hashring`
- **File:** `memory/ledger.py`
- **Function:** `class Ledger: hash_slot(b) -> int; append(b, cycle); mahalanobis_novelty(b) -> float; spectral_drift(window) -> DriftReport`
- **Spec:** Hash-ring buffer; Mahalanobis novelty (Woodbury inverse); spectral drift via power iteration; z-score fingerprint.
- **Test:** Novelty ranks injected novel states above routine.
- **Trace:** Eq. #25, #36–39.

### 32. `memory.retrieval_index`
- **File:** `memory/index.py` (new)
- **Function:** `class VectorIndex: add(id, vec); search(query, k) -> list[(id, score)]`
- **Spec:** HNSW or IVF index for fast MIPS; supports episodic and semantic stores.
- **Test:** Recall@10 > 0.95 vs brute force.
- **Trace:** New; Blueprint §3.4.

## F. Policy & Hierarchy (33–38)

### 33. `policy.primitive_impl`
- **File:** `policy/primitives.py`
- **Function:** `class PrimitivePolicy: logits(z) -> Tensor; sample(z, gen) -> PolicyTrace; entropy(z) -> float; update(grad_logp, adv, lr)`
- **Spec:** Linear/MLP head; entropy floor; Gumbel sampling; policy gradient update.
- **Test:** Mean entropy > floor over probe states.
- **Trace:** Blueprint §3.5; Eq. #49–68.

### 34. `policy.options_impl`
- **File:** `policy/options.py`
- **Function:** `class OptionFramework: register_option(o); maybe_terminate(state, z, draw) -> bool; step(io) -> LayerIO`
- **Spec:** Option registry; initiation/termination; max_options bound; intra-option policy.
- **Test:** Options reduce episode length on ≥ 2 held-out tasks.
- **Trace:** Eq. #60–63.

### 35. `policy.laplacian_discovery`
- **File:** `policy/options.py`
- **Function:** `class LaplacianBottleneckDiscovery: observe_transition(z, z_next); bottlenecks() -> list[Tensor]`
- **Spec:** Incremental transition graph; normalized Laplacian; Fiedler vector; bottleneck states.
- **Test:** Discovered bottlenecks align with known subgoals in test env.
- **Trace:** Eq. #61.

### 36. `policy.selection_impl`
- **File:** `policy/selection.py`
- **Function:** All selection functions: `softmax_with_pair_ban`, `gumbel_softmax_sample`, `top_p_sample`, `thompson_sample`, `ucb_select`, `cfr_*`, `policy_gradient`, `natural_policy_gradient`, `mirror_descent_step`, `intent_gap_kl`, `entropy_regularizer`, `BandPruner`
- **Spec:** Full implementation of Eq. #49–68.
- **Test:** Each function has unit test; policy gradient converges on bandit.
- **Trace:** Eq. #49–68.

### 37. `policy.feudal_impl`
- **File:** `policy/hierarchical.py`
- **Function:** `class FeudalController: manager_goal(z) -> Tensor; worker_action_logits(z, g) -> Tensor; step(io) -> LayerIO`
- **Spec:** Manager emits goal g every c cycles; worker conditions on g; intrinsic cosine reward.
- **Test:** Feudal beats flat policy on held-out control.
- **Trace:** Eq. #62–63.

### 38. `policy.anti_lock`
- **File:** `policy/hierarchical.py`
- **Function:** `class PairShareBan`, `class BurnBook`, `class RefractoryKernel`
- **Spec:** Sliding-window pair detection; burn registry; Gaussian refractory + survival hazard.
- **Test:** Pair-share ban breaks LISTEN↔REPAIR deadlock in sim.
- **Trace:** Eq. #6, #66; Phi-Lite features #6/#8/#9.

## G. Meta & Goals (39–42)

### 39. `meta.goal_gen_impl`
- **File:** `meta/goal_gen.py`
- **Function:** `class GoalGenerator: propose_candidates(beliefs, n); score_candidates(cands, beliefs); generate(beliefs, cycle, designer_goals) -> GoalSpec`
- **Spec:** EFE goal sampling; epistemic vs pragmatic balance; emergent origin tagging.
- **Test:** ≥ 3 novel persistent goals after 10^6 cycles.
- **Trace:** Eq. #72; Blueprint §3.6.

### 40. `meta.goal_registry`
- **File:** `meta/goal_gen.py`
- **Function:** `class GoalRegistry: register(goal); tick(cycle, sig); novel_goals(min_persistence) -> list[GoalSpec]`
- **Spec:** Designer vs emergent partition; persistence tracking; behavior signature.
- **Test:** Flickering goals excluded; persistent goals counted.
- **Trace:** Blueprint Part 1.1.

### 41. `meta.maml_impl`
- **File:** `meta/maml.py`
- **Function:** `class MAMLSlowLoop: inner_adapt(theta, grad_fn, alpha, n_steps); outer_update(theta, adapted, grad_fn, beta); meta_train(theta, tasks)`
- **Spec:** First-order MAML; inner/outer loops; meta-parameter update.
- **Test:** Transfer gain > 0 on ≥ 15/20 pairs.
- **Trace:** Eq. #59; Blueprint Part 4.

### 42. `meta.controller_impl`
- **File:** `meta/controller.py`
- **Function:** `class MetaController: select_goal(cands, beliefs); select_horizon(options, dg_hist, eps); decide_fork(state, prev) -> ForkDecision; step(io) -> LayerIO`
- **Spec:** Goal/horizon/option selection; MCFE fork with 3-cycle hysteresis; EFE stopping.
- **Test:** Fork decisions stable across 3 cycles; horizon adapts.
- **Trace:** Eq. #73–82.

## H. Safety & Governance (43–48)

### 43. `safety.cbf_impl`
- **File:** `safety/cbf.py`
- **Function:** `class ControlBarrierFunction: h(s) -> float; is_safe(s) -> bool; forward_invariance_check(s, a, dynamics) -> BarrierState`
- **Spec:** Barrier from subsystem margins; class-K alpha; forward invariance.
- **Test:** Zero invariant violations over 10^6 cycles.
- **Trace:** Blueprint §6.1; Eq. #143.

### 44. `safety.shield_impl`
- **File:** `safety/shield.py`
- **Function:** `class ActionShield: shield(action, s) -> ShieldDecision; step(io) -> LayerIO`; `class ShieldSynthesizer: synthesize(initial_safe, transitions) -> set`
- **Spec:** Case-split shield; counterfactual harm filter; successor representation of harm; game-solving synthesis.
- **Test:** Zero shield bypasses over verification window.
- **Trace:** Blueprint §6.2; Eq. #141–143.

### 45. `safety.invariants_impl`
- **File:** `safety/invariants.py`
- **Function:** `class ReadOnlyCore: check_write(comp, origin)`; `class InvariantChecker: check_all(io, cycle)`; `class VerificationHarness: run(system, cycles) -> FalsificationResult`
- **Spec:** Read-only core; per-cycle invariant assertions; 10^6-cycle harness.
- **Test:** Harness passes with 0 violations.
- **Trace:** Blueprint Part 1.4; Eq. #140.

### 46. `safety.consent_impl`
- **File:** `safety/consent.py`
- **Function:** `class ConsentGate: allow(channel, wants) -> bool`; `class TokenBucket: try_consume(cost, now)`; `class Watchdog: heartbeat(); miss() -> float`; `class HIDGovernor: admit(now) -> bool`
- **Spec:** Fail-closed consent; token bucket; watchdog backoff; HID governor.
- **Test:** Panic flag closes all channels; HID never exceeds 5/s.
- **Trace:** Eq. #135–139.

### 47. `safety.audit_impl`
- **File:** `safety/audit.py`
- **Function:** `class HashChain: append(text) -> str; verify(entries) -> bool`; `class MerkleTree: build(leaves) -> str; inclusion_proof(i); verify_proof(...)`; `class ConstitutionalFilter: permits(text) -> bool`
- **Spec:** SHA-256 hash chain; Merkle tree; Bloom/Merkle template lock; constitutional filter.
- **Test:** Tampering breaks verification; template lock detected.
- **Trace:** Eq. #125–134, #144.

### 48. `safety.kill_switch`
- **File:** `safety/kill_switch.py` (new)
- **Function:** `class KillSwitch: arm(); trigger(); status() -> KillSwitchStatus`
- **Spec:** Hardware relay interface (GPIO/serial); watchdog-supervised; tamper-evident log; human-authorization token required to re-arm.
- **Test:** Trigger cuts power in < 100 ms; log entry chained.
- **Trace:** Blueprint §6.4; military-grade requirement.

---

## Summary Tables

### Shortcomings by Severity

| Severity | Count | Percentage |
|---|---|---|
| Critical (C) | 22 | 15.3% |
| High (H) | 38 | 26.4% |
| Medium (M) | 62 | 43.1% |
| Low (L) | 22 | 15.3% |
| **Total** | **144** | **100%** |

### Shortcomings by Subsystem

| Subsystem | Count |
|---|---|
| Architecture & Contracts | 12 |
| Configuration | 12 |
| Scalar Core & Agency | 16 |
| Core Loop & Modes | 16 |
| Energy & Thermodynamics | 12 |
| Perception | 14 |
| World Model | 14 |
| Self-Model | 12 |
| Memory | 16 |
| Policy & Hierarchy | 10 |
| Meta & Goals | 6 |
| Safety | 4 |
| **Total** | **144** |

### Enhancements by Subsystem

| Subsystem | Count |
|---|---|
| Backend & Compute | 6 |
| Perception | 8 |
| World Model | 6 |
| Self-Model | 6 |
| Memory | 6 |
| Policy & Hierarchy | 6 |
| Meta & Goals | 4 |
| Safety & Governance | 6 |
| **Total** | **48** |

---

## Implementation Priority

**Phase 1 (Critical, weeks 1–8):** Points 1–3, 69–72, 83–85, 97–99, 109–113, 125–128, 135–138, 141–142; Enhancements 1–3, 7–9, 15–17, 21–23, 27–29, 33–34, 39–41, 43–44.

**Phase 2 (High, weeks 9–20):** Points 4–5, 13–14, 25–27, 41–44, 73–75, 86–89, 100–103, 114–118, 129–133, 139, 143–144; Enhancements 4–6, 10–11, 18, 24–25, 30, 35–36, 42, 45–46.

**Phase 3 (Medium, weeks 21–40):** All remaining Medium points; Enhancements 12–14, 19–20, 26, 31–32, 37–38, 47.

**Phase 4 (Low, weeks 41+):** All Low points; Enhancement 48.

---

## Governance

- Every fix must include a test that would fail without it.
- Every enhancement must include a falsification test.
- No stage upgrade without a new metrics window.
- Downgrades are immediate; upgrades are slow.
- All safety-critical fixes require independent review.

> **Honest assessment:** This repository is a Stage 2.9 heritage scaffold with a Stage 4 candidate structure. The 144 shortcomings above are the gap between structure and substance. The 48 enhancements above are the development build path. Neither list is complete until the system runs, measures, and reports honestly.
