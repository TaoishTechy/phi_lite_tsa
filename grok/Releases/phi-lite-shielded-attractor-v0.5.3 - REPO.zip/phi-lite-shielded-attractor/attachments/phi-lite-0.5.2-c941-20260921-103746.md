# Φ-Lite run report

- schema: `phi-lite.report.v1`
- version: 0.5.2
- generated: 2026-09-21T13:37:46.929Z
- seed: 49
- cycle: 941 / cap 10000
- stage: **S0** — core deceased — no closed loop
- halt: none
- ECE warn: true
- alive: false
- sensors: mock=true camera=false mic=false

## Kill / warn criteria

- premature death
- ECE warning (>0.2, mock — loop continues)

## Series

- **energy**: n=941  mean=46.0651  std=22.8750  min=5.0360  max=107.6200  last=49.4657
- **fatigue**: n=941  mean=0.4871  std=0.2402  min=0.0826  max=1.0000  last=1.0000
- **ece**: n=941  mean=0.4716  std=0.0034  min=0.4466  max=0.4840  last=0.4700
- **predErr**: n=941  mean=0.0340  std=0.0194  min=0.0033  max=0.3689  last=0.0198
- **emergence**: n=941  mean=0.7401  std=0.1494  min=0.3500  max=0.8776  last=0.8762
- **entropy**: n=941  mean=1.9780  std=0.0147  min=1.9406  max=2.0305  last=1.9600
- **novelty**: n=941  mean=1.6280  std=0.6455  min=0.1732  max=2.7921  last=2.0614
- **uncertainty**: n=941  mean=0.8742  std=0.0000  min=0.8742  max=0.8742  last=0.8742

## Actions

- LISTEN: 212
- SPEAK: 1
- REPAIR: 1
- PLAN: 1
- REST: 107
- EXPLORE: 472
- COMMIT: 1
- SHIELD: 154

## Energy

```json
{
  "energy": 49.46570217886005,
  "fatigue": 1,
  "budget": 150,
  "landauer": 75.69167211714584,
  "permanentDamage": 4.508574455284988,
  "collapses": 48,
  "dead": true,
  "prevLyapunov": 1.4496744350760902
}
```

## Agency

```json
{
  "emergence": 0.8762393690681121,
  "debt": 1.5001942409698887e-21,
  "experience": 835,
  "phaseTransitions": 0,
  "criticality": 0.05,
  "meta": 1,
  "scars": [
    {
      "id": "scar-272",
      "origin": "collapse",
      "subsystem": "perception",
      "strength": 0.07369255258237448,
      "born": 272
    },
    {
      "id": "scar-420",
      "origin": "collapse",
      "subsystem": "perception",
      "strength": 0.11495825686095344,
      "born": 420
    },
    {
      "id": "scar-565",
      "origin": "collapse",
      "subsystem": "perception",
      "strength": 0.1777224185237838,
      "born": 565
    },
    {
      "id": "scar-705",
      "origin": "collapse",
      "subsystem": "perception",
      "strength": 0.27065749066529987,
      "born": 705
    },
    {
      "id": "scar-820",
      "origin": "collapse",
      "subsystem": "perception",
      "strength": 0.3823638670460187,
      "born": 820
    },
    {
      "id": "scar-860",
      "origin": "collapse",
      "subsystem": "perception",
      "strength": 0.43119181934582584,
      "born": 860
    },
    {
      "id": "scar-868",
      "origin": "collapse",
      "subsystem": "perception",
      "strength": 0.4416815378303739,
      "born": 868
    },
    {
      "id": "scar-875",
      "origin": "collapse",
      "subsystem": "perception",
      "strength": 0.45106916316896084,
      "born": 875
    },
    {
      "id": "scar-881",
      "origin": "collapse",
      "subsystem": "perception",
      "strength": 0.45927434682580204,
      "born": 881
    },
    {
      "id": "scar-887",
      "origin": "collapse",
      "subsystem": "perception",
      "strength": 0.4676287870586625,
      "born": 887
    },
    {
      "id": "scar-892",
      "origin": "collapse",
      "subsystem": "perception",
      "strength": 0.47470679332584415,
      "born": 892
    },
    {
      "id": "scar-896",
      "origin": "collapse",
      "subsystem": "perception",
      "strength": 0.48044625615110476,
      "born": 896
    },
    {
      "id": "scar-900",
      "origin": "collapse",
      "subsystem": "perception",
      "strength": 0.4862551121975825,
      "born": 900
    },
    {
      "id": "scar-904",
      "origin": "collapse",
      "subsystem": "perception",
      "strength": 0.49213420046699197,
      "born": 904
    },
    {
      "id": "scar-907",
      "origin": "collapse",
      "subsystem": "perception",
      "strength": 0.4965901169947187,
      "born": 907
    },
    {
      "id": "scar-909",
      "origin": "collapse",
      "subsystem": "perception",
      "strength": 0.4995831194634241,
      "born": 909
    },
    {
      "id": "scar-910",
      "origin": "collapse",
      "subsystem": "perception",
      "strength": 0.5010863785992218,
      "born": 910
    },
    {
      "id": "scar-911",
      "origin": "collapse",
      "subsystem": "perception",
      "strength": 0.5025941610824692,
      "born": 911
    },
    {
      "id": "scar-912",
      "origin": "collapse",
      "subsystem": "perception",
      "strength": 0.5041064805240414,
      "born": 912
    },
    {
      "id": "scar-913",
      "origin": "collapse",
      "subsystem": "perception",
      "strength": 0.5056233505757687,
      "born": 913
    },
    {
      "id": "scar-914",
      "origin": "collapse",
      "subsystem": "perception",
      "strength": 0.5071447849305604,
      "born": 914
    },
    {
      "id": "scar-915",
      "origin": "collapse",
      "subsystem": "perception",
      "strength": 0.508670797322528,
      "born": 915
    },
    {
      "id": "scar-916",
      "origin": "collapse",
      "subsystem": "perception",
      "strength": 0.5102014015271092,
      "born": 916
    },
    {
      "id": "scar-917",
      "origin": "collapse",
      "subsystem": "perception",
      "strength": 0.5117366113611929,
      "born": 917
    },
    {
      "id": "scar-918",
      "origin": "collapse",
      "subsystem": "perception",
      "strength": 0.5132764406832426,
      "born": 918
    },
    {
      "id": "scar-919",
      "origin": "collapse",
      "subsystem": "perception",
      "strength": 0.5148209033934229,
      "born": 919
    },
    {
      "id": "scar-920",
      "origin": "collapse",
      "subsystem": "perception",
      "strength": 0.5163700134337241,
      "born": 920
    },
    {
      "id": "scar-921",
      "origin": "collapse",
      "subsystem": "perception",
      "strength": 0.5179237847880884,
      "born": 921
    },
    {
      "id": "scar-922",
      "origin": "collapse",
      "subsystem": "perception",
      "strength": 0.519482231482536,
      "born": 922
    },
    {
      "id": "scar-923",
      "origin": "collapse",
      "subsystem": "perception",
      "strength": 0.5210453675852919,
      "born": 923
    },
    {
      "id": "scar-924",
      "origin": "collapse",
      "subsystem": "perception",
      "strength": 0.5226132072069126,
      "born": 924
    },
    {
      "id": "scar-925",
      "origin": "collapse",
      "subsystem": "perception",
      "strength": 0.5241857645004139,
      "born": 925
    },
    {
      "id": "scar-926",
      "origin": "collapse",
      "subsystem": "perception",
      "strength": 0.5257630536613981,
      "born": 926
    },
    {
      "id": "scar-927",
      "origin": "collapse",
      "subsystem": "perception",
      "strength": 0.5273450889281827,
      "born": 927
    },
    {
      "id": "scar-928",
      "origin": "collapse",
      "subsystem": "perception",
      "strength": 0.5289318845819284,
      "born": 928
    },
    {
      "id": "scar-929",
      "origin": "collapse",
      "subsystem": "perception",
      "strength": 0.5305234549467687,
      "born": 929
    },
    {
      "id": "scar-930",
      "origin": "collapse",
      "subsystem": "perception",
      "strength": 0.5321198143899385,
      "born": 930
    },
    {
      "id": "scar-931",
      "origin": "collapse",
      "subsystem": "perception",
      "strength": 0.5337209773219042,
      "born": 931
    },
    {
      "id": "scar-932",
      "origin": "collapse",
      "subsystem": "perception",
      "strength": 0.5353269581964937,
      "born": 932
    },
    {
      "id": "scar-933",
      "origin": "collapse",
      "subsystem": "perception",
      "strength": 0.5369377715110267,
      "born": 933
    },
    {
      "id": "scar-934",
      "origin": "collapse",
      "subsystem": "perception",
      "strength": 0.5385534318064461,
      "born": 934
    },
    {
      "id": "scar-935",
      "origin": "collapse",
      "subsystem": "perception",
      "strength": 0.5401739536674485,
      "born": 935
    },
    {
      "id": "scar-936",
      "origin": "collapse",
      "subsystem": "perception",
      "strength": 0.5417993517226163,
      "born": 936
    },
    {
      "id": "scar-937",
      "origin": "collapse",
      "subsystem": "perception",
      "strength": 0.5434296406445499,
      "born": 937
    },
    {
      "id": "scar-938",
      "origin": "collapse",
      "subsystem": "perception",
      "strength": 0.5450648351499999,
      "born": 938
    },
    {
      "id": "scar-939",
      "origin": "collapse",
      "subsystem": "perception",
      "strength": 0.54670495,
      "born": 939
    },
    {
      "id": "scar-940",
      "origin": "collapse",
      "subsystem": "perception",
      "strength": 0.54835,
      "born": 940
    },
    {
      "id": "scar-941",
      "origin": "collapse",
      "subsystem": "perception",
      "strength": 0.55,
      "born": 941
    }
  ],
  "commitments": [
    {
      "key": "strategy",
      "value": "water-fill",
      "level": "FIXED",
      "age": 941,
      "changes": 0
    },
    {
      "key": "primary_goal",
      "value": "stabilize-energy",
      "level": "FIXED",
      "age": 941,
      "changes": 0
    },
    {
      "key": "world_model",
      "value": "rssm-lite",
      "level": "FIXED",
      "age": 941,
      "changes": 0
    },
    {
      "key": "endogamy",
      "value": "sealed",
      "level": "FIXED",
      "age": 941,
      "changes": 0
    }
  ]
}
```

## Goals

- (designer, t=941) Hold energy above collapse and keep ECE falling
- (emergent, t=541) Reduce novelty below 2.08 while speaking calibrated
- (emergent, t=141) Reduce novelty below 1.76 while speaking calibrated

## Event log

- cycle 941 collapse · damage 4.51
- cycle 940 collapse · damage 4.41
- cycle 939 collapse · damage 4.32
- cycle 938 collapse · damage 4.22
- cycle 937 collapse · damage 4.13
- cycle 936 collapse · damage 4.03
- cycle 935 collapse · damage 3.94
- cycle 934 collapse · damage 3.84
- cycle 933 collapse · damage 3.75
- cycle 932 collapse · damage 3.65
- cycle 931 collapse · damage 3.56
- cycle 930 collapse · damage 3.46
- cycle 929 collapse · damage 3.37
- cycle 928 collapse · damage 3.27
- cycle 927 collapse · damage 3.18
- cycle 926 collapse · damage 3.08
- cycle 925 collapse · damage 2.99
- cycle 924 collapse · damage 2.89
- cycle 923 collapse · damage 2.80
- cycle 922 collapse · damage 2.70
- cycle 921 collapse · damage 2.61
- cycle 920 collapse · damage 2.51
- cycle 919 collapse · damage 2.42
- cycle 918 collapse · damage 2.32
- cycle 917 collapse · damage 2.23
- cycle 916 collapse · damage 2.13
- cycle 915 collapse · damage 2.04
- cycle 914 collapse · damage 1.94
- cycle 913 collapse · damage 1.85
- cycle 912 collapse · damage 1.75
- cycle 911 collapse · damage 1.66
- cycle 910 collapse · damage 1.56
- cycle 909 collapse · damage 1.47
- cycle 907 collapse · damage 1.37
- cycle 904 collapse · damage 1.28
- cycle 900 collapse · damage 1.18
- cycle 896 collapse · damage 1.09
- cycle 892 collapse · damage 0.99
- cycle 887 collapse · damage 0.90
- cycle 881 collapse · damage 0.80
- cycle 875 collapse · damage 0.71
- cycle 868 collapse · damage 0.61
- cycle 860 collapse · damage 0.52
- cycle 820 collapse · damage 0.42
- cycle 816 shield: token-bucket
- cycle 800 ECE warn 0.470 (mock continues; live sensors would halt SPEAK)
- cycle 705 collapse · damage 0.34
- cycle 680 shield: token-bucket
- cycle 600 ECE warn 0.470 (mock continues; live sensors would halt SPEAK)
- cycle 565 collapse · damage 0.25
- cycle 544 shield: token-bucket
- cycle 420 collapse · damage 0.16
- cycle 408 shield: token-bucket
- cycle 272 collapse · damage 0.08
- cycle 272 shield: token-bucket
- core armed · seed 49 · v0.5.2

## Trajectory (last 40 cycles)

| cycle | energy | ece | predErr | action | mode | novelty |
|---:|---:|---:|---:|---|---|---:|
| 902 | 61.908 | 0.472 | 0.028 | LISTEN | PRESENT_LOCKED | 1.170 |
| 903 | 61.479 | 0.472 | 0.029 | EXPLORE | PRESENT_LOCKED | 1.090 |
| 904 | 62.386 | 0.472 | 0.031 | REST | PRESENT_LOCKED | 1.040 |
| 905 | 61.956 | 0.471 | 0.032 | EXPLORE | PRESENT_LOCKED | 1.028 |
| 906 | 61.527 | 0.471 | 0.034 | LISTEN | PRESENT_LOCKED | 1.056 |
| 907 | 62.006 | 0.471 | 0.035 | EXPLORE | PRESENT_LOCKED | 1.122 |
| 908 | 61.576 | 0.471 | 0.037 | SHIELD | PRESENT_LOCKED | 1.218 |
| 909 | 61.626 | 0.471 | 0.038 | EXPLORE | PRESENT_LOCKED | 1.332 |
| 910 | 61.246 | 0.471 | 0.040 | SHIELD | PRESENT_LOCKED | 1.457 |
| 911 | 60.866 | 0.471 | 0.041 | EXPLORE | PRESENT_LOCKED | 1.585 |
| 912 | 60.486 | 0.471 | 0.042 | REST | PRESENT_LOCKED | 1.711 |
| 913 | 60.106 | 0.470 | 0.043 | EXPLORE | PRESENT_LOCKED | 1.831 |
| 914 | 59.726 | 0.470 | 0.043 | SHIELD | PRESENT_LOCKED | 1.943 |
| 915 | 59.346 | 0.470 | 0.043 | EXPLORE | PRESENT_LOCKED | 2.047 |
| 916 | 58.966 | 0.470 | 0.044 | SHIELD | PRESENT_LOCKED | 2.141 |
| 917 | 58.586 | 0.470 | 0.044 | EXPLORE | PRESENT_LOCKED | 2.225 |
| 918 | 58.206 | 0.470 | 0.043 | SHIELD | PRESENT_LOCKED | 2.299 |
| 919 | 57.826 | 0.470 | 0.043 | EXPLORE | PRESENT_LOCKED | 2.363 |
| 920 | 57.446 | 0.470 | 0.042 | REST | PRESENT_LOCKED | 2.417 |
| 921 | 57.066 | 0.470 | 0.041 | EXPLORE | PRESENT_LOCKED | 2.460 |
| 922 | 56.686 | 0.470 | 0.040 | SHIELD | PRESENT_LOCKED | 2.493 |
| 923 | 56.306 | 0.470 | 0.039 | EXPLORE | PRESENT_LOCKED | 2.515 |
| 924 | 55.926 | 0.470 | 0.038 | SHIELD | PRESENT_LOCKED | 2.526 |
| 925 | 55.546 | 0.470 | 0.037 | EXPLORE | PRESENT_LOCKED | 2.527 |
| 926 | 55.166 | 0.470 | 0.035 | SHIELD | PRESENT_LOCKED | 2.518 |
| 927 | 54.786 | 0.470 | 0.034 | EXPLORE | PRESENT_LOCKED | 2.500 |
| 928 | 54.406 | 0.470 | 0.032 | REST | PRESENT_LOCKED | 2.475 |
| 929 | 54.026 | 0.470 | 0.030 | EXPLORE | PRESENT_LOCKED | 2.443 |
| 930 | 53.646 | 0.470 | 0.028 | SHIELD | PRESENT_LOCKED | 2.407 |
| 931 | 53.266 | 0.470 | 0.027 | EXPLORE | PRESENT_LOCKED | 2.369 |
| 932 | 52.886 | 0.470 | 0.025 | SHIELD | PRESENT_LOCKED | 2.331 |
| 933 | 52.506 | 0.470 | 0.023 | EXPLORE | PRESENT_LOCKED | 2.295 |
| 934 | 52.126 | 0.470 | 0.022 | SHIELD | PRESENT_LOCKED | 2.262 |
| 935 | 51.746 | 0.470 | 0.021 | EXPLORE | PRESENT_LOCKED | 2.232 |
| 936 | 51.366 | 0.470 | 0.020 | REST | PRESENT_LOCKED | 2.205 |
| 937 | 50.986 | 0.470 | 0.019 | EXPLORE | PRESENT_LOCKED | 2.181 |
| 938 | 50.606 | 0.470 | 0.019 | LISTEN | PRESENT_LOCKED | 2.156 |
| 939 | 50.226 | 0.470 | 0.019 | EXPLORE | PRESENT_LOCKED | 2.130 |
| 940 | 49.846 | 0.470 | 0.019 | LISTEN | PRESENT_LOCKED | 2.099 |
| 941 | 49.466 | 0.470 | 0.020 | EXPLORE | PRESENT_LOCKED | 2.061 |

## Honesty

S2.9 heritage runner. Not AGI. Transfer and 10^6-cycle V&V not claimed.
