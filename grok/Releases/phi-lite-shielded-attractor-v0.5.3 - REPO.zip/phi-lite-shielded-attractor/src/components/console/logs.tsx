import { Button } from "@/components/ui/button";
import { usePhi, killCriteria, stageEstimate } from "@/lib/phi/store";
import { buildReport, downloadText, reportToMarkdown } from "@/lib/phi/report";
import { templateLock } from "@/lib/phi/memory";
import { PHI } from "@/lib/phi/config";

export function LogsPanel() {
  const core = usePhi((s) => s.core);
  const stage = stageEstimate(core);
  const kills = killCriteria(core);
  const stamp = () => {
    const t = new Date();
    const p = (n: number) => String(n).padStart(2, "0");
    return `${t.getFullYear()}${p(t.getMonth() + 1)}${p(t.getDate())}-${p(t.getHours())}${p(t.getMinutes())}${p(t.getSeconds())}`;
  };

  function exportJson() {
    const r = buildReport(core);
    downloadText(`phi-lite-${PHI.version}-c${core.cycle}-${stamp()}.json`, JSON.stringify(r, null, 2), "application/json");
  }

  function exportMd() {
    const r = buildReport(core);
    downloadText(`phi-lite-${PHI.version}-c${core.cycle}-${stamp()}.md`, reportToMarkdown(r), "text/markdown");
  }

  const recent = core.history.slice(-16).reverse();

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h2 className="text-sm font-medium">Run log</h2>
          <p className="mt-1 max-w-xl text-sm text-muted">
            Science-grade dump of the current window: series stats, action histogram, kill criteria, trajectory, hash head. JSON for machines, Markdown for notebooks.
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Button size="sm" onClick={exportJson}>
            Export JSON
          </Button>
          <Button size="sm" variant="outline" onClick={exportMd}>
            Export Markdown
          </Button>
        </div>
      </div>

      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <Meta k="cycle" v={String(core.cycle)} />
        <Meta k="stage" v={stage.stage} />
        <Meta k="ECE" v={core.ece.toFixed(4)} />
        <Meta k="action-collapse" v={templateLock(core.memory.narratives).toFixed(3)} />
        <Meta k="hash" v={core.memory.hashHead} />
        <Meta k="events" v={String(core.logs.length)} />
        <Meta k="history" v={String(core.history.length)} />
        <Meta k="sensors" v={core.perception.mock ? "mock" : "live"} />
        <Meta k="motion" v={core.perception.motion.toFixed(3)} />
        <Meta k="still" v={String(core.perception.stillFrames)} />
      </div>

      <div className="rounded-xl border border-border bg-bg-elevated p-4">
        <div className="mb-2 text-xs uppercase tracking-wide text-subtle">Criteria</div>
        {kills.length ? (
          <ul className="space-y-1 text-sm text-danger">
            {kills.map((k) => (
              <li key={k}>{k}</li>
            ))}
          </ul>
        ) : (
          <p className="text-sm text-ok">none latched</p>
        )}
        {core.safety.eceWarn ? (
          <p className="mt-2 text-xs text-muted">ECE warn latched — mock loop continues; live sensors would freeze SPEAK.</p>
        ) : null}
      </div>

      <div className="rounded-xl border border-border bg-bg-elevated p-4">
        <div className="mb-2 text-xs uppercase tracking-wide text-subtle">Event log</div>
        <ul className="max-h-56 space-y-1 overflow-auto font-mono text-[11px] text-muted">
          {core.logs.map((l, i) => (
            <li key={i}>{l}</li>
          ))}
          {!core.logs.length ? <li>awaiting cycles</li> : null}
        </ul>
      </div>

      <div className="overflow-auto rounded-xl border border-border">
        <table className="w-full min-w-[720px] text-left text-xs">
          <thead className="bg-bg-elevated text-subtle">
            <tr>
              {["cycle", "energy", "ece", "err", "action", "mode", "H", "nov"].map((h) => (
                <th key={h} className="px-3 py-2 font-medium">
                  {h}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {recent.map((row) => (
              <tr key={row.cycle} className="border-t border-border">
                <td className="px-3 py-1.5 font-mono tabular-nums">{row.cycle}</td>
                <td className="px-3 py-1.5 font-mono tabular-nums">{row.energy.toFixed(2)}</td>
                <td className="px-3 py-1.5 font-mono tabular-nums">{row.ece.toFixed(3)}</td>
                <td className="px-3 py-1.5 font-mono tabular-nums">{row.predErr.toFixed(3)}</td>
                <td className="px-3 py-1.5 font-mono">{row.action}</td>
                <td className="px-3 py-1.5">{row.mode}</td>
                <td className="px-3 py-1.5 font-mono tabular-nums">{row.entropy.toFixed(3)}</td>
                <td className="px-3 py-1.5 font-mono tabular-nums">{row.novelty.toFixed(3)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function Meta({ k, v }: { k: string; v: string }) {
  return (
    <div className="rounded-xl border border-border bg-bg-elevated px-3 py-2">
      <div className="text-[11px] uppercase tracking-wide text-subtle">{k}</div>
      <div className="truncate font-mono text-sm">{v}</div>
    </div>
  );
}
