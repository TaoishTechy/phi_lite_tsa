import { useEffect, useRef, useState } from "react";
import {
  attachVideo,
  cameraStream,
  micLive,
  startMediaLoops,
  subscribeMedia,
} from "@/lib/phi/media";
import { usePhi } from "@/lib/phi/store";

/** Always mounted. Keeps camera/mic sampling alive across views. */
export function MediaHost() {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const feedCamera = usePhi((s) => s.feedCamera);
  const feedMic = usePhi((s) => s.feedMic);
  const setCameraBound = usePhi((s) => s.setCameraBound);
  const setMicBound = usePhi((s) => s.setMicBound);
  const [on, setOn] = useState(false);

  useEffect(() => {
    return subscribeMedia(() => {
      attachVideo(videoRef.current);
      setOn(Boolean(cameraStream()));
      setCameraBound(Boolean(cameraStream()));
      setMicBound(micLive());
    });
  }, [setCameraBound, setMicBound]);

  useEffect(() => {
    attachVideo(videoRef.current);
  }, [on]);

  useEffect(() => {
    const v = videoRef.current;
    const c = canvasRef.current;
    if (!v || !c) return;
    return startMediaLoops(v, c, feedCamera, feedMic);
  }, [feedCamera, feedMic, on]);

  return (
    <div className="pointer-events-none absolute h-0 w-0 overflow-hidden" aria-hidden>
      <video ref={videoRef} muted playsInline autoPlay />
      <canvas ref={canvasRef} width={160} height={90} />
    </div>
  );
}
