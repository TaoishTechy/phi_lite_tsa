import { useEffect, useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { usePhi } from "@/lib/phi/store";
import { attachVideo, bindCamera, bindMic, cameraStream, micLive, releaseMedia, subscribeMedia } from "@/lib/phi/media";

export function SensorsPanel() {
  const videoRef = useRef<HTMLVideoElement>(null);
  const p = usePhi((s) => s.core.perception);
  const camErr = usePhi((s) => s.cameraError);
  const micErr = usePhi((s) => s.micError);
  const setCameraError = usePhi((s) => s.setCameraError);
  const setMicError = usePhi((s) => s.setMicError);
  const feedCamera = usePhi((s) => s.feedCamera);
  const [liveCam, setLiveCam] = useState(Boolean(cameraStream()));
  const [liveMic, setLiveMic] = useState(micLive());

  useEffect(() => {
    attachVideo(videoRef.current);
    return subscribeMedia(() => {
      attachVideo(videoRef.current);
      setLiveCam(Boolean(cameraStream()));
      setLiveMic(micLive());
    });
  }, []);

  async function openCamera() {
    try {
      await bindCamera();
      attachVideo(videoRef.current);
      setCameraError(null);
    } catch (e) {
      setCameraError(e instanceof Error ? e.message : "camera denied");
    }
  }

  async function openMic() {
    try {
      await bindMic();
      setMicError(null);
    } catch (e) {
      setMicError(e instanceof Error ? e.message : "microphone denied");
    }
  }

  function stopAll() {
    releaseMedia();
    feedCamera(null);
  }

  return (
    <div className="grid gap-4 md:grid-cols-2">
      <div className="rounded-xl border border-border bg-bg-elevated p-4">
        <div className="mb-3 flex items-center justify-between">
          <h3 className="text-sm font-medium">Camera</h3>
          <Badge tone={liveCam ? "ok" : "neutral"}>{liveCam ? "live" : "mock"}</Badge>
        </div>
        <video ref={videoRef} className="mb-3 h-40 w-full rounded-lg bg-bg object-cover" playsInline muted autoPlay />
        <div className="flex gap-2">
          <Button size="sm" onClick={openCamera}>
            Bind camera
          </Button>
          <Button size="sm" variant="outline" onClick={stopAll}>
            Release
          </Button>
        </div>
        {camErr ? <p className="mt-2 text-xs text-danger">{camErr}</p> : null}
        <p className="mt-2 font-mono text-xs text-muted">
          brightness {p.brightness.toFixed(3)} · motion {p.motion.toFixed(3)} · stays bound across views
        </p>
      </div>
      <div className="rounded-xl border border-border bg-bg-elevated p-4">
        <div className="mb-3 flex items-center justify-between">
          <h3 className="text-sm font-medium">Microphone</h3>
          <Badge tone={liveMic ? "ok" : "neutral"}>{liveMic ? "live" : "mock"}</Badge>
        </div>
        <div className="mb-3 h-40 overflow-hidden rounded-lg bg-bg">
          <div className="h-full bg-ok/30" style={{ width: `${Math.min(100, p.rms * 100)}%` }} />
        </div>
        <Button size="sm" onClick={openMic}>
          Bind microphone
        </Button>
        {micErr ? <p className="mt-2 text-xs text-danger">{micErr}</p> : null}
        <p className="mt-2 font-mono text-xs text-muted">rms {p.rms.toFixed(3)} · fail-closed if hardware missing</p>
      </div>
    </div>
  );
}

export function CameraPip() {
  const ref = useRef<HTMLVideoElement>(null);
  const bound = usePhi((s) => s.cameraBound);
  const p = usePhi((s) => s.core.perception);

  useEffect(() => {
    attachVideo(ref.current);
    return subscribeMedia(() => attachVideo(ref.current));
  }, [bound]);

  if (!bound) return null;
  return (
    <div className="overflow-hidden rounded-xl border border-border bg-bg-elevated">
      <video ref={ref} className="h-28 w-full object-cover md:h-36" playsInline muted autoPlay />
      <div className="px-3 py-2 font-mono text-[11px] text-muted">
        live · brightness {p.brightness.toFixed(2)} · motion {p.motion.toFixed(2)}
      </div>
    </div>
  );
}
