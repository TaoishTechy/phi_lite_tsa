import { Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { usePhi } from "@/lib/phi/store";

export function TelemetryChart() {
  const history = usePhi((s) => s.core.history);
  const data = history.slice(-180);
  return (
    <div className="h-44 w-full">
      <ResponsiveContainer width="100%" height="100%">
        <LineChart data={data} margin={{ top: 8, right: 8, left: 0, bottom: 0 }}>
          <XAxis dataKey="cycle" hide />
          <YAxis hide domain={[0, "auto"]} />
          <Tooltip
            contentStyle={{
              background: "#121214",
              border: "1px solid #26262c",
              borderRadius: 8,
              fontSize: 12,
              color: "#ececef",
            }}
          />
          <Line type="monotone" dataKey="energy" stroke="#e8eaee" strokeWidth={1.4} dot={false} isAnimationActive={false} />
          <Line type="monotone" dataKey="emergence" stroke="#7ee0d0" strokeWidth={1.2} dot={false} isAnimationActive={false} />
          <Line type="monotone" dataKey="predErr" stroke="#d4b07a" strokeWidth={1.2} dot={false} isAnimationActive={false} />
          <Line type="monotone" dataKey="ece" stroke="#e07a72" strokeWidth={1.1} dot={false} isAnimationActive={false} />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}
