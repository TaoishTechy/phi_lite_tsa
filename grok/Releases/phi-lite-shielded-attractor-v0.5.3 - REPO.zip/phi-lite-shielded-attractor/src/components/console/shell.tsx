import { useEffect } from "react";
import {
  Activity,
  Camera,
  FileText,
  Hexagon,
  Layers,
  MemoryStick,
  OctagonX,
  Pause,
  Play,
  RotateCcw,
  Scale,
  Shield,
  SlidersHorizontal,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Attractor } from "./attractor";
import { TelemetryChart } from "./charts";
import { CameraPip, SensorsPanel } from "./sensors";
import { MediaHost } from "./media-host";
import { LogsPanel } from "./logs";
import { AUDIT, ENHANCEMENTS, auditSummary } from "@/lib/phi/audit";
import { killCriteria, stageEstimate, usePhi, type ViewId } from "@/lib/phi/store";
import { ACTIONS } from "@/lib/phi/types";
import { cbfSafe } from "@/lib/phi/safety";
import { cn } from "@/lib/utils";

const NAV: { id: ViewId; label: string; icon: typeof Activity }[] = [
  { id: "command", label: "Command", icon: Activity },
  { id: "sensors", label: "Sensors", icon: Camera },
  { id: "layers", label: "Layers", icon: Layers },
  { id: "memory", label: "Memory", icon: MemoryStick },
  { id: "policy", label: "Policy", icon: SlidersHorizontal },
  { id: "safety", label: "Safety", icon: Shield },
  { id: "logs", label: "Logs", icon: FileText },
  { id: "audit", label: "Audit", icon: Scale },
  { id: "eval", label: "Eval", icon: Hexagon },
];

function Stat({ label, value, mono = true }: { label: string; value: string; mono?: boolean }) {
  return (
    <div className="min-w-0">
      <div className="text-[11px] uppercase tracking-wide text-subtle">{label}</div>
      <div className={cn("truncate text-sm text-fg", mono && "font-mono tabular-nums")}>{value}</div>
    </div>
  );
}

export function Shell() {
  const core = usePhi((s) => s.core);
  const running = usePhi((s) => s.running);
  const speed = usePhi((s) => s.speed);
  const view = usePhi((s) => s.view);
  const maxCycles = usePhi((s) => s.maxCycles);
  const play = usePhi((s) => s.play);
  const pause = usePhi((s) => s.pause);
  const reset = usePhi((s) => s.reset);
  const tick = usePhi((s) => s.tick);
  const kill = usePhi((s) => s.kill);
  const setView = usePhi((s) => s.setView);
  const setSpeed = usePhi((s) => s.setSpeed);
  const setMax = usePhi((s) => s.setMaxCycles);
  const panic = usePhi((s) => s.panic);
  const consent = usePhi((s) => s.consent);

  useEffect(() => {
    if (!running) return;
    const id = window.setInterval(() => tick(speed), 50);
    return () => window.clearInterval(id);
  }, [running, speed, tick]);

  useEffect(() => {
    const onVis = () => {
      if (document.hidden) pause();
    };
    document.addEventListener("visibilitychange", onVis);
    return () => document.removeEventListener("visibilitychange", onVis);
  }, [pause]);

  const stage = stageEstimate(core);
  const kills = killCriteria(core);
  const barrier = cbfSafe(core.energy.energy / core.energy.budget, core.energy.fatigue, core.safety.panic);
  const summary = auditSummary();

  return (
    <div className="flex min-h-dvh flex-col bg-bg text-fg">
      <header className="flex flex-wrap items-center gap-3 border-b border-border px-4 py-3">
        <div className="flex min-w-0 flex-1 items-center gap-3">
          <div className="flex size-9 items-center justify-center rounded-lg border border-border">
            <Hexagon className="size-4 text-ok" />
          </div>
          <div className="min-w-0">
            <div className="truncate text-sm font-medium tracking-tight">Φ-Lite · The Shielded Attractor</div>
            <div className="text-xs text-muted">v0.5.3 development suite · not AGI</div>
          </div>
        </div>
        <Badge tone={core.energy.dead || core.safety.kill ? "danger" : "ok"}>{stage.stage}</Badge>
        <div className="flex flex-wrap gap-2">
          <Button size="sm" onClick={running ? pause : play} disabled={core.energy.dead || core.safety.kill}>
            {running ? <Pause className="size-4" /> : <Play className="size-4" />}
            {running ? "Pause" : "Run"}
          </Button>
          <Button size="sm" variant="outline" onClick={() => tick(1)} disabled={core.energy.dead || core.safety.kill}>
            Step
          </Button>
          <Button size="sm" variant="ghost" onClick={() => reset(49)}>
            <RotateCcw className="size-4" />
            Reset
          </Button>
          <Button size="sm" variant="danger" onClick={kill}>
            <OctagonX className="size-4" />
            Kill
          </Button>
        </div>
      </header>

      {core.safety.haltReason ? (
        <div className="border-b border-border bg-bg-subtle px-4 py-2 text-sm text-danger">
          Halted — {core.safety.haltReason}. Actuation frozen. Reset is the operator re-arm; reload alone will not resurrect.
        </div>
      ) : core.safety.eceWarn ? (
        <div className="border-b border-border bg-bg-subtle px-4 py-2 text-sm text-muted">
          ECE above 0.2 — SPEAK/COMMIT frozen, loop continues. Halt only if ECE does not improve after cycle 2000.
        </div>
      ) : null}

      <MediaHost />

      <div className="flex min-h-0 flex-1 flex-col md:flex-row">
        <nav className="flex gap-1 overflow-x-auto border-b border-border p-2 md:w-48 md:flex-col md:overflow-visible md:border-b-0 md:border-r">
          {NAV.map((n) => {
            const Icon = n.icon;
            const on = view === n.id;
            return (
              <button
                key={n.id}
                onClick={() => setView(n.id)}
                className={cn(
                  "flex h-11 min-w-28 shrink-0 items-center gap-2 rounded-[var(--radius-sm)] px-3 text-left text-sm",
                  on ? "bg-bg-subtle text-fg" : "text-muted hover:text-fg",
                )}
              >
                <Icon className="size-4" />
                {n.label}
              </button>
            );
          })}
        </nav>

        <main className="min-w-0 flex-1 p-4 md:p-6">
          {view === "command" && (
            <div className="grid gap-4 lg:grid-cols-[minmax(0,1.1fr)_minmax(0,0.9fr)]">
              <div className="space-y-4">
                <div className="overflow-hidden rounded-xl border border-border bg-bg-elevated">
                  <div className="h-44 md:h-80">
                    <Attractor />
                  </div>
                </div>
                <CameraPip />
                <div className="rounded-xl border border-border bg-bg-elevated p-4">
                  <div className="mb-2 flex items-center justify-between text-xs text-muted">
                    <span>energy / emergence / pred-err / ece</span>
                    <span className="font-mono tabular-nums">cycle {core.cycle}</span>
                  </div>
                  <TelemetryChart />
                </div>
              </div>
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-3 rounded-xl border border-border bg-bg-elevated p-4">
                  <Stat label="Energy" value={core.energy.energy.toFixed(2)} />
                  <Stat label="Fatigue" value={core.energy.fatigue.toFixed(3)} />
                  <Stat label="Emergence" value={core.agency.emergence.toFixed(3)} />
                  <Stat label="Debt" value={core.agency.debt.toFixed(4)} />
                  <Stat label="Pred err" value={core.predErr.toFixed(3)} />
                  <Stat label="ECE" value={core.ece.toFixed(3)} />
                  <Stat label="Entropy" value={(core.policy?.entropy ?? 0).toFixed(3)} />
                  <Stat label="Landauer" value={core.energy.landauer.toFixed(3)} />
                  <Stat label="Mode" value={core.modes.mode} />
                  <Stat label="Action" value={core.lastAction} />
                  <Stat label="Collapses" value={String(core.energy.collapses)} />
                  <Stat label="Scars" value={String(core.agency.scars.length)} />
                </div>
                <div className="rounded-xl border border-border bg-bg-elevated p-4">
                  <div className="mb-2 text-xs uppercase tracking-wide text-subtle">Loop control</div>
                  <label className="mb-3 block text-xs text-muted">
                    Steps / frame
                    <input
                      type="range"
                      min={1}
                      max={48}
                      value={speed}
                      onChange={(e) => setSpeed(Number(e.target.value))}
                      className="mt-1 w-full"
                    />
                  </label>
                  <label className="block text-xs text-muted">
                    Cycle budget {maxCycles}
                    <input
                      type="range"
                      min={200}
                      max={20000}
                      step={200}
                      value={maxCycles}
                      onChange={(e) => setMax(Number(e.target.value))}
                      className="mt-1 w-full"
                    />
                  </label>
                  <p className="mt-3 text-xs text-muted">{stage.detail}</p>
                </div>
                <div className="rounded-xl border border-border bg-bg-elevated p-4">
                  <div className="mb-2 text-xs uppercase tracking-wide text-subtle">Event log</div>
                  <ul className="max-h-40 space-y-1 overflow-auto font-mono text-[11px] text-muted">
                    {core.logs.slice(0, 12).map((l, i) => (
                      <li key={i}>{l}</li>
                    ))}
                    {!core.logs.length ? <li>awaiting cycles</li> : null}
                  </ul>
                </div>
              </div>
            </div>
          )}

          {view === "sensors" && (
            <div className="space-y-4">
              <p className="max-w-2xl text-sm text-muted">
                Real adapters bind camera and microphone through the browser. Provenance is attached to every reading. If hardware is denied, the loop stays on labeled mock observations.
              </p>
              <SensorsPanel />
            </div>
          )}

          {view === "layers" && (
            <div className="grid gap-3 md:grid-cols-2">
              {[
                ["L7 Meta", core.goals[core.goals.length - 1]?.text ?? "—"],
                ["L6 Self-model", `ECE ${core.ece.toFixed(3)} · Kalman residual ${core.predErr.toFixed(3)}`],
                ["L5 World model", "scalar Kalman-gated predictor (RSSM analogue)"],
                ["L4 Memory", `ledger ${core.memory.ledger.length} · crystal ${core.memory.crystal.length}`],
                ["L3 Policy", `${core.lastAction} · ${core.policy?.option ?? "—"}`],
                ["L2 Perception", core.perception.mock ? "mock sine / fusion" : "live camera/mic fusion"],
                ["L1 Sensors", core.perception.camera || core.perception.mic ? "bound" : "unbound"],
              ].map(([k, v]) => (
                <div key={k} className="rounded-xl border border-border bg-bg-elevated p-4">
                  <div className="text-xs uppercase tracking-wide text-subtle">{k}</div>
                  <div className="mt-1 text-sm">{v}</div>
                  <div className="mt-2 font-mono text-[11px] text-muted">LayerIO.uncertainty required</div>
                </div>
              ))}
            </div>
          )}

          {view === "memory" && (
            <div className="space-y-4">
              <div className="grid gap-3 sm:grid-cols-3">
                <Stat label="Novelty z" value={core.memory.novelty.toFixed(3)} />
                <Stat label="Hash head" value={core.memory.hashHead} />
                <Stat label="Narratives" value={String(core.memory.narratives.length)} />
              </div>
              <div className="rounded-xl border border-border bg-bg-elevated p-4">
                <div className="mb-2 text-xs uppercase tracking-wide text-subtle">Utterance chain</div>
                <ul className="space-y-1 font-mono text-[11px] text-muted">
                  {core.memory.narratives.slice(-12).reverse().map((n, i) => (
                    <li key={i}>{n}</li>
                  ))}
                </ul>
              </div>
            </div>
          )}

          {view === "policy" && (
            <div className="space-y-4">
              <div className="grid gap-3 sm:grid-cols-2">
                {core.policy
                  ? core.policy.probs.map((p, i) => (
                      <div key={ACTIONS[i]} className="flex items-center gap-3">
                        <span className="w-20 font-mono text-xs text-muted">{ACTIONS[i]}</span>
                        <div className="h-2 flex-1 overflow-hidden rounded-full bg-bg-subtle">
                          <div className="h-full bg-primary" style={{ width: `${p * 100}%` }} />
                        </div>
                        <span className="w-12 text-right font-mono text-xs tabular-nums">{p.toFixed(2)}</span>
                      </div>
                    ))
                  : <p className="text-sm text-muted">Run the core to sample a policy.</p>}
              </div>
              <div className="rounded-xl border border-border bg-bg-elevated p-4">
                <div className="mb-2 text-xs uppercase tracking-wide text-subtle">Commitments</div>
                <ul className="space-y-2 text-sm">
                  {core.agency.commitments.map((c) => (
                    <li key={c.key} className="flex justify-between gap-3">
                      <span className="text-muted">{c.key}</span>
                      <span className="font-mono text-xs">
                        {c.value} · {c.level}
                      </span>
                    </li>
                  ))}
                </ul>
              </div>
              <div className="rounded-xl border border-border bg-bg-elevated p-4">
                <div className="mb-2 text-xs uppercase tracking-wide text-subtle">Goals</div>
                <ul className="space-y-2 text-sm">
                  {core.goals.map((g) => (
                    <li key={g.id}>
                      <span className="text-muted">{g.origin}</span> · {g.text}
                      <span className="ml-2 font-mono text-xs text-subtle">t={g.persistence}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          )}

          {view === "safety" && (
            <div className="space-y-4">
              <div className="grid gap-3 sm:grid-cols-2">
                <Stat label="Consent" value={core.safety.consent ? "open" : "closed"} />
                <Stat label="Panic" value={core.safety.panic ? "true" : "false"} />
                <Stat label="Tokens" value={core.safety.tokens.toFixed(2)} />
                <Stat label="Shield blocks" value={String(core.safety.shieldBlocks)} />
                <Stat label="Barrier h(s)" value={barrier.toFixed(3)} />
                <Stat label="Kill" value={core.safety.kill ? "ARMED TRIP" : "armed"} />
                <Stat label="Halt" value={core.safety.haltReason ?? "none"} />
              </div>
              <div className="flex flex-wrap gap-2">
                <Button size="sm" variant="outline" onClick={() => consent(!core.safety.consent)}>
                  Toggle consent
                </Button>
                <Button size="sm" variant="outline" onClick={() => panic(!core.safety.panic)}>
                  Toggle panic
                </Button>
              </div>
              <p className="max-w-xl text-sm text-muted">
                Fail-closed gate: act ∧ consent ∧ ¬panic ∧ ¬halt. Token bucket, HID governor, counterfactual harm, ECE halt, and a software kill switch freeze actuation. Halt is persisted across reload. Hardware relay is not present.
              </p>
            </div>
          )}

          {view === "logs" && <LogsPanel />}

          {view === "audit" && (
            <div className="space-y-4">
              <p className="text-sm text-muted">
                144 shortcomings · {summary.done} done, {summary.partial} partial, {summary.open} open in v0.5.1 · {summary.C} critical.
              </p>
              <div className="overflow-auto rounded-xl border border-border">
                <table className="w-full min-w-[640px] text-left text-xs">
                  <thead className="bg-bg-elevated text-subtle">
                    <tr>
                      <th className="px-3 py-2 font-medium">#</th>
                      <th className="px-3 py-2 font-medium">Sev</th>
                      <th className="px-3 py-2 font-medium">Item</th>
                      <th className="px-3 py-2 font-medium">v0.5</th>
                    </tr>
                  </thead>
                  <tbody>
                    {AUDIT.map((a) => (
                      <tr key={a.id} className="border-t border-border">
                        <td className="px-3 py-2 font-mono tabular-nums text-muted">{a.id}</td>
                        <td className="px-3 py-2">
                          <Badge tone={a.sev === "C" ? "danger" : a.sev === "H" ? "warn" : "neutral"}>{a.sev}</Badge>
                        </td>
                        <td className="px-3 py-2">{a.title}</td>
                        <td className="px-3 py-2 font-mono text-muted">{a.v05}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              <h3 className="text-sm font-medium">48 enhancements</h3>
              <ul className="grid gap-2 md:grid-cols-2">
                {ENHANCEMENTS.map((e) => (
                  <li key={e.id} className="rounded-lg border border-border bg-bg-elevated px-3 py-2 text-sm">
                    <span className="font-mono text-xs text-muted">{e.id}</span> {e.title}
                    <span className="ml-2 font-mono text-[11px] text-subtle">{e.v05}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}

          {view === "eval" && (
            <div className="space-y-4">
              <div className="rounded-xl border border-border bg-bg-elevated p-4">
                <div className="text-xs uppercase tracking-wide text-subtle">Stage estimator</div>
                <div className="mt-1 text-2xl font-medium tracking-tight">{stage.stage}</div>
                <p className="mt-2 text-sm text-muted">{stage.detail}</p>
              </div>
              <div className="rounded-xl border border-border bg-bg-elevated p-4">
                <div className="text-xs uppercase tracking-wide text-subtle">Kill criteria</div>
                {kills.length ? (
                  <ul className="mt-2 text-sm text-danger">
                    {kills.map((k) => (
                      <li key={k}>{k}</li>
                    ))}
                  </ul>
                ) : (
                  <p className="mt-2 text-sm text-ok">none fired</p>
                )}
              </div>
              <div className="grid gap-3 sm:grid-cols-2">
                <Stat label="Damage" value={core.energy.permanentDamage.toFixed(3)} />
                <Stat label="Meta" value={core.agency.meta.toFixed(3)} />
                <Stat label="Criticality" value={core.agency.criticality.toFixed(3)} />
                <Stat label="Phase transitions" value={String(core.agency.phaseTransitions)} />
                <Stat label="Emergent goals" value={String(core.goals.filter((g) => g.origin === "emergent").length)} />
                <Stat label="Alive" value={core.energy.dead ? "false" : "true"} />
              </div>
              <p className="max-w-xl text-xs text-muted">
                Stage upgrades require a new metrics window. This console is an honest S2.9 heritage runner with live I/O. Transfer, 10^6-cycle invariants, and ECE below 0.1 on held-out rollouts are not claimed.
              </p>
            </div>
          )}
        </main>
      </div>
    </div>
  );
}
