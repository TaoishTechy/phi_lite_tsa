import { useEffect, useRef } from "react";
import { usePhi } from "@/lib/phi/store";

export function Attractor() {
  const ref = useRef<HTMLCanvasElement>(null);
  const cycle = usePhi((s) => s.core.cycle);
  const energy = usePhi((s) => s.core.energy);
  const mode = usePhi((s) => s.core.modes.mode);
  const emergence = usePhi((s) => s.core.agency.emergence);
  const kill = usePhi((s) => s.core.safety.kill);
  const panic = usePhi((s) => s.core.safety.panic);
  const tokens = usePhi((s) => s.core.safety.tokens);

  useEffect(() => {
    const c = ref.current;
    if (!c) return;
    const ctx = c.getContext("2d");
    if (!ctx) return;
    const dpr = Math.min(2, window.devicePixelRatio || 1);
    const w = c.clientWidth;
    const h = c.clientHeight;
    c.width = w * dpr;
    c.height = h * dpr;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.fillStyle = "#09090b";
    ctx.fillRect(0, 0, w, h);

    const cx = w / 2;
    const cy = h / 2;
    const sat = energy.energy / Math.max(1, energy.budget);
    const R = Math.min(w, h) * 0.38;

    ctx.strokeStyle = "rgba(232,234,238,0.12)";
    ctx.lineWidth = 1;
    for (let i = 1; i <= 4; i++) {
      ctx.beginPath();
      ctx.arc(cx, cy, (R * i) / 4, 0, Math.PI * 2);
      ctx.stroke();
    }

    ctx.save();
    ctx.translate(cx, cy);
    ctx.rotate(cycle * 0.01);
    ctx.beginPath();
    for (let i = 0; i < 6; i++) {
      const a = (Math.PI / 3) * i - Math.PI / 2;
      const x = Math.cos(a) * R * 1.12;
      const y = Math.sin(a) * R * 1.12;
      if (i === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    }
    ctx.closePath();
    ctx.strokeStyle = kill ? "rgba(224,122,114,0.7)" : panic ? "rgba(212,176,122,0.7)" : "rgba(126,224,208,0.55)";
    ctx.lineWidth = 1.5;
    ctx.stroke();
    ctx.restore();

    const t = cycle * 0.04;
    ctx.beginPath();
    const rx = R * (0.28 + 0.22 * sat);
    const ry = R * (0.18 + 0.12 * (1 - energy.fatigue));
    ctx.ellipse(cx, cy, rx, ry, t, 0, Math.PI * 2);
    ctx.strokeStyle = "rgba(232,234,238,0.55)";
    ctx.stroke();
    ctx.beginPath();
    ctx.ellipse(cx, cy, ry * 0.9, rx * 0.7, -t * 0.7, 0, Math.PI * 2);
    ctx.strokeStyle = "rgba(126,224,208,0.45)";
    ctx.stroke();

    const px = cx + Math.cos(t) * rx;
    const py = cy + Math.sin(t) * ry;
    ctx.beginPath();
    ctx.arc(px, py, 3.5, 0, Math.PI * 2);
    ctx.fillStyle = "#e8eaee";
    ctx.fill();

    ctx.beginPath();
    ctx.arc(cx, cy, 3 + emergence * 6, 0, Math.PI * 2);
    ctx.fillStyle = energy.dead ? "#e07a72" : "#7ee0d0";
    ctx.fill();

    ctx.fillStyle = "#9a9aa3";
    ctx.font = "11px 'IBM Plex Mono', monospace";
    ctx.fillText(mode, 12, 18);
    ctx.fillText(`tok ${tokens.toFixed(1)}`, 12, h - 12);
  }, [cycle, energy, mode, emergence, kill, panic, tokens]);

  return <canvas ref={ref} className="h-full w-full" aria-label="Shielded attractor" />;
}
