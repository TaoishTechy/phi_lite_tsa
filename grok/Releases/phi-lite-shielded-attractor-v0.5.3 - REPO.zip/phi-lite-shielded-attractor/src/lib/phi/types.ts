export const SYSTEM_MODES = [
  "EXPLOIT",
  "CONSOLIDATE",
  "REFLECT",
  "EXPLORE",
  "ENCAPSULATED",
  "PROPHETIC",
  "PRESENT_LOCKED",
  "SUPERSOLID",
  "TIME_CRYSTAL",
] as const;

export type SystemMode = (typeof SYSTEM_MODES)[number];

export const COMMITMENT_LEVELS = [
  "VOLATILE",
  "ADMIXED",
  "STABLE",
  "CRYSTALLIZED",
  "FIXED",
] as const;

export type CommitmentLevel = (typeof COMMITMENT_LEVELS)[number];

export const ACTIONS = [
  "LISTEN",
  "SPEAK",
  "REPAIR",
  "PLAN",
  "REST",
  "EXPLORE",
  "COMMIT",
  "SHIELD",
] as const;

export type Action = (typeof ACTIONS)[number];

export type LayerIO = {
  state: number[];
  uncertainty: number;
  cost: number;
  meta: Record<string, string | number | boolean>;
};

export type GoalSpec = {
  id: string;
  text: string;
  origin: "designer" | "emergent";
  born: number;
  persistence: number;
  signature: number;
};

export type Commitment = {
  key: string;
  value: string;
  level: CommitmentLevel;
  age: number;
  changes: number;
};

export type Scar = {
  id: string;
  origin: string;
  subsystem: string;
  strength: number;
  born: number;
};

export type CycleSnapshot = {
  cycle: number;
  energy: number;
  fatigue: number;
  emergence: number;
  debt: number;
  mode: SystemMode;
  entropy: number;
  predErr: number;
  ece: number;
  novelty: number;
  landauer: number;
  alive: boolean;
  uncertainty: number;
  action: Action;
};

export type FalsificationResult = {
  name: string;
  passed: boolean;
  detail: string;
};

export type SensorReading = {
  modality: "CAMERA" | "MICROPHONE" | "MOCK";
  value: number[];
  timestamp: number;
  isMock: boolean;
  provenance: string;
};
