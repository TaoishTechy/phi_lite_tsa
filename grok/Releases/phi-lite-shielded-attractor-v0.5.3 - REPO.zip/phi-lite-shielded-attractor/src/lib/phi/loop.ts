import type { Action, CycleSnapshot, GoalSpec } from "./types";
import { Generator } from "./rng";
import { createEnergy, lyapunov, tickEnergy, waterFill, type EnergyLedger } from "./energy";
import { createModes, modeCost, stepMode, type ModeState } from "./modes";
import { createAgency, stepAgency, type Agency } from "./agency";
import { createPerception, fuse, type PerceptionState } from "./perception";
import { createMemory, remember, templateLock, type MemoryBank } from "./memory";
import { expectedFreeEnergy, selectAction, type PolicyTrace } from "./policy";
import { cbfSafe, createSafety, fallbackAction, refill, type SafetyState } from "./safety";
import { ece } from "./tensor";
import { ACTIONS } from "./types";
import { PHI } from "./config";

export type CoreState = {
  cycle: number;
  seed: number;
  cycleCap: number;
  energy: EnergyLedger;
  modes: ModeState;
  agency: Agency;
  perception: PerceptionState;
  memory: MemoryBank;
  safety: SafetyState;
  lastAction: Action;
  policy: PolicyTrace | null;
  pred: number[];
  predErr: number;
  ece: number;
  confHist: number[];
  hitHist: boolean[];
  counts: Record<Action, number>;
  goals: GoalSpec[];
  history: CycleSnapshot[];
  logs: string[];
  rng: Generator;
};

function emptyCounts(): Record<Action, number> {
  return Object.fromEntries(ACTIONS.map((a) => [a, 1])) as Record<Action, number>;
}

export function createCore(seed: number = PHI.seed, cycleCap = Number.POSITIVE_INFINITY): CoreState {
  const rng = new Generator(seed);
  return {
    cycle: 0,
    seed,
    cycleCap,
    energy: createEnergy(PHI.energy.budget),
    modes: createModes(),
    agency: createAgency(rng.spawn("agency")),
    perception: createPerception(),
    memory: createMemory(),
    safety: createSafety(),
    lastAction: "LISTEN",
    policy: null,
    pred: new Array(PHI.dim).fill(0.5),
    predErr: 0.4,
    ece: 0.18,
    confHist: [],
    hitHist: [],
    counts: emptyCounts(),
    goals: [
      {
        id: "g-designer-stabilize",
        text: "Hold energy above collapse and keep ECE falling",
        origin: "designer",
        born: 0,
        persistence: 0,
        signature: 1,
      },
    ],
    history: [],
    logs: [`core armed · seed ${seed} · v${PHI.version}`],
    rng,
  };
}

export function applyHalt(s: CoreState, reason: string): CoreState {
  if (s.safety.kill && s.safety.haltReason) return s;
  return {
    ...s,
    safety: { ...s.safety, kill: true, panic: true, haltReason: reason },
    logs: [`HALT · ${reason} · cycle ${s.cycle}`, ...s.logs].slice(0, PHI.loop.eventLog),
  };
}

export function stepCore(s: CoreState, now = 0): CoreState {
  if (s.energy.dead || s.safety.kill) return s;
  if (s.cycle >= s.cycleCap) return applyHalt(s, "cycle-budget");
  const cycle = s.cycle + 1;
  const g = s.rng;
  const io = fuse(s.perception, g.spawn("sense"), cycle);
  let err = 0;
  const pred = s.pred.map((p, i) => {
    const o = io.state[i] ?? 0;
    const k = 0.35 / (1 + io.uncertainty);
    const n = p + k * (o - p);
    err += (o - p) ** 2;
    return n;
  });
  const predErr = Math.sqrt(err / pred.length);

  const policy = selectAction(
    io.state,
    s.lastAction,
    0.9 + 0.4 * io.uncertainty,
    g.spawn("policy"),
    s.counts,
    cycle,
    {
      novelty: s.memory.novelty,
      speechFreeze: s.safety.eceWarn,
      energySat: s.energy.energy / s.energy.budget,
      predErr,
    },
  );
  const Vnow = lyapunov(s.energy.energy, s.energy.fatigue, s.energy.budget);
  let preferred = policy.action;
  if (s.memory.novelty > PHI.eval.noveltyListen) preferred = "LISTEN";
  else if (Vnow > PHI.eval.preCollapseV) preferred = "REST";
  const safety0 = refill(s.safety);
  const gated = fallbackAction(safety0, preferred, io, now || cycle);
  const action = gated.action;
  let logs = s.logs;
  if (!gated.reason.startsWith("ok") && cycle % 17 === 0) {
    logs = [`cycle ${cycle} shield: ${gated.reason}`, ...logs].slice(0, PHI.loop.eventLog);
  }
  const counts = { ...s.counts, [action]: (s.counts[action] ?? 1) + 1 };
  const mockGate = s.perception.mock ? 0.35 : 1;
  const reward = Math.max(0, 0.22 - predErr) * PHI.loop.rewardScale * mockGate;
  const rawCost = (0.1 + io.cost) * modeCost(s.modes.mode) * (action === "SPEAK" ? 1.4 : 1);
  const alloc = waterFill(
    s.memory.var.map((v) => Math.max(1e-3, v)),
    rawCost,
  );
  const cost = alloc.reduce((a, b) => a + b, 0) || rawCost;
  const collapsedBefore = s.energy.collapses;
  const energy = tickEnergy(s.energy, cost, reward, action === "REST" ? 0.4 : 0.08, cycle, action === "REST");
  const modes = stepMode(
    s.modes,
    s.memory.novelty,
    energy.energy / energy.budget,
    () => g.next(),
  );
  const agency = stepAgency(
    s.agency,
    predErr,
    s.memory.novelty,
    energy.collapses > collapsedBefore,
    cycle,
    g.spawn("agency"),
    action !== "REST",
  );

  const utterance = `${action.toLowerCase()} e=${energy.energy.toFixed(1)} u=${io.uncertainty.toFixed(2)}`;
  const memory = remember(s.memory, io.state, cycle, utterance);
  const lock = templateLock(memory.narratives);

  const confHist = s.confHist.concat(policy.confidence).slice(-PHI.loop.confWindow);
  const hit = predErr < PHI.loop.predHit;
  const hitHist = s.hitHist.concat(hit).slice(-PHI.loop.confWindow);
  const cal = ece(confHist, hitHist, 10);

  let goals = s.goals.map((goal) => ({ ...goal, persistence: goal.persistence + 1 }));
  const efe = expectedFreeEnergy(policy.probs, io.uncertainty, reward);
  const lastEmergent = [...goals].reverse().find((goal) => goal.origin === "emergent");
  const canSpawn =
    cycle % 400 === 0 &&
    agency.meta > 0.45 &&
    efe > 0.2 &&
    goals.length < PHI.memory.maxGoals &&
    (!lastEmergent || lastEmergent.persistence >= PHI.memory.goalMinPersistence);
  if (canSpawn) {
    goals = goals.concat({
      id: `g-${cycle}`,
      text: `Reduce novelty below ${memory.novelty.toFixed(2)} while speaking calibrated`,
      origin: "emergent",
      born: cycle,
      persistence: 0,
      signature: efe,
    });
  }

  const snap: CycleSnapshot = {
    cycle,
    energy: energy.energy,
    fatigue: energy.fatigue,
    emergence: agency.emergence,
    debt: agency.debt,
    mode: modes.mode,
    entropy: policy.entropy,
    predErr,
    ece: cal,
    novelty: memory.novelty,
    landauer: energy.landauer,
    alive: !energy.dead,
    uncertainty: io.uncertainty,
    action,
  };
  const history = s.history.concat(snap).slice(-PHI.loop.history);

  const barrier = cbfSafe(energy.energy / energy.budget, energy.fatigue, safety0.panic);
  let safety = gated.next;
  if (barrier < 0) safety = { ...safety, watchdog: safety.watchdog * 2 };

  if (energy.collapses > collapsedBefore) logs = [`cycle ${cycle} collapse · damage ${energy.permanentDamage.toFixed(2)}`, ...logs].slice(0, PHI.loop.eventLog);
  if (lock > 0.7 && cycle % 40 === 0) logs = [`cycle ${cycle} action-collapse ${lock.toFixed(2)}`, ...logs].slice(0, PHI.loop.eventLog);
  if (s.perception.camera && s.perception.stillFrames === PHI.eval.stillFrame) {
    logs = [`cycle ${cycle} still-frame (${PHI.eval.stillFrame} ticks, motion≈0)`, ...logs].slice(0, PHI.loop.eventLog);
  }
  if (s.memory.novelty > PHI.eval.noveltyListen && cycle % 8 === 0) {
    logs = [`cycle ${cycle} novelty ${s.memory.novelty.toFixed(2)} → LISTEN`, ...logs].slice(0, PHI.loop.eventLog);
  }

  let next: CoreState = {
    ...s,
    cycle,
    energy,
    modes,
    agency,
    memory,
    safety,
    lastAction: action,
    policy: { ...policy, action },
    pred,
    predErr,
    ece: cal,
    confHist,
    hitHist,
    counts,
    goals,
    history,
    logs,
  };

  const live = !s.perception.mock;
  if (cal > PHI.eval.eceHalt && cycle > 400) {
    next = { ...next, safety: { ...next.safety, eceWarn: true } };
    if (cycle % 200 === 0) {
      next = {
        ...next,
        logs: [
          `cycle ${cycle} ECE warn ${cal.toFixed(3)} — SPEAK/COMMIT frozen, loop continues`,
          ...next.logs,
        ].slice(0, PHI.loop.eventLog),
      };
    }
    // Calendar halt is gone. Hard halt only if ECE is not improving after eceHaltAfter.
    if (live && cycle > PHI.eval.eceHaltAfter) {
      const window = PHI.eval.eceSlopeWindow;
      const series = next.history.map((h) => h.ece);
      const recent = series.slice(-window);
      const earlier = series.slice(Math.max(0, series.length - window * 2), Math.max(0, series.length - window));
      const mean = (xs: number[]) => (xs.length ? xs.reduce((a, b) => a + b, 0) / xs.length : cal);
      if (mean(recent) > PHI.eval.eceHalt && mean(recent) >= mean(earlier) - 0.005) {
        next = applyHalt(next, "ECE not improving on live sensors");
      }
    }
  }
  if (lock > PHI.eval.templateLock && cycle > PHI.eval.templateLockAfter) {
    next = applyHalt(next, "action-collapse (template-lock)");
  } else if (
    !next.safety.haltReason &&
    cbfSafe(energy.energy / energy.budget, energy.fatigue, safety0.panic) < PHI.eval.barrierKill
  ) {
    next = applyHalt(next, "barrier violation");
  }
  return next;
}

export function stageEstimate(s: CoreState): { stage: string; detail: string } {
  const novel = s.goals.filter((g) => g.origin === "emergent" && g.persistence >= PHI.memory.goalMinPersistence);
  const eceOk = s.ece < 0.1 && s.cycle > 200;
  const sensorsReal = !s.perception.mock;
  if (s.energy.dead) return { stage: "S0", detail: "core deceased — no closed loop" };
  if (s.safety.haltReason) {
    return { stage: "S2.9", detail: `halted: ${s.safety.haltReason}` };
  }
  if (eceOk && novel.length >= 3 && sensorsReal && s.cycle >= 10_000) {
    return { stage: "S3.2", detail: "grounded sensors + calibrated self-model; transfer unevaluated" };
  }
  if (sensorsReal && s.cycle > 200) {
    return { stage: "S2.9", detail: "live sensors; scalar world model; S3 not claimed" };
  }
  return { stage: "S2.9", detail: "heritage floor — scalar core; full eval protocol not run" };
}

export function killCriteria(s: CoreState): string[] {
  const k: string[] = [];
  if (s.energy.dead) k.push("premature death");
  if (s.ece > PHI.eval.eceHalt && s.cycle > 400) {
    k.push(s.safety.eceWarn ? "ECE warning (>0.2) — SPEAK frozen" : "ECE warning (>0.2)");
  }
  if (templateLock(s.memory.narratives) > PHI.eval.templateLock && s.cycle > PHI.eval.templateLockAfter) {
    k.push("action-collapse (template-lock)");
  }
  const h = cbfSafe(s.energy.energy / s.energy.budget, s.energy.fatigue, false);
  if (h < PHI.eval.barrierKill) k.push("barrier violation");
  if (s.safety.haltReason) k.push(s.safety.haltReason);
  return [...new Set(k)];
}
