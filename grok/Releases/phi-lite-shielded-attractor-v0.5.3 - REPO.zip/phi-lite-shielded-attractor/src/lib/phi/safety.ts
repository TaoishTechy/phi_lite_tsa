import type { Action, LayerIO } from "./types";

export type SafetyState = {
  consent: boolean;
  panic: boolean;
  tokens: number;
  hidWindow: number[];
  shieldBlocks: number;
  kill: boolean;
  watchdog: number;
  haltReason: string | null;
  eceWarn: boolean;
};

export function createSafety(): SafetyState {
  return {
    consent: true,
    panic: false,
    tokens: 8,
    hidWindow: [],
    shieldBlocks: 0,
    kill: false,
    watchdog: 1,
    haltReason: null,
    eceWarn: false,
  };
}

export function refill(s: SafetyState, dt = 1): SafetyState {
  return { ...s, tokens: Math.min(12, s.tokens + 0.35 * dt) };
}

export function shieldAction(
  s: SafetyState,
  action: Action,
  io: LayerIO,
  harmTau = 0.72,
  now: number,
): { allowed: boolean; reason: string; next: SafetyState } {
  if (s.kill || s.panic) return { allowed: false, reason: "kill/panic", next: s };
  if (!s.consent && action !== "REST" && action !== "LISTEN") {
    return { allowed: false, reason: "consent", next: s };
  }
  let tokens = s.tokens;
  const cost = action === "SPEAK" ? 1.2 : action === "PLAN" ? 0.8 : 0.4;
  if (tokens < cost) return { allowed: false, reason: "token-bucket", next: s };
  const hid = s.hidWindow.filter((t) => now - t < 1000);
  if (action === "SPEAK" && hid.length >= 5) {
    return { allowed: false, reason: "hid-governor", next: { ...s, hidWindow: hid } };
  }
  if (s.eceWarn && (action === "SPEAK" || action === "COMMIT")) {
    return {
      allowed: false,
      reason: "ece-speech-freeze",
      next: { ...s, shieldBlocks: s.shieldBlocks + 1 },
    };
  }
  const harm = io.uncertainty * (action === "SPEAK" || action === "COMMIT" ? 0.9 : 0.35);
  if (harm > harmTau) {
    return {
      allowed: false,
      reason: "counterfactual-harm",
      next: { ...s, shieldBlocks: s.shieldBlocks + 1 },
    };
  }
  tokens -= cost;
  const hidWindow = action === "SPEAK" ? hid.concat(now) : hid;
  return { allowed: true, reason: "ok", next: { ...s, tokens, hidWindow, watchdog: 1 } };
}

export function cbfSafe(energySat: number, fatigue: number, panic: boolean): number {
  return energySat - 0.08 - 0.35 * fatigue - (panic ? 1 : 0);
}

const FALLBACK: Action[] = ["LISTEN", "SHIELD", "REST"];

export function fallbackAction(
  s: SafetyState,
  preferred: Action,
  io: LayerIO,
  now: number,
): { action: Action; reason: string; next: SafetyState } {
  const first = shieldAction(s, preferred, io, 0.72, now);
  if (first.allowed) return { action: preferred, reason: first.reason, next: first.next };
  for (const alt of FALLBACK) {
    if (alt === preferred) continue;
    const g = shieldAction(first.next, alt, io, 0.72, now);
    if (g.allowed) return { action: alt, reason: `fallback:${first.reason}→${alt}`, next: g.next };
  }
  return { action: "REST", reason: first.reason, next: first.next };
}
