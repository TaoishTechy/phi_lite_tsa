/** Deterministic mulberry32 with SHA-style stream forks (audit #21/#22). */
export class Generator {
  private s: number;
  readonly seed: number;
  readonly stream: string;

  constructor(seed: number, stream = "") {
    this.seed = seed >>> 0;
    this.stream = stream;
    this.s = this.seed || 1;
  }

  spawn(stream: string): Generator {
    const salt = (this.next() * 0xffffffff) >>> 0;
    const h = hash32(`${this.seed}:${this.s}:${stream}:${salt}`);
    return new Generator(h || 1, stream);
  }

  next(): number {
    let t = (this.s += 0x6d2b79f5);
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  }

  uniform(lo = 0, hi = 1): number {
    return lo + (hi - lo) * this.next();
  }

  gauss(mean = 0, std = 1): number {
    const u = Math.max(1e-12, this.next());
    const v = this.next();
    const z = Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v);
    return mean + std * z;
  }

  gumbel(): number {
    const u = Math.min(1 - 1e-12, Math.max(1e-12, this.next()));
    return -Math.log(-Math.log(u));
  }

  choice<T>(items: readonly T[]): T {
    if (!items.length) throw new Error("choice from empty sequence");
    return items[Math.floor(this.next() * items.length)]!;
  }
}

export function hash32(s: string): number {
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}
