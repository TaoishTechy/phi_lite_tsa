import assert from "node:assert/strict";
import { describe, it } from "node:test";
import { createEnergy, tickEnergy, waterFill } from "./energy.ts";

describe("energy homeostasis", () => {
  it("never exceeds budget under fat rewards", () => {
    let e = createEnergy(150);
    for (let i = 0; i < 5000; i++) {
      e = tickEnergy(e, 0.05, 40, 0.01);
      assert.ok(e.energy <= e.budget + 1e-9, `energy ${e.energy} > budget`);
    }
    assert.equal(e.dead, false);
    assert.ok("lastCollapse" in e);
  });

  it("water-fill sums to approximately the budget", () => {
    const alloc = waterFill([0.2, 0.8, 1.4, 0.05, 2.2, 0.4, 0.9, 1.1], 10);
    const s = alloc.reduce((a, b) => a + b, 0);
    assert.ok(Math.abs(s - 10) < 0.05, `sum ${s}`);
  });
});
