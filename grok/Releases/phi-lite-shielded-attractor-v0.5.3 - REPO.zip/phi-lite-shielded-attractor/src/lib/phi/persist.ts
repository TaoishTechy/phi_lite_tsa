/** Kill/halt marker — survives reload. Reset is the operator re-arm. */
export const HALT_KEY = "phi-lite:v05:halt";

export type HaltRecord = {
  reason: string;
  cycle: number;
  t: number;
};

function storage(): Storage | null {
  try {
    if (typeof localStorage === "undefined") return null;
    return localStorage;
  } catch {
    return null;
  }
}

export function writeHalt(record: HaltRecord): void {
  const s = storage();
  if (!s) return;
  s.setItem(HALT_KEY, JSON.stringify(record));
}

export function readHalt(): HaltRecord | null {
  const s = storage();
  if (!s) return null;
  const raw = s.getItem(HALT_KEY);
  if (!raw) return null;
  try {
    const v = JSON.parse(raw) as HaltRecord;
    if (!v || typeof v.reason !== "string") return null;
    return v;
  } catch {
    return null;
  }
}

export function clearHalt(): void {
  storage()?.removeItem(HALT_KEY);
}
