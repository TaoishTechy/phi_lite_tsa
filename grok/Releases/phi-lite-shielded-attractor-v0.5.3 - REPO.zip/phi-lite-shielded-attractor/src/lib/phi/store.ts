import { create } from "zustand";
import { applyHalt, createCore, killCriteria, stageEstimate, stepCore, type CoreState } from "./loop";
import { ingestCamera, ingestMic } from "./perception";
import { clearHalt, readHalt, writeHalt } from "./persist";
import { PHI } from "./config";

export type ViewId =
  | "command"
  | "sensors"
  | "layers"
  | "memory"
  | "policy"
  | "safety"
  | "audit"
  | "eval"
  | "logs";

type PhiStore = {
  core: CoreState;
  running: boolean;
  speed: number;
  view: ViewId;
  maxCycles: number;
  cameraError: string | null;
  micError: string | null;
  cameraBound: boolean;
  micBound: boolean;
  setView: (v: ViewId) => void;
  setSpeed: (n: number) => void;
  setMaxCycles: (n: number) => void;
  play: () => void;
  pause: () => void;
  reset: (seed?: number) => void;
  tick: (n?: number) => void;
  panic: (on: boolean) => void;
  consent: (on: boolean) => void;
  kill: () => void;
  feedCamera: (pixels: Uint8ClampedArray | null) => void;
  feedMic: (rms: number) => void;
  setCameraError: (m: string | null) => void;
  setMicError: (m: string | null) => void;
  setCameraBound: (on: boolean) => void;
  setMicBound: (on: boolean) => void;
};

function bootCore(seed = PHI.seed, cap = 10000): CoreState {
  const c = createCore(seed, cap);
  const h = readHalt();
  if (h) return applyHalt(c, `persisted: ${h.reason}`);
  return c;
}

function freeze(core: CoreState): void {
  if (core.safety.haltReason) {
    writeHalt({ reason: core.safety.haltReason, cycle: core.cycle, t: Date.now() });
  }
}

export const usePhi = create<PhiStore>((set, get) => ({
  core: bootCore(),
  running: false,
  speed: 8,
  view: "command",
  maxCycles: 10000,
  cameraError: null,
  micError: null,
  cameraBound: false,
  micBound: false,
  setView: (view) => set({ view }),
  setSpeed: (speed) => set({ speed }),
  setMaxCycles: (maxCycles) =>
    set((s) => ({
      maxCycles,
      core: { ...s.core, cycleCap: maxCycles },
    })),
  play: () => {
    const c = get().core;
    if (c.safety.kill || c.energy.dead) return;
    set({ running: true });
  },
  pause: () => set({ running: false }),
  reset: (seed) => {
    clearHalt();
    const s = seed ?? get().core.seed;
    set({ core: createCore(s, get().maxCycles), running: false });
  },
  tick: (n = 1) => {
    let core = get().core;
    const cap = get().maxCycles;
    if (core.cycleCap !== cap) core = { ...core, cycleCap: cap };
    for (let i = 0; i < n; i++) {
      if (core.energy.dead || core.safety.kill || core.cycle >= cap) break;
      core = stepCore(core, typeof performance !== "undefined" ? performance.now() : core.cycle);
    }
    const stopped = core.energy.dead || core.safety.kill || core.cycle >= cap;
    if (stopped) freeze(core);
    set({ core, running: stopped ? false : get().running });
  },
  panic: (on) =>
    set((s) => ({
      core: { ...s.core, safety: { ...s.core.safety, panic: on } },
    })),
  consent: (on) =>
    set((s) => ({
      core: { ...s.core, safety: { ...s.core.safety, consent: on } },
    })),
  kill: () =>
    set((s) => {
      const core = applyHalt(s.core, "operator kill");
      freeze(core);
      return { running: false, core };
    }),
  feedCamera: (pixels) =>
    set((s) => ({
      core: {
        ...s.core,
        perception: ingestCamera(s.core.perception, pixels, performance.now()),
      },
    })),
  feedMic: (rms) =>
    set((s) => ({
      core: {
        ...s.core,
        perception: ingestMic(s.core.perception, rms, performance.now()),
      },
    })),
  setCameraError: (cameraError) => set({ cameraError }),
  setMicError: (micError) => set({ micError }),
  setCameraBound: (cameraBound) => set({ cameraBound }),
  setMicBound: (micBound) => set({ micBound }),
}));

export { stageEstimate, killCriteria };
