import { ACTIONS, type Action } from "./types";
import { entropy, softmax } from "./tensor";
import type { Generator } from "./rng";
import { PHI } from "./config";

export type PolicyTrace = {
  action: Action;
  logits: number[];
  probs: number[];
  entropy: number;
  confidence: number;
  option: string;
};

export type PolicyHints = {
  novelty?: number;
  speechFreeze?: boolean;
  energySat?: number;
  predErr?: number;
};

const PAIR_BAN: Array<[Action, Action]> = [
  ["LISTEN", "REPAIR"],
  ["REPAIR", "LISTEN"],
];

export function selectAction(
  z: number[],
  last: Action,
  temperature: number,
  g: Generator,
  counts: Record<Action, number>,
  cycle: number,
  hints: PolicyHints = {},
): PolicyTrace {
  const novelty = hints.novelty ?? 0;
  const logits = ACTIONS.map((a, i) => {
    const feat = z[i % z.length] ?? 0;
    let v = 0.6 * feat + 0.3 * Math.sin((i + 1) * 1.7 + z[0]! * 2) + g.gauss(0, 0.05);
    if (PAIR_BAN.some(([x, y]) => x === last && y === a)) v -= 2.4;
    if (last === a) v -= a === "LISTEN" ? 0.2 : 1.65;
    const n = counts[a] || 0.5;
    v += 0.35 * Math.sqrt(Math.log(cycle + 2) / n);
    if (novelty > PHI.eval.noveltyListen) {
      if (a === "LISTEN") v += 2.4;
      if (a === "EXPLORE") v -= 1.1;
      if (a === "SPEAK") v -= 0.6;
    }
    if ((hints.energySat ?? 1) < 0.28 && (a === "REST" || a === "REPAIR")) v += 1.1;
    if ((hints.energySat ?? 1) < 0.28 && a === "EXPLORE") v -= 0.7;
    if (hints.speechFreeze && (a === "SPEAK" || a === "COMMIT")) v -= 10;
    return v;
  });
  const gumbel = logits.map((v) => v / temperature + g.gumbel());
  let idx = 0;
  for (let i = 1; i < gumbel.length; i++) if (gumbel[i]! > gumbel[idx]!) idx = i;
  const probs = softmax(logits, temperature);
  const action = ACTIONS[idx]!;
  const sorted = [...probs].sort((a, b) => b - a);
  const gap = Math.min(1, Math.max(0, (Math.log(sorted[0]! + 1e-9) - Math.log(sorted[1]! + 1e-9)) / 3 + 0.5));
  const resid = Math.max(0, Math.min(1, 1 - (hints.predErr ?? 0.3) / 0.4));
  const confidence = 0.72 * resid + 0.28 * gap;
  const option = action === "PLAN" ? "horizon-opt" : action === "EXPLORE" ? "curiosity" : "primitive";
  return {
    action,
    logits,
    probs,
    entropy: entropy(probs),
    confidence,
    option,
  };
}

export function expectedFreeEnergy(probs: number[], uncertainty: number, reward: number, lambda = 0.5): number {
  const H = entropy(probs);
  return H - lambda * reward + 0.4 * uncertainty;
}
