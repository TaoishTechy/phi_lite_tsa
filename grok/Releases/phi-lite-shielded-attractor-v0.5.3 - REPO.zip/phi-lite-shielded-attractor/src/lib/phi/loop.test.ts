import assert from "node:assert/strict";
import { describe, it } from "node:test";
import { applyHalt, createCore, killCriteria, stepCore } from "./loop.ts";
import { ACTIONS } from "./types.ts";
import { templateLock } from "./memory.ts";
import { Generator } from "./rng.ts";
import { createEnergy, tickEnergy } from "./energy.ts";
import { createPerception, fuse } from "./perception.ts";

describe("stepCore halt + thermodynamics", () => {
  it("does not calendar-halt in the first 800 cycles on mock", () => {
    let s = createCore(49, 5000);
    for (let i = 0; i < 800; i++) s = stepCore(s, i);
    assert.equal(s.safety.kill, false, s.safety.haltReason ?? "killed");
    assert.equal(s.cycle, 800);
    assert.equal(s.energy.dead, false);
    assert.ok(s.energy.energy <= s.energy.budget + 1e-6);
  });

  it("keeps energy inside the budget", () => {
    let s = createCore(49, 350);
    for (let i = 0; i < 350; i++) {
      if (s.safety.kill) break;
      s = stepCore(s, i);
      assert.ok(s.energy.energy <= s.energy.budget + 1e-6);
    }
  });

  it("does not REST on every cycle", () => {
    let s = createCore(49, 200);
    for (let i = 0; i < 120; i++) s = stepCore(s, i * 16);
    const seen = new Set(s.history.map((h) => h.action));
    assert.ok(seen.size >= 3, `actions ${[...seen].join(",")}`);
    assert.ok([...seen].every((a) => (ACTIONS as readonly string[]).includes(a)));
  });

  it("applyHalt is sticky", () => {
    const s = applyHalt(createCore(7), "operator kill");
    assert.equal(s.safety.kill, true);
    assert.equal(s.safety.panic, true);
    assert.equal(stepCore(s).cycle, 0);
  });

  it("templateLock ignores numeric telemetry", () => {
    const n = [
      "explore e=79.96 u=0.85",
      "explore e=79.10 u=0.84",
      "listen e=78.40 u=0.86",
      "repair e=77.20 u=0.81",
    ];
    assert.ok(templateLock(n.concat(n).concat(n).concat(n).concat(n).concat(n)) < 0.9);
    const same = Array.from({ length: 40 }, () => "explore e=10.0 u=0.1");
    assert.ok(templateLock(same) >= 0.9);
  });

  it("killCriteria does not invent a barrier from panic latch", () => {
    const s = applyHalt(createCore(49), "ECE not improving on live sensors");
    const k = killCriteria(s);
    assert.ok(!k.includes("barrier violation"), k.join(","));
  });
});

describe("v0.5.3 plant patches", () => {
  it("spawn forks actually differ", () => {
    const g = new Generator(49);
    const seen = new Set<string>();
    for (let i = 0; i < 12; i++) {
      seen.add(g.spawn("agency").choice(["perception", "memory", "executive", "adaptation"]));
    }
    assert.ok(seen.size >= 2, `all ${[...seen]}`);
  });

  it("fatigue at the ceiling recovers", () => {
    let e = createEnergy(150);
    e = { ...e, fatigue: 0.99, energy: 80 };
    for (let i = 1; i <= 80; i++) e = tickEnergy(e, 0.02, 0.2, 0.01, i, true);
    assert.ok(e.fatigue < 0.7, `fatigue ${e.fatigue}`);
    assert.equal(e.dead, false);
  });

  it("collapse refractory prevents per-cycle death spirals", () => {
    let e = createEnergy(150);
    e = { ...e, energy: 4, fatigue: 0.95 };
    e = tickEnergy(e, 0.2, 0, 0.08, 10, false);
    const n = e.collapses;
    for (let i = 11; i < 40; i++) e = tickEnergy(e, 0.2, 0, 0.08, i, false);
    assert.equal(e.collapses, n);
  });

  it("live fusion does not inject mock oscillators", () => {
    const p = createPerception();
    const live = {
      ...p,
      camera: {
        modality: "CAMERA" as const,
        value: [0.4, 0.1],
        timestamp: 1,
        isMock: false,
        provenance: "getUserMedia:video",
      },
      brightness: 0.4,
      motion: 0.1,
      rms: 0.05,
      mock: false,
    };
    const z0 = fuse(live, new Generator(1), 100).state;
    const z1 = fuse(live, new Generator(1), 117).state;
    assert.equal(z0[2], 0.4);
    assert.equal(z0[5], 0.4);
    assert.equal(z0[7], 0.1);
    assert.deepEqual(z0, z1);
  });
});
