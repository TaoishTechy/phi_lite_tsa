import type { LayerIO, SensorReading } from "./types";
import { softmax } from "./tensor";
import type { Generator } from "./rng";

export type PerceptionState = {
  z: number[];
  uncertainty: number;
  camera: SensorReading | null;
  mic: SensorReading | null;
  motion: number;
  brightness: number;
  rms: number;
  mock: boolean;
  stillFrames: number;
};

export function createPerception(): PerceptionState {
  return {
    z: new Array(8).fill(0),
    uncertainty: 0.5,
    camera: null,
    mic: null,
    motion: 0,
    brightness: 0,
    rms: 0,
    mock: true,
    stillFrames: 0,
  };
}

export function ingestCamera(prev: PerceptionState, pixels: Uint8ClampedArray | null, t: number): PerceptionState {
  if (!pixels || !pixels.length) return prev;
  let s = 0;
  const step = Math.max(1, Math.floor(pixels.length / 1200));
  let n = 0;
  for (let i = 0; i < pixels.length; i += 4 * step) {
    s += (pixels[i]! + pixels[i + 1]! + pixels[i + 2]!) / 3;
    n++;
  }
  const brightness = s / Math.max(1, n) / 255;
  const motion = Math.min(1, Math.abs(brightness - prev.brightness) * 8);
  const reading: SensorReading = {
    modality: "CAMERA",
    value: [brightness, motion],
    timestamp: t,
    isMock: false,
    provenance: "getUserMedia:video",
  };
  const stillFrames = motion < 0.012 ? prev.stillFrames + 1 : 0;
  return { ...prev, brightness, motion, camera: reading, mock: false, stillFrames };
}

export function ingestMic(prev: PerceptionState, rms: number, t: number): PerceptionState {
  const reading: SensorReading = {
    modality: "MICROPHONE",
    value: [rms],
    timestamp: t,
    isMock: false,
    provenance: "getUserMedia:audio",
  };
  return { ...prev, rms, mic: reading, mock: false };
}

export function fuse(p: PerceptionState, g: Generator, cycle: number): LayerIO {
  const live = Boolean(p.camera || p.mic);
  const camU = p.camera ? 0.15 + 0.4 * (1 - Math.min(1, p.motion + 0.2)) : 0.85;
  const micU = p.mic ? 0.2 + 0.5 * (1 - p.rms) : 0.9;
  const mockObs = [
    0.5 + 0.25 * Math.sin(cycle / 17),
    0.5 + 0.2 * Math.cos(cycle / 11),
    g.gauss(0, 0.08),
  ];
  const cam = p.camera?.value ?? [mockObs[0]!, 0];
  const mic = p.mic?.value ?? [Math.abs(mockObs[2]!)];
  const wCam = 1 / Math.max(0.05, camU);
  const wMic = 1 / Math.max(0.05, micU);
  const w = softmax([wCam, wMic]);
  const fused = w[0]! * (cam[0] ?? 0) + w[1]! * (mic[0] ?? 0);
  // Live I/O: no clock oscillators in z. Mock: keep the sine so the loop still has a signal.
  const z = live
    ? [fused, w[0]! * (cam[1] ?? 0), p.brightness, p.rms, p.motion, p.brightness, p.rms, p.motion]
    : [
        fused,
        w[0]! * (cam[1] ?? 0),
        p.brightness,
        p.rms,
        p.motion,
        mockObs[0]!,
        mockObs[1]!,
        0.5 + 0.1 * Math.sin(cycle / 9),
      ];
  const uncertainty = w[0]! * camU + w[1]! * micU;
  return {
    state: z,
    uncertainty,
    cost: 0.04 + 0.03 * uncertainty,
    meta: {
      mock: p.mock,
      camera: Boolean(p.camera),
      mic: Boolean(p.mic),
      still: p.stillFrames,
    },
  };
}
