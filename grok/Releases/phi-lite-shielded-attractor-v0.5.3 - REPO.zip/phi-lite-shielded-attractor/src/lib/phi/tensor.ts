/** Minimal dense tensor for v0.5 — real ops, CPU, f64 accumulation. */
export class Tensor {
  readonly data: Float64Array;
  readonly shape: number[];

  constructor(data: ArrayLike<number>, shape?: number[]) {
    this.data = data instanceof Float64Array ? data : Float64Array.from(data);
    this.shape = shape ?? [this.data.length];
  }

  static zeros(shape: number[]): Tensor {
    const n = shape.reduce((a, b) => a * b, 1);
    return new Tensor(new Float64Array(n), shape);
  }

  static from(rows: number[][]): Tensor {
    const h = rows.length;
    const w = rows[0]?.length ?? 0;
    const t = Tensor.zeros([h, w]);
    let k = 0;
    for (const row of rows) for (const v of row) t.data[k++] = v;
    return t;
  }

  get numel(): number {
    return this.data.length;
  }

  add(other: Tensor | number): Tensor {
    const out = new Float64Array(this.data.length);
    if (typeof other === "number") {
      for (let i = 0; i < out.length; i++) out[i] = this.data[i]! + other;
    } else {
      for (let i = 0; i < out.length; i++) out[i] = this.data[i]! + (other.data[i] ?? 0);
    }
    return new Tensor(out, this.shape);
  }

  mul(other: Tensor | number): Tensor {
    const out = new Float64Array(this.data.length);
    if (typeof other === "number") {
      for (let i = 0; i < out.length; i++) out[i] = this.data[i]! * other;
    } else {
      for (let i = 0; i < out.length; i++) out[i] = this.data[i]! * (other.data[i] ?? 0);
    }
    return new Tensor(out, this.shape);
  }

  mean(): number {
    let s = 0;
    for (const v of this.data) s += v;
    return s / Math.max(1, this.data.length);
  }

  sum(): number {
    let s = 0;
    for (const v of this.data) s += v;
    return s;
  }

  l2(): number {
    let s = 0;
    for (const v of this.data) s += v * v;
    return Math.sqrt(s);
  }
}

export function matmul(a: Tensor, b: Tensor): Tensor {
  const [m, k] = a.shape.length === 1 ? [1, a.shape[0]!] : [a.shape[0]!, a.shape[1]!];
  const n = b.shape.length === 1 ? 1 : b.shape[1]!;
  const out = Tensor.zeros([m, n]);
  for (let i = 0; i < m; i++) {
    for (let j = 0; j < n; j++) {
      let acc = 0;
      for (let t = 0; t < k; t++) acc += (a.data[i * k + t] ?? 0) * (b.data[t * n + j] ?? 0);
      out.data[i * n + j] = acc;
    }
  }
  return out;
}

export function softmax(z: number[], temperature = 1): number[] {
  const t = Math.max(1e-6, temperature);
  const m = Math.max(...z);
  const ex = z.map((v) => Math.exp((v - m) / t));
  const s = ex.reduce((a, b) => a + b, 0);
  return ex.map((v) => v / s);
}

export function kl(p: number[], q: number[]): number {
  let s = 0;
  for (let i = 0; i < p.length; i++) {
    const pi = Math.max(1e-12, p[i] ?? 0);
    const qi = Math.max(1e-12, q[i] ?? 0);
    s += pi * Math.log(pi / qi);
  }
  return s;
}

export function entropy(p: number[]): number {
  let s = 0;
  for (const v of p) if (v > 0) s -= v * Math.log(v);
  return s;
}

export function ece(conf: number[], correct: boolean[], bins = 10): number {
  const n = conf.length;
  if (!n) return 0;
  let acc = 0;
  for (let b = 0; b < bins; b++) {
    const lo = b / bins;
    const hi = (b + 1) / bins;
    let c = 0,
      sConf = 0,
      sAcc = 0;
    for (let i = 0; i < n; i++) {
      const p = conf[i] ?? 0;
      if (p >= lo && (b === bins - 1 ? p <= hi : p < hi)) {
        c++;
        sConf += p;
        sAcc += correct[i] ? 1 : 0;
      }
    }
    if (c) acc += (c / n) * Math.abs(sAcc / c - sConf / c);
  }
  return acc;
}
