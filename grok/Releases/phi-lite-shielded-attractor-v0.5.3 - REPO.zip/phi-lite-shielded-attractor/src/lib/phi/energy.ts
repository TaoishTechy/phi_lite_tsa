/** Homeostasis: Lyapunov, metabolic multiplier, Landauer, collapse (Eq 1–14). */
import { PHI } from "./config";

export type EnergyLedger = {
  energy: number;
  fatigue: number;
  budget: number;
  landauer: number;
  permanentDamage: number;
  collapses: number;
  lastCollapse: number;
  dead: boolean;
  prevLyapunov: number;
};

const E = PHI.energy;

export function createEnergy(budget = E.budget): EnergyLedger {
  const fatigue = 0.08;
  return {
    energy: budget * 0.72,
    fatigue,
    budget,
    landauer: 0,
    permanentDamage: 0,
    collapses: 0,
    lastCollapse: -E.collapseRefractory,
    dead: false,
    prevLyapunov: lyapunov(budget * 0.72, fatigue, budget),
  };
}

export function lyapunov(e: number, f: number, budget: number): number {
  const x = 1 - Math.max(0, Math.min(1, e / Math.max(1, budget)));
  return x * x + f * f;
}

export function metabolicMultiplier(e: EnergyLedger): number {
  const sat = Math.max(0, Math.min(1, e.energy / e.budget));
  return 1 + E.alpha * (1 - sat) + E.beta * e.fatigue;
}

export function homeostaticPotential(
  e: EnergyLedger,
  eStar = E.eStar,
  fStar = E.fStar,
): number {
  const sat = e.energy / Math.max(1, e.budget);
  return ((sat - eStar) ** 2) / (2 * E.sigmaE ** 2) + ((e.fatigue - fStar) ** 2) / (2 * E.sigmaF ** 2);
}

export function landauerCost(bits: number): number {
  return E.landauerKtLn2 * bits;
}

export function tickEnergy(
  e: EnergyLedger,
  actionCost: number,
  reward: number,
  erasedBits: number,
  cycle = 0,
  resting = false,
): EnergyLedger {
  if (e.dead) return e;
  const mu = metabolicMultiplier(e);
  const sat = Math.max(0, Math.min(1, e.energy / e.budget));
  const spend = actionCost * mu + E.basal * mu;
  const heat = landauerCost(erasedBits);
  const income = Math.max(0, reward) * (1 - sat);
  let energy = e.energy - spend + income - heat;
  energy = Math.min(e.budget, Math.max(0, energy));
  // Linear leak so f=1 is not absorbing. REST bleeds extra.
  let fatigue = e.fatigue + E.eta * spend - E.gamma * e.fatigue;
  if (resting) fatigue -= E.restFatigue;
  fatigue = Math.max(0, Math.min(1, fatigue));
  let { collapses, permanentDamage, lastCollapse } = e;
  let dead: boolean = e.dead;
  const V = lyapunov(energy, fatigue, e.budget);
  const refractory = cycle - lastCollapse < E.collapseRefractory;
  if ((energy < E.collapseEnergy || V > E.collapseV) && !refractory) {
    collapses += 1;
    lastCollapse = cycle;
    permanentDamage = Math.min(8, permanentDamage + E.collapseDamage + 0.02 * fatigue);
    energy = Math.max(18, e.budget * 0.5 - permanentDamage * 3);
    energy = Math.min(e.budget, energy);
    fatigue = Math.max(0.12, fatigue * 0.82);
    if (permanentDamage >= 6 || collapses >= 48) dead = true;
  }
  return {
    ...e,
    energy,
    fatigue,
    landauer: e.landauer + heat,
    collapses,
    lastCollapse,
    permanentDamage,
    dead,
    prevLyapunov: V,
  };
}

export function waterFill(variances: number[], budget: number): number[] {
  const n = variances.length;
  if (!n) return [];
  let lo = 0,
    hi = budget + Math.max(...variances);
  for (let i = 0; i < E.waterFillIters; i++) {
    const mid = (lo + hi) / 2;
    let s = 0;
    for (const v of variances) s += Math.max(0, mid - v);
    if (s > budget) hi = mid;
    else lo = mid;
  }
  return variances.map((v) => Math.max(0, lo - v));
}
