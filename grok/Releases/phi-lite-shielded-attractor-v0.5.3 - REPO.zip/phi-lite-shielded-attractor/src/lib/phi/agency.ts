import type { Commitment, CommitmentLevel, Scar } from "./types";
import { COMMITMENT_LEVELS } from "./types";
import type { Generator } from "./rng";

export type Agency = {
  emergence: number;
  debt: number;
  experience: number;
  phaseTransitions: number;
  commitments: Commitment[];
  scars: Scar[];
  commitmentChanges: number;
  criticality: number;
  meta: number;
};

const POOLS: Record<string, string[]> = {
  strategy: ["water-fill", "exploit-core", "repair-first", "listen-heavy"],
  primary_goal: ["stabilize-energy", "reduce-surprise", "hold-shield", "calibrate-ece"],
  world_model: ["rssm-lite", "kalman-gate", "causal-toy"],
  endogamy: ["open", "bounded", "sealed"],
};

export function createAgency(g: Generator): Agency {
  const commitments: Commitment[] = Object.keys(POOLS).map((key) => ({
    key,
    value: g.choice(POOLS[key]!),
    level: key === "strategy" || key === "world_model" ? "FIXED" : "VOLATILE",
    age: 0,
    changes: 0,
  }));
  return {
    emergence: 0.42,
    debt: 0.02,
    experience: 0,
    phaseTransitions: 0,
    commitments,
    scars: [],
    commitmentChanges: 0,
    criticality: 0.38,
    meta: 0.2,
  };
}

export function stepAgency(
  a: Agency,
  predErr: number,
  novelty: number,
  collapsed: boolean,
  cycle: number,
  g: Generator,
  acted = true,
): Agency {
  const experience = a.experience + (acted ? 1 : 0);
  const complexity = Math.log1p(experience) + 1.4 * novelty - 0.8 * predErr;
  const raw = 1 / (1 + Math.exp(-(0.45 * complexity - 2.4)));
  const emergence = Math.max(0.05, Math.min(1, 0.94 * a.emergence + 0.06 * raw));
  let debt = a.debt;
  if (emergence > 0.4) debt *= 0.95;
  else debt += 0.0008 * predErr + 0.0012 * novelty;
  debt = Math.max(0, Math.min(3, debt));
  let phaseTransitions = a.phaseTransitions;
  if (Math.abs(emergence - a.emergence) > 0.08) phaseTransitions += 1;
  const commitments = a.commitments.map((c) => {
    let { value, level, age, changes } = c;
    age += 1;
    if (age > 40 && level !== "FIXED") {
      const i = Math.min(COMMITMENT_LEVELS.length - 1, COMMITMENT_LEVELS.indexOf(level) + 1);
      level = COMMITMENT_LEVELS[i] as CommitmentLevel;
    }
    return { ...c, value, level, age, changes };
  });
  let commitmentChanges = a.commitmentChanges;
  if (g.next() < 0.04 && novelty > 0.9) {
    const idx = Math.floor(g.next() * commitments.length);
    const c = commitments[idx]!;
    if (c.level !== "FIXED" && c.level !== "CRYSTALLIZED") {
      const pool = POOLS[c.key]!;
      const next = g.choice(pool.filter((v) => v !== c.value).concat(pool));
      if (next !== c.value) {
        commitments[idx] = { ...c, value: next, age: 0, changes: c.changes + 1 };
        commitmentChanges += 1;
        debt += 0.02;
      }
    }
  }
  const scars = a.scars
    .map((s) => ({ ...s, strength: Math.max(0, s.strength * (s.origin === "collapse" ? 0.997 : 0.999)) }))
    .filter((s) => s.strength > 0.02);
  if (collapsed) {
    scars.push({
      id: `scar-${cycle}`,
      origin: "collapse",
      subsystem: g.choice(["perception", "memory", "executive", "adaptation"]),
      strength: 0.55,
      born: cycle,
    });
  }
  if (novelty > 2.2 && g.next() < 0.08) {
    scars.push({
      id: `stag-${cycle}`,
      origin: "stagnation",
      subsystem: "adaptation",
      strength: 0.3,
      born: cycle,
    });
  }
  const criticality = Math.max(0.05, Math.min(0.95, a.criticality + 0.02 * (predErr - 0.45) + (g.next() - 0.5) * 0.01));
  const meta = Math.max(0, Math.min(1, a.meta + 0.01 * (Math.abs(predErr - 0.4) - 0.1)));
  return {
    emergence,
    debt,
    experience,
    phaseTransitions,
    commitments,
    scars,
    commitmentChanges,
    criticality,
    meta,
  };
}
