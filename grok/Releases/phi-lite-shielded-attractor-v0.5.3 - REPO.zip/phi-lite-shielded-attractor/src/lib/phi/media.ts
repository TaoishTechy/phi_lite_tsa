/** Persistent camera/mic bus — survives view changes. */

type Listener = () => void;

let camera: MediaStream | null = null;
let mic: MediaStream | null = null;
let audio: AudioContext | null = null;
let analyser: AnalyserNode | null = null;
let rafCam = 0;
let rafMic = 0;
const listeners = new Set<Listener>();

function emit() {
  for (const l of listeners) l();
}

export function subscribeMedia(fn: Listener): () => void {
  listeners.add(fn);
  return () => listeners.delete(fn);
}

export function cameraStream(): MediaStream | null {
  return camera;
}

export function micLive(): boolean {
  return Boolean(mic);
}

export function attachVideo(el: HTMLVideoElement | null): void {
  if (!el) return;
  el.srcObject = camera;
  if (camera) void el.play().catch(() => undefined);
}

export async function bindCamera(): Promise<void> {
  if (camera) return;
  const stream = await navigator.mediaDevices.getUserMedia({
    video: { width: 320, height: 240, facingMode: "user" },
    audio: false,
  });
  camera = stream;
  emit();
}

export async function bindMic(): Promise<void> {
  if (mic && audio) return;
  const stream = await navigator.mediaDevices.getUserMedia({ audio: true, video: false });
  mic = stream;
  const ctx = new AudioContext();
  audio = ctx;
  const src = ctx.createMediaStreamSource(stream);
  const an = ctx.createAnalyser();
  an.fftSize = 512;
  src.connect(an);
  analyser = an;
  emit();
}

export function releaseMedia(): void {
  camera?.getTracks().forEach((t) => t.stop());
  mic?.getTracks().forEach((t) => t.stop());
  void audio?.close();
  camera = null;
  mic = null;
  audio = null;
  analyser = null;
  emit();
}

export function sampleCamera(canvas: HTMLCanvasElement, video: HTMLVideoElement): Uint8ClampedArray | null {
  if (!camera || video.readyState < 2) return null;
  const ctx = canvas.getContext("2d", { willReadFrequently: true });
  if (!ctx) return null;
  ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
  return ctx.getImageData(0, 0, canvas.width, canvas.height).data;
}

export function sampleMicRms(): number | null {
  if (!analyser) return null;
  const buf = new Float32Array(analyser.fftSize);
  analyser.getFloatTimeDomainData(buf);
  let s = 0;
  for (const x of buf) s += x * x;
  return Math.min(1, Math.sqrt(s / buf.length) * 8);
}

export function startMediaLoops(
  video: HTMLVideoElement,
  canvas: HTMLCanvasElement,
  onCam: (px: Uint8ClampedArray) => void,
  onMic: (rms: number) => void,
): () => void {
  const camLoop = () => {
    const px = sampleCamera(canvas, video);
    if (px) onCam(px);
    rafCam = requestAnimationFrame(camLoop);
  };
  const micLoop = () => {
    const rms = sampleMicRms();
    if (rms != null) onMic(rms);
    rafMic = requestAnimationFrame(micLoop);
  };
  rafCam = requestAnimationFrame(camLoop);
  rafMic = requestAnimationFrame(micLoop);
  return () => {
    cancelAnimationFrame(rafCam);
    cancelAnimationFrame(rafMic);
  };
}
