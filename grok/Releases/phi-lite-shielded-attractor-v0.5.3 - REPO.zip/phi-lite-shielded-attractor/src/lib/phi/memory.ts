import { hash32 } from "./rng";
import { PHI } from "./config";

export type MemoryBank = {
  ledger: number[][];
  crystal: number[][];
  narratives: string[];
  hashHead: string;
  novelty: number;
  mu: number[];
  var: number[];
};

const DIM = PHI.dim;
const LEDGER = PHI.memory.ledger;
const CRYSTAL = PHI.memory.crystal;

export function createMemory(): MemoryBank {
  return {
    ledger: [],
    crystal: [],
    narratives: [],
    hashHead: "genesis",
    novelty: 0.4,
    mu: new Array(DIM).fill(0),
    var: new Array(DIM).fill(1),
  };
}

function rff(x: number[]): number[] {
  const out: number[] = [];
  for (let i = 0; i < 4; i++) {
    const w = (i + 1) * 1.618;
    const d = x.reduce((s, v, j) => s + v * Math.cos((j + 1) * w), 0);
    out.push(Math.cos(d), Math.sin(d));
  }
  return out;
}

export function remember(m: MemoryBank, z: number[], cycle: number, utterance: string): MemoryBank {
  const mu = m.mu.map((u, i) => 0.98 * u + 0.02 * (z[i] ?? 0));
  const vr = m.var.map((v, i) => 0.98 * v + 0.02 * ((z[i] ?? 0) - mu[i]!) ** 2);
  let d2 = 0;
  for (let i = 0; i < DIM; i++) d2 += ((z[i] ?? 0) - mu[i]!) ** 2 / Math.max(1e-4, vr[i]!);
  const novelty = Math.sqrt(d2);
  const ledger = m.ledger.concat([z.slice(0, DIM)]);
  if (ledger.length > LEDGER) ledger.shift();
  const slot = rff(z);
  const crystal = m.crystal.concat([slot]);
  if (crystal.length > CRYSTAL) crystal.shift();
  const narratives = m.narratives.concat([utterance]);
  if (narratives.length > PHI.memory.narratives) narratives.shift();
  const hashHead = (hash32(`${m.hashHead}|${utterance}|${cycle}`) >>> 0).toString(16);
  return { ledger, crystal, narratives, hashHead, novelty, mu, var: vr };
}

export function hopfieldRecall(m: MemoryBank, query: number[]): number[] {
  if (!m.crystal.length) return query.slice();
  const q = rff(query);
  let best = m.crystal[0]!;
  let bestD = Infinity;
  for (const z of m.crystal) {
    let d = 0;
    for (let i = 0; i < z.length; i++) d += (z[i]! - (q[i] ?? 0)) ** 2;
    if (d > 1e-6 && d < bestD) {
      bestD = d;
      best = z;
    }
  }
  return best;
}

export function levenshtein(a: string, b: string): number {
  const m = a.length;
  const n = b.length;
  const dp = Array.from({ length: m + 1 }, (_, i) => {
    const row = new Array<number>(n + 1).fill(0);
    row[0] = i;
    return row;
  });
  for (let j = 0; j <= n; j++) dp[0]![j] = j;
  for (let i = 1; i < m + 1; i++) {
    for (let j = 1; j < n + 1; j++) {
      const c = a[i - 1] === b[j - 1] ? 0 : 1;
      dp[i]![j] = Math.min(dp[i - 1]![j]! + 1, dp[i]![j - 1]! + 1, dp[i - 1]![j - 1]! + c);
    }
  }
  return dp[m]![n]!;
}

/** Action-token collapse in [0,1]. Ignores telemetry numbers in the utterance. */
export function templateLock(narratives: string[]): number {
  if (narratives.length < 24) return 0;
  const actions = narratives.slice(-40).map((u) => (u.split(/\s+/)[0] ?? "").toLowerCase());
  const n = actions.length;
  const freq = new Map<string, number>();
  for (const a of actions) freq.set(a, (freq.get(a) ?? 0) + 1);
  let max = 0;
  for (const v of freq.values()) if (v > max) max = v;
  return max / n;
}
