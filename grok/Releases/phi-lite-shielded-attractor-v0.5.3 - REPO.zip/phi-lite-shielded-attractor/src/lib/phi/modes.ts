import type { SystemMode } from "./types";

export type ModeState = {
  mode: SystemMode;
  coherence: number;
  dwell: number;
};

const LADDER: SystemMode[] = ["EXPLORE", "EXPLOIT", "CONSOLIDATE", "REFLECT", "PRESENT_LOCKED"];

export function createModes(): ModeState {
  return { mode: "CONSOLIDATE", coherence: 0.62, dwell: 6 };
}

export function stepMode(m: ModeState, novelty: number, energySat: number, rng: () => number): ModeState {
  let coherence = m.coherence + (rng() - 0.48) * 0.04 - 0.03 * novelty + 0.02 * energySat;
  coherence = Math.max(0.05, Math.min(0.98, coherence));
  let dwell = m.dwell + 1;
  let mode = m.mode;
  const band = 0.05;
  if (dwell >= 5) {
    let next: SystemMode = mode;
    if (coherence > 0.8 + band) next = "EXPLOIT";
    else if (coherence > 0.5) next = "CONSOLIDATE";
    else if (coherence > 0.3) next = "EXPLORE";
    else next = "PRESENT_LOCKED";
    if (energySat < 0.18) next = "REFLECT";
    if (novelty > 1.8 && energySat > 0.4) next = "EXPLORE";
    if (next !== mode) {
      mode = next;
      dwell = 0;
    }
  }
  if (rng() < 0.004) {
    const ext: SystemMode[] = ["ENCAPSULATED", "PROPHETIC", "SUPERSOLID", "TIME_CRYSTAL"];
    mode = ext[Math.floor(rng() * ext.length)]!;
    dwell = 0;
  }
  return { mode, coherence, dwell };
}

export function modeCost(mode: SystemMode): number {
  switch (mode) {
    case "EXPLORE":
      return 1.25;
    case "PRESENT_LOCKED":
      return 0.7;
    case "REFLECT":
      return 0.85;
    case "ENCAPSULATED":
      return 0.6;
    default:
      return 1;
  }
}

export function modePlasticity(mode: SystemMode): number {
  if (mode === "EXPLORE" || mode === "PROPHETIC") return 1.35;
  if (mode === "PRESENT_LOCKED" || mode === "TIME_CRYSTAL") return 0.45;
  return 1;
}

export { LADDER };
