import { PHI } from "./config";
import { templateLock } from "./memory";
import { killCriteria, stageEstimate, type CoreState } from "./loop";
import { ACTIONS } from "./types";

function stats(xs: number[]) {
  if (!xs.length) return { n: 0, mean: 0, std: 0, min: 0, max: 0, last: 0 };
  let s = 0,
    s2 = 0,
    lo = xs[0]!,
    hi = xs[0]!;
  for (const x of xs) {
    s += x;
    s2 += x * x;
    if (x < lo) lo = x;
    if (x > hi) hi = x;
  }
  const n = xs.length;
  const mean = s / n;
  const std = Math.sqrt(Math.max(0, s2 / n - mean * mean));
  return { n, mean, std, min: lo, max: hi, last: xs[n - 1]! };
}

export function buildReport(core: CoreState) {
  const h = core.history;
  const raw = Object.fromEntries(ACTIONS.map((a) => [a, core.counts[a] ?? 0]));
  const taken = Object.fromEntries(ACTIONS.map((a) => [a, Math.max(0, (core.counts[a] ?? 1) - 1)]));
  const stage = stageEstimate(core);
  const barrierNow = (() => {
    const sat = core.energy.energy / Math.max(1, core.energy.budget);
    return sat - 0.08 - 0.35 * core.energy.fatigue;
  })();
  return {
    schema: "phi-lite.report.v2",
    generatedAt: new Date().toISOString(),
    version: PHI.version,
    seed: core.seed,
    cycle: core.cycle,
    cycleCap: core.cycleCap,
    stage,
    halt: core.safety.haltReason,
    eceWarn: core.safety.eceWarn,
    killCriteria: killCriteria(core),
    alive: !core.energy.dead && !core.safety.kill,
    barrier: { h: barrierNow, panicLatched: core.safety.panic },
    perception: {
      mock: core.perception.mock,
      camera: Boolean(core.perception.camera),
      mic: Boolean(core.perception.mic),
      brightness: core.perception.brightness,
      motion: core.perception.motion,
      rms: core.perception.rms,
      stillFrames: core.perception.stillFrames,
      provenance: {
        camera: core.perception.camera?.provenance ?? null,
        mic: core.perception.mic?.provenance ?? null,
      },
    },
    energy: { ...core.energy },
    agency: {
      emergence: core.agency.emergence,
      debt: core.agency.debt,
      experience: core.agency.experience,
      phaseTransitions: core.agency.phaseTransitions,
      criticality: core.agency.criticality,
      meta: core.agency.meta,
      scars: core.agency.scars,
      commitments: core.agency.commitments,
    },
    calibration: { ece: core.ece, predErr: core.predErr, lastAction: core.lastAction, mode: core.modes.mode },
    memory: {
      hashHead: core.memory.hashHead,
      novelty: core.memory.novelty,
      ledger: core.memory.ledger.length,
      crystal: core.memory.crystal.length,
      actionCollapse: templateLock(core.memory.narratives),
      narratives: core.memory.narratives.slice(-24),
    },
    goals: core.goals,
    actions: taken,
    actionCountsRaw: raw,
    series: {
      energy: stats(h.map((x) => x.energy)),
      fatigue: stats(h.map((x) => x.fatigue)),
      ece: stats(h.map((x) => x.ece)),
      predErr: stats(h.map((x) => x.predErr)),
      emergence: stats(h.map((x) => x.emergence)),
      entropy: stats(h.map((x) => x.entropy)),
      novelty: stats(h.map((x) => x.novelty)),
      uncertainty: stats(h.map((x) => x.uncertainty)),
    },
    history: h,
    events: core.logs,
    config: PHI,
  };
}

export type PhiReport = ReturnType<typeof buildReport>;

function fmt(s: { mean: number; std: number; min: number; max: number; last: number; n: number }) {
  return `n=${s.n}  mean=${s.mean.toFixed(4)}  std=${s.std.toFixed(4)}  min=${s.min.toFixed(4)}  max=${s.max.toFixed(4)}  last=${s.last.toFixed(4)}`;
}

export function reportToMarkdown(r: PhiReport): string {
  const lines: string[] = [
    `# Φ-Lite run report`,
    ``,
    `- schema: \`${r.schema}\``,
    `- version: ${r.version}`,
    `- generated: ${r.generatedAt}`,
    `- seed: ${r.seed}`,
    `- cycle: ${r.cycle} / cap ${r.cycleCap}`,
    `- stage: **${r.stage.stage}** — ${r.stage.detail}`,
    `- halt: ${r.halt ?? "none"}`,
    `- ECE warn: ${r.eceWarn}`,
    `- alive: ${r.alive}`,
    `- sensors: mock=${r.perception.mock} camera=${r.perception.camera} mic=${r.perception.mic}`,
    ``,
    `## Kill / warn criteria`,
    ``,
  ];
  if (r.killCriteria.length) for (const k of r.killCriteria) lines.push(`- ${k}`);
  else lines.push(`- none fired`);
  lines.push(``, `## Series`, ``);
  for (const [k, v] of Object.entries(r.series)) lines.push(`- **${k}**: ${fmt(v)}`);
  lines.push(``, `## Actions`, ``);
  for (const [k, v] of Object.entries(r.actions)) lines.push(`- ${k}: ${v}`);
  lines.push(``, `## Energy`, ``);
  lines.push("```json", JSON.stringify(r.energy, null, 2), "```");
  lines.push(``, `## Agency`, ``);
  lines.push("```json", JSON.stringify(r.agency, null, 2), "```");
  lines.push(``, `## Goals`, ``);
  for (const g of r.goals) lines.push(`- (${g.origin}, t=${g.persistence}) ${g.text}`);
  lines.push(``, `## Event log`, ``);
  for (const e of r.events) lines.push(`- ${e}`);
  lines.push(``, `## Trajectory (last ${Math.min(40, r.history.length)} cycles)`, ``);
  lines.push(`| cycle | energy | ece | predErr | action | mode | novelty |`);
  lines.push(`|---:|---:|---:|---:|---|---|---:|`);
  for (const row of r.history.slice(-40)) {
    lines.push(
      `| ${row.cycle} | ${row.energy.toFixed(3)} | ${row.ece.toFixed(3)} | ${row.predErr.toFixed(3)} | ${row.action} | ${row.mode} | ${row.novelty.toFixed(3)} |`,
    );
  }
  lines.push(``, `## Honesty`, ``);
  lines.push(`S2.9 heritage runner. Not AGI. Transfer and 10^6-cycle V&V not claimed.`);
  lines.push("");
  return lines.join("\n");
}

export function downloadText(filename: string, body: string, mime: string): void {
  const blob = new Blob([body], { type: mime });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}
