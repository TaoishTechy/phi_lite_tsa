#!/bin/sh
# Portable: sandbox revive AND a local unzip. Never hardcode a host path.
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
cd "$ROOT"

if ! command -v node >/dev/null 2>&1; then
  echo "Phi-Lite: Node.js not found. Install 20.19+ or 22.12+ from https://nodejs.org" >&2
  exit 1
fi

node scripts/check-node.cjs --print >/dev/null

if [ ! -d "$ROOT/node_modules/vite" ]; then
  echo "Phi-Lite: dependencies missing. From this folder run:  npm install" >&2
  exit 1
fi

# QA preview on :8081 is sandbox-only; ignore failures on a laptop.
node scripts/preview.mjs stop >/dev/null 2>&1 || true

if command -v curl >/dev/null 2>&1; then
  if curl -sf -o /dev/null --max-time 2 http://127.0.0.1:8080/; then
    exit 0
  fi
fi

mkdir -p "$ROOT/.grok"
if [ -w /tmp ]; then
  LOG=/tmp/app-startup.log
else
  LOG="$ROOT/.grok/startup.log"
fi
npm run dev >>"$LOG" 2>&1 &
