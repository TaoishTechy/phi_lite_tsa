#!/usr/bin/env node
"use strict";

/**
 * Gate Node version before any ESM that uses ?? / import.meta.
 * Must parse on Node 12 so a bad runtime prints this instead of SyntaxError.
 */
function nodeOk() {
  var parts = String(process.versions.node).split(".");
  var major = parseInt(parts[0], 10);
  var minor = parseInt(parts[1], 10);
  if (major > 22) return true;
  if (major === 22 && minor >= 12) return true;
  if (major === 20 && minor >= 19) return true;
  return false;
}

if (!nodeOk()) {
  console.error("Phi-Lite: The Shielded Attractor needs Node.js 20.19+ or 22.12+.");
  console.error("This machine has v" + process.version + ".");
  console.error("");
  console.error("Install a current Node, then retry:");
  console.error("  https://nodejs.org");
  console.error("  nvm install 22 && nvm use 22");
  process.exit(1);
}

if (process.argv[2] === "--print") {
  console.log("node " + process.version);
}
